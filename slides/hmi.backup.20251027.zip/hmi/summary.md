# HCI/HMI 강의

## 🎯 과목 개요
반도체 장비를 위한 Human-Computer Interaction(HCI)과 Human-Machine Interface(HMI) 설계 및 구현 능력을 습득하는 강의입니다.

## 📚 주요 내용
- **C# WPF**: Windows 기반 HMI 개발
- **Python PySide6**: 크로스 플랫폼 HMI 개발
- **ImGui C++**: 실시간 반도체 HMI 개발

## 🔧 기술 스택
C#, WPF, MVVM, Python, PySide6, Qt, C++, ImGui, OpenGL

## 👥 대상
반도체 장비 소프트웨어 개발자, HMI 설계자, 산업용 UI/UX 엔지니어
