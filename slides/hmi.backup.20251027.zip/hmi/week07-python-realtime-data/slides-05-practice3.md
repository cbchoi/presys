# 실습 3: 통합 실시간 모니터링 시스템

## 배경: 왜 통합 시스템이 필요한가?

**문제 상황**:
반도체 HMI는 단순히 데이터를 표시하는 것을 넘어서, 데이터 수집/저장/시각화/통신을 통합적으로 관리해야 합니다. 예를 들어 CMP 장비는 연마 압력, 회전 속도, 슬러리 유량 등을 동시에 모니터링하면서 DB에 저장하고, 이상 발생 시 원격 서버에 알람을 전송해야 합니다.

**해결책**:
멀티스레드 기반 아키텍처로 각 기능을 독립적인 스레드에서 처리하고, Signal/Slot으로 안전하게 통신하여 24시간 무중단 운영이 가능한 시스템을 구현합니다.

## 핵심 개념

**통합 시스템의 4대 구성요소**:
1. **데이터 수집 스레드 (DataCollector)**: QTimer 기반 주기적 센서 데이터 수집
2. **데이터베이스 스레드 (DatabaseManager)**: SQLite 비동기 저장 처리
3. **통신 스레드 (EquipmentCommunicator)**: Serial/TCP 프로토콜 처리
4. **UI 스레드 (MainWindow)**: 사용자 입력 및 차트 업데이트

**스레드 간 통신 구조**:
- **Signal/Slot**: 스레드 안전한 데이터 전달
- **moveToThread()**: 객체를 워커 스레드로 이동
- **QMetaObject::invokeMethod**: 크로스 스레드 메서드 호출

## 실제 적용 사례

**CVD 장비 종합 모니터링 시스템**:
- **데이터 수집**: 10개 센서 × 4개 챔버 = 40개/초
- **DB 저장**: 배치 1000개씩 SQLite INSERT (초당 40개 누적, 25초마다 저장)
- **차트 업데이트**: 100ms 간격으로 3개 차트 동시 업데이트
- **통신**: Serial 포트로 PLC와 5초마다 Heartbeat 교환

---
# 실습 3: 통합 실시간 모니터링 시스템
**성능 요구사항**:
- 데이터 처리율: >1000 msg/s
- DB INSERT: >500 rows/s
- UI 응답시간: <100ms
- 메모리 사용: <200MB (24시간 운영)
---
# 실습 3: 통합 실시간 모니터링 시스템
## Week 1 HCI 이론 적용

**Miller's Law (작업기억 한계 7±2)**:
통합 시스템의 상태 패널에는 최대 5가지 핵심 지표만 표시합니다:
1. 연결 상태 (연결됨/끊김)
2. 수집 상태 (실행 중/중지됨)
3. 데이터 포인트 수 (123,456개)
4. DB 쓰기 횟수 (45,678회)
5. 차트 업데이트 횟수 (12,345회)

**정보처리 모델 (250ms 응답)**:
- 시작 버튼 클릭 → 100ms 이내 상태 변경 피드백
- 데이터 수집 시작 → 200ms 이내 첫 차트 업데이트

## 시스템 아키텍처 다이어그램

```mermaid
flowchart TD
    A[메인 윈도우<br/>UI Thread] -->|moveToThread| B[데이터 수집 스레드]
    A -->|moveToThread| C[DB 저장 스레드]
    A -->|moveToThread| D[통신 스레드]

    B -->|data_collected Signal| E[차트 위젯]
    B -->|data_collected Signal| C
    C -->|data_saved Signal| A
    D -->|data_received Signal| B

    E -->|렌더링| F[PyQtGraph<br/>GPU 가속]
    C -->|저장| G[(SQLite DB)]
    D -->|Serial/TCP| H[장비/PLC]

---
# 실습 3: 통합 실시간 모니터링 시스템
    style A fill:#e1f5ff
    style B fill:#fff4e1
    style C fill:#ffe1e1
    style D fill:#e1ffe1
    style F fill:#f0e1ff
```

## 주요 코드 해설

**1. 멀티스레드 설정 (안전한 객체 이동)**:
```python
self.data_collector = EnhancedDataCollector()
self.collector_thread = QThread()
self.data_collector.moveToThread(self.collector_thread)  # 워커 스레드로 이동
self.collector_thread.start()  # 스레드 시작
```
- **핵심**: moveToThread()로 객체를 UI 스레드에서 분리 → UI 블로킹 방지
- **실무 적용**: 데이터 수집이 3초 걸려도 UI는 계속 응답

**2. Signal/Slot 크로스 스레드 통신**:
```python
self.data_collector.data_collected.connect(self.handle_new_data)  # 자동으로 큐잉됨
```
- **핵심**: Qt의 이벤트 루프가 자동으로 스레드 간 동기화 처리
- **실무 적용**: 락(Lock) 없이도 안전한 데이터 공유

---
# 실습 3: 통합 실시간 모니터링 시스템
**3. 성능 모니터링 (통계 수집)**:
```python
self.performance_stats['data_points_collected'] += 1
runtime = (datetime.now() - stats['start_time']).total_seconds()
data_rate = stats['data_points_collected'] / runtime  # 초당 처리량
```
- **핵심**: 실시간으로 시스템 성능 추적 → 병목 지점 발견
- **실무 적용**: 목표 1000 msg/s에 미달 시 경고
---

# 실습 코드: 통합 모니터링 애플리케이션

```python
# -*- coding: utf-8 -*- (1/2) (1/2) (1/2) (1/2) (1/2)

import sys
import time
import math
import random
from datetime import datetime
from PySide6.QtWidgets import (QApplication, QMainWindow, QVBoxLayout,
QHBoxLayout, QWidget, QPushButton, QLabel,
QTabWidget, QTextEdit, QGroupBox, QGridLayout,
QSpinBox, QComboBox, QCheckBox, QSplitter,
QMenuBar, QStatusBar, QProgressBar)
from PySide6.QtCore import QObject, QThread, Signal, Slot, QTimer, Qt
from PySide6.QtGui import QFont, QAction, QIcon

# 사전 구현된 컴포넌트 import
from database_manager import DatabaseManager
from multi_channel_chart import MultiChannelRealtimeChart
from equipment_communicator import EquipmentCommunicator
---
# -*- coding: utf-8 -*- (1/2) (1/2) (1/2) (1/2) (2/2)

class IntegratedEquipmentMonitor(QMainWindow):
""" """

def __init__(self):
super().__init__()
self.setup_ui()
self.setup_components()
self.setup_connections()

# self.performance_stats = {
'data_points_collected': 0,
'database_writes': 0,
'chart_updates': 0,
'start_time': datetime.now()
}
---
# -*- coding: utf-8 -*- (1/2) (1/2) (1/2) (2/2) (1/2)

def setup_ui(self):
"""UI """
self.setWindowTitle(" v2.0")
self.setGeometry(100, 100, 1400, 900)

# self.setup_menubar()

# central_widget = QWidget()
self.setCentralWidget(central_widget)

# main_splitter = QSplitter(Qt.Horizontal)
central_widget_layout = QVBoxLayout(central_widget)
central_widget_layout.addWidget(main_splitter)

# ( )
left_panel = self.create_left_panel()
main_splitter.addWidget(left_panel)
---
# -*- coding: utf-8 -*- (1/2) (1/2) (1/2) (2/2) (2/2)

# ( )
right_panel = self.create_right_panel()
main_splitter.addWidget(right_panel)

# main_splitter.setStretchFactor(0, 1)
main_splitter.setStretchFactor(1, 3)

# self.setup_statusbar()

def setup_menubar(self):
""" """
menubar = self.menuBar()

# file_menu = menubar.addMenu('')
---
# -*- coding: utf-8 -*- (1/2) (1/2) (2/2) (1/2) (1/2)

export_action = QAction(' ', self)
export_action.triggered.connect(self.export_data)
file_menu.addAction(export_action)

file_menu.addSeparator()

exit_action = QAction('', self)
exit_action.triggered.connect(self.close)
file_menu.addAction(exit_action)

# tools_menu = menubar.addMenu('')

db_stats_action = QAction(' ', self)
db_stats_action.triggered.connect(self.show_database_stats)
tools_menu.addAction(db_stats_action)

clear_data_action = QAction(' ', self)
clear_data_action.triggered.connect(self.clear_chart_data)
tools_menu.addAction(clear_data_action)
---
# -*- coding: utf-8 -*- (1/2) (1/2) (2/2) (1/2) (2/2)

def create_left_panel(self):
""" """
widget = QWidget()
layout = QVBoxLayout(widget)

# collection_group = QGroupBox(" ")
collection_layout = QVBoxLayout(collection_group)

# button_layout = QHBoxLayout()
self.start_button = QPushButton(" ")
self.stop_button = QPushButton(" ")
self.stop_button.setEnabled(False)
---
# -*- coding: utf-8 -*- (1/2) (1/2) (2/2) (2/2) (1/2)

self.start_button.clicked.connect(self.start_monitoring)
self.stop_button.clicked.connect(self.stop_monitoring)

button_layout.addWidget(self.start_button)
button_layout.addWidget(self.stop_button)
collection_layout.addLayout(button_layout)

# settings_layout = QGridLayout()

settings_layout.addWidget(QLabel(" (ms):"), 0, 0)
self.interval_spinbox = QSpinBox()
self.interval_spinbox.setRange(10, 10000)
self.interval_spinbox.setValue(100)
settings_layout.addWidget(self.interval_spinbox, 0, 1)
---
# -*- coding: utf-8 -*- (1/2) (1/2) (2/2) (2/2) (2/2)

settings_layout.addWidget(QLabel(":"), 1, 0)
self.db_save_checkbox = QCheckBox()
self.db_save_checkbox.setChecked(True)
settings_layout.addWidget(self.db_save_checkbox, 1, 1)

collection_layout.addLayout(settings_layout)
layout.addWidget(collection_group)

# comm_group = QGroupBox(" ")
comm_layout = QVBoxLayout(comm_group)

comm_type_layout = QHBoxLayout()
comm_type_layout.addWidget(QLabel(":"))
self.comm_type_combo = QComboBox()
self.comm_type_combo.addItems(["", "", "TCP/IP"])
comm_type_layout.addWidget(self.comm_type_combo)
comm_layout.addLayout(comm_type_layout)
---
# -*- coding: utf-8 -*- (1/2) (2/2) (1/2) (1/2) (1/2)

self.connect_button = QPushButton("")
self.connect_button.clicked.connect(self.toggle_connection)
comm_layout.addWidget(self.connect_button)

layout.addWidget(comm_group)

# status_group = QGroupBox(" ")
status_layout = QVBoxLayout(status_group)

self.status_labels = {}
status_items = [
(' ', 'connection'),
(' ', 'collection'),
(' ', 'data_points'),
('DB ', 'db_writes'),
(' ', 'chart_updates')
]
---
# -*- coding: utf-8 -*- (1/2) (2/2) (1/2) (1/2) (2/2)

for label_text, key in status_items:
label = QLabel(f"{label_text}: ")
label.setFont(QFont("Arial", 9))
self.status_labels[key] = label
status_layout.addWidget(label)

layout.addWidget(status_group)

# log_group = QGroupBox(" ")
log_layout = QVBoxLayout(log_group)
---
# -*- coding: utf-8 -*- (1/2) (2/2) (1/2) (2/2) (1/2)

self.log_text = QTextEdit()
self.log_text.setMaximumHeight(200)
self.log_text.setFont(QFont("Consolas", 8))
log_layout.addWidget(self.log_text)

clear_log_button = QPushButton(" ")
clear_log_button.clicked.connect(self.log_text.clear)
log_layout.addWidget(clear_log_button)

layout.addWidget(log_group)

layout.addStretch()
return widget

def create_right_panel(self):
""" """
# tab_widget = QTabWidget()
---
# -*- coding: utf-8 -*- (1/2) (2/2) (1/2) (2/2) (2/2)

# self.chart_widget = MultiChannelRealtimeChart()
tab_widget.addTab(self.chart_widget, " ")

# ( )
data_tab = QWidget()
data_layout = QVBoxLayout(data_tab)
data_layout.addWidget(QLabel(" ( )"))
tab_widget.addTab(data_tab, " ")

# ( )
stats_tab = QWidget()
stats_layout = QVBoxLayout(stats_tab)
stats_layout.addWidget(QLabel(" ( )"))
tab_widget.addTab(stats_tab, "")

return tab_widget
---
# -*- coding: utf-8 -*- (1/2) (2/2) (2/2) (1/2) (1/2)

def setup_statusbar(self):
""" """
self.statusbar = QStatusBar()
self.setStatusBar(self.statusbar)

# self.progress_bar = QProgressBar()
self.progress_bar.setVisible(False)
self.statusbar.addPermanentWidget(self.progress_bar)

# self.time_label = QLabel()
self.statusbar.addPermanentWidget(self.time_label)

# self.time_timer = QTimer()
self.time_timer.timeout.connect(self.update_time)
self.time_timer.start(1000)
---
# -*- coding: utf-8 -*- (1/2) (2/2) (2/2) (1/2) (2/2)

self.statusbar.showMessage("")

def setup_components(self):
""" """
# self.db_manager = DatabaseManager()

# self.data_collector = EnhancedDataCollector()
self.collector_thread = QThread()
self.data_collector.moveToThread(self.collector_thread)

# self.communicator = EquipmentCommunicator()

# self.performance_timer = QTimer()
self.performance_timer.timeout.connect(self.update_performance_stats)
self.performance_timer.start(5000) # 5
---
# -*- coding: utf-8 -*- (1/2) (2/2) (2/2) (2/2) (1/2)

def setup_connections(self):
"""- """
# self.data_collector.data_collected.connect(self.handle_new_data)
self.data_collector.status_changed.connect(self.update_collection_status)

# self.db_manager.data_saved.connect(self.on_data_saved)
self.db_manager.error_occurred.connect(self.on_db_error)

# self.communicator.connected.connect(self.on_connection_changed)
self.communicator.data_received.connect(self.handle_communication_data)
self.communicator.status_changed.connect(self.log_message)

# self.collector_thread.start()

def start_monitoring(self):
""" """
try:
interval = self.interval_spinbox.value()
---
# -*- coding: utf-8 -*- (1/2) (2/2) (2/2) (2/2) (2/2)

# UI
self.start_button.setEnabled(False)
self.stop_button.setEnabled(True)
self.progress_bar.setVisible(True)

# self.data_collector.set_interval(interval)
self.data_collector.start_collection()

# self.performance_stats = {
'data_points_collected': 0,
'database_writes': 0,
'chart_updates': 0,
'start_time': datetime.now()
}
---
# -*- coding: utf-8 -*- (2/2) (1/2) (1/2) (1/2) (1/2)

self.log_message(" ")
self.statusbar.showMessage("...")

except Exception as e:
self.log_message(f": {str(e)}")

def stop_monitoring(self):
""" """
try:
# UI
self.start_button.setEnabled(True)
self.stop_button.setEnabled(False)
self.progress_bar.setVisible(False)

# self.data_collector.stop_collection()

self.log_message(" ")
self.statusbar.showMessage("")
---
# -*- coding: utf-8 -*- (2/2) (1/2) (1/2) (1/2) (2/2)

except Exception as e:
self.log_message(f": {str(e)}")

@Slot(dict)
def handle_new_data(self, data):
""" """
try:
# self.chart_widget.update_charts(data)
self.performance_stats['chart_updates'] += 1

# if self.db_save_checkbox.isChecked():
self.db_manager.save_equipment_data(data)

# self.performance_stats['data_points_collected'] += 1
---
# -*- coding: utf-8 -*- (2/2) (1/2) (1/2) (2/2) (1/2)

except Exception as e:
self.log_message(f": {str(e)}")

@Slot(bool)
def on_data_saved(self, success):
""" """
if success:
self.performance_stats['database_writes'] += 1

@Slot(str)
def on_db_error(self, error):
""" """
self.log_message(f"DB: {error}")
---
# -*- coding: utf-8 -*- (2/2) (1/2) (1/2) (2/2) (2/2)

def update_performance_stats(self):
""" """
stats = self.performance_stats
runtime = (datetime.now() - stats['start_time']).total_seconds()

if runtime > 0:
data_rate = stats['data_points_collected'] / runtime

self.status_labels['data_points'].setText(
f": {stats['data_points_collected']} ({data_rate:.1f}/)")
self.status_labels['db_writes'].setText(
f"DB: {stats['database_writes']}")
self.status_labels['chart_updates'].setText(
f": {stats['chart_updates']}")
---
# -*- coding: utf-8 -*- (2/2) (1/2) (2/2) (1/2) (1/2)

def update_time(self):
""" """
current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
self.time_label.setText(current_time)

def log_message(self, message):
""" """
timestamp = datetime.now().strftime("%H:%M:%S")
self.log_text.append(f"[{timestamp}] {message}")

# scrollbar = self.log_text.verticalScrollBar()
scrollbar.setValue(scrollbar.maximum())

def toggle_connection(self):
""" """
comm_type = self.comm_type_combo.currentText()
---
# -*- coding: utf-8 -*- (2/2) (1/2) (2/2) (1/2) (2/2)

if comm_type == "":
self.log_message(" ")
self.status_labels['connection'].setText(": ")
elif comm_type == "":
# self.log_message("...")
elif comm_type == "TCP/IP":
# TCP
self.log_message("TCP/IP...")

def on_connection_changed(self, connected):
""" """
status = "" if connected else " "
self.status_labels['connection'].setText(f": {status}")
---
# -*- coding: utf-8 -*- (2/2) (1/2) (2/2) (2/2) (1/2)

def update_collection_status(self, status):
""" """
self.status_labels['collection'].setText(f": {status}")

def handle_communication_data(self, data):
""" """
self.log_message(f": {data}")

def export_data(self):
""" """
self.log_message(" ( )")

def show_database_stats(self):
""" """
stats = self.db_manager.get_statistics()
self.log_message(f"DB: {stats}")
---
# -*- coding: utf-8 -*- (2/2) (1/2) (2/2) (2/2) (2/2)

def clear_chart_data(self):
""" """
self.chart_widget.clear_all_charts()
self.log_message(" ")

def closeEvent(self, event):
""" """
self.stop_monitoring()

# self.collector_thread.quit()
self.collector_thread.wait()
---
# -*- coding: utf-8 -*- (2/2) (2/2) (1/2) (1/2) (1/2)

# self.db_manager.close()

event.accept()

class EnhancedDataCollector(QObject):
""" """

data_collected = Signal(dict)
status_changed = Signal(str)

def __init__(self):
super().__init__()
self.is_collecting = False
self.interval_ms = 100
self.collection_timer = QTimer()
self.collection_timer.timeout.connect(self.collect_data)
self.sequence = 0
---
# -*- coding: utf-8 -*- (2/2) (2/2) (1/2) (1/2) (2/2)

def set_interval(self, interval_ms):
""" """
self.interval_ms = interval_ms
if self.collection_timer.isActive():
self.collection_timer.setInterval(interval_ms)

@Slot()
def start_collection(self):
""" """
self.is_collecting = True
self.sequence = 0
self.collection_timer.start(self.interval_ms)
self.status_changed.emit(" ")
---
# -*- coding: utf-8 -*- (2/2) (2/2) (1/2) (2/2) (1/2)

@Slot()
def stop_collection(self):
""" """
self.is_collecting = False
self.collection_timer.stop()
self.status_changed.emit("")

def collect_data(self):
""" """
if not self.is_collecting:
return

# now = datetime.now()
time_factor = time.time() % 120 # 2
---
# -*- coding: utf-8 -*- (2/2) (2/2) (1/2) (2/2) (2/2)

# base_temp = 350 + 30 * math.sin(time_factor / 20) + 10 * math.sin(time_factor / 5)
temperature = base_temp + random.gauss(0, 2)

base_pressure = 5.0 + 3 * math.cos(time_factor / 15) + math.sin(time_factor / 3)
pressure = max(0.1, base_pressure + random.gauss(0, 0.3))

base_flow = 100 + 50 * math.sin(time_factor / 25)
gas_flow = max(0, base_flow + random.gauss(0, 5))

# RF
step = int(time_factor / 30) % 4
rf_base = [200, 300, 400, 250][step]
rf_power = rf_base + random.gauss(0, 15)
---
# -*- coding: utf-8 -*- (2/2) (2/2) (2/2) (1/2) (1/2)

data = {
'timestamp': now,
'chamber_temperature': round(temperature, 2),
'chamber_pressure': round(pressure, 3),
'gas_flow_rate': round(gas_flow, 1),
'rf_power': round(rf_power, 1),
'recipe_step': step + 1,
'status': 'Running',
'sequence': self.sequence
}

self.sequence += 1
self.data_collected.emit(data)
---
# -*- coding: utf-8 -*- (2/2) (2/2) (2/2) (1/2) (2/2)

# if __name__ == "__main__":
app = QApplication(sys.argv)

# app.setStyle('Fusion')

window = IntegratedEquipmentMonitor()
window.show()

sys.exit(app.exec())
```

</div>

#### **4.3 **

##### ** **

<div class="assignments">

**Phase 1: **
1. ** **:
---
# -*- coding: utf-8 -*- (2/2) (2/2) (2/2) (2/2) (1/2)

2. ** **:
3. ** **: SQLite

**Phase 2: **
1. ** **:
2. ** **: TCP
3. ** **:

**Phase 3: **
1. **UI **:
2. ** **:
3. ** **:

</div>

##### ** **

<div class="evaluation">
---
# -*- coding: utf-8 -*- (2/2) (2/2) (2/2) (2/2) (2/2)

** **:
- ** (40%)**:
- ** (25%)**:
- ** (20%)**:,,
- ** (15%)**: UI/UX,,

** **:
- 1000+ /
- 24
- - UI

</div>

---

## ** **

###:?

** **:
,:
- - - UI/UX

****:
:
- - -
---

###
** **:
QTimer, SQLite, Serial/TCP,,.

** **:
1. QTimer 100ms Serial/TCP
2. SQLite INSERT (Batch )
3. QTableView/QChart

** **:
- QTimer
- QThread Worker
- SQLite

---

###
```mermaid
sequenceDiagram
participant User as
participant UI as UI Thread
participant BG as Background Thread
participant Data as

User->>UI:
UI->>BG:
BG->>Data:
Data-->>BG:
BG->>UI: UI
UI->>User:
```

---

### Week 6

**Week 6 **:
- QWidget
- Signal/Slot
- QThread

**Week 7 **:
- Week 6: PySide6 UI
- Week 7: → HMI

### Week 1 HCI

**Miller's Law ( 7±2)**:
-: Critical/Warning/Info 3
-: 30%, 50%

** (250ms )**:
-: Serial 100ms
-: 40%

---

### (1/2) (1/2)

** **:

1. ** **
- Serial
-: 20
-: SQLite

2. ** **
- SQLite Batch INSERT (1000 rows/s)
-: 30
-: SQLite
---
### (1/2) (2/2)

3. ** **
- QChart (100ms)
-: (msg/s), DB INSERT (rows/s), (ms)
-: >1000 msg/s, INSERT >500 rows/s, <100ms

** **:
- [ ]
- [ ]
- [ ]
---
### (2/2) (1/2)

### ** **
1. **QThread **: UI
2. ** **: SQLite
3. ** **: /
4. ** **: PyQtGraph
5. ** **:

### ** Python vs C# **
| | C# (Task/async) | Python (QThread) |
|------|----------------|------------------|
| ** ** | Task Parallel Library | QThread + QObject |
| **UI ** | Dispatcher.Invoke | - |
| **** | | |
| ** ** | GC | + GC |
| **** | Entity Framework | SQLite3 |
---
### (2/2) (2/2)

### **: Python PySide6 **
- ** UI **: 3D
- ** **:
- **(i18n)**:
- ** **: PyInstaller, cx_Freeze
