
## Python 실시간 처리의 핵심

### 배경: 왜 비동기 처리가 필요한가?

**문제 상황**:
반도체 장비는 초당 수백~수천 개의 데이터를 생성합니다. 만약 이를 동기적으로 처리하면 UI가 멈추고(Freezing), 중요한 알람을 놓칠 수 있습니다. 예를 들어 ETCH 장비에서 플라즈마 압력 데이터를 100ms마다 읽는 동안 UI가 블로킹되면 운영자는 시스템이 멈춘 것으로 오인합니다.

**해결책**:
Python의 비동기 프로그래밍(asyncio, threading)과 PySide6의 QThread를 활용하여 백그라운드에서 데이터를 처리하고, Signal/Slot으로 UI를 안전하게 업데이트합니다.

### 핵심 개념

**비동기 처리의 3가지 방식**:
1. **asyncio (Event Loop 기반)**: I/O 바운드 작업에 최적, 단일 스레드에서 동시성 구현
2. **threading (멀티스레드)**: GIL 제약이 있지만 I/O 대기 시 다른 작업 수행 가능
3. **multiprocessing (멀티프로세스)**: CPU 바운드 작업에 최적, GIL 우회

**실시간 데이터 처리 아키텍처**:
```mermaid
sequenceDiagram
    participant User as 운영자
    participant UI as UI Thread
    participant BG as Background Thread
    participant Data as 데이터베이스

    User->>UI: 모니터링 시작
    UI->>BG: 데이터 수집 시작 Signal
    BG->>Data: 센서 데이터 읽기
    Data-->>BG: 데이터 반환
    BG->>UI: Signal로 UI 업데이트 요청
    UI->>User: 차트 업데이트 표시
```

---

### Week 6 복습 및 연결

**Week 6 핵심 내용**:
- QWidget 기반 UI 구성
- Signal/Slot 메커니즘
- QThread 기본 사용법

**Week 7 진화 과정**:
- Week 6: PySide6 기본 UI 구조 학습
- Week 7: 실시간 대량 데이터 처리 → 실무형 HMI 시스템 구현

### Week 1 HCI 이론 적용

**Miller's Law (작업기억 한계 7±2)**:
- 실무 적용: 알람 레벨을 Critical/Warning/Info 3단계로 제한
- 차트 시각화: 동시 표시 파라미터 30%, 압력 50%로 제한하여 인지 부하 감소

**정보처리 모델 (250ms 응답 시간)**:
- 실무 적용: Serial 통신 응답 100ms 이내 유지
- 차트 업데이트: 최소 60fps(16ms) → 실제 40ms 간격으로 부드러운 애니메이션

---
### 실제 적용 사례: CVD 장비 실시간 모니터링

**CVD 챔버 온도 모니터링 시스템**:
- **데이터 발생률**: 초당 10개 센서 × 4개 챔버 = 40개/초
- **처리 요구사항**: 각 데이터 처리 시간 <5ms, UI 업데이트 100ms
- **저장 요구사항**: SQLite에 배치 단위 1000개씩 저장

**구현 전략**:
1. **데이터 수집 스레드**: Serial 포트에서 40개/초 데이터 읽기
2. **DB 저장 스레드**: 버퍼에 1000개 쌓이면 Batch INSERT
3. **UI 스레드**: 100ms마다 차트 업데이트 (Signal/Slot 사용)

### 동기 vs 비동기 처리 비교

```mermaid
gantt
    title 동기 vs 비동기 데이터 처리 타임라인
    dateFormat SSS
    axisFormat %L ms

    section 동기 처리
    센서1 읽기    :a1, 000, 100ms
    DB 저장1      :a2, after a1, 50ms
    센서2 읽기    :a3, after a2, 100ms
    DB 저장2      :a4, after a3, 50ms
    UI 업데이트   :a5, after a4, 20ms

    section 비동기 처리
    센서1 읽기    :b1, 000, 100ms
    센서2 읽기    :b2, 000, 100ms
    DB 저장 (병렬):b3, 050, 50ms
    UI 업데이트   :b4, 100, 20ms
```

---
### 실제 적용 사례: CVD 장비 실시간 모니터링
**성능 차이**:
- 동기 처리: 320ms 소요 → 초당 3회만 처리 가능
- 비동기 처리: 120ms 소요 → 초당 8회 처리 가능 (2.6배 향상)
---

### 학습 목표 상세 (1/2) (1/2) (1/2)

**학습 목표**:

1. ** **
- Serial
-: 20
-: SQLite

2. ** **
- SQLite Batch INSERT (1000 rows/s)
-: 30
-: SQLite
---
### (1/2) (1/2) (2/2)

3. ** **
- QChart (100ms)
-: (msg/s), DB INSERT (rows/s), (ms)
-: >1000 msg/s, INSERT >500 rows/s, <100ms

** **:
- [ ]
- [ ]
- [ ]

### vs

** **
---
### (1/2) (2/2) (Part 1)

<div class="grid grid-cols-2 gap-8">
<div>

**(Synchronous) **:
```python
import time

def download_sensor_data(sensor_id):
""" ()"""
print(f" {sensor_id} ")
---
### (1/2) (2/2) (Part 2)

time.sleep(1) # I/O
print(f" {sensor_id} ")
return f" {sensor_id} "

# (Blocking)
start = time.time()

data1 = download_sensor_data(1) # 1
data2 = download_sensor_data(2) # 1
data3 = download_sensor_data(3) # 1

print(f": {time.time() - start:.2f}")
#:: 3.00
```
---
### (2/2) (Part 1)


** **:
- - - - I/O CPU

</div>
<div>

**(Asynchronous) **:
---
### (2/2) (Part 1)

```python
import asyncio

async def download_sensor_data(sensor_id):
""" ()"""
print(f" {sensor_id} ")
await asyncio.sleep(1) # Non-blocking I/O
print(f" {sensor_id} ")
return f" {sensor_id} "

# (Non-blocking)
async def main():
start = time.time()
```
---
### (2/2) (Part 2)

```python

# 3
results = await asyncio.gather(
download_sensor_data(1),
download_sensor_data(2),
download_sensor_data(3)
)

print(f": {time.time() - start:.2f}")
#:: 1.00

asyncio.run(main())
```
---
### (2/2) (Part 2)

** **:
- I/O
- ( )
- I/O
-
</div>
</div>

---
### Python (Event Loop) (Part 1)



**asyncio **

<div class="grid grid-cols-2 gap-8">
<div>

```python
import asyncio

# """

Event Loop

1. Check ready tasks
2. Execute ready task
3. Check I/O events
4. Schedule waiting tasks
5. Repeat
```
---
### Python (Event Loop) (Part 2)

```python

"""

async def sensor_read():
""" (I/O )"""
print(" ")
await asyncio.sleep(0.5) # I/O
print(" ")
return 25.5

async def data_process():
""" (CPU )"""
```
---
### Python (Event Loop) (Part 3)

```python
print(" ")
# CPU blocking!
result = sum(range(1000000))
print(" ")
return result

async def main():
""" """
# print("=== ===")

# Task 1:
```
---
### Python (Event Loop) (Part 4)

```python
task1 = asyncio.create_task(sensor_read())

# Task 2:
task2 = asyncio.create_task(data_process())

# sensor_data = await task1
process_result = await task2

print(f": {sensor_data},: {process_result}")

# ```
---
### Python (Event Loop) (Part 5) (Code Part 1/2)


```python
asyncio.run(main())

```python
async def background_task():
while True:
print("...")
await asyncio.sleep(1)

async def main():
# Task →
task = asyncio.create_task(background_task())

# ```
---
### Python (Event Loop) (Part 5) (Code Part 2/2)

```python
await asyncio.sleep(3)

# Task
task.cancel()
try:
await task
except asyncio.CancelledError:
print("Task ")
```


**3. Future ()**:
```python
---
### Coroutine await (Part 1)



** **

<div class="grid grid-cols-2 gap-8">
<div>

```python
import asyncio
from typing import List

# async def simple_coroutine():
""" """
print(" ")
await asyncio.sleep(1)
print(" ")
return ""

# ```
---
### Coroutine await (Part 2)

```python
async def level_3():
"""3 """
print(" Level 3 ")
await asyncio.sleep(0.5)
print(" Level 3 ")
return "Level 3 "

async def level_2():
"""2 """
print(" Level 2 ")
result = await level_3() # await
print(f" Level 2: {result}")
```
---
### Coroutine await (Part 3)

```python
return "Level 2 "

async def level_1():
"""1 """
print("Level 1 ")
result = await level_2() # await
print(f"Level 1: {result}")
return "Level 1 "

# asyncio.run(level_1())

```
---
### Coroutine await (Part 4) (Code Part 1/3)


```python
```

```python
async def fetch_data(source_id: int):
await asyncio.sleep(1)
return f" from {source_id}"

async def main():
# 1:
result1 = await fetch_data(1) # 1
result2 = await fetch_data(2) # 1
# 2

```
---
### Coroutine await (Part 4) (Code Part 2/3)

```python
# 2: (gather)
results = await asyncio.gather(
fetch_data(1),
fetch_data(2),
fetch_data(3)
)
# 1 ( )

# 3: (TaskGroup, Python 3.11+)
async with asyncio.TaskGroup() as tg:
```
---
### Coroutine await (Part 4) (Code Part 3/3)

```python
task1 = tg.create_task(fetch_data(1))
task2 = tg.create_task(fetch_data(2))
task3 = tg.create_task(fetch_data(3))

# TaskGroup Task
```


** vs **:
```python
---
## Python (Part 1)




**Python **

<div class="grid grid-cols-2 gap-8">
<div>

**GIL?**:

```python
"""
GIL (Global Interpreter Lock)
- Python
- Python
- C GIL
- I/O GIL
"""

import threading
import time

# CPU-bound (GIL )
```
---
## Python (Part 2)

```python
def cpu_intensive_work(n):
"""CPU """
count = 0
for i in range(n):
count += i ** 2
return count

# start = time.time()
result1 = cpu_intensive_work(10_000_000)
result2 = cpu_intensive_work(10_000_000)
single_time = time.time() - start
```
---
## Python (Part 3)

```python
print(f": {single_time:.2f}")

# start = time.time()
thread1 = threading.Thread(
target=cpu_intensive_work, args=(10_000_000,))
thread2 = threading.Thread(
target=cpu_intensive_work, args=(10_000_000,))

thread1.start()
thread2.start()
thread1.join()
```
---
## Python (Part 4) (Code Part 1/4)


```python
thread2.join()

```python
"""
1 GIL 2
| | |
>
| | |
I/O <
| |
<
|
| | |
```
---
## Python (Part 4) (Code Part 2/4)

```python
"""

import threading
import time

def io_task(task_id):
"""I/O (GIL )"""
print(f"Task {task_id} ")
time.sleep(1) # I/O GIL
print(f"Task {task_id} ")
```
---
## Python (Part 4) (Code Part 3/4)

```python

# I/O
start = time.time()
threads = []
for i in range(5):
t = threading.Thread(target=io_task, args=(i,))
threads.append(t)
t.start()

for t in threads:
```
---
## Python (Part 4) (Code Part 4/4)

```python
t.join()

print(f": {time.time() - start:.2f}")
#:: 1.00 ( )
```


</div>
<div>
---
### threading vs multiprocessing (Part 1)



** **

<div class="grid grid-cols-2 gap-8">
<div>

**threading ()**:

```python
import threading
import time

# shared_data = {"count": 0}
lock = threading.Lock()

def increment_counter(thread_id):
""" ( )"""
global shared_data

for _ in range(100000):
```
---
### threading vs multiprocessing (Part 2)

```python
# Lock
with lock:
shared_data["count"] += 1

print(f"Thread {thread_id} ")

# threads = []
for i in range(4):
t = threading.Thread(
target=increment_counter, args=(i,))
threads.append(t)
```
---
### threading vs multiprocessing (Part 3)

```python
t.start()

for t in threads:
t.join()

print(f": {shared_data['count']}")
#:: 400000

#:
# -
# - ( )
# -
```
---
### threading vs multiprocessing (Part 4) (Code Part 1/6)


```python
```

```python
from multiprocessing import Process, Queue, Pool
import os

def cpu_intensive_task(data_chunk, result_queue):
"""CPU ( )"""
process_id = os.getpid()

# result = {
'process_id': process_id,
```
---
### threading vs multiprocessing (Part 4) (Code Part 2/6)

```python
'mean': sum(data_chunk) / len(data_chunk),
'max': max(data_chunk),
'min': min(data_chunk),
}

result_queue.put(result)
print(f" {process_id} ")

# import numpy as np
```
---
### threading vs multiprocessing (Part 4) (Code Part 3/6)

```python
full_data = np.random.rand(10_000_000)
chunk_size = len(full_data) // 4

data_chunks = [
full_data[i:i+chunk_size]
for i in range(0, len(full_data), chunk_size)
]

# result_queue = Queue()
```
---
### threading vs multiprocessing (Part 4) (Code Part 4/6)

```python
processes = []

for chunk in data_chunks:
p = Process(
target=cpu_intensive_task,
args=(chunk, result_queue)
)
processes.append(p)
p.start()

```
---
### threading vs multiprocessing (Part 4) (Code Part 5/6)

```python
for p in processes:
p.join()

# results = [result_queue.get() for _ in processes]
print(f": {len(results)} ")

#:
# -
# -
```
---
### threading vs multiprocessing (Part 4) (Code Part 6/6)

```python
# - (IPC)
# - GIL → CPU-bound
# - ( )
```


**multiprocessing.Pool **:
```python
---
## (Part 1)




**TCP/IP **

<div class="grid grid-cols-2 gap-8">
<div>

**TCP Server ()**:

```python
import socket
import threading

def handle_client(client_socket, address):
""" """
print(f": {address}")

try:
while True:
# ()
data = client_socket.recv(1024)

```
---
## (Part 2)

```python
if not data:
break #

# message = data.decode('utf-8')
print(f"{address}: {message}")

# response = f"Echo: {message}"
client_socket.send(response.encode('utf-8'))

except Exception as e:
```
---
## (Part 3)

```python
print(f": {e}")

finally:
client_socket.close()
print(f": {address}")

# TCP
server_socket = socket.socket(
socket.AF_INET, # IPv4
socket.SOCK_STREAM # TCP
)

```
---
## (Part 4)

```python
# server_socket.setsockopt(
socket.SOL_SOCKET,
socket.SO_REUSEADDR,
1
)

# HOST = '0.0.0.0' #
PORT = 5000
server_socket.bind((HOST, PORT))

```
---
## (Part 5)

```python
# (: 5)
server_socket.listen(5)
print(f": {HOST}:{PORT}")

try:
while True:
# ()
client_socket, address = server_socket.accept()

# client_thread = threading.Thread(
target=handle_client,
```
---
## (Part 6) (Code Part 1/5)


```python
args=(client_socket, address)

```python
import asyncio

async def handle_client(reader, writer):
""" """
address = writer.get_extra_info('peername')
print(f": {address}")

try:
while True:
# ```
---
## (Part 6) (Code Part 2/5)

```python
data = await reader.read(1024)

if not data:
break

message = data.decode('utf-8')
print(f"{address}: {message}")

# response = f"Echo: {message}"
```
---
## (Part 6) (Code Part 3/5)

```python
writer.write(response.encode('utf-8'))
await writer.drain()

except Exception as e:
print(f": {e}")

finally:
writer.close()
await writer.wait_closed()

```
---
## (Part 6) (Code Part 4/5)

```python
async def main():
# server = await asyncio.start_server(
handle_client,
'0.0.0.0',
5000
)

address = server.sockets[0].getsockname()
print(f": {address}")
```
---
## (Part 6) (Code Part 5/5)

```python

async with server:
await server.serve_forever()

# asyncio.run(main())
```


** **:
```python
---
### (Part 1)



** **

<div class="grid grid-cols-2 gap-8">
<div>

**struct (C )**:

```python
import struct
import time

# """
---
### (Part 1)

Packet Format (12 bytes):
- Header (1 byte): 0xAA
- Sensor ID (2 bytes): uint16
- Temperature (4 bytes): float
- Pressure (4 bytes): float
- Checksum (1 byte): XOR
"""
```
---
### (Part 2)

```python

def create_sensor_packet(sensor_id, temperature, pressure):
""" """
header = 0xAA

# # B: unsigned char (1 byte)
# H: unsigned short (2 bytes)
# f: float (4 bytes)
packet = struct.pack(
'!BHff', #! =
header,
```
---
### (Part 3)

```python
sensor_id,
temperature,
pressure
)

# (XOR)
checksum = 0
for byte in packet:
checksum ^= byte

# packet += struct.pack('B', checksum)
```
---
### (Part 4)

```python

return packet

def parse_sensor_packet(packet):
""" """
if len(packet)!= 12:
raise ValueError(" ")

# checksum = 0
for byte in packet[:-1]:
checksum ^= byte
```
---
### (Part 5)

```python

received_checksum = packet[-1]
if checksum!= received_checksum:
raise ValueError(" ")

# header, sensor_id, temp, pressure = struct.unpack(
'!BHff', packet[:-1])

if header!= 0xAA:
raise ValueError(" ")

```
---
### (Part 6) (Code Part 1/8)


```python
return {

```python
import json
import socket

class SensorProtocol:
"""JSON """

@staticmethod
def encode_message(msg_type, data):
""" """
message = {
```
---
### (Part 6) (Code Part 2/8)

```python
'type': msg_type,
'timestamp': time.time(),
'data': data
}

# JSON
json_str = json.dumps(message)

# (4 bytes)
length = len(json_str)
```
---
### (Part 6) (Code Part 3/8)

```python
header = struct.pack('!I', length)

return header + json_str.encode('utf-8')

@staticmethod
def decode_message(sock):
""" """
# (4 bytes)
header = sock.recv(4)
if not header:
```
---
### (Part 6) (Code Part 4/8)

```python
return None

length = struct.unpack('!I', header)[0]

# data = b''
while len(data) < length:
chunk = sock.recv(length - len(data))
if not chunk:
raise ConnectionError(" ")
```
---
### (Part 6) (Code Part 5/8)

```python
data += chunk

# JSON
message = json.loads(data.decode('utf-8'))
return message

# # def handle_client(client_socket):
protocol = SensorProtocol()
```
---
### (Part 6) (Code Part 6/8)

```python

while True:
# message = protocol.decode_message(client_socket)
if not message:
break

print(f": {message}")

# ```
---
### (Part 6) (Code Part 7/8)

```python
response = protocol.encode_message(
'ack',
{'status': 'ok'}
)
client_socket.send(response)

# def send_sensor_data(sock, sensor_id, value):
protocol = SensorProtocol()

```
---
### (Part 6) (Code Part 8/8)

```python
message = protocol.encode_message(
'sensor_data',
{
'sensor_id': sensor_id,
'value': value
}
)

sock.send(message)
```


**MessagePack ( )**:
```python