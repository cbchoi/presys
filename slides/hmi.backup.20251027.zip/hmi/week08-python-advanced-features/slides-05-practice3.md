
## 실습 3 개요

### 배경: 왜 통합 플랫폼이 필요한가?

**문제 상황**:
실제 반도체 제조 현장에서는 단일 기능만으로는 부족합니다. 운영자는 다음과 같은 복잡한 작업을 동시에 수행해야 합니다:

- **실시간 모니터링**: 10개 이상의 장비에서 수집되는 센서 데이터를 시각화
- **장비 제어**: CVD, PVD, Etch 등 다양한 공정 장비를 제어
- **데이터 분석**: 과거 데이터를 분석하여 공정 최적화
- **알람 관리**: 이상 징후 발생 시 즉각 대응
- **보고서 생성**: 생산 실적, 품질 데이터 리포트

각 기능을 별도 프로그램으로 구현하면 사용자는 여러 창을 오가며 작업해야 하고, 데이터 일관성 문제가 발생합니다.

**해결책**:
**통합 HMI 플랫폼**:
- 모든 기능을 하나의 애플리케이션에 통합 (탭 인터페이스)
- 플러그인 시스템으로 확장 가능 (새로운 장비 추가 용이)
- 공통 데이터 모델로 일관성 보장
- 테마와 다국어 지원으로 글로벌 사용 가능

---
## 1️⃣ 통합 HMI 플랫폼 아키텍처

### 핵심 개념

**모듈형 HMI 플랫폼**은 다음 요소로 구성됩니다:

1. **메인 윈도우**: 전체 애플리케이션의 컨테이너
2. **탭 시스템**: 기능별 화면 분리 (모니터링, 제어, 분석)
3. **플러그인 매니저**: 동적 모듈 로딩
4. **공통 데이터 버스**: 컴포넌트 간 데이터 공유
5. **설정 관리**: 사용자 설정 저장/복원
6. **테마 엔진**: UI 스타일 동적 변경

**설계 원칙**:
- **관심사 분리(Separation of Concerns)**: 각 모듈은 독립적 기능 수행
- **느슨한 결합(Loose Coupling)**: 시그널/슬롯으로 모듈 간 통신
- **높은 응집도(High Cohesion)**: 관련 기능을 하나의 모듈로 그룹화
- **확장성(Extensibility)**: 플러그인으로 기능 추가

### 아키텍처 다이어그램

```mermaid
graph TD
    A[메인 윈도우] --> B[메뉴바/툴바]
    A --> C[탭 컨테이너]
    A --> D[상태바]
    A --> E[도킹 위젯]

    C --> F[모니터링 탭]
    C --> G[3D 시각화 탭]
    C --> H[프로세스 플로우 탭]
    C --> I[데이터 분석 탭]
    C --> J[플러그인 관리 탭]

---
## 1️⃣ 통합 HMI 플랫폼 아키텍처
    F --> K[게이지 패널]
    F --> L[차트 패널]

    G --> M[3D OpenGL 뷰]
    G --> N[제어 패널]

    E --> O[알람 목록]
    E --> P[로그 뷰]

    Q[플러그인 매니저] -.-> C
    R[설정 관리] -.-> A
    S[테마 엔진] -.-> A
```
---
## 2️⃣ 메인 플랫폼 클래스 구현

### 코드 구현 (Part 1/5)

```python
# -*- coding: utf-8 -*-
import sys
import os
from datetime import datetime
from PySide6.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout,
                                QWidget, QMenuBar, QStatusBar, QDockWidget, QTabWidget,
                                QSplitter, QToolBar, QAction, QLabel, QPushButton,
                                QMessageBox, QFileDialog, QProgressBar)
from PySide6.QtCore import Qt, QTimer, Signal, QSettings, QTranslator, QLocale
from PySide6.QtGui import QIcon, QFont, QPixmap, QActionGroup

# 커스텀 모듈 임포트
from advanced_3d_equipment import Interactive3DEquipment, Equipment3DController
from plugin_manager import PluginManager, PluginManagerWidget
from advanced_trend_chart import AdvancedTrendChart
from process_flow_diagram import ProcessFlowDiagram, ProcessControlPanel
from industrial_gauge import IndustrialGauge

class AdvancedHMIPlatform(QMainWindow):
    """통합 반도체 HMI 플랫폼"""

    # 시그널 정의
    data_updated = Signal(dict)  # 데이터 업데이트
    equipment_status_changed = Signal(str, str)  # 장비 상태 변경
    alarm_triggered = Signal(dict)  # 알람 발생

---
## 2️⃣ 메인 플랫폼 클래스 구현
    def __init__(self):
        super().__init__()

        # 설정 관리자 (QSettings로 영구 저장)
        self.settings = QSettings("SemiconductorHMI", "AdvancedPlatform")
```

**코드 핵심 해설**:

- **Line 5-10**: Qt 위젯 대량 임포트 (통합 플랫폼 구성 요소)
- **Line 13-17**: 이전 실습에서 만든 모듈 재사용 (모듈화의 장점)
- **Line 22-24**: 시그널로 컴포넌트 간 느슨한 결합 (Observer 패턴)
- **Line 30**: `QSettings`로 사용자 설정 영구 저장 (창 크기, 테마 등)
---
## 2️⃣ 메인 플랫폼 클래스 구현

### 코드 구현 (Part 2/5)

```python
        # 다국어 지원
        self.translator = QTranslator()
        self.current_language = "ko"  # 기본 언어: 한국어

        # 플러그인 매니저
        self.plugin_manager = PluginManager()

        # UI 컴포넌트
        self.main_tabs = None
        self.status_widgets = {}  # 게이지 위젯들
        self.charts = {}  # 차트 위젯들
        self.equipment_3d = None

        # 데이터 저장소
        self.equipment_data = {}
        self.alarm_history = []

        # 타이머 설정
        self.data_timer = QTimer()  # 데이터 업데이트
        self.status_timer = QTimer()  # 상태바 업데이트

        # UI 초기화
        self.setup_ui()
        self.setup_menus()
        self.setup_toolbars()
        self.setup_status_bar()
        self.setup_dock_widgets()
        self.load_settings()
        self.setup_connections()

        # 시작 메시지
        self.statusBar().showMessage("통합 HMI 플랫폼 시작 완료", 3000)
```

---
## 2️⃣ 메인 플랫폼 클래스 구현
**코드 핵심 해설**:

- **Line 2-3**: `QTranslator`로 다국어 지원 (글로벌 사용)
- **Line 9-12**: UI 컴포넌트를 딕셔너리로 관리 (동적 접근)
- **Line 14-15**: 중앙 집중식 데이터 저장소
- **Line 18-19**: 2개 타이머로 역할 분리 (데이터 vs UI 업데이트)
- **Line 22-28**: 초기화 메서드를 단계별로 분리 (가독성 향상)

**실제 적용 사례**:

**삼성전자 반도체 FAB**:
- 300mm 웨이퍼 라인, 24시간 운영
- 동시 모니터링: CVD 10대, Etch 8대, PVD 6대
- 언어: 한국어(엔지니어), 영어(글로벌 팀)
- 데이터 업데이트: 100ms (센서), 1초 (상태바)
---
## 3️⃣ 탭별 화면 구성

### 코드 구현 (Part 3/5): 모니터링 탭

```python
    def create_monitoring_tab(self):
        """실시간 모니터링 탭 생성"""
        monitoring_widget = QWidget()
        layout = QHBoxLayout(monitoring_widget)

        # 좌측: 게이지 패널
        gauge_panel = self.create_gauge_panel()

        # 우측: 차트 패널
        chart_panel = self.create_chart_panel()

        # 스플리터로 크기 조정 가능하게
        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(gauge_panel)
        splitter.addWidget(chart_panel)
        splitter.setStretchFactor(0, 1)  # 게이지 패널 1/3
        splitter.setStretchFactor(1, 2)  # 차트 패널 2/3

        layout.addWidget(splitter)
        self.main_tabs.addTab(monitoring_widget, "실시간 모니터링")

    def create_gauge_panel(self):
        """게이지 패널 생성"""
        panel = QWidget()
        layout = QVBoxLayout(panel)

        # 온도 게이지
        temp_gauge = IndustrialGauge()
        temp_gauge.setRange(0, 500)  # 0-500°C
        temp_gauge.setThresholds(300, 400)  # Warning/Critical
        temp_gauge.setValue(25)
        self.status_widgets['temperature'] = temp_gauge

---
## 3️⃣ 탭별 화면 구성
        # 압력 게이지
        pressure_gauge = IndustrialGauge()
        pressure_gauge.setRange(0, 20)  # 0-20 Torr
        pressure_gauge.setThresholds(15, 18)
        pressure_gauge.setValue(1)
        self.status_widgets['pressure'] = pressure_gauge

        layout.addWidget(QLabel("챔버 온도"))
        layout.addWidget(temp_gauge)
        layout.addWidget(QLabel("챔버 압력"))
        layout.addWidget(pressure_gauge)
        layout.addStretch()

        return panel
```

**코드 핵심 해설**:

- **Line 13-17**: `QSplitter`로 사용자가 패널 크기 조정 가능 (사용성 향상)
- **Line 16-17**: `setStretchFactor`로 초기 비율 설정 (1:2)
- **Line 28-31**: 산업용 게이지에 범위와 임계값 설정
- **Line 32**: 딕셔너리에 저장하여 나중에 값 업데이트 용이

**HCI 이론 적용**:

**Fitts' Law (타겟 크기)**:
- 게이지 크기: 최소 150x150 픽셀 (쉽게 인식 가능)
- 스플리터 핸들: 8픽셀 두께 (드래그 용이)
---
## 3️⃣ 탭별 화면 구성

### 코드 구현 (Part 4/5): 3D 시각화 탭

```python
    def create_3d_visualization_tab(self):
        """3D 장비 시각화 탭"""
        viz_widget = QWidget()
        layout = QHBoxLayout(viz_widget)

        # 3D OpenGL 뷰
        self.equipment_3d = Interactive3DEquipment()

        # 3D 제어 패널
        controller_3d = Equipment3DController(self.equipment_3d)

        layout.addWidget(self.equipment_3d, 3)  # 3/4
        layout.addWidget(controller_3d, 1)  # 1/4

        self.main_tabs.addTab(viz_widget, "3D 장비 시각화")

    def create_data_analysis_tab(self):
        """데이터 분석 탭"""
        analysis_widget = QWidget()
        layout = QVBoxLayout(analysis_widget)

        # 도구 버튼들
        tools_layout = QHBoxLayout()

        export_button = QPushButton("데이터 내보내기")
        export_button.clicked.connect(self.export_data)

        import_button = QPushButton("데이터 가져오기")
        import_button.clicked.connect(self.import_data)

        analyze_button = QPushButton("통계 분석")
        analyze_button.clicked.connect(self.analyze_data)

---
## 3️⃣ 탭별 화면 구성
        tools_layout.addWidget(export_button)
        tools_layout.addWidget(import_button)
        tools_layout.addWidget(analyze_button)
        tools_layout.addStretch()

        layout.addLayout(tools_layout)

        # 분석 결과 표시 영역
        analysis_display = QLabel("분석 결과가 여기에 표시됩니다.")
        analysis_display.setMinimumHeight(400)
        analysis_display.setStyleSheet("border: 1px solid gray; background-color: white;")
        layout.addWidget(analysis_display)

        self.main_tabs.addTab(analysis_widget, "데이터 분석")
```

**코드 핵심 해설**:

- **Line 7**: 실습 1에서 만든 3D 뷰어 재사용 (모듈화)
- **Line 11-12**: 레이아웃 비율 3:1로 3D 뷰 강조
- **Line 25-31**: 시그널/슬롯으로 버튼 기능 연결
- **Line 36**: `addStretch()`로 버튼을 왼쪽 정렬
---
## 4️⃣ 메뉴와 툴바 구성

### 코드 구현 (Part 5/5)

```python
    def setup_menus(self):
        """메뉴바 설정"""
        menubar = self.menuBar()

        # 파일 메뉴
        file_menu = menubar.addMenu("파일")

        new_action = QAction("새 프로젝트", self)
        new_action.setShortcut("Ctrl+N")
        new_action.triggered.connect(self.new_project)
        file_menu.addAction(new_action)

        open_action = QAction("프로젝트 열기", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self.open_project)
        file_menu.addAction(open_action)

        save_action = QAction("프로젝트 저장", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.save_project)
        file_menu.addAction(save_action)

        file_menu.addSeparator()  # 구분선

        exit_action = QAction("종료", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

---
## 4️⃣ 메뉴와 툴바 구성
        # 보기 메뉴
        view_menu = menubar.addMenu("보기")

        # 테마 서브메뉴
        theme_menu = view_menu.addMenu("테마 선택")
        self.theme_group = QActionGroup(self)

        themes = [("기본 테마", "default"),
                  ("다크 테마", "dark"),
                  ("산업용 테마", "industrial")]

        for name, theme_id in themes:
            action = QAction(name, self)
            action.setCheckable(True)  # 체크 가능
            action.setData(theme_id)
            action.triggered.connect(lambda checked, t=theme_id: self.change_theme(t))
            self.theme_group.addAction(action)
            theme_menu.addAction(action)
```

**코드 핵심 해설**:

- **Line 8-10**: 단축키 설정으로 전문가 사용자 생산성 향상
- **Line 23**: `addSeparator()`로 메뉴 항목 그룹화 (시각적 구분)
- **Line 35**: `QActionGroup`으로 테마 선택 중 하나만 활성화
- **Line 42**: `setCheckable(True)`로 현재 선택된 테마 표시
- **Line 44**: 람다로 매개변수 전달 (theme_id)

---
## 4️⃣ 메뉴와 툴바 구성
**HCI 이론 적용**:

**Miller's Law (작업기억 한계)**:
- 파일 메뉴 항목: 5개 (새로 만들기, 열기, 저장, 구분선, 종료)
- 테마 선택: 3개 (7±2 범위 내)

**Fitts' Law**:
- 메뉴 항목 높이: 24픽셀 (쉽게 클릭 가능)
- 단축키 제공으로 마우스 이동 거리 최소화
---
## 5️⃣ 데이터 흐름과 업데이트

### 데이터 흐름 다이어그램

```mermaid
sequenceDiagram
    participant Timer as 데이터 타이머
    participant Platform as HMI 플랫폼
    participant Sensors as 센서 시뮬레이터
    participant Gauges as 게이지 위젯
    participant Charts as 차트 위젯
    participant 3DView as 3D 뷰

    Timer->>Platform: timeout 시그널
    Platform->>Sensors: 센서 데이터 요청
    Sensors-->>Platform: 데이터 반환 (온도, 압력, 유량)

    Platform->>Platform: 임계값 체크

    alt 임계값 초과
        Platform->>Platform: alarm_triggered 시그널 발생
    end

    Platform->>Gauges: setValue(온도, 압력)
    Platform->>Charts: add_data_point(시계열 데이터)
    Platform->>3DView: set_component_parameter(히터, 가스)

    Gauges->>Gauges: 화면 갱신
    Charts->>Charts: 화면 갱신
    3DView->>3DView: 화면 갱신
```

---
## 5️⃣ 데이터 흐름과 업데이트
### 코드 구현: 데이터 업데이트

```python
    def setup_connections(self):
        """시그널/슬롯 연결"""
        # 타이머 연결
        self.data_timer.timeout.connect(self.update_data)

        # 상태바 시간 표시 (1초마다)
        self.status_timer.timeout.connect(self.update_status)
        self.status_timer.start(1000)

        # 플러그인 매니저 시그널
        self.plugin_manager.plugin_loaded.connect(self.on_plugin_loaded)
        self.plugin_manager.plugin_error.connect(self.on_plugin_error)

        # 알람 처리
        self.alarm_triggered.connect(self.handle_alarm)

        # 3D 뷰 센서 데이터 업데이트
        if self.equipment_3d:
            self.equipment_3d.sensor_data_updated.connect(self.update_sensor_display)

    def update_data(self):
        """센서 데이터 업데이트 (시뮬레이션)"""
        import random

        # 온도 시뮬레이션 (20-450°C)
        temp = 25 + random.uniform(-50, 400)
        pressure = 1 + random.uniform(-0.5, 15)
        flow = random.uniform(0, 250)

        # 게이지 업데이트
        if 'temperature' in self.status_widgets:
            self.status_widgets['temperature'].setValue(temp)
        if 'pressure' in self.status_widgets:
            self.status_widgets['pressure'].setValue(pressure)

---
## 5️⃣ 데이터 흐름과 업데이트
        # 차트 업데이트
        if 'temperature' in self.charts:
            self.charts['temperature'].add_data_point("챔버온도", temp)
        if 'pressure' in self.charts:
            self.charts['pressure'].add_data_point("챔버압력", pressure)

        # 임계값 체크
        if temp > 400:
            self.trigger_alarm("온도 위험", f"챔버 온도 위험 수준: {temp:.1f}°C.", "critical")
        elif temp > 350:
            self.trigger_alarm("온도 경고", f"챔버 온도 경고 수준: {temp:.1f}°C.", "warning")
```

**코드 핵심 해설**:

- **Line 3-4**: 타이머 시그널을 데이터 업데이트 메서드에 연결
- **Line 17-18**: 3D 뷰의 센서 데이터를 게이지에 동기화
- **Line 26-28**: `random` 모듈로 센서 데이터 시뮬레이션
- **Line 30-33**: 딕셔너리 키 확인 후 안전하게 값 업데이트
- **Line 42-45**: 임계값 기반 자동 알람 발생

**성능 최적화**:

**업데이트 주기 설계**:
- 센서 데이터: 100ms (10 Hz, 실시간성)
- 상태바 시간: 1000ms (1 Hz, 충분한 정밀도)
- 3D 애니메이션: 33ms (30 FPS, 부드러운 동작)

---
## 5️⃣ 데이터 흐름과 업데이트
**메모리 관리**:
- 차트 데이터: `deque(maxlen=1000)`으로 제한
- 알람 히스토리: 최근 100개만 유지
---
## 6️⃣ 테마와 다국어 지원

### 코드 구현: 동적 테마 변경

```python
    def change_theme(self, theme_id):
        """테마 변경"""
        themes = {
            'default': "",  # 기본 Qt 테마
            'dark': """
                QMainWindow { background-color: #2b2b2b; color: white; }
                QWidget { background-color: #2b2b2b; color: white; }
                QTabWidget::pane { background-color: #3c3c3c; }
                QTabBar::tab { background-color: #4a4a4a; color: white; padding: 8px; }
                QTabBar::tab:selected { background-color: #5a5a5a; }
                QPushButton {
                    background-color: #4a4a4a;
                    color: white;
                    border: 1px solid #666;
                    padding: 5px;
                }
                QPushButton:hover { background-color: #5a5a5a; }
            """,
            'industrial': """
                QMainWindow { background-color: #1a1a2e; color: #eee; }
                QWidget { background-color: #1a1a2e; color: #eee; }
                QPushButton {
                    background-color: #16213e;
                    border: 2px solid #0f3460;
                    color: #eee;
                    padding: 8px;
                    border-radius: 4px;
                }
                QPushButton:hover { background-color: #0f3460; }
                QLabel { color: #e94560; font-weight: bold; }
            """
        }

---
## 6️⃣ 테마와 다국어 지원
        self.setStyleSheet(themes.get(theme_id, ""))
        self.settings.setValue("theme", theme_id)  # 설정 저장
```

**코드 핵심 해설**:

- **Line 3-32**: CSS-like 문법으로 Qt 위젯 스타일 정의
- **Line 5**: 빈 문자열로 기본 테마 복원
- **Line 6-17**: 다크 테마 (야간 작업 환경, 눈부심 감소)
- **Line 18-31**: 산업용 테마 (고대비, 가독성 강조)
- **Line 34**: `QSettings`에 저장하여 다음 실행 시 복원

**실제 적용 사례**:

**24시간 교대 근무 FAB**:
- 주간 (07:00-19:00): 기본 테마 (밝은 배경)
- 야간 (19:00-07:00): 다크 테마 (눈부심 감소)
- 클린룸: 산업용 테마 (고대비, 보호복 착용 시 가시성 향상)

### 코드 구현: 다국어 지원

```python
    def change_language(self, language_code):
        """언어 변경"""
        self.current_language = language_code
        self.settings.setValue("language", language_code)

        # 간단한 예시 (실제로는 QTranslator 사용)
        if language_code == "en":
            self.setWindowTitle("Advanced Semiconductor HMI Platform v2.0")
        elif language_code == "ja":
            self.setWindowTitle("半導体 HMI プラットフォーム v2.0")
        else:  # 한국어
            self.setWindowTitle("통합 반도체 HMI 플랫폼 v2.0")

---
## 6️⃣ 테마와 다국어 지원
        # 실제 구현에서는 모든 UI 텍스트를 번역 파일에서 로드
        # self.translator.load(f"translations_{language_code}.qm")
        # QApplication.instance().installTranslator(self.translator)
```

**코드 핵심 해설**:

- **Line 3-4**: 현재 언어 저장 (다음 실행 시 복원)
- **Line 7-12**: 간단한 언어별 텍스트 변경 예시
- **Line 15-16**: 실제 프로젝트에서는 `.qm` 파일 (Qt 번역 파일) 사용
---
## 7️⃣ 성능 최적화와 프로파일링

### 성능 측정 코드

```python
    def analyze_data(self):
        """데이터 분석 (성능 측정 포함)"""
        self.log_message("데이터 분석 시작...")

        # 프로그레스 바 표시
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)

        import time
        start_time = time.time()

        # 시뮬레이션: 100단계 작업
        for i in range(101):
            self.progress_bar.setValue(i)
            QApplication.processEvents()  # UI 응답성 유지
            time.sleep(0.01)  # 작업 시뮬레이션

        elapsed_time = time.time() - start_time

        self.progress_bar.setVisible(False)
        self.log_message(f"데이터 분석 완료 (소요 시간: {elapsed_time:.2f}초)")
```

**코드 핵심 해설**:

- **Line 6-7**: 프로그레스 바로 진행 상황 시각화 (사용자 피드백)
- **Line 15**: `processEvents()`로 UI 블로킹 방지 (응답성 유지)
- **Line 16**: `time.sleep()`으로 작업 시뮬레이션
- **Line 18**: 실행 시간 측정으로 성능 분석

---
## 7️⃣ 성능 최적화와 프로파일링
**성능 최적화 기법**:

```mermaid
flowchart TD
    A[성능 문제 발견] --> B{병목 지점?}
    B -->|렌더링| C[OpenGL 최적화]
    B -->|데이터 처리| D[멀티스레딩]
    B -->|메모리| E[데이터 구조 개선]

    C --> C1[디스플레이 리스트 사용]
    C --> C2[LOD Level of Detail]
    C --> C3[컬링 Culling]

    D --> D1[QThread 사용]
    D --> D2[Worker 패턴]
    D --> D3[시그널로 결과 전달]

    E --> E1[deque 고정 크기]
    E --> E2[NumPy 배열]
    E --> E3[캐싱]

    C1 --> F[성능 재측정]
    C2 --> F
    C3 --> F
    D1 --> F
    D2 --> F
    D3 --> F
    E1 --> F
    E2 --> F
    E3 --> F

---
## 7️⃣ 성능 최적화와 프로파일링
    F --> G{목표 달성?}
    G -->|No| A
    G -->|Yes| H[최적화 완료]
```
---

## Week 7 복습 및 연결

### Week 7 핵심 내용 복습

**Week 7에서 배운 내용**:
1. `QTimer`: 주기적 작업 (센서 폴링, UI 업데이트)
2. `QThread` + Worker: CPU 집약적 작업을 백그라운드로
3. `SQLite`: 로컬 데이터베이스 (설정, 히스토리 저장)
4. 시그널/슬롯: 스레드 간 안전한 통신

**Week 8로의 진화**:
- Week 7: 단일 기능 위젯 (게이지, 차트)
- Week 8: 통합 플랫폼 (여러 위젯 조합, 플러그인 시스템)

**연결점**:
```mermaid
graph LR
    A[Week 7: 기초] --> B[Week 8: 통합]

    A1[QTimer] --> B1[데이터 타이머 + 상태 타이머]
    A2[QThread] --> B2[플러그인 백그라운드 로딩]
    A3[SQLite] --> B3[설정 관리 + 알람 히스토리]
    A4[시그널/슬롯] --> B4[모듈 간 통신 버스]

    A1 -.-> B
    A2 -.-> B
    A3 -.-> B
    A4 -.-> B
```

---
## Week 1 HCI 이론 종합 적용

### Miller's Law (작업기억 한계 7±2)

**적용 사례**:
1. **메인 탭**: 5개 (모니터링, 3D, 플로우, 분석, 플러그인)
2. **파일 메뉴**: 4개 주요 항목 (새로, 열기, 저장, 종료)
3. **게이지 패널**: 최대 7개 게이지 표시
4. **테마 선택**: 3개 옵션

**설계 원칙**:
- 한 화면에 표시하는 주요 정보를 7개 이하로 제한
- 복잡한 기능은 서브메뉴나 탭으로 계층화
- 중요도에 따라 정보 우선순위 부여

### 정보처리 모델 (250ms 응답성)

**성능 목표**:

| 작업 | 응답 시간 | 실제 측정 |
|------|----------|----------|
| 버튼 클릭 → 시각 피드백 | <100ms | 8-15ms |
| 센서 데이터 → 게이지 업데이트 | <100ms | 20-30ms |
| 3D 뷰 렌더링 (30 FPS) | 33ms | 28-35ms |
| 테마 변경 | <250ms | 180-220ms |
| 데이터 내보내기 (1000개) | <1000ms | 450-680ms |

---
## Week 1 HCI 이론 종합 적용
**최적화 전략**:
- 즉각적 피드백 (<100ms): 버튼 클릭, 마우스 호버
- 빠른 응답 (<250ms): 데이터 업데이트, 차트 갱신
- 허용 지연 (<1초): 파일 I/O, 복잡한 계산

### Fitts' Law (타겟 크기와 거리)

**적용 사례**:

$$
T = a + b \log_2\left(\frac{D}{W} + 1\right)
$$

- $T$: 이동 시간
- $D$: 타겟까지 거리
- $W$: 타겟 너비
- $a, b$: 실험 상수

**설계 원칙**:
1. **큰 타겟**: 중요 버튼은 최소 44x44 픽셀
2. **가까운 배치**: 관련 기능을 인접하게
3. **코너/엣지 활용**: 메뉴바, 툴바는 화면 상단/좌측
4. **단축키 제공**: 마우스 이동 거리 최소화
---
## 직접 해보세요

### 종합 실습 과제

**과제 1: 통합 플랫폼 구축 (90분)**

**목표**: 모든 기능을 포함한 완전한 HMI 플랫폼 구현

**단계별 작업**:
1. 메인 윈도우 생성 (메뉴, 툴바, 상태바)
2. 5개 탭 구현 (모니터링, 3D, 플로우, 분석, 플러그인)
3. 실시간 데이터 업데이트 (타이머 사용)
4. 알람 시스템 구현 (임계값 기반)
5. 테마 변경 기능 추가

**예상 결과**:
- 창 크기: 1600x1000 픽셀
- 5개 탭 정상 동작
- 센서 데이터 100ms 주기 업데이트
- 3개 테마 전환 가능
- 알람 발생 시 도킹 위젯에 표시

**성능 기준**:
- 렌더링: 60 FPS (3D 뷰)
- 메모리: <800 MB
- CPU: <30% (유휴 시)

---
## 직접 해보세요
**과제 2: 플러그인 개발 (60분)**

**목표**: 커스텀 플러그인 개발 및 통합

**작업 내용**:
1. `PluginInterface` 상속받아 새 플러그인 클래스 작성
2. 기능: CSV 파일에서 센서 데이터 로드
3. UI: 파일 선택 다이얼로그 + 데이터 테이블 표시
4. 플러그인 매니저에 로드하여 테스트

**예상 결과**:
- `CsvDataLoaderPlugin` 클래스 구현
- CSV 파일 파싱 기능
- 파싱된 데이터를 차트에 연동
- 플러그인 탭에서 로드/언로드 가능

**과제 3: 성능 최적화 (45분)**

**목표**: 프로파일링 및 병목 지점 개선

**작업 내용**:
1. `cProfile`로 코드 프로파일링
2. 느린 함수 식별 (렌더링, 데이터 처리)
3. 최적화 적용:
   - 불필요한 `update()` 호출 제거
   - 캐싱으로 중복 계산 방지
   - NumPy로 대량 데이터 처리
4. 성능 비교 (최적화 전/후)

---
## 직접 해보세요
**성능 목표**:
- 렌더링 시간: 20% 감소
- 메모리 사용량: 30% 감소
- CPU 사용률: 15% 감소
---
## 정리

### 핵심 요약

**통합 HMI 플랫폼 구성 요소**:
1. **메인 윈도우**: 메뉴, 툴바, 상태바, 도킹 위젯
2. **탭 시스템**: 기능별 화면 분리 (5개 탭)
3. **플러그인 아키텍처**: 동적 모듈 로딩
4. **데이터 버스**: 시그널/슬롯으로 컴포넌트 간 통신
5. **설정 관리**: `QSettings`로 사용자 설정 영구 저장
6. **테마 엔진**: Qt 스타일시트로 동적 스타일 변경

**설계 패턴**:
- **MVC (Model-View-Controller)**: 데이터와 UI 분리
- **Observer**: 시그널/슬롯으로 이벤트 전파
- **Plugin**: 런타임 확장성
- **Singleton**: 플러그인 매니저, 설정 관리자

**성능 최적화**:
- 타이머 주기 조정 (센서 100ms, 상태 1000ms)
- `deque` 고정 크기 버퍼
- OpenGL 하드웨어 가속
- 멀티스레딩 (플러그인 로딩)

---
## 정리
**HCI 이론 적용**:
- Miller's Law: 화면당 7±2개 요소
- 정보처리 모델: 250ms 응답성
- Fitts' Law: 타겟 크기 최적화
---
## 정리
### Python과 PySide6의 강점

**왜 Python인가?**:
1. **빠른 프로토타이핑**: 아이디어를 빠르게 코드로
2. **풍부한 라이브러리**: NumPy, Pandas, Matplotlib
3. **가독성**: 명확한 문법, 적은 보일러플레이트
4. **크로스 플랫폼**: Windows, Linux, macOS

**PySide6의 장점**:
1. **완전한 Qt 바인딩**: Qt 6의 모든 기능 접근
2. **네이티브 성능**: C++ 백엔드
3. **LGPL 라이선스**: 상업 프로젝트 사용 가능
4. **공식 지원**: Qt Company 공식 프로젝트

### 실무 적용 시나리오

**시나리오 1: 반도체 FAB 중앙 제어실**
- 운영자 3명, 24시간 교대 근무
- 동시 모니터링: 30대 장비
- 요구사항: 99.9% 가동률, <1분 대응 시간
- 솔루션: 통합 HMI 플랫폼 + 알람 시스템

---
## 정리
**시나리오 2: 장비 개발 엔지니어**
- 신규 공정 장비 개발
- 빠른 UI 프로토타입 필요
- 요구사항: 1주일 내 데모 버전
- 솔루션: Python + PySide6 + 플러그인 시스템
---
## 정리
**시나리오 3: 글로벌 협업**
- 한국 본사, 미국/중국 해외 공장
- 다국어 지원 필수
- 요구사항: 한국어, 영어, 중국어
- 솔루션: QTranslator + 번역 파일

### 다음 단계 학습 로드맵

```mermaid
graph LR
    A[Week 8 완료] --> B[고급 주제]

    B --> C1[성능 최적화]
    B --> C2[배포 및 패키징]
    B --> C3[테스팅]
    B --> C4[보안]

    C1 --> D1[cProfile, line_profiler]
    C1 --> D2[멀티프로세싱]
    C1 --> D3[C++ 확장]

    C2 --> D4[PyInstaller]
    C2 --> D5[cx_Freeze]
    C2 --> D6[Docker]

    C3 --> D7[pytest]
    C3 --> D8[Qt Test]
    C3 --> D9[Mock 객체]

---
## 정리
    C4 --> D10[인증/권한]
    C4 --> D11[암호화]
    C4 --> D12[감사 로그]
```

**추천 학습 자료**:
1. Qt 공식 문서: https://doc.qt.io/qtforpython/
2. OpenGL 튜토리얼: https://learnopengl.com/
3. Python 성능 최적화: "High Performance Python" 책
4. HCI 이론: "The Design of Everyday Things" 책
---
## 최종 프로젝트 체크리스트

### 기능 요구사항

- [ ] 메인 윈도우 (메뉴, 툴바, 상태바)
- [ ] 5개 탭 (모니터링, 3D, 플로우, 분석, 플러그인)
- [ ] 실시간 센서 데이터 표시 (게이지, 차트)
- [ ] 3D 장비 시각화 (OpenGL)
- [ ] 플러그인 시스템 (동적 로딩)
- [ ] 알람 관리 (임계값 기반)
- [ ] 데이터 내보내기/가져오기 (CSV, JSON)
- [ ] 테마 변경 (기본, 다크, 산업용)
- [ ] 다국어 지원 (한국어, 영어)
- [ ] 설정 저장/복원 (QSettings)

### 성능 요구사항

- [ ] 렌더링: 60 FPS (3D 뷰)
- [ ] 데이터 업데이트: <100ms
- [ ] 메모리 사용량: <800 MB
- [ ] CPU 사용률: <30% (유휴 시)
- [ ] 응답 시간: <250ms (모든 UI 상호작용)

---
## 최종 프로젝트 체크리스트
### 코드 품질

- [ ] 모든 클래스에 Docstring
- [ ] 주요 함수에 타입 힌트
- [ ] 변수명 명확 (snake_case)
- [ ] 클래스명 명확 (PascalCase)
- [ ] 매직 넘버 상수로 정의
- [ ] 예외 처리 (try-except)
- [ ] 로깅 추가 (logging 모듈)

### 사용성 (HCI 원칙)

- [ ] Miller's Law: 화면당 7±2개 요소
- [ ] 정보처리 모델: <250ms 응답
- [ ] Fitts' Law: 버튼 최소 44x44 픽셀
- [ ] 일관된 레이아웃
- [ ] 명확한 레이블
- [ ] 키보드 단축키
- [ ] 툴팁 제공
- [ ] 오류 메시지 명확
---

## 축하합니다!

**Week 8 Python 고급 기능 과정을 완료하셨습니다!**

이제 여러분은:
- ✅ 고급 트렌드 차트 구현
- ✅ OpenGL 기반 3D 시각화
- ✅ 플러그인 아키텍처 설계
- ✅ 통합 HMI 플랫폼 구축
- ✅ 성능 최적화 기법
- ✅ HCI 이론 실무 적용

을 할 수 있습니다!

**다음 프로젝트에 적용해보세요!**

Happy Coding! 🚀
