# 기초 실습: Unit Test 및 Integration Test

## xUnit 기반 Unit Test 구현

### 테스트 프로젝트 설정

<div class="code-section">

**SemiconductorHMI.UnitTests.csproj**

---
# 기초 실습: Unit Test 및 Integration Test
```xml
<Project Sdk="Microsoft.NET.Sdk">

 <PropertyGroup>
 <TargetFramework>net6.0</TargetFramework>
 <ImplicitUsings>enable</ImplicitUsings>
 <Nullable>enable</Nullable>
 <IsPackable>false</IsPackable>
 </PropertyGroup>

 <ItemGroup>
 <PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.3.2" />
 <PackageReference Include="xunit" Version="2.4.2" />
 <PackageReference Include="xunit.runner.visualstudio" Version="2.4.3">
 <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
 <PrivateAssets>all</PrivateAssets>
 </PackageReference>
 <PackageReference Include="coverlet.collector" Version="3.1.2" />
 <PackageReference Include="Moq" Version="4.18.4" />
 <PackageReference Include="FluentAssertions" Version="6.8.0" />
 <PackageReference Include="AutoFixture" Version="4.18.0" />
 <PackageReference Include="Microsoft.Extensions.DependencyInjection" Version="6.0.0" />
 </ItemGroup>

 <ItemGroup>
 <ProjectReference Include="..\SemiconductorHMI.Core\SemiconductorHMI.Core.csproj" />
 <ProjectReference Include="..\SemiconductorHMI.Services\SemiconductorHMI.Services.csproj" />
 </ItemGroup>

</Project>
```

---
# 기초 실습: Unit Test 및 Integration Test
</div>

**배경 설명**

반도체 Fab에서는 장비가 24/7 가동되며 웨이퍼당 수백만원의 비용이 발생합니다. 테스트 없이 배포된 코드의 버그는 생산 라인 전체를 정지시킬 수 있습니다. xUnit 기반 자동화 테스트는 코드 변경 시 즉시 회귀 테스트를 수행하여 품질을 보장합니다.

**핵심 개념**

xUnit은 .NET의 대표적인 테스트 프레임워크로, Fact와 Theory 속성으로 테스트를 정의합니다. Moq는 Mock 객체를 생성하여 의존성을 격리하고, FluentAssertions는 가독성 높은 검증문을 제공합니다. AutoFixture는 테스트 데이터를 자동 생성하여 반복 코드를 줄입니다. 이 조합으로 독립적이고 반복 가능한 테스트를 작성할 수 있습니다.

**코드 해설**

- Line 24-25: xUnit 2.4.2는 .NET 6 호환 테스트 프레임워크
- Line 31: Moq 4.18.4로 인터페이스 기반 Mock 객체 생성
- Line 32: FluentAssertions 6.8.0으로 `.Should().Be()` 스타일 검증
- Line 33: AutoFixture 4.18.0으로 테스트 데이터 자동 생성
- Line 30: coverlet.collector로 코드 커버리지 측정 (목표 80% 이상)

**실제 사례**

삼성전자 Fab에서는 CVD 장비 제어 소프트웨어를 배포하기 전 xUnit 테스트 5,000개 이상을 실행합니다. 평균 온도 150-800°C, 압력 0.1-10 Torr 범위에서 테스트 데이터를 생성하여 엣지 케이스를 검증합니다. 테스트 실행 시간은 2분 이내로 제한하여 빠른 피드백을 보장합니다.

**Week 1 HCI 이론 연결**

밀러의 법칙(7±2 chunk)에 따라 테스트 하나는 하나의 기능만 검증해야 합니다. 테스트 이름은 "무엇을_어떤조건에서_어떤결과"로 작성하여 인지 부하를 줄입니다. 색상 코딩(녹색=성공, 빨간색=실패)은 시각적 피드백으로 신속한 의사결정을 지원합니다.

```mermaid
graph TD
    A[테스트 실행] --> B{의존성 주입}
    B --> C[Mock 객체 생성]
    B --> D[실제 객체 생성]
    C --> E[Arrange: 테스트 설정]
    D --> E
    E --> F[Act: 메서드 실행]
    F --> G[Assert: 결과 검증]
    G --> H{통과?}
    H -->|Yes| I[녹색: 성공]
    H -->|No| J[빨간색: 실패]
    J --> K[디버깅 및 수정]
    K --> A
```

### Process Controller 테스트

<div class="code-section">

**ProcessControllerTests.cs**

---
# 기초 실습: Unit Test 및 Integration Test
```csharp
using AutoFixture;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using SemiconductorHMI.Core.Interfaces;
using SemiconductorHMI.Core.Models;
using SemiconductorHMI.Services;
using Xunit;

namespace SemiconductorHMI.UnitTests.Services
{
 public class ProcessControllerTests : IDisposable
 {
 private readonly Fixture fixture;
 private readonly Mock<ITemperatureSensor> mockTemperatureSensor;
 private readonly Mock<IPressureSensor> mockPressureSensor;
 private readonly Mock<IDataLogger> mockDataLogger;
 private readonly Mock<IAlarmSystem> mockAlarmSystem;
 private readonly Mock<ILogger<ProcessController>> mockLogger;
 private readonly ProcessController processController;

 public ProcessControllerTests()
 {
 fixture = new Fixture();
 mockTemperatureSensor = new Mock<ITemperatureSensor>();
 mockPressureSensor = new Mock<IPressureSensor>();
 mockDataLogger = new Mock<IDataLogger>();
 mockAlarmSystem = new Mock<IAlarmSystem>();
 mockLogger = new Mock<ILogger<ProcessController>>();

 processController = new ProcessController(
 mockTemperatureSensor.Object,
 mockPressureSensor.Object,
 mockDataLogger.Object,
 mockAlarmSystem.Object,
 mockLogger.Object);
 }

 [Fact]
 public async Task StartProcessAsync_ValidParameters_ShouldReturnSuccess()
 {
 // Arrange
 var processParams = fixture.Build<ProcessParameters>()
 .With(p => p.TargetTemperature, 150.0)
 .With(p => p.PressureSetpoint, 1.5)
 .With(p => p.Duration, TimeSpan.FromMinutes(30))
 .Create();

 mockTemperatureSensor.Setup(x => x.ReadTemperatureAsync())
 .ReturnsAsync(25.0); // 초기 온도

 mockPressureSensor.Setup(x => x.ReadPressureAsync())
 .ReturnsAsync(1.0); // 초기 압력

 // Act
 var result = await processController.StartProcessAsync(processParams);

 // Assert
 result.Should().NotBeNull();
 result.IsSuccess.Should().BeTrue();
 result.ProcessId.Should().NotBeEmpty();

 // 데이터 로깅이 시작되었는지 확인
 mockDataLogger.Verify(x => x.StartLoggingAsync(It.IsAny<string>()), Times.Once);
 }

 [Theory]
 [InlineData(-50.0)] // 너무 낮은 온도
 [InlineData(1000.0)] // 너무 높은 온도
 public async Task StartProcessAsync_InvalidTemperature_ShouldReturnFailure(double invalidTemperature)
 {
 // Arrange
 var processParams = fixture.Build<ProcessParameters>()
 .With(p => p.TargetTemperature, invalidTemperature)
 .Create();

 // Act
 var result = await processController.StartProcessAsync(processParams);

 // Assert
 result.IsSuccess.Should().BeFalse();
 result.ErrorMessage.Should().Contain("temperature");
 }

 [Fact]
 public async Task MonitorProcess_TemperatureExceedsThreshold_ShouldTriggerAlarm()
 {
 // Arrange
 var processId = Guid.NewGuid().ToString();
 var highTemperature = 200.0;
 var threshold = 180.0;

 mockTemperatureSensor.Setup(x => x.ReadTemperatureAsync())
 .ReturnsAsync(highTemperature);

 // 프로세스 시작
 var processParams = fixture.Build<ProcessParameters>()
 .With(p => p.TargetTemperature, 150.0)
 .With(p => p.MaxTemperatureThreshold, threshold)
 .Create();

 await processController.StartProcessAsync(processParams);

 // Act
 await Task.Delay(100); // 모니터링 사이클 대기

 // Assert
 mockAlarmSystem.Verify(x => x.TriggerAlarmAsync(
 It.Is<Alarm>(a => a.Type == AlarmType.HighTemperature &&
 a.Value == highTemperature)),
 Times.AtLeastOnce);
 }

 [Fact]
 public async Task StopProcessAsync_RunningProcess_ShouldStopSuccessfully()
 {
 // Arrange
 var processParams = fixture.Create<ProcessParameters>();
 var startResult = await processController.StartProcessAsync(processParams);

 // Act
 var stopResult = await processController.StopProcessAsync(startResult.ProcessId);

 // Assert
 stopResult.Should().BeTrue();
 mockDataLogger.Verify(x => x.StopLoggingAsync(startResult.ProcessId), Times.Once);
 }

 [Fact]
 public async Task GetProcessStatus_ExistingProcess_ShouldReturnCorrectStatus()
 {
 // Arrange
 var processParams = fixture.Create<ProcessParameters>();
 var startResult = await processController.StartProcessAsync(processParams);

 // Act
 var status = await processController.GetProcessStatusAsync(startResult.ProcessId);

 // Assert
 status.Should().NotBeNull();
 status.ProcessId.Should().Be(startResult.ProcessId);
 status.Status.Should().Be(ProcessStatus.Running);
 }

 [Fact]
 public void Constructor_NullTemperatureSensor_ShouldThrowArgumentNullException()
 {
 // Act & Assert
 Assert.Throws<ArgumentNullException>(() => new ProcessController(
 null,
 mockPressureSensor.Object,
 mockDataLogger.Object,
 mockAlarmSystem.Object,
 mockLogger.Object));
 }

 public void Dispose()
 {
 processController?.Dispose();
 }
 }
}
```

---
# 기초 실습: Unit Test 및 Integration Test
</div>

**배경 설명**

반도체 공정에서는 온도, 압력 등 센서 데이터를 실시간 수집하며, 제어 로직 오류는 웨이퍼 손실로 이어집니다. Unit Test는 외부 하드웨어 없이 제어 로직을 격리 검증하여, 개발 속도를 높이고 하드웨어 의존성을 제거합니다.

**핵심 개념**

Mock 객체는 실제 센서 인터페이스를 시뮬레이션하여 특정 값을 반환합니다. Arrange-Act-Assert 패턴으로 테스트를 구조화하고, Theory와 InlineData로 여러 입력값을 효율적으로 테스트합니다. Verify로 메서드 호출 여부를 검증하여 부수 효과를 확인합니다.

**코드 해설**

- Line 81-86: AutoFixture로 Mock 객체 자동 생성, 테스트 초기화 간소화
- Line 100-104: `.Build().With()`로 특정 속성만 지정, 나머지는 자동 생성
- Line 106-110: `.Setup().ReturnsAsync()`로 비동기 Mock 응답 정의
- Line 125-126: Theory + InlineData로 경계값 테스트 (-50°C, 1000°C)
- Line 165-168: `.Verify()`로 알람 시스템 호출 검증, Times.AtLeastOnce로 최소 호출 확인

**실제 사례**

TSMC Fab에서는 Etcher 장비의 RF Power 제어 로직을 테스트할 때, 실제 하드웨어 없이 Mock으로 0-3000W 범위를 검증합니다. 온도 임계값(180°C) 초과 시 알람 트리거를 0.1초 이내에 검증하여 실시간 응답성을 보장합니다. 연간 50,000회 이상의 회귀 테스트를 자동 실행합니다.

**Week 1 HCI 이론 연결**

Fitts의 법칙에 따라 테스트 실패 메시지는 명확하고 구체적이어야 합니다. "temperature" 키워드를 에러 메시지에 포함하여 문제 위치를 즉시 파악하게 합니다. 테스트 실행 결과는 1초 이내에 표시되어 빠른 피드백 루프를 형성합니다.

```mermaid
sequenceDiagram
    participant Test as 테스트 코드
    participant PC as ProcessController
    participant MockTemp as Mock 온도센서
    participant MockAlarm as Mock 알람시스템

    Test->>PC: StartProcessAsync(params)
    PC->>MockTemp: ReadTemperatureAsync()
    MockTemp-->>PC: 25.0°C
    PC->>PC: 프로세스 시작

    loop 모니터링
        PC->>MockTemp: ReadTemperatureAsync()
        MockTemp-->>PC: 200.0°C (임계값 초과)
        PC->>MockAlarm: TriggerAlarmAsync(HighTemp)
        MockAlarm-->>PC: 알람 활성화
    end

    Test->>MockAlarm: Verify 호출 확인
    MockAlarm-->>Test: Times.AtLeastOnce 검증
```

### Data Service 테스트

<div class="code-section">

**EquipmentDataServiceTests.cs**

---
# 기초 실습: Unit Test 및 Integration Test
```csharp
public class EquipmentDataServiceTests : IAsyncLifetime
{
 private readonly ServiceProvider serviceProvider;
 private readonly IEquipmentDataService dataService;
 private readonly ITestDatabase testDatabase;

 public EquipmentDataServiceTests()
 {
 var services = new ServiceCollection();

 // In-Memory 데이터베이스 설정
 services.AddDbContext<EquipmentDbContext>(options =>
 options.UseInMemoryDatabase(Guid.NewGuid().ToString()));

 services.AddScoped<IEquipmentDataService, EquipmentDataService>();
 services.AddScoped<ITestDatabase, TestDatabase>();

 serviceProvider = services.BuildServiceProvider();
 dataService = serviceProvider.GetRequiredService<IEquipmentDataService>();
 testDatabase = serviceProvider.GetRequiredService<ITestDatabase>();
 }

 public async Task InitializeAsync()
 {
 await testDatabase.SeedTestDataAsync();
 }

 [Fact]
 public async Task GetEquipmentByIdAsync_ExistingId_ShouldReturnEquipment()
 {
 // Arrange
 var equipmentId = "CVD-001";

 // Act
 var equipment = await dataService.GetEquipmentByIdAsync(equipmentId);

 // Assert
 equipment.Should().NotBeNull();
 equipment.Id.Should().Be(equipmentId);
 equipment.Type.Should().Be(EquipmentType.CVD);
 }

 [Fact]
 public async Task SaveSensorDataAsync_ValidData_ShouldPersist()
 {
 // Arrange
 var sensorData = new SensorData
 {
 EquipmentId = "CVD-001",
 SensorType = SensorType.Temperature,
 Value = 150.5,
 Timestamp = DateTime.UtcNow,
 Unit = "°C"
 };

 // Act
 await dataService.SaveSensorDataAsync(sensorData);

 // Assert
 var savedData = await dataService.GetSensorDataAsync(
 sensorData.EquipmentId,
 sensorData.SensorType,
 DateTime.UtcNow.AddMinutes(-1),
 DateTime.UtcNow.AddMinutes(1));

 savedData.Should().ContainSingle();
 savedData.First().Value.Should().Be(sensorData.Value);
 }

 [Fact]
 public async Task GetEquipmentStatisticsAsync_ValidDateRange_ShouldReturnStatistics()
 {
 // Arrange
 var equipmentId = "CVD-001";
 var startDate = DateTime.UtcNow.AddDays(-7);
 var endDate = DateTime.UtcNow;

 // Act
 var statistics = await dataService.GetEquipmentStatisticsAsync(
 equipmentId, startDate, endDate);

 // Assert
 statistics.Should().NotBeNull();
 statistics.EquipmentId.Should().Be(equipmentId);
 statistics.UpTime.Should().BeGreaterThan(TimeSpan.Zero);
 statistics.TotalWafersProcessed.Should().BeGreaterThan(0);
 }

 [Theory]
 [InlineData(null)]
 [InlineData("")]
 [InlineData(" ")]
 public async Task GetEquipmentByIdAsync_InvalidId_ShouldThrowArgumentException(string invalidId)
 {
 // Act & Assert
 await Assert.ThrowsAsync<ArgumentException>(() =>
 dataService.GetEquipmentByIdAsync(invalidId));
 }

 public async Task DisposeAsync()
 {
 await serviceProvider.DisposeAsync();
 }
}
```

---
# 기초 실습: Unit Test 및 Integration Test
</div>

**배경 설명**

반도체 장비는 데이터베이스에 공정 데이터를 저장하며, SQL 쿼리 오류나 트랜잭션 실패는 데이터 손실을 유발합니다. In-Memory 데이터베이스로 실제 DB 없이 데이터 계층을 테스트하여, 개발 환경 구축 복잡도를 줄이고 테스트 속도를 향상시킵니다.

**핵심 개념**

In-Memory DB는 메모리에만 존재하는 경량 데이터베이스로, 각 테스트마다 독립적인 DB 인스턴스를 생성합니다. IAsyncLifetime으로 테스트 전후 초기화/정리를 비동기로 처리하고, ServiceProvider로 의존성 주입을 테스트에 적용합니다. FluentAssertions의 `.Should().ContainSingle()`로 결과를 직관적으로 검증합니다.

**코드 해설**

- Line 247: `Guid.NewGuid()`로 테스트마다 독립적인 DB 생성, 병렬 실행 지원
- Line 257-260: InitializeAsync로 테스트 데이터 Seeding, 일관된 초기 상태 보장
- Line 294-301: 데이터 저장 후 시간 범위 쿼리로 검증, 실제 시나리오 시뮬레이션
- Line 323-326: Theory + InlineData(null, "", " ")로 잘못된 입력 처리 검증
- Line 335-337: DisposeAsync로 리소스 정리, 메모리 누수 방지

**실제 사례**

Intel Fab에서는 CVD 장비의 웨이퍼 처리 통계(Uptime, 처리량)를 In-Memory DB로 테스트합니다. 실제 DB는 PostgreSQL이지만 테스트는 EF Core In-Memory Provider를 사용하여 10초 이내에 완료됩니다. 일주일 데이터 범위를 쿼리하여 99.9% Uptime, 웨이퍼당 1.2분 처리 시간을 검증합니다.

**Week 1 HCI 이론 연결**

정보 처리 모델에 따라 테스트는 입력(Sensor Data) → 처리(DB 저장) → 출력(통계 조회) 단계로 구조화됩니다. 각 단계는 독립적으로 검증 가능하며, 테스트 이름으로 의도를 명확히 전달하여 인지 부하를 최소화합니다.

```mermaid
graph LR
    A[테스트 시작] --> B[ServiceProvider 생성]
    B --> C[In-Memory DB 구성]
    C --> D[DataService 주입]
    D --> E[InitializeAsync]
    E --> F[테스트 데이터 Seed]
    F --> G[Act: 메서드 실행]
    G --> H{검증}
    H -->|SaveData| I[데이터 저장 확인]
    H -->|GetData| J[쿼리 결과 확인]
    H -->|Statistics| K[통계 계산 확인]
    I --> L[DisposeAsync]
    J --> L
    K --> L
    L --> M[DB 메모리 해제]
```

## Integration Test 구현

### 테스트 환경 설정

<div class="code-section">

**IntegrationTestBase.cs**

---
# 기초 실습: Unit Test 및 Integration Test
```csharp
public class IntegrationTestBase : IAsyncLifetime
{
 protected readonly WebApplicationFactory<Program> Factory;
 protected readonly HttpClient Client;
 protected readonly IServiceScope Scope;
 protected readonly EquipmentDbContext DbContext;

 public IntegrationTestBase()
 {
 Factory = new WebApplicationFactory<Program>()
 .WithWebHostBuilder(builder =>
 {
 builder.ConfigureServices(services =>
 {
 // 실제 데이터베이스를 테스트용으로 교체
 var descriptor = services.SingleOrDefault(
 d => d.ServiceType == typeof(DbContextOptions<EquipmentDbContext>));

 if (descriptor != null)
 services.Remove(descriptor);

 services.AddDbContext<EquipmentDbContext>(options =>
 options.UseInMemoryDatabase("TestDb"));

 // 외부 의존성을 Mock으로 교체
 services.AddSingleton<IEmailService, MockEmailService>();
 services.AddSingleton<IHardwareInterface, MockHardwareInterface>();
 });

 builder.UseEnvironment("Testing");
 });

 Client = Factory.CreateClient();
 Scope = Factory.Services.CreateScope();
 DbContext = Scope.ServiceProvider.GetRequiredService<EquipmentDbContext>();
 }

 public async Task InitializeAsync()
 {
 await DbContext.Database.EnsureCreatedAsync();
 await SeedTestDataAsync();
 }

 protected virtual async Task SeedTestDataAsync()
 {
 var equipment = new Equipment
 {
 Id = "CVD-001",
 Name = "CVD Chamber 1",
 Type = EquipmentType.CVD,
 Location = "Fab1-Bay2",
 Status = EquipmentStatus.Running,
 InstallDate = DateTime.UtcNow.AddYears(-2)
 };

 DbContext.Equipment.Add(equipment);
 await DbContext.SaveChangesAsync();
 }

 public async Task DisposeAsync()
 {
 Scope.Dispose();
 await Factory.DisposeAsync();
 }
}
```

---
# 기초 실습: Unit Test 및 Integration Test
</div>

**배경 설명**

반도체 HMI는 Web API로 프론트엔드와 통신하며, 잘못된 HTTP 응답이나 JSON 직렬화 오류는 UI 오작동을 유발합니다. Integration Test는 컨트롤러부터 데이터베이스까지 전체 스택을 검증하여, 컴포넌트 간 통합 문제를 조기 발견합니다.

**핵심 개념**

WebApplicationFactory는 테스트용 In-Process 웹 서버를 생성하여 실제 HTTP 요청을 시뮬레이션합니다. `WithWebHostBuilder`로 테스트 환경에 맞게 서비스를 교체하고, In-Memory DB와 Mock 하드웨어로 외부 의존성을 제거합니다. 실제 라우팅, 인증, 직렬화 로직이 모두 실행됩니다.

**코드 해설**

- Line 365-386: WebApplicationFactory로 프로그램 호스팅, UseEnvironment("Testing")로 테스트 설정 로드
- Line 371-378: 실제 DB를 In-Memory로 교체, 외부 서비스를 Mock으로 대체
- Line 400-413: SeedTestDataAsync로 공통 테스트 데이터 준비 (CVD-001 장비)
- Line 389-391: CreateClient()로 HttpClient 생성, 실제 HTTP 프로토콜 사용
- Line 415-419: DisposeAsync로 웹 서버 및 DB 정리, 테스트 격리 보장

**실제 사례**

Micron Fab에서는 장비 제어 API를 Integration Test로 검증합니다. GET /api/equipment, POST /api/start-process 등 20개 엔드포인트를 30초 이내에 테스트하며, HTTP 상태 코드, JSON 스키마, 응답 시간(<200ms)을 검증합니다. 실제 환경과 99% 일치하는 테스트로 배포 전 신뢰성을 확보합니다.

**Week 1 HCI 이론 연결**

Norman의 7단계 행동 모델에서 Integration Test는 목표 설정(API 호출) → 실행(HTTP 요청) → 평가(응답 검증) 단계를 자동화합니다. 테스트는 사용자 시나리오를 따라 설계되어, 실제 사용 패턴을 반영합니다.

```mermaid
sequenceDiagram
    participant TF as WebApplicationFactory
    participant API as Controller
    participant Service as DataService
    participant DB as In-Memory DB
    participant Mock as Mock Services

    TF->>TF: 테스트 환경 구성
    TF->>DB: In-Memory DB 생성
    TF->>Mock: Mock 서비스 등록
    TF->>API: HTTP 클라이언트 생성

    Note over TF,DB: 테스트 실행
    TF->>API: GET /api/equipment/CVD-001
    API->>Service: GetEquipmentByIdAsync()
    Service->>DB: SELECT * FROM Equipment
    DB-->>Service: Equipment 데이터
    Service-->>API: Equipment DTO
    API-->>TF: 200 OK + JSON

    TF->>TF: 응답 검증
    TF->>DB: 정리 및 삭제
```

### API 통합 테스트

<div class="code-section">

**EquipmentControllerIntegrationTests.cs**

---
# 기초 실습: Unit Test 및 Integration Test
```csharp
public class EquipmentControllerIntegrationTests : IntegrationTestBase
{
 [Fact]
 public async Task GetEquipment_ExistingId_ShouldReturnOkWithEquipment()
 {
 // Arrange
 var equipmentId = "CVD-001";

 // Act
 var response = await Client.GetAsync($"/api/equipment/{equipmentId}");

 // Assert
 response.StatusCode.Should().Be(HttpStatusCode.OK);

 var content = await response.Content.ReadAsStringAsync();
 var equipment = JsonSerializer.Deserialize<Equipment>(content, new JsonSerializerOptions
 {
 PropertyNamingPolicy = JsonNamingPolicy.CamelCase
 });

 equipment.Should().NotBeNull();
 equipment.Id.Should().Be(equipmentId);
 }

 [Fact]
 public async Task StartProcess_ValidRequest_ShouldReturnAccepted()
 {
 // Arrange
 var equipmentId = "CVD-001";
 var processRequest = new ProcessStartRequest
 {
 TargetTemperature = 150.0,
 PressureSetpoint = 1.5,
 Duration = TimeSpan.FromMinutes(30),
 ProcessType = "StandardCVD"
 };

 var jsonContent = JsonSerializer.Serialize(processRequest);
 var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");

 // Act
 var response = await Client.PostAsync($"/api/equipment/{equipmentId}/start-process", content);

 // Assert
 response.StatusCode.Should().Be(HttpStatusCode.Accepted);

 var responseContent = await response.Content.ReadAsStringAsync();
 var result = JsonSerializer.Deserialize<ProcessStartResponse>(responseContent, new JsonSerializerOptions
 {
 PropertyNamingPolicy = JsonNamingPolicy.CamelCase
 });

 result.ProcessId.Should().NotBeEmpty();
 result.EstimatedDuration.Should().Be(processRequest.Duration);
 }

 [Fact]
 public async Task GetSensorData_ValidDateRange_ShouldReturnData()
 {
 // Arrange
 var equipmentId = "CVD-001";
 var startDate = DateTime.UtcNow.AddHours(-1);
 var endDate = DateTime.UtcNow;

 // Test data 추가
 await AddTestSensorDataAsync(equipmentId);

 // Act
 var response = await Client.GetAsync(
 $"/api/equipment/{equipmentId}/sensor-data?" +
 $"startDate={startDate:yyyy-MM-ddTHH:mm:ss}&" +
 $"endDate={endDate:yyyy-MM-ddTHH:mm:ss}");

 // Assert
 response.StatusCode.Should().Be(HttpStatusCode.OK);

 var content = await response.Content.ReadAsStringAsync();
 var sensorData = JsonSerializer.Deserialize<List<SensorDataDto>>(content, new JsonSerializerOptions
 {
 PropertyNamingPolicy = JsonNamingPolicy.CamelCase
 });

 sensorData.Should().NotBeEmpty();
 }

 private async Task AddTestSensorDataAsync(string equipmentId)
 {
 var testData = new[]
 {
 new SensorData
 {
 EquipmentId = equipmentId,
 SensorType = SensorType.Temperature,
 Value = 150.5,
 Timestamp = DateTime.UtcNow.AddMinutes(-30),
 Unit = "°C"
 },
 new SensorData
 {
 EquipmentId = equipmentId,
 SensorType = SensorType.Pressure,
 Value = 1.5,
 Timestamp = DateTime.UtcNow.AddMinutes(-30),
 Unit = "Torr"
 }
 };

 DbContext.SensorData.AddRange(testData);
 await DbContext.SaveChangesAsync();
 }
}
```

---
# 기초 실습: Unit Test 및 Integration Test
</div>

**배경 설명**

반도체 Fab의 API는 장비 상태 조회, 공정 시작, 센서 데이터 수집 등 핵심 기능을 제공합니다. API 통합 테스트는 엔드포인트, 라우팅, JSON 직렬화, 데이터베이스 통신을 종합적으로 검증하여 배포 전 시스템 전체의 동작을 확인합니다.

**핵심 개념**

HttpClient로 실제 HTTP 요청을 생성하고, StatusCode와 JSON 응답을 검증합니다. JsonSerializer로 응답을 DTO로 역직렬화하여 타입 안정성을 확보하고, StringContent로 요청 본문을 전송합니다. 여러 엔드포인트를 순차적으로 테스트하여 E2E 시나리오를 검증합니다.

**코드 해설**

- Line 445: GetAsync()로 GET 요청, response.StatusCode로 HTTP 상태 검증
- Line 451-454: JsonSerializer.Deserialize()로 응답 JSON을 강타입 객체로 변환
- Line 473-474: StringContent로 JSON 본문 생성, UTF-8 인코딩 및 Content-Type 설정
- Line 477: PostAsync()로 POST 요청, 202 Accepted로 비동기 작업 시작 확인
- Line 521-545: AddTestSensorDataAsync()로 테스트 데이터 Seeding, 독립적 테스트 환경 보장

**실제 사례**

SK하이닉스 Fab에서는 CMP 장비 API를 테스트할 때, 장비 목록 조회(GET) → 장비 선택(GET by ID) → 공정 시작(POST) → 센서 데이터 조회(GET)의 E2E 시나리오를 검증합니다. 온도 150.5°C, 압력 1.5 Torr의 실제 센서 값을 테스트 데이터로 사용하며, 응답 시간 100ms 이내를 요구합니다.

**Week 1 HCI 이론 연결**

사용자 중심 설계 원칙에 따라 API 테스트는 실제 운영자의 작업 흐름을 따릅니다. 장비 선택 → 파라미터 설정 → 공정 시작 → 결과 확인의 순서로 테스트하여, 인터페이스의 일관성과 사용성을 검증합니다. HTTP 상태 코드는 명확한 피드백을 제공합니다.

```mermaid
graph TD
    A[테스트 시작] --> B[GET /api/equipment/CVD-001]
    B --> C{StatusCode 200?}
    C -->|Yes| D[JSON Deserialize]
    C -->|No| E[테스트 실패]
    D --> F[POST /api/equipment/CVD-001/start-process]
    F --> G{StatusCode 202?}
    G -->|Yes| H[ProcessId 검증]
    G -->|No| E
    H --> I[GET /api/equipment/CVD-001/sensor-data]
    I --> J{데이터 존재?}
    J -->|Yes| K[센서 값 검증]
    J -->|No| E
    K --> L[테스트 성공]

    style L fill:#90EE90
    style E fill:#FFB6C1
```

---

