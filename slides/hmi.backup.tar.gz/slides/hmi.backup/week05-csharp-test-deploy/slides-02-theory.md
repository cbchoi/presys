# 이론 강의: 테스트 전략 및 CI/CD

---
## C# 기초 개념 복습

### 객체지향 프로그래밍의 4대 원칙

**OOP (Object-Oriented Programming)의 핵심 개념**

<div class="grid grid-cols-2 gap-8">
<div>

**1. 캡슐화 (Encapsulation)**:
- 데이터와 동작을 하나로 묶음
- 정보 은닉 (Information Hiding)
- 접근 제어자 활용

---
## C# 기초 개념 복습
```csharp
public class TemperatureSensor
{
 // private: 외부 접근 불가
 private double _currentTemperature;
 private const double MIN_TEMP = -273.15;
 private const double MAX_TEMP = 1000.0;

 // public: 검증된 방법으로만 접근
 public double CurrentTemperature
 {
 get => _currentTemperature;
 set
 {
 if (value < MIN_TEMP || value > MAX_TEMP)
 throw new ArgumentOutOfRangeException();
 _currentTemperature = value;
 }
 }

 // public method: 제어된 인터페이스
 public void Calibrate(double referenceValue)
 {
 ValidateCalibration(referenceValue);
 _currentTemperature = referenceValue;
 }

 // private: 내부 구현 숨김
 private void ValidateCalibration(double value)
 {
 // 검증 로직
 }
}
```

---
## C# 기초 개념 복습
**장점**:
- 내부 구현 변경 시 외부 코드 영향 없음
- 데이터 무결성 보장
- 유지보수 용이

</div>
<div>

**2. 추상화 (Abstraction)**:
- 복잡한 시스템을 단순화
- 인터페이스와 추상 클래스 활용
- 구현과 명세 분리

---
## C# 기초 개념 복습
```csharp
// 인터페이스: 계약(Contract) 정의
public interface ISensor
{
 string SensorId { get; }
 Task<double> ReadValueAsync();
 Task<bool> CalibrateAsync(double reference);
 event EventHandler<SensorEventArgs> ValueChanged;
}

// 구체 구현: 다양한 센서 타입
public class TemperatureSensor : ISensor
{
 public string SensorId { get; }

 public async Task<double> ReadValueAsync()
 {
 // 온도 센서 구현
 return await ReadI2CTemperature();
 }

 public async Task<bool> CalibrateAsync(double reference)
 {
 // 온도 센서 보정
 return true;
 }

 public event EventHandler<SensorEventArgs> ValueChanged;
}

public class PressureSensor : ISensor
{
 public string SensorId { get; }

 public async Task<double> ReadValueAsync()
 {
 // 압력 센서 구현
 return await ReadAnalogPressure();
 }

 // ... 다른 구현
}

// 사용: 구체 타입에 의존하지 않음
public class DataLogger
{
 private readonly List<ISensor> _sensors;

 public async Task LogAllSensors()
 {
 foreach (var sensor in _sensors)
 {
 // ISensor 인터페이스만 의존
 var value = await sensor.ReadValueAsync();
 Log($"{sensor.SensorId}: {value}");
 }
 }
}
```

---
## C# 기초 개념 복습
**장점**:
- 복잡도 감소
- 확장성 향상
- 코드 재사용성

</div>
</div>
---
### 객체지향 프로그래밍의 4대 원칙 (계속)

<div class="grid grid-cols-2 gap-8">
<div>

**3. 상속 (Inheritance)**:
- 기존 클래스 기능 재사용
- "is-a" 관계 표현
- 코드 중복 제거

---
### 객체지향 프로그래밍의 4대 원칙 (계속)
```csharp
// 베이스 클래스: 공통 기능
public abstract class Equipment
{
 public string Id { get; set; }
 public string Name { get; set; }
 public EquipmentState State { get; protected set; }
 public DateTime LastUpdate { get; protected set; }

 // 공통 메서드
 public virtual void Initialize()
 {
 State = EquipmentState.Idle;
 LastUpdate = DateTime.UtcNow;
 OnInitialized();
 }

 // 추상 메서드: 하위 클래스 구현 필수
 protected abstract void OnInitialized();

 // 가상 메서드: 재정의 가능
 public virtual async Task StartAsync()
 {
 if (State != EquipmentState.Idle)
 throw new InvalidOperationException();

 State = EquipmentState.Running;
 await OnStartAsync();
 }

 protected virtual Task OnStartAsync()
 {
 return Task.CompletedTask;
 }
}

// 파생 클래스: Etcher
public class Etcher : Equipment
{
 public double RFPower { get; set; }
 public double Pressure { get; set; }

 protected override void OnInitialized()
 {
 Console.WriteLine("Etcher initialized");
 RFPower = 0;
 Pressure = 0;
 }

 protected override async Task OnStartAsync()
 {
 await base.OnStartAsync(); // 베이스 동작 먼저
 await RampUpRFPower();
 await StabilizePressure();
 }

 private async Task RampUpRFPower()
 {
 // Etcher 특화 로직
 }
}

// 파생 클래스: CVD
public class CVDEquipment : Equipment
{
 public double Temperature { get; set; }
 public double GasFlow { get; set; }

 protected override void OnInitialized()
 {
 Console.WriteLine("CVD initialized");
 Temperature = 25.0;
 GasFlow = 0;
 }

 protected override async Task OnStartAsync()
 {
 await base.OnStartAsync();
 await HeatUpChamber();
 await StartGasFlow();
 }
}
```

---
### 객체지향 프로그래밍의 4대 원칙 (계속)
</div>
<div>

**4. 다형성 (Polymorphism)**:
- 같은 인터페이스, 다른 구현
- 런타임에 동작 결정
- 유연한 코드 작성

---
### 객체지향 프로그래밍의 4대 원칙 (계속)
```csharp
// 다형성 예제: 동일한 메서드, 다른 동작
public class EquipmentController
{
 private readonly List<Equipment> _equipmentList;

 public async Task StartAllEquipment()
 {
 foreach (var equipment in _equipmentList)
 {
 // 컴파일 타임: Equipment.StartAsync()
 // 런타임: Etcher.StartAsync() 또는
 // CVDEquipment.StartAsync() 호출
 await equipment.StartAsync();
 }
 }

 public void InitializeAll()
 {
 foreach (var equipment in _equipmentList)
 {
 // 각 장비의 OnInitialized() 호출
 equipment.Initialize();
 }
 }
}

// 사용 예제
var controller = new EquipmentController();
controller.AddEquipment(new Etcher { Id = "E001" });
controller.AddEquipment(new CVDEquipment { Id = "CVD001" });
controller.AddEquipment(new Etcher { Id = "E002" });

// 다형성: 각 장비 타입에 맞는 동작 실행
await controller.StartAllEquipment();
// E001: Etcher 시작 로직
// CVD001: CVD 시작 로직
// E002: Etcher 시작 로직
```

---
### 객체지향 프로그래밍의 4대 원칙 (계속)
**메서드 오버로딩 (Compile-time Polymorphism)**:
```csharp
public class DataLogger
{
 // 같은 이름, 다른 매개변수
 public void Log(string message)
 {
 Console.WriteLine($"[INFO] {message}");
 }

 public void Log(string message, Exception ex)
 {
 Console.WriteLine($"[ERROR] {message}: {ex.Message}");
 }

 public void Log(string message, params object[] args)
 {
---
### 객체지향 프로그래밍의 4대 원칙 (계속)
 Console.WriteLine($"[INFO] {string.Format(message, args)}");
 }
}

// 컴파일러가 적절한 메서드 선택
logger.Log("System started");
logger.Log("Failed to connect", new Exception("timeout"));
logger.Log("Processing {0} items at {1}", 100, DateTime.Now);
```

</div>
</div>
---
## RAII와 리소스 관리

### RAII (Resource Acquisition Is Initialization)

**C#의 IDisposable 패턴으로 구현되는 RAII**

<div class="grid grid-cols-2 gap-8">
<div>

**RAII 핵심 개념**:
- 객체 생성 시 리소스 획득
- 객체 소멸 시 리소스 해제
- 예외 안전성 보장
- 메모리 누수 방지

**문제: 수동 리소스 관리**:
```csharp
// 나쁜 예: 수동 관리
public class DataLogger
{
 private FileStream _fileStream;

---
## RAII와 리소스 관리
 public void Start(string path)
 {
 _fileStream = new FileStream(path, FileMode.Create);
 }

 public void Log(string message)
 {
 var bytes = Encoding.UTF8.GetBytes(message);
 _fileStream.Write(bytes, 0, bytes.Length);
 }

 public void Stop()
 {
 _fileStream?.Close(); // 호출 잊으면 누수!
 }
}

// 사용: 위험!
---
## RAII와 리소스 관리
var logger = new DataLogger();
logger.Start("log.txt");
logger.Log("Test");
// Stop() 호출 잊으면 파일 핸들 누수!
// 예외 발생 시 Stop() 실행 안됨!
```

**문제점**:
- `Stop()` 호출을 잊을 수 있음
- 예외 발생 시 리소스 해제 안됨
- 다중 리소스 관리 복잡

</div>
<div>

**해결: IDisposable 패턴**:
```csharp
// 좋은 예: IDisposable 구현
---
## RAII와 리소스 관리
public class DataLogger : IDisposable
{
 private FileStream _fileStream;
 private StreamWriter _writer;
 private bool _disposed = false;

 public DataLogger(string path)
 {
 // 생성자에서 리소스 획득
 _fileStream = new FileStream(path, FileMode.Create);
 _writer = new StreamWriter(_fileStream);
 }

 public void Log(string message)
 {
 if (_disposed)
 throw new ObjectDisposedException(nameof(DataLogger));

---
## RAII와 리소스 관리
 _writer.WriteLine($"[{DateTime.Now}] {message}");
 _writer.Flush();
 }

 // IDisposable 구현
 public void Dispose()
 {
 Dispose(true);
 GC.SuppressFinalize(this); // Finalizer 호출 방지
 }

 // 실제 리소스 해제 로직
 protected virtual void Dispose(bool disposing)
 {
 if (_disposed) return;

 if (disposing)
 {
---
## RAII와 리소스 관리
 // Managed 리소스 해제
 _writer?.Dispose();
 _fileStream?.Dispose();
 }

 // Unmanaged 리소스 해제 (필요시)

 _disposed = true;
 }

 // Finalizer (가비지 컬렉터 백업)
 ~DataLogger()
 {
 Dispose(false);
 }
}

// 사용: using문으로 자동 해제
using (var logger = new DataLogger("log.txt"))
---
## RAII와 리소스 관리
{
 logger.Log("Test message");
 logger.Log("Another message");
 // 블록 종료 시 자동으로 Dispose() 호출
 // 예외 발생해도 Dispose() 보장!
}

// C# 8.0 이상: using 선언
using var logger = new DataLogger("log.txt");
logger.Log("Test");
// 스코프 종료 시 자동 Dispose()
```

</div>
</div>
---
### IDisposable 패턴 심화

<div class="grid grid-cols-2 gap-8">
<div>

**반도체 HMI에서의 리소스 관리**:

---
### IDisposable 패턴 심화
```csharp
// 센서 연결 관리
public class SensorConnection : IDisposable
{
 private TcpClient _client;
 private NetworkStream _stream;
 private CancellationTokenSource _cts;
 private Task _readTask;
 private bool _disposed;

 public SensorConnection(string host, int port)
 {
 _client = new TcpClient(host, port);
 _stream = _client.GetStream();
 _cts = new CancellationTokenSource();

 // 백그라운드 읽기 시작
 _readTask = ReadDataAsync(_cts.Token);
 }

 private async Task ReadDataAsync(CancellationToken ct)
 {
 var buffer = new byte[1024];
 while (!ct.IsCancellationRequested)
 {
 var bytesRead = await _stream.ReadAsync(
 buffer, 0, buffer.Length, ct);
 ProcessData(buffer, bytesRead);
 }
 }

 public void Dispose()
 {
 if (_disposed) return;

 // 1. 백그라운드 작업 취소
 _cts?.Cancel();

 // 2. 작업 완료 대기 (타임아웃 포함)
 _readTask?.Wait(TimeSpan.FromSeconds(5));

 // 3. 리소스 해제 (순서 중요!)
 _cts?.Dispose();
 _stream?.Dispose();
 _client?.Dispose();

 _disposed = true;
 }
}

// 사용
using var sensor = new SensorConnection("192.168.1.100", 502);
// 자동으로 연결 종료 및 백그라운드 작업 취소
```

---
### IDisposable 패턴 심화
**다중 리소스 관리**:
```csharp
public class EquipmentDataCollector : IDisposable
{
 private readonly List<SensorConnection> _sensors;
 private readonly DatabaseConnection _database;
 private readonly Timer _timer;
 private bool _disposed;

 public EquipmentDataCollector()
 {
 _sensors = new List<SensorConnection>();
 _database = new DatabaseConnection("connStr");
 _timer = new Timer(CollectData, null,
 TimeSpan.Zero, TimeSpan.FromSeconds(1));
 }

---
### IDisposable 패턴 심화
 public void Dispose()
 {
 if (_disposed) return;

 // 타이머 먼저 정지
 _timer?.Dispose();

 // 센서 연결 종료
 foreach (var sensor in _sensors)
 {
 sensor?.Dispose();
 }
 _sensors.Clear();

 // DB 연결 마지막에 해제
 _database?.Dispose();

 _disposed = true;
 }
---
### IDisposable 패턴 심화
}
```

</div>
<div>

**IAsyncDisposable (.NET Core 3.0+)**:

```csharp
// 비동기 리소스 해제
public class AsyncEquipmentController : IAsyncDisposable
{
 private HttpClient _httpClient;
 private SemaphoreSlim _semaphore;

 public AsyncEquipmentController()
 {
 _httpClient = new HttpClient();
 _semaphore = new SemaphoreSlim(1, 1);
---
### IDisposable 패턴 심화
 }

 public async ValueTask DisposeAsync()
 {
 if (_httpClient != null)
 {
 // 진행 중인 요청 완료 대기
 await _semaphore.WaitAsync();
 try
 {
 _httpClient.Dispose();
 _httpClient = null;
 }
 finally
 {
 _semaphore.Release();
---
### IDisposable 패턴 심화
 _semaphore.Dispose();
 }
 }
 }
}

// 사용: await using
await using var controller = new AsyncEquipmentController();
// 비동기 Dispose 호출
---
### IDisposable 패턴 심화
```

**Dispose 패턴 체크리스트**:

 **해야 할 것**:
- `IDisposable` 인터페이스 구현
- `Dispose(bool)` 패턴 사용
- `GC.SuppressFinalize()` 호출
- 여러 번 호출 안전하게 처리
- 리소스 해제 순서 고려

 **하지 말아야 할 것**:
- `Dispose()`에서 예외 던지기
- `Dispose()` 후 객체 사용
- 순환 참조 만들기
- Finalizer 남용

**테스트 시 리소스 관리**:
```csharp
---
### IDisposable 패턴 심화
[TestClass]
public class SensorTests : IDisposable
{
 private SensorConnection _sensor;
 private TestContext _context;

 [TestInitialize]
 public void Setup()
 {
 _sensor = new SensorConnection("localhost", 5000);
 }

 [TestMethod]
 public async Task ReadData_ReturnsValidValue()
 {
 var value = await _sensor.ReadAsync();
 Assert.IsTrue(value > 0);
---
### IDisposable 패턴 심화
 }

 [TestCleanup]
 public void Cleanup()
 {
 _sensor?.Dispose();
 }

 // 전체 테스트 클래스 리소스 해제
 public void Dispose()
 {
 // 추가 정리 작업
 }
}
```

</div>
</div>
---
## 소프트웨어 테스팅 원칙

### Test Pyramid (테스트 피라미드)

**테스트 전략의 기본 원칙**

<div class="grid grid-cols-2 gap-8">
<div>

---
## 소프트웨어 테스팅 원칙
```
 /\
 / \ E2E Tests
 /____\ (UI Tests)
 / \
 / Integration \
 / Tests \
/___________________\
/ \
/ Unit Tests \
/_____________________\
```

**각 계층의 특징**:

---
## 소프트웨어 테스팅 원칙
```csharp
// Unit Test (70-80%)
[TestMethod]
public void CalculateDiscount_WithValidInput_ReturnsCorrectValue()
{
 // Arrange
 var calculator = new PriceCalculator();

 // Act
 var result = calculator.CalculateDiscount(100, 0.1);

 // Assert
 Assert.AreEqual(10.0, result);
}

// Integration Test (15-20%)
[TestMethod]
public async Task SaveEquipmentData_WithDatabase_PersistsCorrectly()
{
 // Arrange
 var repository = new EquipmentRepository(_dbContext);
 var equipment = new Equipment { Id = "E001", Name = "Etcher" };

 // Act
 await repository.SaveAsync(equipment);

 // Assert
 var saved = await repository.GetByIdAsync("E001");
 Assert.IsNotNull(saved);
 Assert.AreEqual("Etcher", saved.Name);
}

// E2E Test (5-10%)
[TestMethod]
public async Task UserCanStartEquipment_ThroughUI()
{
 // Selenium WebDriver로 UI 테스트
 await _driver.Navigate().GoToUrl("/equipment");
 await _driver.FindElement(By.Id("startButton")).Click();

 var status = await _driver.FindElement(By.Id("status")).Text;
 Assert.AreEqual("Running", status);
}
```

---
## 소프트웨어 테스팅 원칙
</div>
<div>

**Test Pyramid 원칙**:

**Unit Tests (기반)**:
- 가장 많은 수 (70-80%)
- 빠른 실행 (밀리초 단위)
- 격리된 테스트
- 낮은 유지보수 비용
- 높은 안정성

**Integration Tests (중간)**:
- 중간 규모 (15-20%)
- 여러 컴포넌트 통합
- DB, 파일, 네트워크 등 실제 리소스 사용
- 적당한 실행 시간 (초 단위)
- 중간 유지보수 비용

---
## 소프트웨어 테스팅 원칙
**E2E Tests (정점)**:
- 소수 (5-10%)
- 전체 시스템 검증
- 사용자 시나리오 테스트
- 느린 실행 (분 단위)
- 높은 유지보수 비용
- 불안정할 수 있음 (flaky tests)

---
## 소프트웨어 테스팅 원칙
**Anti-Pattern (Ice Cream Cone)**:
```
 __________
 / \
| Unit Tests | ← 소수
|____________|
 \ /
 \ E2E / ← 다수 (문제!)
 \______/
```
- E2E에 의존하면 느리고 불안정
- 단위 테스트 부족으로 디버깅 어려움

---
## 소프트웨어 테스팅 원칙
**반도체 HMI에서의 적용**:
- Unit: 비즈니스 로직, 계산, 변환
- Integration: DB 저장, 센서 통신
- E2E: 전체 워크플로우 (장비 시작→데이터 수집→알람)

</div>
</div>
---
### Test-Driven Development (TDD)

**Red-Green-Refactor 사이클**

<div class="grid grid-cols-2 gap-8">
<div>

**TDD 워크플로우**:

```
1. RED → 2. GREEN → 3. REFACTOR
(실패하는 (테스트를 (코드 개선)
 테스트 작성) 통과시킴) ↓
 ↑ |
 ←←←←←←←←←←←←←←←←←←←←←←←←←←←←
```

**Step 1: RED - 실패하는 테스트 작성**

---
### Test-Driven Development (TDD)
```csharp
[TestClass]
public class TemperatureConverterTests
{
 [TestMethod]
 public void CelsiusToFahrenheit_WithZero_Returns32()
 {
 // Arrange
 var converter = new TemperatureConverter();

 // Act
 var result = converter.CelsiusToFahrenheit(0);

 // Assert
 Assert.AreEqual(32.0, result);
 }

 [TestMethod]
 public void CelsiusToFahrenheit_With100_Returns212()
 {
 var converter = new TemperatureConverter();
 var result = converter.CelsiusToFahrenheit(100);
 Assert.AreEqual(212.0, result);
 }
}

// 이 시점에서 TemperatureConverter 클래스가 없으므로
// 컴파일 에러 또는 테스트 실패
```

---
### Test-Driven Development (TDD)
**Step 2: GREEN - 최소한의 코드로 통과**

```csharp
public class TemperatureConverter
{
 public double CelsiusToFahrenheit(double celsius)
 {
 // 가장 간단한 구현으로 테스트 통과
 return celsius * 9.0 / 5.0 + 32.0;
 }
}

// 테스트 통과!
```

</div>
<div>

**TDD의 핵심 원칙**:

---
### Test-Driven Development (TDD)
**1. 실패하는 테스트 먼저**:
- 구현 전에 테스트 작성
- 요구사항을 테스트 코드로 명세
- 컴파일 에러도 "실패"로 간주

**2. 최소한의 코드**:
- 테스트를 통과시키는 최소 코드
- Over-engineering 방지
- YAGNI (You Aren't Gonna Need It)

**3. Refactor (리팩터링)**:
- 테스트가 통과한 후 개선
- 중복 제거, 명확성 향상
- 테스트가 안전망 역할

**Step 3: REFACTOR - 코드 개선**

---
### Test-Driven Development (TDD)
```csharp
public class TemperatureConverter
{
 private const double CelsiusToFahrenheitFactor = 9.0 / 5.0;
 private const double FahrenheitOffset = 32.0;

 public double CelsiusToFahrenheit(double celsius)
 {
 if (double.IsNaN(celsius) || double.IsInfinity(celsius))
 {
 throw new ArgumentException(
 "Invalid temperature value", nameof(celsius));
 }

 return celsius * CelsiusToFahrenheitFactor
 + FahrenheitOffset;
 }

 public double FahrenheitToCelsius(double fahrenheit)
 {
 if (double.IsNaN(fahrenheit) || double.IsInfinity(fahrenheit))
 {
 throw new ArgumentException(
 "Invalid temperature value", nameof(fahrenheit));
 }

 return (fahrenheit - FahrenheitOffset)
 / CelsiusToFahrenheitFactor;
 }
}

// 테스트 여전히 통과!
// 더 명확하고 확장 가능한 코드
```

---
### Test-Driven Development (TDD)
**TDD의 장점**:
- 설계 개선 (테스트 가능한 코드 = 좋은 설계)
- 높은 코드 커버리지 (자동)
- 리그레션 방지
- 문서화 (테스트가 사용 예시)
- 자신감 있는 리팩터링

---
### Test-Driven Development (TDD)
**반도체 HMI에서의 TDD**:
```csharp
// 1. RED: 알람 로직 테스트 작성
[TestMethod]
public void CheckTemperature_AboveThreshold_TriggersAlarm()
{
 var alarmSystem = new AlarmSystem();
 var triggered = alarmSystem.CheckTemperature(250.0, 200.0);
 Assert.IsTrue(triggered);
}

// 2. GREEN: 최소 구현
public bool CheckTemperature(double current, double threshold)
{
 return current > threshold;
}

---
### Test-Driven Development (TDD)
// 3. REFACTOR: 히스테리시스 추가
public bool CheckTemperature(double current, double threshold)
{
 const double Hysteresis = 5.0;
 if (current > threshold)
 {
 _alarmTriggered = true;
 }
 else if (current < threshold - Hysteresis)
 {
 _alarmTriggered = false;
 }
 return _alarmTriggered;
}
---
### Test-Driven Development (TDD)
```

</div>
</div>
---
### Behavior-Driven Development (BDD)

**Given-When-Then 패턴**

<div class="grid grid-cols-2 gap-8">
<div>

**BDD 핵심 개념**:
- 비즈니스 가치 중심 테스트
- 자연어로 시나리오 작성
- 개발자-QA-비즈니스 팀 협업

**SpecFlow를 활용한 BDD**:

---
### Behavior-Driven Development (BDD)
```gherkin
# EquipmentControl.feature
Feature: Equipment Control
 As a fab operator
 I want to control equipment through HMI
 So that I can manage production processes

Scenario: Starting idle equipment
 Given the equipment is in "Idle" state
 And the equipment has no alarms
 When the operator presses the "Start" button
 Then the equipment state should be "Running"
 And the start time should be recorded
 And a notification should be sent to supervisors

Scenario: Cannot start equipment with active alarm
 Given the equipment is in "Idle" state
 And the equipment has a "High Temperature" alarm
 When the operator presses the "Start" button
 Then the equipment state should remain "Idle"
 And an error message "Cannot start with active alarms" should be displayed
 And no notification should be sent

Scenario: Emergency stop during operation
 Given the equipment is in "Running" state
 And the process has been running for "5" minutes
 When the operator presses the "Emergency Stop" button
 Then the equipment state should be "Emergency Stopped"
 And all recipes should be aborted
 And an emergency alert should be sent immediately
 And the equipment should be locked for "30" minutes
```

---
### Behavior-Driven Development (BDD)
</div>
<div>

**Step Definitions (C# 구현)**:

---
### Behavior-Driven Development (BDD)
```csharp
[Binding]
public class EquipmentControlSteps
{
 private Equipment _equipment;
 private EquipmentController _controller;
 private string _lastErrorMessage;
 private bool _notificationSent;

 [Given(@"the equipment is in ""(.*)"" state")]
 public void GivenTheEquipmentIsInState(string state)
 {
 _equipment = new Equipment
 {
 Id = "TEST001",
 State = Enum.Parse<EquipmentState>(state)
 };
 _controller = new EquipmentController(_equipment);
 }

 [Given(@"the equipment has no alarms")]
 public void GivenTheEquipmentHasNoAlarms()
 {
 _equipment.Alarms.Clear();
 }

 [Given(@"the equipment has a ""(.*)"" alarm")]
 public void GivenTheEquipmentHasAlarm(string alarmType)
 {
 _equipment.Alarms.Add(new Alarm
 {
 Type = Enum.Parse<AlarmType>(alarmType.Replace(" ", "")),
 Timestamp = DateTime.UtcNow
 });
 }

 [When(@"the operator presses the ""(.*)"" button")]
 public async Task WhenTheOperatorPressesButton(string buttonName)
 {
 try
 {
 switch (buttonName)
 {
 case "Start":
 await _controller.StartAsync();
 break;
 case "Emergency Stop":
 await _controller.EmergencyStopAsync();
 break;
 }
 }
 catch (Exception ex)
 {
 _lastErrorMessage = ex.Message;
 }
 }

 [Then(@"the equipment state should be ""(.*)""")]
 public void ThenTheEquipmentStateShouldBe(string expectedState)
 {
 var expected = Enum.Parse<EquipmentState>(expectedState);
 Assert.AreEqual(expected, _equipment.State);
 }

 [Then(@"the equipment state should remain ""(.*)""")]
 public void ThenTheEquipmentStateShouldRemain(string expectedState)
 {
 ThenTheEquipmentStateShouldBe(expectedState);
 }

 [Then(@"an error message ""(.*)"" should be displayed")]
 public void ThenAnErrorMessageShouldBeDisplayed(string expectedMessage)
 {
 Assert.IsNotNull(_lastErrorMessage);
 Assert.IsTrue(_lastErrorMessage.Contains(expectedMessage));
 }

 [Then(@"the start time should be recorded")]
 public void ThenTheStartTimeShouldBeRecorded()
 {
 Assert.IsNotNull(_equipment.LastStartTime);
 Assert.IsTrue(
 DateTime.UtcNow - _equipment.LastStartTime < TimeSpan.FromSeconds(5));
 }
}
```

---
### Behavior-Driven Development (BDD)
**BDD의 장점**:
- 비즈니스 요구사항을 직접 테스트
- 실행 가능한 명세 (Living Documentation)
- 팀 간 의사소통 도구
- 인수 테스트 자동화

**테스트 리포트 예시**:
```
Feature: Equipment Control
 Starting idle equipment (2.3s)
 Cannot start equipment with active alarm (1.1s)
 Emergency stop during operation (3.5s)

scenarios (3 passed)
steps (12 passed)
Total: 6.9s
---
### Behavior-Driven Development (BDD)
```

</div>
</div>
---
### Test Doubles (테스트 대역)

**Mock, Stub, Fake, Spy 비교**

<div class="grid grid-cols-2 gap-8">
<div>

**1. Dummy (더미)**:
```csharp
// 전달만 되고 실제로 사용되지 않음
public class DummyLogger : ILogger
{
 public void Log(string message) { }
 public void LogError(Exception ex) { }
}

// 사용
var service = new EquipmentService(
 repository,
 new DummyLogger()); // 로거가 필요하지만 테스트에서 미사용
---
### Test Doubles (테스트 대역)
```

**2. Stub (스텁)**:
```csharp
// 미리 정의된 응답 반환
public class StubTemperatureSensor : ITemperatureSensor
{
 private readonly Queue<double> _temperatures;

 public StubTemperatureSensor(params double[] temps)
 {
 _temperatures = new Queue<double>(temps);
 }

 public Task<double> ReadTemperatureAsync()
 {
 if (_temperatures.Count > 0)
 {
---
### Test Doubles (테스트 대역)
 return Task.FromResult(_temperatures.Dequeue());
 }
 return Task.FromResult(25.0); // 기본값
 }
}

// 테스트
[TestMethod]
public async Task ProcessData_WithSpecificTemperatures_CalculatesAverage()
{
 // Arrange: 예측 가능한 온도 시퀀스
 var sensor = new StubTemperatureSensor(20.0, 25.0, 30.0);
 var processor = new DataProcessor(sensor);

 // Act
 var average = await processor.CalculateAverageTemperature(3);

 // Assert
---
### Test Doubles (테스트 대역)
 Assert.AreEqual(25.0, average);
}
```

**3. Fake (가짜)**:
```csharp
// 실제 동작하는 간단한 구현
public class FakeEquipmentRepository : IEquipmentRepository
{
 private readonly Dictionary<string, Equipment> _storage
 = new Dictionary<string, Equipment>();

 public Task<Equipment> GetByIdAsync(string id)
 {
 _storage.TryGetValue(id, out var equipment);
 return Task.FromResult(equipment);
 }

---
### Test Doubles (테스트 대역)
 public Task SaveAsync(Equipment equipment)
 {
 _storage[equipment.Id] = equipment;
 return Task.CompletedTask;
 }

 public Task<List<Equipment>> GetAllAsync()
 {
 return Task.FromResult(_storage.Values.ToList());
 }

 public Task DeleteAsync(string id)
 {
 _storage.Remove(id);
 return Task.CompletedTask;
 }
}

---
### Test Doubles (테스트 대역)
// 실제 DB 없이 동작하지만, 메모리에서 CRUD 동작 구현
```

</div>
<div>

**4. Mock (목)**:
```csharp
// 호출 검증 + 행동 정의
[TestMethod]
public async Task StartEquipment_WhenSuccessful_SendsNotification()
{
 // Arrange
 var mockNotificationService = new Mock<INotificationService>();
 var controller = new EquipmentController(
 _equipment,
 mockNotificationService.Object);

---
### Test Doubles (테스트 대역)
 // Act
 await controller.StartAsync();

 // Assert: 정확히 1번 호출되었는지 검증
 mockNotificationService.Verify(
 x => x.SendAsync(
 It.Is<Notification>(n =>
 n.Type == NotificationType.EquipmentStarted &&
 n.EquipmentId == "E001")),
 Times.Once);
}

[TestMethod]
public async Task ProcessAlarm_WithCriticalAlarm_CallsEmergencyProtocol()
{
 // Arrange
 var mockEmergencySystem = new Mock<IEmergencySystem>();
---
### Test Doubles (테스트 대역)
 mockEmergencySystem
 .Setup(x => x.TriggerProtocolAsync(It.IsAny<Alarm>()))
 .ReturnsAsync(true);

 var alarmHandler = new AlarmHandler(mockEmergencySystem.Object);
 var criticalAlarm = new Alarm
 {
 Severity = AlarmSeverity.Critical,
 Type = AlarmType.SafetyInterlock
 };

 // Act
 await alarmHandler.HandleAsync(criticalAlarm);

 // Assert
 mockEmergencySystem.Verify(
 x => x.TriggerProtocolAsync(criticalAlarm),
 Times.Once);
---
### Test Doubles (테스트 대역)
 mockEmergencySystem.Verify(
 x => x.NotifyOpsTeamAsync(It.IsAny<string>()),
 Times.Once);
}
```

**5. Spy (스파이)**:
```csharp
// 호출 기록 + 실제 동작
public class SpyLogger : ILogger
{
 private readonly List<LogEntry> _logEntries
 = new List<LogEntry>();

 public IReadOnlyList<LogEntry> LogEntries => _logEntries;

 public void Log(string message)
 {
---
### Test Doubles (테스트 대역)
 var entry = new LogEntry
 {
 Level = LogLevel.Info,
 Message = message,
 Timestamp = DateTime.UtcNow
 };
 _logEntries.Add(entry);

 // 실제 로깅도 수행
 Console.WriteLine($"[{entry.Timestamp}] {message}");
 }

 public void LogError(Exception ex)
 {
 var entry = new LogEntry
 {
 Level = LogLevel.Error,
---
### Test Doubles (테스트 대역)
 Message = ex.Message,
 Exception = ex,
 Timestamp = DateTime.UtcNow
 };
 _logEntries.Add(entry);
 Console.Error.WriteLine($"[ERROR] {ex.Message}");
 }
}

// 테스트
[TestMethod]
public async Task ProcessEquipment_LogsAllSteps()
{
 // Arrange
 var spyLogger = new SpyLogger();
 var processor = new EquipmentProcessor(spyLogger);

---
### Test Doubles (테스트 대역)
 // Act
 await processor.ProcessAsync(equipment);

 // Assert: 로깅 검증
 Assert.AreEqual(4, spyLogger.LogEntries.Count);
 Assert.IsTrue(spyLogger.LogEntries[0].Message.Contains("Starting"));
 Assert.IsTrue(spyLogger.LogEntries[3].Message.Contains("Completed"));
}
---
### Test Doubles (테스트 대역)
```

**선택 가이드**:
- **Dummy**: 필수 파라미터이지만 사용되지 않음
- **Stub**: 간접 입력 (indirect input) 제어
- **Fake**: 실제 동작하는 경량 구현
- **Mock**: 간접 출력 (indirect output) 검증
- **Spy**: 실제 동작 + 호출 기록

</div>
</div>
---
### ️ AAA 패턴 (Arrange-Act-Assert)

**테스트 구조화**

<div class="grid grid-cols-2 gap-8">
<div>

**AAA 패턴 구조**:

---
### ️ AAA 패턴 (Arrange-Act-Assert)
```csharp
[TestMethod]
public async Task StartEquipment_WithValidConditions_StartsSuccessfully()
{
 // ============= ARRANGE =============
 // 테스트 준비: 객체 생성, 상태 설정, 의존성 주입

 var equipment = new Equipment
 {
 Id = "E001",
 Name = "Etcher",
 State = EquipmentState.Idle,
 Temperature = 25.0
 };

 var mockRepository = new Mock<IEquipmentRepository>();
 mockRepository
 .Setup(r => r.GetByIdAsync("E001"))
 .ReturnsAsync(equipment);

 var mockNotificationService = new Mock<INotificationService>();

 var controller = new EquipmentController(
 mockRepository.Object,
 mockNotificationService.Object);

 // ============= ACT =============
 // 테스트 대상 메서드 실행

 var result = await controller.StartEquipmentAsync("E001");

 // ============= ASSERT =============
 // 결과 검증

 Assert.IsTrue(result.IsSuccess);
 Assert.AreEqual(EquipmentState.Running, equipment.State);
 Assert.IsNotNull(equipment.LastStartTime);

 mockNotificationService.Verify(
 n => n.SendAsync(It.IsAny<Notification>()),
 Times.Once);
}
```

---
### ️ AAA 패턴 (Arrange-Act-Assert)
**복잡한 Arrange 리팩터링**:

---
### ️ AAA 패턴 (Arrange-Act-Assert)
```csharp
public class EquipmentTestBuilder
{
 private Equipment _equipment = new Equipment();
 private List<Alarm> _alarms = new List<Alarm>();

 public EquipmentTestBuilder WithId(string id)
 {
 _equipment.Id = id;
 return this;
 }

 public EquipmentTestBuilder WithState(EquipmentState state)
 {
 _equipment.State = state;
 return this;
 }

 public EquipmentTestBuilder WithTemperature(double temp)
 {
 _equipment.Temperature = temp;
 return this;
 }

 public EquipmentTestBuilder WithAlarm(AlarmType type, AlarmSeverity severity)
 {
 _alarms.Add(new Alarm { Type = type, Severity = severity });
 return this;
 }

 public Equipment Build()
 {
 _equipment.Alarms = _alarms;
 return _equipment;
 }
}

// 사용: Fluent API로 깔끔한 테스트
[TestMethod]
public async Task Test_WithBuilder()
{
 // Arrange - 훨씬 읽기 쉬움
 var equipment = new EquipmentTestBuilder()
 .WithId("E001")
 .WithState(EquipmentState.Idle)
 .WithTemperature(150.0)
 .WithAlarm(AlarmType.HighTemperature, AlarmSeverity.Warning)
 .Build();

 // Act
 var canStart = _controller.CanStart(equipment);

 // Assert
 Assert.IsFalse(canStart);
}
```

---
### ️ AAA 패턴 (Arrange-Act-Assert)
</div>
<div>

**AAA 패턴의 장점**:
- 테스트 가독성 향상
- 일관된 구조
- 명확한 의도 전달

**Common Patterns**:

**1. Setup 메서드 활용**:
```csharp
[TestClass]
public class EquipmentControllerTests
{
 private EquipmentController _controller;
 private Mock<IEquipmentRepository> _mockRepository;

 [TestInitialize]
---
### ️ AAA 패턴 (Arrange-Act-Assert)
 public void Setup()
 {
 // 모든 테스트에서 공통으로 사용할 Arrange
 _mockRepository = new Mock<IEquipmentRepository>();
 _controller = new EquipmentController(_mockRepository.Object);
 }

 [TestMethod]
 public async Task Test1()
 {
 // Arrange: 이 테스트만의 특수 설정
 var equipment = CreateTestEquipment();

 // Act
 await _controller.StartAsync(equipment);

 // Assert
 Assert.AreEqual(EquipmentState.Running, equipment.State);
---
### ️ AAA 패턴 (Arrange-Act-Assert)
 }
}
```

**2. Theory 테스트 (데이터 주도)**:
```csharp
[TestClass]
public class TemperatureValidationTests
{
 [DataTestMethod]
 [DataRow(-50, true, "최소 온도")]
 [DataRow(0, true, "경계값 하한")]
 [DataRow(150, true, "정상 범위")]
 [DataRow(300, true, "경계값 상한")]
 [DataRow(301, false, "최대 초과")]
 [DataRow(double.NaN, false, "유효하지 않은 값")]
---
### ️ AAA 패턴 (Arrange-Act-Assert)
 public void ValidateTemperature_WithVariousInputs_ReturnsExpected(
 double temperature,
 bool expectedValid,
 string scenario)
 {
 // Arrange
 var validator = new TemperatureValidator(-50, 300);

 // Act
 var isValid = validator.IsValid(temperature);

 // Assert
 Assert.AreEqual(expectedValid, isValid, $"Failed for: {scenario}");
 }
}
---
### ️ AAA 패턴 (Arrange-Act-Assert)
```

**3. Helper Methods**:
```csharp
[TestClass]
public class AlarmTests
{
 [TestMethod]
 public async Task HighPriorityAlarm_TriggersImmediateNotification()
 {
 // Arrange
 var alarm = CreateCriticalAlarm();
 var handler = CreateAlarmHandler();

 // Act
 await handler.HandleAsync(alarm);

 // Assert
---
### ️ AAA 패턴 (Arrange-Act-Assert)
 AssertNotificationSent();
 AssertAlarmLogged(alarm);
 }

 private Alarm CreateCriticalAlarm()
 {
 return new Alarm
 {
 Type = AlarmType.SafetyInterlock,
 Severity = AlarmSeverity.Critical,
 EquipmentId = "E001",
 Message = "Safety door opened during operation",
 Timestamp = DateTime.UtcNow
 };
 }

 private AlarmHandler CreateAlarmHandler()
---
### ️ AAA 패턴 (Arrange-Act-Assert)
 {
 var mockNotification = new Mock<INotificationService>();
 var mockLogger = new Mock<ILogger>();
 return new AlarmHandler(
 mockNotification.Object,
 mockLogger.Object);
 }

 private void AssertNotificationSent()
 {
 // 검증 로직
 }
}
---
### ️ AAA 패턴 (Arrange-Act-Assert)
```

**Anti-Patterns (피해야 할 패턴)**:
- Multiple Act: 하나의 테스트에서 여러 동작
- No Assert: 검증 없는 테스트
- Conditional Logic: if/for 문 사용
- Test Interdependence: 테스트 간 의존성

</div>
</div>
---
## .NET 테스트 프레임워크 비교

### MSTest (Microsoft Test Framework)
**장점**:
- Visual Studio 완전 통합
- Azure DevOps 네이티브 지원
- Enterprise 기능 (Live Unit Testing)

**단점**:
- 상대적으로 느린 실행 속도
- 제한적인 확장성

**적용 분야**: 기업 환경, Azure 생태계

### xUnit.net
**장점**:
- 빠른 실행 속도
- 병렬 테스트 실행
- 현대적인 API 설계

---
## .NET 테스트 프레임워크 비교
**단점**:
- Setup/Teardown 개념 부재
- 러닝 커브 존재

**적용 분야**: 신규 프로젝트, 성능 중시

### NUnit
**장점**:
- 풍부한 Assert 메서드
- 유연한 테스트 구성
- 강력한 파라미터화 테스트

**단점**:
- 복잡한 설정
- 버전 호환성 이슈

**적용 분야**: 복잡한 테스트 시나리오

## 반도체 HMI 테스트 아키텍처

### Test Doubles 패턴

---
## .NET 테스트 프레임워크 비교
<div class="code-section">

**테스트용 Mock 객체 구현**

---
## .NET 테스트 프레임워크 비교
```csharp
// 1. 센서 인터페이스 정의
public interface ITemperatureSensor
{
 Task<double> ReadTemperatureAsync();
 Task<bool> CalibrateAsync(double referenceValue);
 event EventHandler<TemperatureChangedEventArgs> TemperatureChanged;
}

// 2. Mock 센서 구현
public class MockTemperatureSensor : ITemperatureSensor
{
 private double currentTemperature = 25.0;
 private readonly Random random = new Random();

 public event EventHandler<TemperatureChangedEventArgs> TemperatureChanged;

 public async Task<double> ReadTemperatureAsync()
 {
 // 실제 센서 응답 시간 시뮬레이션
 await Task.Delay(50);

 // 노이즈가 포함된 온도값 생성
 var noise = (random.NextDouble() - 0.5) * 0.1;
 currentTemperature += noise;

 return Math.Round(currentTemperature, 2);
 }

 public async Task<bool> CalibrateAsync(double referenceValue)
 {
 await Task.Delay(1000); // 보정 시간 시뮬레이션
 currentTemperature = referenceValue;
 return true;
 }

 // 테스트용 온도 설정 메서드
 public void SetTemperature(double temperature)
 {
 currentTemperature = temperature;
 TemperatureChanged?.Invoke(this, new TemperatureChangedEventArgs(temperature));
 }
}

// 3. Stub을 활용한 예측 가능한 테스트
public class StubTemperatureSensor : ITemperatureSensor
{
 private readonly Queue<double> temperatureValues;
 private bool calibrationResult = true;

 public event EventHandler<TemperatureChangedEventArgs> TemperatureChanged;

 public StubTemperatureSensor(params double[] temperatures)
 {
 temperatureValues = new Queue<double>(temperatures);
 }

 public Task<double> ReadTemperatureAsync()
 {
 if (temperatureValues.Count > 0)
 return Task.FromResult(temperatureValues.Dequeue());

 throw new InvalidOperationException("No more temperature values available");
 }

 public Task<bool> CalibrateAsync(double referenceValue)
 {
 return Task.FromResult(calibrationResult);
 }

 public void SetCalibrationResult(bool result) => calibrationResult = result;
}
```

---
## .NET 테스트 프레임워크 비교
</div>

### 의존성 주입을 통한 테스트 용이성

<div class="code-section">

**DI 컨테이너 기반 테스트 설정**

---
## .NET 테스트 프레임워크 비교
```csharp
public class EquipmentControllerTests
{
 private ServiceProvider serviceProvider;
 private IEquipmentController equipmentController;

 [TestInitialize]
 public void Setup()
 {
 var services = new ServiceCollection();

 // 프로덕션 의존성을 테스트용으로 교체
 services.AddSingleton<ITemperatureSensor, MockTemperatureSensor>();
 services.AddSingleton<IPressureSensor, MockPressureSensor>();
 services.AddSingleton<IDataLogger, InMemoryDataLogger>();
 services.AddSingleton<IAlarmSystem, MockAlarmSystem>();

 // 실제 비즈니스 로직은 그대로 사용
 services.AddSingleton<IEquipmentController, EquipmentController>();
 services.AddSingleton<IProcessController, ProcessController>();

 serviceProvider = services.BuildServiceProvider();
 equipmentController = serviceProvider.GetRequiredService<IEquipmentController>();
 }

 [TestMethod]
 public async Task StartProcess_WhenTemperatureInRange_ShouldSucceed()
 {
 // Arrange
 var mockSensor = serviceProvider.GetRequiredService<ITemperatureSensor>()
 as MockTemperatureSensor;
 mockSensor.SetTemperature(150.0); // 정상 운영 온도

 var processParameters = new ProcessParameters
 {
 TargetTemperature = 150.0,
 PressureSetpoint = 1.5,
 Duration = TimeSpan.FromMinutes(30)
 };

 // Act
 var result = await equipmentController.StartProcessAsync(processParameters);

 // Assert
 Assert.IsTrue(result.IsSuccess);
 Assert.AreEqual(ProcessStatus.Running, result.Status);
 }

 [TestCleanup]
 public void Cleanup()
 {
 serviceProvider?.Dispose();
 }
}
```

---
## .NET 테스트 프레임워크 비교
</div>

## CI/CD 파이프라인 설계

### Azure DevOps 파이프라인

<div class="code-section">

**azure-pipelines.yml - 완전한 CI/CD 파이프라인**

---
## .NET 테스트 프레임워크 비교
```yaml
# Azure DevOps 파이프라인 정의
trigger:
 branches:
 include:
 - main
 - develop
 - release/*

variables:
 buildConfiguration: 'Release'
 dotNetFramework: 'net6.0'
 vmImageName: 'windows-2022'

stages:
- stage: Build
 displayName: 'Build and Test'
 jobs:
 - job: Build
 displayName: 'Build job'
 pool:
 vmImage: $(vmImageName)

 steps:
 # .NET SDK 설치
 - task: UseDotNet@2
 displayName: 'Use .NET 6 SDK'
 inputs:
 packageType: 'sdk'
 version: '6.0.x'

 # NuGet 패키지 복원
 - task: DotNetCoreCLI@2
 displayName: 'Restore packages'
 inputs:
 command: 'restore'
 projects: '**/*.csproj'

 # 코드 빌드
 - task: DotNetCoreCLI@2
 displayName: 'Build'
 inputs:
 command: 'build'
 projects: '**/*.csproj'
 arguments: '--configuration $(buildConfiguration) --no-restore'

 # 단위 테스트 실행
 - task: DotNetCoreCLI@2
 displayName: 'Run Unit Tests'
 inputs:
 command: 'test'
 projects: '**/*UnitTests.csproj'
 arguments: '--configuration $(buildConfiguration) --collect:"XPlat Code Coverage" --logger trx --no-build'
 publishTestResults: true

 # 통합 테스트 실행
 - task: DotNetCoreCLI@2
 displayName: 'Run Integration Tests'
 inputs:
 command: 'test'
 projects: '**/*IntegrationTests.csproj'
 arguments: '--configuration $(buildConfiguration) --collect:"XPlat Code Coverage" --logger trx --no-build'
 publishTestResults: true

 # 코드 커버리지 발행
 - task: PublishCodeCoverageResults@1
 displayName: 'Publish Code Coverage'
 inputs:
 codeCoverageTool: 'Cobertura'
 summaryFileLocation: '$(Agent.TempDirectory)/**/coverage.cobertura.xml'

 # SonarQube 코드 품질 분석
 - task: SonarQubePrepare@4
 displayName: 'Prepare SonarQube analysis'
 inputs:
 SonarQube: 'SonarQube-Server'
 scannerMode: 'MSBuild'
 projectKey: 'semiconductor-hmi'
 projectName: 'Semiconductor HMI'

 - task: SonarQubeAnalyze@4
 displayName: 'Run SonarQube analysis'

 - task: SonarQubePublish@4
 displayName: 'Publish SonarQube results'

 # Docker 이미지 빌드
 - task: Docker@2
 displayName: 'Build Docker image'
 inputs:
 containerRegistry: 'ACR-Connection'
 repository: 'semiconductor-hmi'
 command: 'build'
 Dockerfile: '**/Dockerfile'
 tags: |
 $(Build.BuildId)
 latest

- stage: Deploy_Test
 displayName: 'Deploy to Test Environment'
 dependsOn: Build
 condition: and(succeeded(), eq(variables['Build.SourceBranch'], 'refs/heads/develop'))
 jobs:
 - deployment: DeployToTest
 displayName: 'Deploy to Test'
 pool:
 vmImage: $(vmImageName)
 environment: 'test'
 strategy:
 runOnce:
 deploy:
 steps:
 # Kubernetes 배포
 - task: KubernetesManifest@0
 displayName: 'Deploy to Kubernetes'
 inputs:
 action: 'deploy'
 kubernetesServiceConnection: 'k8s-test-cluster'
 namespace: 'test-environment'
 manifests: |
 k8s/deployment.yaml
 k8s/service.yaml
 k8s/configmap.yaml

 # 배포 후 헬스체크
 - task: PowerShell@2
 displayName: 'Health Check'
 inputs:
 targetType: 'inline'
 script: |
 $healthCheckUrl = "http://test-hmi.company.com/health"
 $maxAttempts = 30
 $attempt = 0

 do {
 $attempt++
 try {
 $response = Invoke-RestMethod -Uri $healthCheckUrl -TimeoutSec 10
 if ($response.status -eq "healthy") {
 Write-Host "Health check passed on attempt $attempt"
 exit 0
 }
 }
 catch {
 Write-Host "Health check failed on attempt $attempt: $($_.Exception.Message)"
 }
 Start-Sleep -Seconds 10
 } while ($attempt -lt $maxAttempts)

 Write-Error "Health check failed after $maxAttempts attempts"
 exit 1

- stage: Deploy_Production
 displayName: 'Deploy to Production'
 dependsOn: Deploy_Test
 condition: and(succeeded(), eq(variables['Build.SourceBranch'], 'refs/heads/main'))
 jobs:
 - deployment: DeployToProduction
 displayName: 'Deploy to Production'
 pool:
 vmImage: $(vmImageName)
 environment: 'production'
 strategy:
 canary:
 increments: [1, 10, 100]
 deploy:
 steps:
 # Blue-Green 배포 전략
 - task: KubernetesManifest@0
 displayName: 'Deploy to Green Environment'
 inputs:
 action: 'deploy'
 kubernetesServiceConnection: 'k8s-prod-cluster'
 namespace: 'production'
 manifests: |
 k8s/deployment-green.yaml

 # 트래픽 전환 대기 (수동 승인)
 - task: ManualValidation@0
 displayName: 'Manual Validation'
 inputs:
 notifyUsers: 'ops-team@company.com'
 instructions: 'Please validate the green deployment and approve traffic switch'

 # 트래픽 전환
 - task: KubernetesManifest@0
 displayName: 'Switch Traffic to Green'
 inputs:
 action: 'deploy'
 kubernetesServiceConnection: 'k8s-prod-cluster'
 namespace: 'production'
 manifests: 'k8s/service-green.yaml'
```

---
## .NET 테스트 프레임워크 비교
</div>

### GitHub Actions 워크플로우

<div class="code-section">

**.github/workflows/ci-cd.yml**

---
## .NET 테스트 프레임워크 비교
```yaml
name: CI/CD Pipeline

on:
 push:
 branches: [ main, develop ]
 pull_request:
 branches: [ main ]

env:
 DOTNET_VERSION: '6.0.x'
 REGISTRY: ghcr.io
 IMAGE_NAME: ${{ github.repository }}

jobs:
 test:
 runs-on: windows-latest

 steps:
 - uses: actions/checkout@v3

 - name: Setup .NET
 uses: actions/setup-dotnet@v3
 with:
 dotnet-version: ${{ env.DOTNET_VERSION }}

 - name: Restore dependencies
 run: dotnet restore

 - name: Build
 run: dotnet build --no-restore --configuration Release

 - name: Test
 run: |
 dotnet test --no-build --configuration Release --collect:"XPlat Code Coverage" `
 --logger trx --results-directory TestResults

 - name: Upload test results
 uses: actions/upload-artifact@v3
 if: always()
 with:
 name: test-results
 path: TestResults

 - name: Upload coverage reports to Codecov
 uses: codecov/codecov-action@v3
 with:
 directory: TestResults
 fail_ci_if_error: true

 security-scan:
 runs-on: ubuntu-latest
 steps:
 - uses: actions/checkout@v3

 - name: Run Snyk to check for vulnerabilities
 uses: snyk/actions/dotnet@master
 env:
 SNYK_TOKEN: ${{ secrets.SNYK_TOKEN }}

 build-and-push:
 needs: [test, security-scan]
 runs-on: ubuntu-latest
 permissions:
 contents: read
 packages: write

 steps:
 - name: Checkout repository
 uses: actions/checkout@v3

 - name: Log in to Container Registry
 uses: docker/login-action@v2
 with:
 registry: ${{ env.REGISTRY }}
 username: ${{ github.actor }}
 password: ${{ secrets.GITHUB_TOKEN }}

 - name: Extract metadata
 id: meta
 uses: docker/metadata-action@v4
 with:
 images: ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}
 tags: |
 type=ref,event=branch
 type=ref,event=pr
 type=sha,prefix={{branch}}-

 - name: Build and push Docker image
 uses: docker/build-push-action@v4
 with:
 context: .
 push: true
 tags: ${{ steps.meta.outputs.tags }}
 labels: ${{ steps.meta.outputs.labels }}
```

---
## .NET 테스트 프레임워크 비교
</div>

## 모니터링 및 로깅 전략

### Application Insights 통합

<div class="code-section">

**Program.cs - 모니터링 설정**

---
## .NET 테스트 프레임워크 비교
```csharp
using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Extensibility;
using Serilog;
using Serilog.Events;

var builder = WebApplication.CreateBuilder(args);

// Application Insights 설정
builder.Services.AddApplicationInsightsTelemetry(options =>
{
 options.ConnectionString = builder.Configuration.GetConnectionString("ApplicationInsights");
 options.EnableAdaptiveSampling = true;
 options.EnableQuickPulseMetricStream = true;
});

// Serilog 구성
Log.Logger = new LoggerConfiguration()
 .MinimumLevel.Information()
 .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
 .MinimumLevel.Override("System", LogEventLevel.Warning)
 .Enrich.FromLogContext()
 .Enrich.WithProperty("Application", "SemiconductorHMI")
 .Enrich.WithProperty("Environment", builder.Environment.EnvironmentName)
 .WriteTo.Console()
 .WriteTo.File("logs/app-.log",
 rollingInterval: RollingInterval.Day,
 retainedFileCountLimit: 30,
 outputTemplate: "{Timestamp:yyyy-MM-dd HH:mm:ss.fff zzz} [{Level:u3}] {Message:lj}{NewLine}{Exception}")
 .WriteTo.ApplicationInsights(
 builder.Configuration.GetConnectionString("ApplicationInsights"),
 TelemetryConverter.Traces)
 .CreateLogger();

builder.Host.UseSerilog();

// 커스텀 미들웨어 등록
builder.Services.AddSingleton<ITelemetryInitializer, CustomTelemetryInitializer>();
builder.Services.AddSingleton<IMetricsCollector, EquipmentMetricsCollector>();

var app = builder.Build();

// 커스텀 미들웨어 추가
app.UseMiddleware<PerformanceLoggingMiddleware>();
app.UseMiddleware<ErrorHandlingMiddleware>();

app.Run();
```

---
## .NET 테스트 프레임워크 비교
</div>

### 커스텀 메트릭 수집

<div class="code-section">

**메트릭 수집 및 알림 시스템**

---
## .NET 테스트 프레임워크 비교
```csharp
public class EquipmentMetricsCollector : IMetricsCollector, IDisposable
{
 private readonly TelemetryClient telemetryClient;
 private readonly ILogger<EquipmentMetricsCollector> logger;
 private readonly Timer metricsTimer;
 private readonly IEquipmentDataService equipmentDataService;

 public EquipmentMetricsCollector(
 TelemetryClient telemetryClient,
 ILogger<EquipmentMetricsCollector> logger,
 IEquipmentDataService equipmentDataService)
 {
 this.telemetryClient = telemetryClient;
 this.logger = logger;
 this.equipmentDataService = equipmentDataService;

 // 1분마다 메트릭 수집
 metricsTimer = new Timer(CollectMetrics, null, TimeSpan.Zero, TimeSpan.FromMinutes(1));
 }

 private async void CollectMetrics(object state)
 {
 try
 {
 var equipmentList = await equipmentDataService.GetAllEquipmentAsync();

 foreach (var equipment in equipmentList)
 {
 await CollectEquipmentMetrics(equipment);
 }

 // 시스템 전체 메트릭
 await CollectSystemMetrics();
 }
 catch (Exception ex)
 {
 logger.LogError(ex, "Failed to collect metrics");
 }
 }

 private async Task CollectEquipmentMetrics(Equipment equipment)
 {
 var metrics = await equipmentDataService.GetCurrentMetricsAsync(equipment.Id);

 // 온도 메트릭
 telemetryClient.TrackMetric("Equipment.Temperature",
 metrics.Temperature,
 new Dictionary<string, string>
 {
 {"EquipmentId", equipment.Id},
 {"EquipmentType", equipment.Type},
 {"Location", equipment.Location}
 });

 // 압력 메트릭
 telemetryClient.TrackMetric("Equipment.Pressure",
 metrics.Pressure,
 new Dictionary<string, string>
 {
 {"EquipmentId", equipment.Id},
 {"EquipmentType", equipment.Type}
 });

 // 처리량 메트릭
 telemetryClient.TrackMetric("Equipment.Throughput",
 metrics.WafersPerHour,
 new Dictionary<string, string>
 {
 {"EquipmentId", equipment.Id},
 {"ProcessType", metrics.CurrentProcess}
 });

 // 에러율 계산 및 추적
 var errorRate = await CalculateErrorRate(equipment.Id);
 telemetryClient.TrackMetric("Equipment.ErrorRate", errorRate);

 // 임계값 체크 및 알림
 await CheckThresholds(equipment, metrics);
 }

 private async Task CheckThresholds(Equipment equipment, EquipmentMetrics metrics)
 {
 var thresholds = await equipmentDataService.GetThresholdsAsync(equipment.Id);

 // 온도 임계값 체크
 if (metrics.Temperature > thresholds.MaxTemperature)
 {
 var alert = new Alert
 {
 Type = AlertType.HighTemperature,
 EquipmentId = equipment.Id,
 Value = metrics.Temperature,
 Threshold = thresholds.MaxTemperature,
 Severity = AlertSeverity.Critical,
 Timestamp = DateTime.UtcNow
 };

 await SendAlert(alert);
 }

 // 처리량 저하 체크
 if (metrics.WafersPerHour < thresholds.MinThroughput)
 {
 var alert = new Alert
 {
 Type = AlertType.LowThroughput,
 EquipmentId = equipment.Id,
 Value = metrics.WafersPerHour,
 Threshold = thresholds.MinThroughput,
 Severity = AlertSeverity.Warning,
 Timestamp = DateTime.UtcNow
 };

 await SendAlert(alert);
 }
 }

 private async Task SendAlert(Alert alert)
 {
 // Application Insights에 알림 이벤트 기록
 telemetryClient.TrackEvent("Equipment.Alert",
 new Dictionary<string, string>
 {
 {"AlertType", alert.Type.ToString()},
 {"EquipmentId", alert.EquipmentId},
 {"Severity", alert.Severity.ToString()},
 {"Value", alert.Value.ToString()},
 {"Threshold", alert.Threshold.ToString()}
 });

 // 심각한 알림의 경우 즉시 알림 발송
 if (alert.Severity == AlertSeverity.Critical)
 {
 await NotifyOpsTeam(alert);
 }

 logger.LogWarning("Equipment alert triggered: {AlertType} for equipment {EquipmentId}. " +
 "Value: {Value}, Threshold: {Threshold}",
 alert.Type, alert.EquipmentId, alert.Value, alert.Threshold);
 }

 private async Task NotifyOpsTeam(Alert alert)
 {
 // Teams/Slack 알림
 // SMS/이메일 알림
 // PagerDuty 연동 등
 }

 public void Dispose()
 {
 metricsTimer?.Dispose();
 }
}
```

---
## .NET 테스트 프레임워크 비교
</div>
---
## 테스트 라이브러리 상세 가이드

### MSTest 프레임워크 완전 가이드

**Microsoft 공식 테스트 프레임워크**

<div class="grid grid-cols-2 gap-8">
<div>

**주요 특징**:
- Visual Studio 완전 통합
- Azure DevOps 네이티브 지원
- Enterprise Live Unit Testing
- .NET Framework부터 .NET 6+ 지원

**설치**:
```bash
dotnet add package MSTest.TestFramework
dotnet add package MSTest.TestAdapter
dotnet add package Microsoft.NET.Test.Sdk
```

---
## 테스트 라이브러리 상세 가이드
**기본 테스트 구조**:
```csharp
using Microsoft.VisualStudio.TestTools.UnitTesting;

[TestClass] // 테스트 클래스 표시
public class CalculatorTests
{
 private Calculator _calculator;

 // 각 테스트 전 실행
 [TestInitialize]
 public void Setup()
 {
 _calculator = new Calculator();
 }

 // 각 테스트 후 실행
 [TestCleanup]
---
## 테스트 라이브러리 상세 가이드
 public void Cleanup()
 {
 _calculator = null;
 }

 // 테스트 메서드
 [TestMethod]
 public void Add_TwoNumbers_ReturnsSum()
 {
 // Arrange
 int a = 5, b = 3;

 // Act
 var result = _calculator.Add(a, b);

 // Assert
 Assert.AreEqual(8, result);
 }

---
## 테스트 라이브러리 상세 가이드
 // 예외 테스트
 [TestMethod]
 [ExpectedException(typeof(DivideByZeroException))]
 public void Divide_ByZero_ThrowsException()
 {
 _calculator.Divide(10, 0);
 }

 // 데이터 주도 테스트
 [DataTestMethod]
 [DataRow(1, 1, 2)]
 [DataRow(2, 3, 5)]
 [DataRow(-1, 1, 0)]
 public void Add_MultipleScenarios_ReturnsCorrectSum(
 int a, int b, int expected)
 {
---
## 테스트 라이브러리 상세 가이드
 var result = _calculator.Add(a, b);
 Assert.AreEqual(expected, result);
 }
}
```

</div>
<div>

**클래스 레벨 Setup/Cleanup**:
```csharp
[TestClass]
public class DatabaseTests
{
 private static DbContext _dbContext;

 // 클래스의 모든 테스트 전 1회 실행
 [ClassInitialize]
---
## 테스트 라이브러리 상세 가이드
 public static void ClassSetup(TestContext context)
 {
 _dbContext = new DbContext("TestConnection");
 _dbContext.Database.EnsureCreated();
 }

 // 클래스의 모든 테스트 후 1회 실행
 [ClassCleanup]
 public static void ClassCleanup()
 {
 _dbContext?.Dispose();
 }

 [TestMethod]
 public void SaveData_ValidEntity_Succeeds()
 {
 // _dbContext 사용
---
## 테스트 라이브러리 상세 가이드
 }
}
```

**Assert 메서드**:
```csharp
// 동등성
Assert.AreEqual(expected, actual);
Assert.AreNotEqual(notExpected, actual);

// 참조 동일성
Assert.AreSame(expectedRef, actualRef);
Assert.AreNotSame(notExpectedRef, actualRef);

// Null 체크
Assert.IsNull(obj);
Assert.IsNotNull(obj);

// Boolean
---
## 테스트 라이브러리 상세 가이드
Assert.IsTrue(condition);
Assert.IsFalse(condition);

// 타입 체크
Assert.IsInstanceOfType(obj, typeof(MyClass));

// 컬렉션
CollectionAssert.AreEqual(expected, actual);
CollectionAssert.Contains(collection, item);
CollectionAssert.AllItemsAreUnique(collection);

// 문자열
StringAssert.Contains(fullString, substring);
StringAssert.StartsWith(fullString, prefix);
StringAssert.Matches(text, regexPattern);
```

**TestContext 활용**:
```csharp
---
## 테스트 라이브러리 상세 가이드
[TestClass]
public class AdvancedTests
{
 public TestContext TestContext { get; set; }

 [TestMethod]
 public void LoggingTest()
 {
 TestContext.WriteLine("Test started");
 TestContext.Properties["Key"] = "Value";

 // 테스트 실행...

 TestContext.WriteLine($"Result: {result}");
 }
}
---
## 테스트 라이브러리 상세 가이드
```

</div>
</div>
---
### NUnit 프레임워크 가이드

**강력하고 유연한 테스트 프레임워크**

<div class="grid grid-cols-2 gap-8">
<div>

**주요 특징**:
- 풍부한 Assert 라이브러리
- 강력한 제약 조건 모델
- 파라미터화 테스트 지원
- 크로스 플랫폼

**설치**:
```bash
dotnet add package NUnit
dotnet add package NUnit3TestAdapter
dotnet add package Microsoft.NET.Test.Sdk
```

---
### NUnit 프레임워크 가이드
**기본 구조**:
```csharp
using NUnit.Framework;

[TestFixture] // MSTest의 [TestClass]와 동일
public class CalculatorTests
{
 private Calculator _calculator;

 [SetUp] // MSTest의 [TestInitialize]
 public void Setup()
 {
 _calculator = new Calculator();
 }

 [TearDown] // MSTest의 [TestCleanup]
 public void TearDown()
 {
---
### NUnit 프레임워크 가이드
 _calculator = null;
 }

 [Test] // MSTest의 [TestMethod]
 public void Add_TwoNumbers_ReturnsSum()
 {
 var result = _calculator.Add(5, 3);
 Assert.That(result, Is.EqualTo(8));
 }

 // 카테고리로 테스트 그룹화
 [Test]
 [Category("Fast")]
 [Category("Unit")]
 public void QuickTest()
 {
 Assert.Pass();
---
### NUnit 프레임워크 가이드
 }

 // 테스트 무시
 [Test]
 [Ignore("작업 중")]
 public void WorkInProgress()
 {
 // 실행되지 않음
 }
}
```

**제약 조건 모델 (Constraint Model)**:
```csharp
[Test]
public void ConstraintExamples()
{
---
### NUnit 프레임워크 가이드
 // 동등성
 Assert.That(actual, Is.EqualTo(expected));
 Assert.That(actual, Is.Not.EqualTo(notExpected));

 // 범위
 Assert.That(value, Is.InRange(1, 10));
 Assert.That(value, Is.GreaterThan(5));
 Assert.That(value, Is.LessThanOrEqualTo(100));

 // 문자열
 Assert.That(text, Does.Contain("substring"));
 Assert.That(text, Does.StartWith("prefix"));
 Assert.That(text, Does.EndWith("suffix"));
 Assert.That(text, Does.Match("regex.*pattern"));

 // 컬렉션
 Assert.That(collection, Has.Count.EqualTo(5));
 Assert.That(collection, Is.Empty);
---
### NUnit 프레임워크 가이드
 Assert.That(collection, Contains.Item(item));
 Assert.That(collection, Is.Ordered);
 Assert.That(collection, Is.Unique);

 // 타입
 Assert.That(obj, Is.TypeOf<MyClass>());
 Assert.That(obj, Is.InstanceOf<IMyInterface>());

 // Null
 Assert.That(obj, Is.Null);
 Assert.That(obj, Is.Not.Null);

 // Boolean
 Assert.That(condition, Is.True);
 Assert.That(condition, Is.False);
}
---
### NUnit 프레임워크 가이드
```

</div>
<div>

**파라미터화 테스트**:
```csharp
// TestCase 속성
[TestCase(1, 1, 2)]
[TestCase(2, 3, 5)]
[TestCase(-1, 1, 0)]
[TestCase(0, 0, 0)]
public void Add_VariousInputs_ReturnsCorrectSum(
 int a, int b, int expected)
{
 var result = _calculator.Add(a, b);
 Assert.That(result, Is.EqualTo(expected));
---
### NUnit 프레임워크 가이드
}

// TestCaseSource 속성
public static IEnumerable<TestCaseData> AddTestCases
{
 get
 {
 yield return new TestCaseData(1, 1, 2)
 .SetName("Adding 1 and 1");
 yield return new TestCaseData(2, 3, 5)
 .SetName("Adding 2 and 3");
 yield return new TestCaseData(-1, 1, 0)
 .SetName("Adding negative and positive");
 }
}

[TestCaseSource(nameof(AddTestCases))]
---
### NUnit 프레임워크 가이드
public void Add_WithTestCaseSource_ReturnsCorrectSum(
 int a, int b, int expected)
{
 var result = _calculator.Add(a, b);
 Assert.That(result, Is.EqualTo(expected));
}

// Values 조합
[Test]
public void MultiplyAllCombinations(
 [Values(1, 2, 3)] int a,
 [Values(2, 4)] int b)
{
 // 6개 테스트 생성 (3 × 2)
 var result = _calculator.Multiply(a, b);
 Assert.That(result, Is.EqualTo(a * b));
---
### NUnit 프레임워크 가이드
}
```

**예외 테스트**:
```csharp
[Test]
public void DivideByZero_ThrowsException()
{
 Assert.Throws<DivideByZeroException>(() =>
 _calculator.Divide(10, 0));
}

[Test]
public void ValidateInput_ThrowsWithMessage()
{
 var ex = Assert.Throws<ArgumentException>(() =>
 _calculator.Validate(-1));

---
### NUnit 프레임워크 가이드
 Assert.That(ex.Message, Does.Contain("must be positive"));
}

// async 메서드 예외 테스트
[Test]
public async Task AsyncOperation_ThrowsException()
{
 Assert.ThrowsAsync<InvalidOperationException>(
 async () => await _service.ProcessAsync());
}
```

**OneTimeSetUp/OneTimeTearDown**:
```csharp
[TestFixture]
public class DatabaseTests
{
---
### NUnit 프레임워크 가이드
 private static DbConnection _connection;

 [OneTimeSetUp] // ClassInitialize
 public void OneTimeSetup()
 {
 _connection = new DbConnection("TestDb");
 _connection.Open();
 }

 [OneTimeTearDown] // ClassCleanup
 public void OneTimeTearDown()
 {
 _connection?.Close();
 _connection?.Dispose();
 }
}
---
### NUnit 프레임워크 가이드
```

</div>
</div>
---
### xUnit.net 프레임워크 가이드

**현대적이고 확장 가능한 테스트 프레임워크**

<div class="grid grid-cols-2 gap-8">
<div>

**주요 특징**:
- 병렬 테스트 실행 (기본)
- 격리된 테스트 (각 테스트마다 새 인스턴스)
- 확장 가능한 아키텍처
- .NET Core/5+에 최적화

**설치**:
```bash
dotnet add package xunit
dotnet add package xunit.runner.visualstudio
dotnet add package Microsoft.NET.Test.Sdk
```

---
### xUnit.net 프레임워크 가이드
**기본 구조**:
```csharp
using Xunit;

// [TestClass] 불필요
public class CalculatorTests
{
 private readonly Calculator _calculator;

 // 각 테스트마다 생성자 호출 (SetUp 대신)
 public CalculatorTests()
 {
 _calculator = new Calculator();
 }

 // IDisposable 구현 (TearDown 대신)
 public void Dispose()
 {
---
### xUnit.net 프레임워크 가이드
 // cleanup
 }

 [Fact] // 파라미터 없는 테스트
 public void Add_TwoNumbers_ReturnsSum()
 {
 var result = _calculator.Add(5, 3);
 Assert.Equal(8, result);
 }

 [Theory] // 파라미터화 테스트
 [InlineData(1, 1, 2)]
 [InlineData(2, 3, 5)]
 [InlineData(-1, 1, 0)]
 public void Add_VariousInputs_ReturnsCorrectSum(
 int a, int b, int expected)
 {
---
### xUnit.net 프레임워크 가이드
 var result = _calculator.Add(a, b);
 Assert.Equal(expected, result);
 }
}
```

**Assert 메서드**:
```csharp
// 동등성
Assert.Equal(expected, actual);
Assert.NotEqual(notExpected, actual);

// Null
Assert.Null(obj);
Assert.NotNull(obj);

// Boolean
Assert.True(condition);
---
### xUnit.net 프레임워크 가이드
Assert.False(condition);

// 타입
Assert.IsType<MyClass>(obj);
Assert.IsAssignableFrom<IMyInterface>(obj);

// 컬렉션
Assert.Empty(collection);
Assert.NotEmpty(collection);
Assert.Contains(item, collection);
Assert.DoesNotContain(item, collection);
Assert.All(collection, item => Assert.NotNull(item));

// 문자열
Assert.Contains("substring", fullString);
Assert.StartsWith("prefix", fullString);
Assert.EndsWith("suffix", fullString);
Assert.Matches("regex.*pattern", text);

---
### xUnit.net 프레임워크 가이드
// 범위
Assert.InRange(value, low, high);

// 예외
Assert.Throws<DivideByZeroException>(() =>
 _calculator.Divide(10, 0));

var ex = Assert.Throws<ArgumentException>(() =>
 _calculator.Validate(-1));
Assert.Equal("Invalid value", ex.Message);
```

</div>
<div>

**고급 Theory 패턴**:
```csharp
// MemberData 사용
public static IEnumerable<object[]> AddTestData =>
---
### xUnit.net 프레임워크 가이드
 new List<object[]>
 {
 new object[] { 1, 1, 2 },
 new object[] { 2, 3, 5 },
 new object[] { -1, 1, 0 }
 };

[Theory]
[MemberData(nameof(AddTestData))]
public void Add_WithMemberData_ReturnsCorrectSum(
 int a, int b, int expected)
{
 var result = _calculator.Add(a, b);
 Assert.Equal(expected, result);
}

// ClassData 사용
---
### xUnit.net 프레임워크 가이드
public class AddTestDataClass : IEnumerable<object[]>
{
 public IEnumerator<object[]> GetEnumerator()
 {
 yield return new object[] { 1, 1, 2 };
 yield return new object[] { 2, 3, 5 };
 }

 IEnumerator IEnumerable.GetEnumerator()
 => GetEnumerator();
}

[Theory]
[ClassData(typeof(AddTestDataClass))]
public void Add_WithClassData_ReturnsCorrectSum(
 int a, int b, int expected)
{
---
### xUnit.net 프레임워크 가이드
 var result = _calculator.Add(a, b);
 Assert.Equal(expected, result);
}
```

**Collection Fixtures (공유 컨텍스트)**:
```csharp
// Fixture 정의
public class DatabaseFixture : IDisposable
{
 public DbContext DbContext { get; }

 public DatabaseFixture()
 {
 DbContext = new DbContext("TestDb");
 DbContext.Database.EnsureCreated();
 }

---
### xUnit.net 프레임워크 가이드
 public void Dispose()
 {
 DbContext?.Dispose();
 }
}

// Collection 정의
[CollectionDefinition("Database collection")]
public class DatabaseCollection
 : ICollectionFixture<DatabaseFixture>
{
 // 구현 필요 없음
}

// 테스트 클래스에서 사용
[Collection("Database collection")]
public class UserRepositoryTests
---
### xUnit.net 프레임워크 가이드
{
 private readonly DatabaseFixture _fixture;

 public UserRepositoryTests(DatabaseFixture fixture)
 {
 _fixture = fixture;
 }

 [Fact]
 public void SaveUser_ValidData_Succeeds()
 {
 // _fixture.DbContext 사용
 }
}

[Collection("Database collection")]
public class ProductRepositoryTests
{
---
### xUnit.net 프레임워크 가이드
 // 같은 DatabaseFixture 인스턴스 공유
}
```

**테스트 출력**:
```csharp
public class OutputTests
{
 private readonly ITestOutputHelper _output;

 public OutputTests(ITestOutputHelper output)
 {
 _output = output;
 }

 [Fact]
 public void TestWithLogging()
 {
---
### xUnit.net 프레임워크 가이드
 _output.WriteLine("Test started");
 _output.WriteLine($"Value: {someValue}");
 // 테스트 러너에서 출력 확인 가능
 }
}
```

</div>
</div>
---
### Moq 라이브러리 완전 가이드

**C#의 대표적인 Mocking 프레임워크**

<div class="grid grid-cols-2 gap-8">
<div>

**주요 특징**:
- 간결한 Fluent API
- LINQ 기반 쿼리 구문
- 강력한 검증 기능
- Auto-mocking 지원

**설치**:
```bash
dotnet add package Moq
```

---
### Moq 라이브러리 완전 가이드
**기본 Mock 생성**:
```csharp
// 인터페이스 Mock
var mockRepository = new Mock<IRepository>();

// Setup: 메서드 동작 정의
mockRepository
 .Setup(r => r.GetById(It.IsAny<string>()))
 .Returns(new Equipment { Id = "E001" });

// 사용
var repository = mockRepository.Object;
var equipment = repository.GetById("test");
// equipment.Id == "E001"

// Verify: 호출 검증
mockRepository.Verify(
 r => r.GetById(It.IsAny<string>()),
---
### Moq 라이브러리 완전 가이드
 Times.Once);
```

**Setup 패턴**:
```csharp
var mock = new Mock<IDataService>();

// 특정 인자값
mock.Setup(s => s.Get(42))
 .Returns("Specific value");

// 모든 인자값
mock.Setup(s => s.Get(It.IsAny<int>()))
 .Returns("Any value");

// 조건부 매칭
mock.Setup(s => s.Get(It.Is<int>(x => x > 0)))
 .Returns("Positive value");

mock.Setup(s => s.Get(It.IsInRange(1, 10, Range.Inclusive)))
---
### Moq 라이브러리 완전 가이드
 .Returns("Range value");

// 복잡한 객체 매칭
mock.Setup(s => s.Save(It.Is<Equipment>(e =>
 e.Id == "E001" && e.State == EquipmentState.Running)))
 .Returns(true);

// 예외 던지기
mock.Setup(s => s.Get(-1))
 .Throws<ArgumentException>();

mock.Setup(s => s.Get(999))
 .Throws(new NotFoundException("Not found"));
```

**비동기 메서드 Mock**:
```csharp
var mock = new Mock<IAsyncService>();

// 성공적인 비동기 호출
---
### Moq 라이브러리 완전 가이드
mock.Setup(s => s.GetDataAsync(It.IsAny<string>()))
 .ReturnsAsync("Data");

// Task 반환
mock.Setup(s => s.ProcessAsync(It.IsAny<Data>()))
 .Returns(Task.CompletedTask);

// 지연 시뮬레이션
mock.Setup(s => s.SlowOperationAsync())
 .Returns(async () =>
 {
 await Task.Delay(100);
 return "Result";
 });

// 예외
mock.Setup(s => s.FailingOperationAsync())
 .ThrowsAsync(new InvalidOperationException());
---
### Moq 라이브러리 완전 가이드
```

</div>
<div>

**Verify 패턴**:
```csharp
var mock = new Mock<INotificationService>();

// 작업 수행
await service.ProcessEquipment(equipment);

// 정확히 1번 호출
mock.Verify(
 n => n.SendAsync(It.IsAny<Notification>()),
 Times.Once);

// 호출 안됨
mock.Verify(
 n => n.SendErrorAsync(It.IsAny<string>()),
---
### Moq 라이브러리 완전 가이드
 Times.Never);

// 여러 번 호출
mock.Verify(
 n => n.LogAsync(It.IsAny<string>()),
 Times.AtLeast(2));

mock.Verify(
 n => n.UpdateStatusAsync(It.IsAny<Status>()),
 Times.Between(1, 5, Range.Inclusive));

// 특정 인자로 호출되었는지 검증
mock.Verify(
 n => n.SendAsync(It.Is<Notification>(
 x => x.Type == NotificationType.Critical)),
 Times.Once);

// 모든 Setup이 호출되었는지 검증
mock.VerifyAll();

---
### Moq 라이브러리 완전 가이드
// Setup되지 않은 메서드 호출 검증
mock.VerifyNoOtherCalls();
```

**Property Mock**:
```csharp
var mock = new Mock<IConfiguration>();

// Property Setup
mock.Setup(c => c.ConnectionString)
 .Returns("Server=localhost;Database=Test");

mock.SetupGet(c => c.Timeout)
 .Returns(30);

mock.SetupSet(c => c.IsEnabled = true)
 .Verifiable();

// Property 변경 추적
mock.SetupProperty(c => c.CurrentUser);
---
### Moq 라이브러리 완전 가이드
mock.Object.CurrentUser = "admin";
// CurrentUser는 "admin" 값 유지

// 모든 프로퍼티 자동 추적
mock.SetupAllProperties();
```

**Event Mock**:
```csharp
var mock = new Mock<ISensor>();

// Event 발생시키기
mock.Raise(s => s.ValueChanged += null,
 new SensorEventArgs { Value = 42 });

// Event 구독 검증
bool eventRaised = false;
mock.Object.ValueChanged += (s, e) => eventRaised = true;

mock.Raise(s => s.ValueChanged += null,
---
### Moq 라이브러리 완전 가이드
 EventArgs.Empty);

Assert.True(eventRaised);
```

**Callback 사용**:
```csharp
var capturedArgs = new List<Equipment>();

mock.Setup(r => r.Save(It.IsAny<Equipment>()))
 .Callback<Equipment>(e => capturedArgs.Add(e))
 .Returns(true);

// 저장 호출
repository.Save(equipment1);
repository.Save(equipment2);

// Callback으로 캡처된 인자 검증
Assert.Equal(2, capturedArgs.Count);
Assert.Equal("E001", capturedArgs[0].Id);
---
### Moq 라이브러리 완전 가이드
```

**Sequential Setup**:
```csharp
// 순차적으로 다른 값 반환
var sequence = new Queue<int>(new[] { 1, 2, 3 });

mock.Setup(s => s.GetNext())
 .Returns(() => sequence.Dequeue());

Assert.Equal(1, service.GetNext());
Assert.Equal(2, service.GetNext());
Assert.Equal(3, service.GetNext());
```

</div>
</div>
---
### Moq 고급 패턴

<div class="grid grid-cols-2 gap-8">
<div>

**Partial Mocks (일부만 Mock)**:
```csharp
// 추상 클래스나 가상 메서드만 Mock
var mock = new Mock<EquipmentService>
{
 CallBase = true // 실제 구현 호출
};

// 특정 메서드만 Override
mock.Setup(s => s.GetSensorData())
 .Returns(mockData);

// 나머지는 실제 구현 사용
var result = mock.Object.Process();
---
### Moq 고급 패턴
```

**Strict Mock (엄격 모드)**:
```csharp
// Setup되지 않은 호출 시 예외 발생
var mock = new Mock<IRepository>(MockBehavior.Strict);

mock.Setup(r => r.GetById("E001"))
 .Returns(equipment);

// Setup되지 않은 메서드 호출 시 예외!
Assert.Throws<MockException>(() =>
 mock.Object.GetById("E002"));
```

**Mock Repository (여러 Mock 관리)**:
```csharp
var repository = new MockRepository(MockBehavior.Strict);

var mock1 = repository.Create<IService1>();
---
### Moq 고급 패턴
var mock2 = repository.Create<IService2>();

// Setup...

// 모든 Mock Verify
repository.VerifyAll();
```

**Protected Members Mocking**:
```csharp
var mock = new Mock<MyBaseClass>();

// protected 메서드 Mock
mock.Protected()
 .Setup<Task<string>>("ProcessDataAsync",
 ItExpr.IsAny<Data>())
 .ReturnsAsync("Result");

// protected 메서드 호출 검증
mock.Protected()
---
### Moq 고급 패턴
 .Verify("ProcessDataAsync", Times.Once(),
 ItExpr.IsAny<Data>());
```

</div>
<div>

**복잡한 시나리오 예제**:
```csharp
// 센서 데이터 수집 시스템 테스트
[TestClass]
public class DataCollectorTests
{
 [TestMethod]
 public async Task CollectData_WithMultipleSensors_SavesAllData()
 {
 // Arrange
---
### Moq 고급 패턴
 var mockSensor1 = new Mock<ISensor>();
 var mockSensor2 = new Mock<ISensor>();
 var mockRepository = new Mock<IDataRepository>();

 mockSensor1.Setup(s => s.ReadAsync())
 .ReturnsAsync(25.5);
 mockSensor2.Setup(s => s.ReadAsync())
 .ReturnsAsync(1.2);

 var capturedData = new List<SensorData>();
 mockRepository
 .Setup(r => r.SaveAsync(It.IsAny<SensorData>()))
 .Callback<SensorData>(data => capturedData.Add(data))
 .Returns(Task.CompletedTask);

 var collector = new DataCollector(
 new[] { mockSensor1.Object, mockSensor2.Object },
 mockRepository.Object);

---
### Moq 고급 패턴
 // Act
 await collector.CollectDataAsync();

 // Assert
 mockSensor1.Verify(s => s.ReadAsync(), Times.Once);
 mockSensor2.Verify(s => s.ReadAsync(), Times.Once);

 mockRepository.Verify(
 r => r.SaveAsync(It.IsAny<SensorData>()),
 Times.Exactly(2));

 Assert.AreEqual(2, capturedData.Count);
 Assert.AreEqual(25.5, capturedData[0].Value);
 Assert.AreEqual(1.2, capturedData[1].Value);
 }
}
---
### Moq 고급 패턴
```

**테스트 헬퍼 클래스**:
```csharp
public static class MockHelper
{
 public static Mock<ISensor> CreateSensorMock(
 double value,
 string sensorId = "S001")
 {
 var mock = new Mock<ISensor>();

 mock.Setup(s => s.SensorId).Returns(sensorId);
 mock.Setup(s => s.ReadAsync()).ReturnsAsync(value);
 mock.Setup(s => s.CalibrateAsync(It.IsAny<double>()))
 .ReturnsAsync(true);

 return mock;
---
### Moq 고급 패턴
 }

 public static Mock<IRepository<T>> CreateRepositoryMock<T>()
 where T : class
 {
 var mock = new Mock<IRepository<T>>();
 var storage = new List<T>();

 mock.Setup(r => r.AddAsync(It.IsAny<T>()))
 .Callback<T>(item => storage.Add(item))
 .Returns(Task.CompletedTask);

 mock.Setup(r => r.GetAllAsync())
 .ReturnsAsync(() => storage.ToList());

 return mock;
 }
}

// 사용
---
### Moq 고급 패턴
[TestMethod]
public async Task TestWithHelper()
{
 var sensor = MockHelper.CreateSensorMock(42.5);
 var repository = MockHelper.CreateRepositoryMock<Equipment>();

 // 테스트...
}
```

</div>
</div>
---
