# 이론 강의: ImGui 고급 기능

---
## 플러그인 시스템 아키텍처

### 플러그인 시스템의 개념과 필요성

**확장 가능한 소프트웨어 설계**

<div class="grid grid-cols-2 gap-8">
<div>

**플러그인 시스템이란?**

플러그인 시스템은 **핵심 프로그램의 수정 없이 기능을 추가/제거**할 수 있는 소프트웨어 아키텍처 패턴입니다.

**실생활 비유**:
- **전원 콘센트**: 본체(벽)는 그대로, 다양한 기기(플러그인) 연결
- **스마트폰 앱**: OS는 그대로, 앱 설치/삭제로 기능 확장
- **레고 블록**: 기본 구조에 다양한 블록 조합

**반도체 HMI에서의 필요성**:

1. **다양한 장비 지원**
 - CVD, Etcher, CMP 등 각기 다른 장비
 - 각 장비마다 다른 센서/제어 방식
 - 플러그인으로 장비별 맞춤 UI 제공

---
## 플러그인 시스템 아키텍처
2. **고객 맞춤화**
 - 고객사마다 다른 요구사항
 - 핵심 시스템 변경 없이 커스터마이징
 - 빠른 대응과 유지보수

3. **확장성**
 - 새로운 데이터 소스 추가 (OPC-UA, SECS/GEM 등)
 - 새로운 시각화 기능 추가
 - 제3자 개발자 지원

---
## 플러그인 시스템 아키텍처
```mermaid
graph TB
 subgraph "Core System (핵심 시스템)"
 Core[HMI Core Application]
 PM[Plugin Manager<br/>플러그인 관리자]
 API[Plugin API/Interface<br/>플러그인 인터페이스]
 end

 subgraph "Plugins (플러그인들)"
 P1[CVD Monitor Plugin<br/>CVD 모니터링]
 P2[OPC-UA Data Source<br/>OPC-UA 데이터]
 P3[Custom Chart Plugin<br/>커스텀 차트]
 P4[3rd Party Plugin<br/>제3자 플러그인]
 end

 Core --> PM
 PM --> API
 API -.DLL Loading.-> P1
 API -.DLL Loading.-> P2
 API -.DLL Loading.-> P3
 API -.DLL Loading.-> P4

 style Core fill:#e1f5fe
 style PM fill:#b3e5fc
 style API fill:#81d4fa
 style P1 fill:#fff9c4
 style P2 fill:#fff9c4
 style P3 fill:#fff9c4
 style P4 fill:#fff9c4
```

---
## 플러그인 시스템 아키텍처
**플러그인 시스템의 핵심 구성요소**:

1. **Host Application (호스트 애플리케이션)**
 - 플러그인을 로드하고 실행하는 주 프로그램
 - 플러그인 생명주기 관리

2. **Plugin Interface (플러그인 인터페이스)**
 - 플러그인이 구현해야 할 표준 인터페이스
 - 호스트와 플러그인 간 통신 규약

3. **Plugin Manager (플러그인 관리자)**
 - 플러그인 검색, 로드, 언로드
 - 의존성 해결, 버전 관리

4. **Plugins (플러그인)**
 - 실제 기능을 구현한 DLL/공유 라이브러리
 - 독립적으로 개발/배포 가능

</div>
<div>

---
## 플러그인 시스템 아키텍처
**플러그인 시스템의 장점**:

 **확장성 (Extensibility)**
- 새 기능을 쉽게 추가
- 핵심 코드 수정 불필요

 **모듈성 (Modularity)**
- 각 플러그인이 독립적
- 한 플러그인 오류가 전체에 영향 안 줌

 **재사용성 (Reusability)**
- 플러그인을 다른 프로젝트에서 재사용
- 공통 기능 라이브러리화

 **유지보수성 (Maintainability)**
- 기능별 분리로 관리 용이
- 버그 수정이 격리됨

**플러그인 시스템의 단점**:

️ **복잡성 증가**
---
## 플러그인 시스템 아키텍처
- 아키텍처가 복잡해짐
- 디버깅 어려움

️ **성능 오버헤드**
- 동적 로딩 비용
- 간접 호출 비용

️ **보안 위험**
- 제3자 플러그인 검증 필요
- 악성 코드 위험

**플러그인 인터페이스 설계 원칙**:

---
## 플러그인 시스템 아키텍처
```cpp
// 1. 안정적인 ABI (Application Binary Interface)
// - 순수 가상 함수 (pure virtual functions)
// - C 스타일 함수 포인터
// - 표준 타입만 사용

class IPlugin {
public:
 virtual ~IPlugin() = default;

 // 메타 정보
 virtual const char* GetName() const = 0;
 virtual const char* GetVersion() const = 0;

 // 생명주기
 virtual bool Initialize() = 0;
 virtual void Shutdown() = 0;

 // 실행
 virtual void Update(float deltaTime) = 0;
 virtual void Render() = 0;
};

// 2. 버전 관리
struct PluginInfo {
 uint32_t api_version; // API 버전
 uint32_t plugin_version; // 플러그인 버전
 const char* name;
 const char* description;
};

// 3. 팩토리 함수 (Factory Function)
extern "C" {
 // C 링크로 심볼 맹글링 방지
 __declspec(dllexport)
 IPlugin* CreatePlugin();

 __declspec(dllexport)
 void DestroyPlugin(IPlugin* plugin);

 __declspec(dllexport)
 PluginInfo GetPluginInfo();
}
```

---
## 플러그인 시스템 아키텍처
**동적 로딩 프로세스**:

---
## 플러그인 시스템 아키텍처
```mermaid
sequenceDiagram
 participant Host as Host Application
 participant PM as Plugin Manager
 participant DLL as Plugin DLL
 participant Plugin as Plugin Instance

 Host->>PM: LoadPlugin("CVDMonitor.dll")
 PM->>DLL: LoadLibrary()
 DLL-->>PM: DLL Handle

 PM->>DLL: GetProcAddress("CreatePlugin")
 DLL-->>PM: Function Pointer

 PM->>DLL: CreatePlugin()
 DLL->>Plugin: new CVDMonitorPlugin()
 Plugin-->>PM: IPlugin*

 PM->>Plugin: Initialize()
 Plugin-->>PM: true/false

 loop Game Loop
 Host->>PM: UpdatePlugins()
 PM->>Plugin: Update(deltaTime)
 PM->>Plugin: Render()
 end

 Host->>PM: UnloadPlugin()
 PM->>DLL: DestroyPlugin(plugin)
 DLL->>Plugin: delete
 PM->>DLL: FreeLibrary()
```

---
## 플러그인 시스템 아키텍처
<!-- IMAGE PLACEHOLDER: 플러그인 시스템 실제 예시 -->
<!--
이미지 설명:
- Visual Studio Code의 확장 마켓플레이스 스크린샷
- Chrome 브라우저의 확장 프로그램 관리 화면
- 반도체 HMI에서 플러그인 관리 UI 목업
세 가지를 나란히 배치하여 플러그인 시스템의 실제 사례 시각화
-->

</div>
</div>
---
### DLL 동적 로딩 메커니즘

**Windows DLL의 동작 원리**

<div class="grid grid-cols-2 gap-8">
<div>

**DLL이란?**

**Dynamic Link Library (동적 링크 라이브러리)**는 여러 프로그램이 공유할 수 있는 코드와 데이터를 포함하는 라이브러리입니다.

**정적 링킹 vs 동적 링킹**:

---
### DLL 동적 로딩 메커니즘
```mermaid
graph LR
 subgraph "Static Linking (정적 링킹)"
 S1[Source Code] --> S2[Compiler]
 S2 --> S3[Object Files]
 S3 --> S4[Linker]
 LIB[Static Library<br/>.lib] --> S4
 S4 --> S5[Executable<br/>큰 파일]
 end

 subgraph "Dynamic Linking (동적 링킹)"
 D1[Source Code] --> D2[Compiler]
 D2 --> D3[Object Files]
 D3 --> D4[Linker]
 DLL[DLL Import Lib<br/>.lib] --> D4
 D4 --> D5[Executable<br/>작은 파일]
 D5 -.Runtime Loading.-> D6[DLL<br/>공유]
 end
```

---
### DLL 동적 로딩 메커니즘
**장점**:
- **메모리 절약**: 여러 프로그램이 하나의 DLL 공유
- **업데이트 용이**: DLL만 교체하면 모든 프로그램 업데이트
- **실행파일 크기 감소**

**단점**:
- **DLL Hell**: 버전 충돌 문제
- **의존성**: DLL이 없으면 실행 불가
- **보안**: 악의적인 DLL 교체 위험

**DLL 로딩 방법**:

**1. 암시적 링킹 (Implicit Linking)**
```cpp
// 컴파일 타임에 링크
#pragma comment(lib, "MyLibrary.lib")

// 사용
MyFunction(); // DLL 함수 직접 호출
---
### DLL 동적 로딩 메커니즘
```

**2. 명시적 링킹 (Explicit Linking)** ⭐
```cpp
// 런타임에 로딩
HMODULE hDll = LoadLibrary("MyPlugin.dll");

if (hDll) {
 // 함수 포인터 가져오기
 typedef int (*FuncPtr)(int);
 FuncPtr func = (FuncPtr)GetProcAddress(
 hDll, "MyFunction");

 if (func) {
 int result = func(42);
 }

 FreeLibrary(hDll);
}
---
### DLL 동적 로딩 메커니즘
```

</div>
<div>

**플러그인 로더 구현**:

```cpp
class PluginLoader {
private:
 HMODULE dll_handle_ = nullptr;
 IPlugin* plugin_instance_ = nullptr;

 // 함수 포인터 타입
 using CreatePluginFunc = IPlugin* (*)();
 using DestroyPluginFunc = void (*)(IPlugin*);
 using GetInfoFunc = PluginInfo (*)();

public:
 bool Load(const std::string& dll_path) {
---
### DLL 동적 로딩 메커니즘
 // 1. DLL 로드
 dll_handle_ = LoadLibraryA(dll_path.c_str());
 if (!dll_handle_) {
 DWORD error = GetLastError();
 std::cerr << "Failed to load DLL: "
 << error << std::endl;
 return false;
 }

 // 2. 버전 확인
 auto getInfo = (GetInfoFunc)GetProcAddress(
 dll_handle_, "GetPluginInfo");

 if (getInfo) {
 PluginInfo info = getInfo();
 if (info.api_version != CURRENT_API_VERSION) {
 std::cerr << "API version mismatch"
---
### DLL 동적 로딩 메커니즘
 << std::endl;
 FreeLibrary(dll_handle_);
 return false;
 }
 }

 // 3. 플러그인 인스턴스 생성
 auto createPlugin = (CreatePluginFunc)
 GetProcAddress(dll_handle_, "CreatePlugin");

 if (!createPlugin) {
 std::cerr << "CreatePlugin not found"
 << std::endl;
 FreeLibrary(dll_handle_);
 return false;
 }

 plugin_instance_ = createPlugin();

---
### DLL 동적 로딩 메커니즘
 if (!plugin_instance_) {
 std::cerr << "Plugin creation failed"
 << std::endl;
 FreeLibrary(dll_handle_);
 return false;
 }

 // 4. 초기화
 if (!plugin_instance_->Initialize()) {
 std::cerr << "Plugin initialization failed"
 << std::endl;
 Unload();
 return false;
 }

 return true;
 }

---
### DLL 동적 로딩 메커니즘
 void Unload() {
 if (plugin_instance_) {
 auto destroyPlugin = (DestroyPluginFunc)
 GetProcAddress(dll_handle_,
 "DestroyPlugin");

 if (destroyPlugin) {
 destroyPlugin(plugin_instance_);
 }
 plugin_instance_ = nullptr;
 }

 if (dll_handle_) {
 FreeLibrary(dll_handle_);
 dll_handle_ = nullptr;
 }
 }

---
### DLL 동적 로딩 메커니즘
 IPlugin* GetPlugin() const {
 return plugin_instance_;
 }
};
```

**에러 처리와 안전성**:

```cpp
// 1. DLL 경로 보안
std::string GetSecureDllPath(const std::string& name) {
 // 절대 경로 확인
 fs::path dll_path = fs::absolute(
 "plugins/" + name + ".dll");

 // plugins 폴더 내부인지 검증
 fs::path plugins_dir = fs::absolute("plugins");

 if (!dll_path.string().starts_with(
---
### DLL 동적 로딩 메커니즘
 plugins_dir.string())) {
 throw std::runtime_error(
 "DLL path outside plugins directory");
 }

 return dll_path.string();
}

// 2. 심볼 검증
bool ValidatePluginExports(HMODULE dll) {
 const char* required_exports[] = {
 "CreatePlugin",
 "DestroyPlugin",
 "GetPluginInfo"
 };

 for (const char* name : required_exports) {
 if (!GetProcAddress(dll, name)) {
---
### DLL 동적 로딩 메커니즘
 return false;
 }
 }

 return true;
}

// 3. 예외 격리
void SafePluginCall(IPlugin* plugin) {
 __try {
 plugin->Update(0.016f);
 }
 __except (EXCEPTION_EXECUTE_HANDLER) {
 std::cerr << "Plugin crashed!" << std::endl;
 // 플러그인 비활성화
 }
}
---
### DLL 동적 로딩 메커니즘
```

<!-- IMAGE PLACEHOLDER: DLL 메모리 맵 -->
<!--
이미지 설명:
- 프로세스 메모리 공간에 DLL이 로드되는 과정 시각화
- Base Address, Import Address Table (IAT) 표시
- 여러 프로세스가 하나의 DLL을 공유하는 모습
Process Explorer 스크린샷 또는 다이어그램
-->

</div>
</div>
---
## 고급 데이터 시각화

### 멀티 차트 시스템

**실시간 데이터의 효과적인 시각화**

<div class="grid grid-cols-2 gap-8">
<div>

**데이터 시각화의 중요성**

반도체 장비에서는 **수십~수백 개의 센서**가 실시간으로 데이터를 생성합니다. 이를 효과적으로 시각화하지 않으면:

 **문제점**:
- 이상 징후 발견 지연
- 운영자 인지 부하 증가
- 데이터 간 상관관계 파악 불가

 **해결책**:
- 다중 차트로 한눈에 파악
- 색상/패턴으로 즉각 인지
- 동기화된 시간축

**차트 유형별 용도**:

---
## 고급 데이터 시각화
```mermaid
graph TB
 Data[센서 데이터] --> Analysis{분석 목적}

 Analysis -->|추세 확인| Line[Line Chart<br/>선 그래프]
 Analysis -->|비교| Bar[Bar Chart<br/>막대 그래프]
 Analysis -->|분포| Scatter[Scatter Plot<br/>산점도]
 Analysis -->|비율| Pie[Pie Chart<br/>원 그래프]
 Analysis -->|시간별 패턴| Heatmap[Heatmap<br/>히트맵]

 Line --> Use1[온도/압력 트렌드]
 Bar --> Use2[장비별 가동률]
 Scatter --> Use3[온도-압력 상관관계]
 Pie --> Use4[불량 유형 비율]
 Heatmap --> Use5[시간대별 온도 분포]

 style Data fill:#e1f5fe
 style Line fill:#c8e6c9
 style Bar fill:#fff9c4
 style Scatter fill:#ffccbc
 style Pie fill:#f8bbd0
 style Heatmap fill:#d1c4e9
```

---
## 고급 데이터 시각화
**실시간 차트 렌더링 최적화**:

**문제**: 60fps로 수십 개 차트를 그리면 성능 저하

**해결책**:

1. **데이터 다운샘플링 (Downsampling)**
---
## 고급 데이터 시각화
```cpp
// 10,000개 데이터를 1,000개로 압축
std::vector<Point> Downsample(
 const std::vector<Point>& data,
 size_t target_count) {

 if (data.size() <= target_count) {
 return data;
 }

 std::vector<Point> result;
 size_t step = data.size() / target_count;

 for (size_t i = 0; i < data.size(); i += step) {
 // 구간 평균
 double sum = 0;
 size_t count = 0;

 for (size_t j = i; j < i + step && j < data.size(); ++j) {
 sum += data[j].value;
 count++;
 }

 result.push_back({
 data[i].timestamp,
 sum / count
 });
 }

 return result;
}
```

---
## 고급 데이터 시각화
</div>
<div>

2. **Level of Detail (LOD)**
---
## 고급 데이터 시각화
```cpp
// 줌 레벨에 따라 다른 해상도
std::vector<Point> GetDataForTimeRange(
 double time_range) {

 if (time_range > 3600) {
 // 1시간 이상: 분 단위
 return hourly_aggregated_data_;
 } else if (time_range > 60) {
 // 1분~1시간: 초 단위
 return second_data_;
 } else {
 // 1분 이하: 밀리초 단위
 return millisecond_data_;
 }
}
```

---
## 고급 데이터 시각화
3. **더티 플래그 (Dirty Flag)**
---
## 고급 데이터 시각화
```cpp
class Chart {
 bool dirty_ = true;
 ImTextureID cached_texture_ = nullptr;

 void Render() {
 if (dirty_) {
 // 차트를 텍스처로 렌더링
 RenderToTexture();
 dirty_ = false;
 }

 // 캐시된 텍스처 표시
 ImGui::Image(cached_texture_, size);
 }

 void OnDataUpdated() {
 dirty_ = true; // 다음 프레임에 재렌더링
 }
};
```

---
## 고급 데이터 시각화
**차트 동기화**:

---
## 고급 데이터 시각화
```cpp
struct ChartSyncManager {
 double current_time_range = 60.0; // 60초
 double time_offset = 0.0;
 bool sync_enabled = true;

 // 모든 차트에 동일한 시간축 적용
 void SyncTimeAxis(std::vector<Chart*>& charts) {
 if (!sync_enabled) return;

 double end_time = GetCurrentTime() - time_offset;
 double start_time = end_time - current_time_range;

 for (auto* chart : charts) {
 chart->SetTimeRange(start_time, end_time);
 }
 }

 // 줌/팬 동기화
 void OnZoom(double factor) {
 current_time_range /= factor;
 current_time_range = std::clamp(
 current_time_range, 1.0, 86400.0);
 }

 void OnPan(double delta_time) {
 time_offset += delta_time;
 time_offset = std::max(0.0, time_offset);
 }
};
```

---
## 고급 데이터 시각화
**색상 스키마**:

---
## 고급 데이터 시각화
```cpp
// 데이터 값에 따른 색상 매핑
ImU32 GetColorForValue(
 double value,
 double min_val,
 double max_val) {

 // 정규화 (0.0 ~ 1.0)
 double t = (value - min_val) / (max_val - min_val);
 t = std::clamp(t, 0.0, 1.0);

 // Heatmap: 파랑 → 초록 → 노랑 → 빨강
 if (t < 0.33) {
 // 파랑 → 초록
 float s = t / 0.33f;
 return IM_COL32(0, 255 * s, 255 * (1 - s), 255);
 } else if (t < 0.66) {
 // 초록 → 노랑
 float s = (t - 0.33f) / 0.33f;
 return IM_COL32(255 * s, 255, 0, 255);
 } else {
 // 노랑 → 빨강
 float s = (t - 0.66f) / 0.34f;
 return IM_COL32(255, 255 * (1 - s), 0, 255);
 }
}
```

---
## 고급 데이터 시각화
<!-- IMAGE PLACEHOLDER: 차트 대시보드 예시 -->
<!--
이미지 설명:
- 반도체 HMI 다중 차트 대시보드 스크린샷
- 2x2 그리드로 배치된 4개 차트:
 1. 온도 추세 (Line Chart, 빨간색)
 2. 압력 추세 (Line Chart, 파란색)
 3. 가스 유량 (Area Chart, 초록색)
 4. 장비 상태 (Bar Chart, 다양한 색상)
- 동기화된 시간축 표시
- 현재 값 오버레이
-->

</div>
</div>
---
### 멀티스레드 렌더링

**성능 최적화를 위한 병렬 처리**

<div class="grid grid-cols-2 gap-8">
<div>

**왜 멀티스레드 렌더링이 필요한가?**

**문제 상황**:
$$
\text{Frame Time} = \text{Data Processing} + \text{Rendering} + \text{UI Logic}
$$

- 차트 1개 렌더링: 5ms
- 차트 20개 렌더링: 100ms
- 60fps 목표: 16.67ms 이하 필요
- **100ms > 16.67ms** → 프레임 드롭 발생

**해결책**: 렌더링을 여러 스레드로 분산

$$
\text{Parallel Frame Time} = \frac{\text{Total Work}}{\text{Thread Count}} + \text{Overhead}
---
### 멀티스레드 렌더링
$$

- 4코어 CPU 사용
- 100ms ÷ 4 = 25ms
- 오버헤드 고려: ~30ms
- 여전히 느리지만 개선됨

**더 나은 방법**: **비동기 렌더링**

---
### 멀티스레드 렌더링
```cpp
// 렌더링을 백그라운드 스레드로
void AsyncRenderChart(Chart* chart) {
 std::thread([chart]() {
 // 1. 데이터 처리 (CPU 작업)
 auto processed = chart->ProcessData();

 // 2. 텍스처로 렌더링 (GPU 작업)
 auto texture = RenderToTexture(processed);

 // 3. 메인 스레드로 결과 전달
 MainThreadQueue.Push([chart, texture]() {
 chart->SetTexture(texture);
 });
 }).detach();
}
```

---
### 멀티스레드 렌더링
**ImGui 멀티스레드 주의사항**:

️ **ImGui는 기본적으로 싱글스레드**
- ImGui 함수는 **메인 스레드에서만** 호출
- 백그라운드 스레드에서는 데이터 처리만
- 렌더링 명령은 메인 스레드에서

**안전한 멀티스레드 패턴**:

---
### 멀티스레드 렌더링
```mermaid
sequenceDiagram
 participant Main as Main Thread
 participant Worker as Worker Thread
 participant Queue as Task Queue
 participant GPU as GPU

 Main->>Queue: QueueRenderTask(chart_data)
 Main->>Main: Continue UI logic

 Queue->>Worker: Dequeue task
 Worker->>Worker: Process chart data
 Worker->>Worker: Generate vertices

 Worker->>Queue: Push result

 Main->>Queue: Check completed tasks
 Queue-->>Main: Processed data
 Main->>GPU: ImGui::DrawList commands
 GPU-->>Main: Rendered frame
```

---
### 멀티스레드 렌더링
</div>
<div>

**작업 큐 기반 시스템**:

---
### 멀티스레드 렌더링
```cpp
class RenderTaskQueue {
private:
 std::queue<RenderTask> tasks_;
 std::mutex mutex_;
 std::condition_variable cv_;
 std::vector<std::thread> workers_;
 bool running_ = true;

public:
 RenderTaskQueue(size_t thread_count = 4) {
 for (size_t i = 0; i < thread_count; ++i) {
 workers_.emplace_back([this]() {
 WorkerThread();
 });
 }
 }

 ~RenderTaskQueue() {
 {
 std::lock_guard lock(mutex_);
 running_ = false;
 }
 cv_.notify_all();

 for (auto& worker : workers_) {
 worker.join();
 }
 }

 void QueueTask(RenderTask task, int priority = 0) {
 {
 std::lock_guard lock(mutex_);
 tasks_.push(task);
 }
 cv_.notify_one();
 }

 std::vector<RenderResult> CollectResults() {
 std::lock_guard lock(mutex_);
 std::vector<RenderResult> results;

 // 완료된 작업 수집
 while (!completed_tasks_.empty()) {
 results.push_back(completed_tasks_.front());
 completed_tasks_.pop();
 }

 return results;
 }

private:
 void WorkerThread() {
 while (running_) {
 RenderTask task;

 {
 std::unique_lock lock(mutex_);
 cv_.wait(lock, [this]() {
 return !tasks_.empty() || !running_;
 });

 if (!running_) break;

 task = tasks_.front();
 tasks_.pop();
 }

 // 작업 실행 (락 없이)
 RenderResult result = task.Execute();

 {
 std::lock_guard lock(mutex_);
 completed_tasks_.push(result);
 }
 }
 }

 std::queue<RenderResult> completed_tasks_;
};
```

---
### 멀티스레드 렌더링
**메인 루프 통합**:

---
### 멀티스레드 렌더링
```cpp
void GameLoop() {
 RenderTaskQueue task_queue(4);

 while (!should_quit) {
 // 1. 백그라운드 작업 큐잉
 for (auto* chart : charts) {
 if (chart->NeedsUpdate()) {
 task_queue.QueueTask(
 CreateChartRenderTask(chart)
 );
 }
 }

 // 2. ImGui 프레임 시작
 ImGui::NewFrame();

 // 3. 완료된 작업 결과 수집
 auto results = task_queue.CollectResults();
 for (const auto& result : results) {
 result.chart->SetRenderData(result.data);
 }

 // 4. ImGui 렌더링 (메인 스레드)
 for (auto* chart : charts) {
 chart->RenderImGui(); // 빠름 (데이터 준비됨)
 }

 // 5. ImGui 프레임 종료
 ImGui::Render();
 RenderDrawData(ImGui::GetDrawData());
 }
}
```

---
### 멀티스레드 렌더링
**성능 측정**:

$$
\text{Speedup} = \frac{T_{\text{serial}}}{T_{\text{parallel}}}
$$

$$
\text{Efficiency} = \frac{\text{Speedup}}{N_{\text{cores}}} \times 100\%
$$

예시:
- Serial: 100ms
- Parallel (4 cores): 30ms
- Speedup: 100/30 = 3.33x
- Efficiency: 3.33/4 = 83.3%

<!-- IMAGE PLACEHOLDER: 멀티스레드 성능 그래프 -->
<!--
이미지 설명:
---
### 멀티스레드 렌더링
- X축: 차트 개수 (1, 5, 10, 20, 40)
- Y축: 프레임 타임 (ms)
- 두 개 라인:
 1. 싱글스레드 (빨강, 선형 증가)
 2. 멀티스레드 4코어 (파랑, 완만한 증가)
- 60fps 기준선 (16.67ms) 표시
- 교차점 강조
-->

</div>
</div>
---
## 외부 시스템 연동

### OPC-UA 통신

**산업 표준 통신 프로토콜**

<div class="grid grid-cols-2 gap-8">
<div>

**OPC-UA란?**

**OPC Unified Architecture**는 산업 자동화를 위한 **플랫폼 독립적인 통신 프로토콜**입니다.

**실생활 비유**:
- **HTTP/REST API**: 웹 서비스의 표준 통신
- **OPC-UA**: 산업 장비의 표준 통신
- **USB**: 다양한 기기를 하나의 방식으로 연결

**OPC-UA vs OPC Classic**:

| 특징 | OPC Classic | OPC-UA |
|-----|------------|--------|
| 플랫폼 | Windows 전용 | 모든 OS |
| 통신 | DCOM | TCP/IP, HTTPS |
---
## 외부 시스템 연동
| 보안 | 약함 | 강력 (암호화) |
| 방화벽 | 어려움 | 쉬움 |
| 데이터 모델 | 단순 | 복잡 (객체지향) |

**OPC-UA 아키텍처**:

---
## 외부 시스템 연동
```mermaid
graph TB
 subgraph "Client (HMI)"
 C1[OPC-UA Client<br/>클라이언트]
 C2[Subscription Manager<br/>구독 관리자]
 C3[Data Cache<br/>데이터 캐시]
 end

 subgraph "Network"
 N1[OPC-UA Binary Protocol<br/>바이너리 프로토콜]
 N2[Security Layer<br/>보안 계층]
 end

 subgraph "Server (Equipment)"
 S1[OPC-UA Server<br/>서버]
 S2[Address Space<br/>주소 공간]
 S3[Sensors/Actuators<br/>센서/액추에이터]
 end

 C1 --> C2
 C2 --> C3
 C1 -.Session.-> N1
 N1 --> N2
 N2 -.Secure Channel.-> S1
 S1 --> S2
 S2 --> S3

 style C1 fill:#e1f5fe
 style S1 fill:#fff9c4
 style N2 fill:#ffcdd2
```

---
## 외부 시스템 연동
**주소 공간 (Address Space)**:

OPC-UA는 **계층적 정보 모델**을 사용:

```
Root
├── Objects
│ ├── DeviceSet
│ │ ├── CVD_Chamber_1
│ │ │ ├── Temperature (Variable)
│ │ │ ├── Pressure (Variable)
│ │ │ └── StartProcess (Method)
│ │ └── CVD_Chamber_2
│ └── RecipeManager
└── Types
 └── EquipmentType
```

---
## 외부 시스템 연동
**노드 ID 형식**:
```
ns=2;s=CVD_Chamber_1.Temperature
│ │ └─────────┬─────────────┘
│ │ └─ String Identifier
│ └─ Namespace Index
└─ Namespace Prefix
```

</div>
<div>

**OPC-UA 클라이언트 구현**:

---
## 외부 시스템 연동
```cpp
#include <open62541/client.h>

class OPCUAClient {
private:
 UA_Client* client_ = nullptr;
 std::string server_url_;
 bool connected_ = false;

public:
 bool Connect(const std::string& server_url) {
 server_url_ = server_url;

 // 클라이언트 생성
 client_ = UA_Client_new();
 UA_ClientConfig_setDefault(
 UA_Client_getConfig(client_));

 // 연결
 UA_StatusCode status = UA_Client_connect(
 client_,
 server_url_.c_str()
 );

 if (status == UA_STATUSCODE_GOOD) {
 connected_ = true;
 return true;
 }

 return false;
 }

 // 단일 값 읽기
 double ReadValue(const std::string& node_id) {
 if (!connected_) return 0.0;

 UA_NodeId nodeId = UA_NODEID_STRING(
 2, const_cast<char*>(node_id.c_str()));

 UA_Variant value;
 UA_StatusCode status = UA_Client_readValueAttribute(
 client_, nodeId, &value);

 if (status == UA_STATUSCODE_GOOD &&
 UA_Variant_hasScalarType(&value,
 &UA_TYPES[UA_TYPES_DOUBLE])) {

 double result = *(UA_Double*)value.data;
 UA_Variant_clear(&value);
 return result;
 }

 return 0.0;
 }

 // 값 쓰기
 bool WriteValue(const std::string& node_id,
 double value) {
 if (!connected_) return false;

 UA_NodeId nodeId = UA_NODEID_STRING(
 2, const_cast<char*>(node_id.c_str()));

 UA_Variant newValue;
 UA_Variant_setScalar(&newValue, &value,
 &UA_TYPES[UA_TYPES_DOUBLE]);

 UA_StatusCode status =
 UA_Client_writeValueAttribute(
 client_, nodeId, &newValue);

 return status == UA_STATUSCODE_GOOD;
 }

 // 구독 (Subscription)
 void CreateSubscription(
 const std::vector<std::string>& node_ids,
 std::function<void(const std::string&,
 double)> callback) {

 // 구독 생성
 UA_CreateSubscriptionRequest request =
 UA_CreateSubscriptionRequest_default();

 UA_CreateSubscriptionResponse response =
 UA_Client_Subscriptions_create(
 client_, request, nullptr,
 nullptr, nullptr);

 UA_UInt32 subId = response.subscriptionId;

 // 모니터링 항목 추가
 for (const auto& node_id : node_ids) {
 UA_NodeId nodeId = UA_NODEID_STRING(
 2, const_cast<char*>(node_id.c_str()));

 UA_MonitoredItemCreateRequest item;
 UA_MonitoredItemCreateRequest_default(&item);
 item.itemToMonitor.nodeId = nodeId;
 item.itemToMonitor.attributeId =
 UA_ATTRIBUTEID_VALUE;
 item.monitoringMode =
 UA_MONITORINGMODE_REPORTING;

 // 콜백 등록
 UA_Client_MonitoredItems_createDataChange(
 client_, subId,
 UA_TIMESTAMPSTORETURN_BOTH,
 item, this,
 DataChangeCallback, nullptr);
 }
 }

private:
 static void DataChangeCallback(
 UA_Client *client,
 UA_UInt32 subId,
 void *subContext,
 UA_UInt32 monId,
 void *monContext,
 UA_DataValue *value) {

 auto* self = static_cast<OPCUAClient*>(
 subContext);

 if (UA_Variant_hasScalarType(&value->value,
 &UA_TYPES[UA_TYPES_DOUBLE])) {

 double val = *(UA_Double*)value->value.data;
 // 콜백 호출
 // self->callback_(node_id, val);
 }
 }
};
```

---
## 외부 시스템 연동
**통신 최적화**:

$$
\text{Total Latency} = \text{Network} + \text{Processing} + \text{Serialization}
$$

- **Batch Read**: 여러 값을 한 번에 읽기
- **Subscription**: 변경 시에만 통지
- **Compression**: 데이터 압축 전송

<!-- IMAGE PLACEHOLDER: OPC-UA 통신 흐름도 -->
<!--
이미지 설명:
---
## 외부 시스템 연동
- Wireshark 캡처 화면 또는 시퀀스 다이어그램
- OPC-UA 세션 생성 과정:
 1. Hello/Acknowledge
 2. OpenSecureChannel
 3. CreateSession
 4. ActivateSession
 5. Read/Write/Subscribe 요청
- 각 단계별 소요 시간 표시
-->

</div>
</div>
---
