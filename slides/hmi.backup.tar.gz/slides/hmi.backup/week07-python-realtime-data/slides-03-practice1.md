# 메인 실행
if __name__ == "__main__":
 import math

 app = QApplication(sys.argv)

 window = RealtimeMonitorWindow()
 window.show()

 sys.exit(app.exec())
```

</div>

---

#### **2.2 타이머 기반 정밀 제어**

##### **배경: 반도체 장비의 타이밍 정확성**

**문제 상황**
- CVD 장비의 가스 유량 측정은 10ms 주기로 정확히 수집되어야 함
- 타이밍 오차가 ±5ms를 초과하면 공정 품질에 영향
- 일반 타이머는 OS 스케줄링에 따라 편차 발생 (평균 ±20ms)

**해결 접근**
- Qt의 PreciseTimer 모드 사용 → 타이밍 정확도 향상
- QElapsedTimer로 실제 경과 시간 측정 → 편차 추적
- 통계 정보 수집 → 성능 모니터링 및 최적화 근거

**HCI 이론 연결 (Week 1)**
- **정보처리 모델**: 인간은 100ms 이상 지연 감지 가능 → 10ms 주기면 실시간 피드백 가능
- **반응 시간**: 시각 자극 처리 약 200ms → 데이터 수집 주기는 그보다 짧아야 함

---

##### **2.2.1 고정밀 데이터 수집 - 핵심 개념**

**타이머 정밀도 모드**
1. **CoarseTimer** (기본): OS 스케줄링에 의존, 편차 ±20ms
2. **PreciseTimer**: 고정밀 타이머, 편차 ±1ms 이내
3. **VeryCoarseTimer**: 초 단위 작업, 편차 ±500ms

**경과 시간 측정**
- QElapsedTimer: 고해상도 시스템 타이머 사용
- restart() 호출 시마다 이전 시점부터 경과 시간(ms) 반환
- 나노초 단위 정확도 (플랫폼 의존)

**성능 통계 수집**
- 평균 간격: 실제 수집 주기의 평균값
- 최대 편차: 설정 간격 대비 최대 오차
- 총 수집 횟수: 누적 데이터 포인트

---

##### **2.2.1 고정밀 데이터 수집 - 코드 구조**

<div class="code-example">

```python
from PySide6.QtCore import QTimer, QElapsedTimer, QObject, Signal, Qt
from datetime import datetime
import random

class PrecisionDataCollector(QObject):
 """정밀 타이밍 데이터 수집기"""

---
# Part 1: 클래스 정의 및 시그널
 data_ready = Signal(dict, float) # data, elapsed_time
```

**코드 해설**
- `Signal(dict, float)`: 데이터 딕셔너리와 경과 시간을 함께 전송
- 수신자는 타이밍 정보를 함께 받아 지연 분석 가능

**실제 사례 - ETCH 장비**
- Plasma Power 변화 감지: 1kW ~ 5kW 범위, 100ms 주기
- 타이밍 정보로 데이터 품질 검증
- 편차 >10ms 발생 시 알람 생성

---

```python
 def __init__(self, interval_ms=100):
 super().__init__()
 self.interval_ms = interval_ms
```

**Part 2: 생성자 - 초기화**

**코드 해설**
- `interval_ms=100`: 기본 수집 주기 100ms (10Hz)
- 반도체 장비는 일반적으로 10Hz ~ 100Hz 사용
- `super().__init__()`: QObject 초기화 → Signal/Slot 기능 활성화

**실제 사례 - PVD 장비**
- Target Power 모니터링: 50ms 주기 (20Hz)
- Deposition Rate: 100ms 주기 (10Hz)
- Chamber Pressure: 200ms 주기 (5Hz)

---

```python
 # 고정밀 타이머
 self.timer = QTimer()
 self.timer.timeout.connect(self.collect_data)
 self.timer.setTimerType(Qt.PreciseTimer)

 # 경과 시간 측정
 self.elapsed_timer = QElapsedTimer()
```

**Part 3: 타이머 설정**

**코드 해설**
- `QTimer()`: Qt 이벤트 루프 기반 타이머 생성
- `timeout.connect()`: 타이머 만료 시 collect_data 호출
- `setTimerType(Qt.PreciseTimer)`: 고정밀 모드 설정 → 편차 ±1ms

**타이밍 정확도 비교**

```mermaid
graph LR
A[CoarseTimer<br/>±20ms] --> B[PreciseTimer<br/>±1ms]
B --> C[VeryCoarseTimer<br/>±500ms]
style B fill:#90EE90
```

**실제 사례 - CVD 장비**
- Gas Flow 제어: PreciseTimer 필수 (±1ms)
- Temperature 모니터링: CoarseTimer 사용 가능 (±20ms)

---

```python
 # 성능 통계
 self.collection_stats = {
 'total_collections': 0,
 'average_interval': 0,
 'max_deviation': 0
 }

```

**Part 4: 통계 딕셔너리**

**코드 해설**
- `total_collections`: 총 수집 횟수 → 데이터 품질 지표
- `average_interval`: 평균 수집 간격 → 목표 간격과 비교
- `max_deviation`: 최대 편차 → 최악의 경우 파악

**성능 계산 수식**

$$
\text{Jitter} = \max(|\text{actual}_i - \text{target}|)
$$

$$
\text{Avg Interval} = \frac{\sum_{i=1}^{n} \text{actual}_i}{n}
$$

**실제 사례 - CMP 장비**
- Pad Rotation Speed: 목표 93 RPM, 허용 편차 ±2 RPM
- 통계 모니터링으로 베어링 마모 조기 감지

---

```python
 def start_collection(self, interval_ms=None):
 """수집 시작"""
 if interval_ms:
 self.interval_ms = interval_ms

 self.elapsed_timer.start()
 self.timer.start(self.interval_ms)
```

**Part 5: 수집 시작**

**코드 해설**
- `interval_ms` 파라미터: 동적 주기 변경 지원
- `elapsed_timer.start()`: 경과 시간 측정 시작점 설정
- `timer.start()`: 주기적 타이머 시작

**시퀀스 다이어그램**

```mermaid
sequenceDiagram
participant App
participant Collector
participant Timer
App->>Collector: start_collection(100ms)
Collector->>Timer: start(100ms)
Timer-->>Collector: timeout (every 100ms)
Collector->>App: data_ready signal
```

---

```python
 def stop_collection(self):
 """수집 중지"""
 self.timer.stop()
```

**Part 6: 수집 중지**
- 타이머 정지 → timeout 시그널 발생 중단
- 리소스 정리 및 전력 절감

---

```python
 def collect_data(self):
 """데이터 수집 및 타이밍 측정"""
 # 실제 경과 시간 측정
 elapsed = self.elapsed_timer.restart()

 # 타이밍 통계 업데이트
 self.update_timing_stats(elapsed)

 # 데이터 생성
 data = self.generate_sample_data()

 # 시그널 발송 (데이터 + 타이밍 정보)
 self.data_ready.emit(data, elapsed)
```

**Part 7: 데이터 수집 메인 로직**

**코드 해설**
- `elapsed_timer.restart()`: 이전 호출부터 경과 시간(ms) 반환 + 타이머 재시작
- 매 호출마다 실제 간격 측정 → 목표 간격과 비교
- `data_ready.emit()`: 데이터와 타이밍 정보를 함께 전송

**Week 6 연결**
- Week 6에서 배운 Signal/Slot 메커니즘 활용
- 비동기 데이터 전달로 UI 블로킹 방지

---

```python
 def update_timing_stats(self, elapsed):
 """타이밍 통계 업데이트"""
 self.collection_stats['total_collections'] += 1

 # 평균 간격 계산
 total = self.collection_stats['total_collections']
 avg = self.collection_stats['average_interval']
 self.collection_stats['average_interval'] = (avg * (total - 1) + elapsed) / total

 # 최대 편차 추적
 deviation = abs(elapsed - self.interval_ms)
 if deviation > self.collection_stats['max_deviation']:
 self.collection_stats['max_deviation'] = deviation
```

**Part 8: 통계 업데이트 - 이동 평균**

**코드 해설**
- **이동 평균 계산**: 새 값을 기존 평균에 점진적으로 반영
- 공식: `new_avg = (old_avg × (n-1) + new_value) / n`
- 메모리 효율적: 모든 과거 값을 저장하지 않음

**알고리즘 시각화**

```mermaid
graph TD
A[elapsed 측정] --> B[total_collections++]
B --> C[평균 간격 계산]
C --> D[편차 계산]
D --> E{편차 > max?}
E -->|Yes| F[max_deviation 업데이트]
E -->|No| G[통계 유지]
```

**실제 사례 - ETCH 장비**
- 1,000,000회 수집 시에도 메모리 사용량 일정 (dict 3개 항목만)
- 평균 간격 99.8ms, 최대 편차 2.3ms 기록

---

```python
 def generate_sample_data(self):
 """샘플 데이터 생성"""
 return {
 'timestamp': datetime.now(),
 'value': random.uniform(0, 100),
 'sequence': self.collection_stats['total_collections']
 }
```

**Part 9: 샘플 데이터 생성**

**코드 해설**
- `datetime.now()`: 현재 시각 타임스탬프
- `random.uniform()`: 0~100 범위 실수 난수
- `sequence`: 데이터 포인트 일련번호 → 순서 보장 확인

**실제 데이터 대체**
실제 장비에서는 이 메서드를 다음으로 교체:
- 센서 읽기 API 호출
- PLC 통신 (Modbus, EtherCAT)
- SECS/GEM 메시지 파싱

</div>

---

## 3️⃣ 심화 실습
### **데이터베이스 연동 및 고급 통신 구현**

#### **배경: 반도체 장비 데이터 영속성**

**문제 상황**
- CVD 장비는 하루 20,000개 웨이퍼 처리 → 약 2천만 개 데이터 포인트
- 메모리만 사용 시 재부팅 시 데이터 손실
- 트렌드 분석, 품질 추적, 규제 준수를 위한 장기 저장 필요

**해결 접근**
- SQLite 경량 데이터베이스 사용 → 별도 서버 불필요
- 데이터 모델 정의 (dataclass) → 타입 안전성
- 인덱싱 및 쿼리 최적화 → 빠른 검색

**HCI 이론 연결 (Week 1)**
- **Miller's Law (7±2)**: 화면에 표시할 데이터는 제한하되, 백그라운드에서 모두 저장
- **인지 부하**: 사용자는 "데이터 저장" 걱정 없이 모니터링에 집중

---

#### **3.1 SQLite 데이터베이스 연동**

##### **3.1.1 데이터 모델 - Dataclass 활용**

<div class="database-section">

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sqlite3
import json
from datetime import datetime, timedelta
from PySide6.QtCore import QObject, Signal, Slot
from dataclasses import dataclass, asdict
from typing import List, Optional

@dataclass
class EquipmentData:
 """장비 데이터 모델"""
 id: Optional[int] = None
 timestamp: datetime = None
 chamber_temperature: float = 0.0
 chamber_pressure: float = 0.0
 gas_flow_rate: float = 0.0
 rf_power: float = 0.0
 recipe_step: int = 0
 recipe_id: Optional[int] = None
 status: str = "Unknown"
 alarm_flags: str = "" # JSON string

 def __post_init__(self):
 if self.timestamp is None:
 self.timestamp = datetime.now()
```

---

**Part 10: EquipmentData 모델**

**코드 해설**
- `@dataclass`: Python 3.7+ 데이터 클래스 → 자동으로 `__init__`, `__repr__` 생성
- `Optional[int]`: None 허용 타입 힌트 → DB 자동 증가 ID
- `__post_init__`: 생성자 실행 후 자동 호출 → 기본값 설정

**필드 설명 (CVD 장비 기준)**
- `chamber_temperature`: 300°C ~ 800°C
- `chamber_pressure`: 0.1 ~ 10 Torr
- `gas_flow_rate`: 100 ~ 5000 sccm (standard cubic centimeters per minute)
- `rf_power`: 100W ~ 2000W

**실제 사례 - PECVD 장비**
```python
data = EquipmentData(
    chamber_temperature=650.5,
    chamber_pressure=2.3,
    gas_flow_rate=850.0,
    rf_power=1200.0,
    recipe_step=3,
    status="Processing"
)
```

---

```python

@dataclass
class Recipe:
 """레시피 데이터 모델"""
 id: Optional[int] = None
 name: str = ""
 description: str = ""
 steps: str = "" # JSON string
 created_at: datetime = None
 updated_at: datetime = None

 def __post_init__(self):
 if self.created_at is None:
 self.created_at = datetime.now()
 if self.updated_at is None:
 self.updated_at = datetime.now()

class DatabaseManager(QObject):
 """데이터베이스 관리자"""

 data_saved = Signal(bool)
 data_loaded = Signal(list)
 error_occurred = Signal(str)

 def __init__(self, db_path="equipment_data.db"):
 super().__init__()
 self.db_path = db_path
 self.connection = None
 self.init_database()

 def init_database(self):
 """데이터베이스 초기화"""
 try:
 self.connection = sqlite3.connect(self.db_path, check_same_thread=False)
 self.connection.row_factory = sqlite3.Row

 # 테이블 생성
 self.create_tables()

 except Exception as e:
 self.error_occurred.emit(f"데이터베이스 초기화 실패: {str(e)}")

 def create_tables(self):
 """테이블 생성"""
 cursor = self.connection.cursor()

 # 장비 데이터 테이블
 cursor.execute('''
 CREATE TABLE IF NOT EXISTS equipment_data (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 timestamp TEXT NOT NULL,
 chamber_temperature REAL,
 chamber_pressure REAL,
 gas_flow_rate REAL,
 rf_power REAL,
 recipe_step INTEGER,
 recipe_id INTEGER,
 status TEXT,
 alarm_flags TEXT,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY (recipe_id) REFERENCES recipes (id)
 )
 ''')

 # 레시피 테이블
 cursor.execute('''
 CREATE TABLE IF NOT EXISTS recipes (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT UNIQUE NOT NULL,
 description TEXT,
 steps TEXT, -- JSON
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 updated_at TEXT DEFAULT CURRENT_TIMESTAMP
 )
 ''')

 # 알람 로그 테이블
 cursor.execute('''
 CREATE TABLE IF NOT EXISTS alarm_logs (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 timestamp TEXT NOT NULL,
 alarm_type TEXT,
 severity TEXT,
 message TEXT,
 acknowledged BOOLEAN DEFAULT FALSE,
 acknowledged_by TEXT,
 acknowledged_at TEXT
 )
 ''')

 # 인덱스 생성
 cursor.execute('CREATE INDEX IF NOT EXISTS idx_equipment_timestamp ON equipment_data(timestamp)')
 cursor.execute('CREATE INDEX IF NOT EXISTS idx_alarm_timestamp ON alarm_logs(timestamp)')

 self.connection.commit()

 @Slot(dict)
 def save_equipment_data(self, data_dict):
 """장비 데이터 저장"""
 try:
 cursor = self.connection.cursor()

 # 데이터 변환
 timestamp_str = data_dict['timestamp'].isoformat()

 cursor.execute('''
 INSERT INTO equipment_data
 (timestamp, chamber_temperature, chamber_pressure, gas_flow_rate,
 rf_power, recipe_step, status, alarm_flags)
 VALUES (?, ?, ?, ?, ?, ?, ?, ?)
 ''', (
 timestamp_str,
 data_dict.get('chamber_temperature', 0),
 data_dict.get('chamber_pressure', 0),
 data_dict.get('gas_flow_rate', 0),
 data_dict.get('rf_power', 0),
 data_dict.get('recipe_step', 0),
 data_dict.get('status', 'Unknown'),
 json.dumps(data_dict.get('alarm_flags', {}))
 ))

 self.connection.commit()
 self.data_saved.emit(True)

 except Exception as e:
 self.error_occurred.emit(f"데이터 저장 실패: {str(e)}")
 self.data_saved.emit(False)
```

---

**Part 11: save_equipment_data - 데이터 저장**

**코드 해설**
- `@Slot(dict)`: Signal/Slot 연결 최적화 → 타입 체크
- `isoformat()`: datetime을 ISO 8601 문자열로 변환 (예: "2025-10-04T14:30:00")
- `?` 플레이스홀더: SQL Injection 방지
- `json.dumps()`: 딕셔너리를 JSON 문자열로 직렬화

**SQL Injection 방지 비교**

❌ **잘못된 방법** (취약):
```python
sql = f"INSERT INTO data VALUES ('{value}')"
```

✅ **올바른 방법** (안전):
```python
cursor.execute("INSERT INTO data VALUES (?)", (value,))
```

**성능 특성**
- 단일 INSERT: ~1ms
- 배치 INSERT (1000개): ~100ms → 트랜잭션 활용 시
- 인덱스 추가 시 INSERT 성능 ~10% 감소, SELECT 성능 ~90% 향상

**실제 사례 - PVD 장비**
- 초당 10개 데이터 포인트
- 하루 864,000개 레코드
- DB 파일 크기: 약 500MB/일

---

```python

 def load_recent_data(self, hours=24):
 """최근 데이터 로드"""
 try:
 cursor = self.connection.cursor()

 # 시간 범위 계산
 start_time = datetime.now() - timedelta(hours=hours)
 start_time_str = start_time.isoformat()

 cursor.execute('''
 SELECT * FROM equipment_data
 WHERE timestamp >= ?
 ORDER BY timestamp DESC
 LIMIT 1000
 ''', (start_time_str,))

 rows = cursor.fetchall()

 # 딕셔너리 리스트로 변환
 data_list = []
 for row in rows:
 data = dict(row)
 data['timestamp'] = datetime.fromisoformat(data['timestamp'])
 if data['alarm_flags']:
 data['alarm_flags'] = json.loads(data['alarm_flags'])
 data_list.append(data)

 self.data_loaded.emit(data_list)
 return data_list

 except Exception as e:
 self.error_occurred.emit(f"데이터 로드 실패: {str(e)}")
 return []
```

---

**Part 12: load_recent_data - 시간 범위 조회**

**코드 해설**
- `timedelta(hours=24)`: 24시간 전 시간 계산
- `ORDER BY timestamp DESC`: 최신 데이터부터 정렬
- `LIMIT 1000`: 최대 1000개만 로드 → 메모리 보호
- `row_factory = sqlite3.Row`: dict 변환 가능한 Row 객체

**인덱스 활용**
```sql
CREATE INDEX idx_equipment_timestamp ON equipment_data(timestamp)
```
- 인덱스 없을 때: 전체 테이블 스캔 (100,000행 → 500ms)
- 인덱스 있을 때: 인덱스 스캔 (100,000행 → 5ms)

**실제 사례 - ETCH 장비**
- Troubleshooting: 최근 1시간 데이터 조회
- Trend 분석: 최근 7일 데이터 조회
- 통계 리포트: 최근 30일 데이터 집계

**HCI 연결**
- **Miller's Law**: LIMIT 1000으로 화면 표시 데이터 제한
- **청킹**: 시간 범위별로 데이터 그룹화 → 인지 부하 감소

---

```python

 def save_recipe(self, recipe: Recipe):
 """레시피 저장"""
 try:
 cursor = self.connection.cursor()

 if recipe.id is None:
 # 새 레시피 삽입
 cursor.execute('''
 INSERT INTO recipes (name, description, steps)
 VALUES (?, ?, ?)
 ''', (recipe.name, recipe.description, recipe.steps))
 recipe.id = cursor.lastrowid
 else:
 # 기존 레시피 업데이트
 cursor.execute('''
 UPDATE recipes
 SET name=?, description=?, steps=?, updated_at=CURRENT_TIMESTAMP
 WHERE id=?
 ''', (recipe.name, recipe.description, recipe.steps, recipe.id))

 self.connection.commit()
 return True

 except Exception as e:
 self.error_occurred.emit(f"레시피 저장 실패: {str(e)}")
 return False
```

---

**Part 13: save_recipe - INSERT/UPDATE 패턴**

**코드 해설**
- `recipe.id is None`: 새 레시피 판단 (CREATE)
- `cursor.lastrowid`: 마지막 삽입된 AUTO_INCREMENT ID 반환
- `UPDATE ... WHERE id=?`: 기존 레시피 수정
- `CURRENT_TIMESTAMP`: DB 서버 시간 자동 기록

**CRUD 패턴**
```mermaid
graph TD
A[save_recipe 호출] --> B{recipe.id 존재?}
B -->|No| C[INSERT 새 레시피]
B -->|Yes| D[UPDATE 기존 레시피]
C --> E[lastrowid 저장]
D --> F[updated_at 갱신]
E --> G[commit]
F --> G
```

**실제 사례 - CVD 레시피**
```python
recipe = Recipe(
    name="SiO2_Deposition_450C",
    description="450도 SiO2 증착",
    steps=json.dumps([
        {"step": 1, "temp": 450, "pressure": 2.5, "duration": 120},
        {"step": 2, "temp": 450, "pressure": 1.8, "duration": 300},
    ])
)
```

---

```python

 def get_statistics(self, hours=24):
 """통계 정보 조회"""
 try:
 cursor = self.connection.cursor()

 start_time = datetime.now() - timedelta(hours=hours)
 start_time_str = start_time.isoformat()

 cursor.execute('''
 SELECT
 COUNT(*) as total_records,
 AVG(chamber_temperature) as avg_temperature,
 MIN(chamber_temperature) as min_temperature,
 MAX(chamber_temperature) as max_temperature,
 AVG(chamber_pressure) as avg_pressure,
 MIN(chamber_pressure) as min_pressure,
 MAX(chamber_pressure) as max_pressure
 FROM equipment_data
 WHERE timestamp >= ?
 ''', (start_time_str,))

 row = cursor.fetchone()
 return dict(row) if row else {}

 except Exception as e:
 self.error_occurred.emit(f"통계 조회 실패: {str(e)}")
 return {}
```

---

**Part 14: get_statistics - 집계 쿼리**

**코드 해설**
- `COUNT(*)`: 전체 레코드 수
- `AVG()`, `MIN()`, `MAX()`: SQL 집계 함수
- 한 번의 쿼리로 여러 통계 계산 → 효율적

**집계 함수 성능**
- 인덱스 활용: WHERE 절 인덱스 사용 → 필터링 빠름
- 집계 연산: 메모리 내 계산 → O(n) 시간 복잡도

**실제 사례 - PVD 장비 대시보드**
```python
stats = db.get_statistics(hours=8)  # 교대 근무 시간
print(f"평균 온도: {stats['avg_temperature']:.1f}°C")
print(f"온도 범위: {stats['min_temperature']:.1f} ~ {stats['max_temperature']:.1f}°C")
print(f"데이터 포인트: {stats['total_records']:,}개")
# 출력 예:
# 평균 온도: 548.3°C
# 온도 범위: 545.2 ~ 551.7°C
# 데이터 포인트: 28,800개
```

---

```python

 def cleanup_old_data(self, days=30):
 """오래된 데이터 정리"""
 try:
 cursor = self.connection.cursor()

 cutoff_date = datetime.now() - timedelta(days=days)
 cutoff_date_str = cutoff_date.isoformat()

 cursor.execute('''
 DELETE FROM equipment_data
 WHERE timestamp < ?
 ''', (cutoff_date_str,))

 deleted_count = cursor.rowcount
 self.connection.commit()

 return deleted_count

 except Exception as e:
 self.error_occurred.emit(f"데이터 정리 실패: {str(e)}")
 return 0

 def close(self):
 """데이터베이스 연결 종료"""
 if self.connection:
 self.connection.close()
```

---

**Part 15: cleanup_old_data - 데이터 정리**

**코드 해설**
- `timedelta(days=30)`: 30일 이전 데이터 삭제
- `cursor.rowcount`: 삭제된 행 수 반환
- 정기 정리로 DB 크기 관리 → 성능 유지

**데이터 보관 정책**
1. **Hot Data** (7일): 빠른 조회용, DB 유지
2. **Warm Data** (30일): 분석용, DB 유지
3. **Cold Data** (>30일): 아카이브 파일로 내보내기 후 삭제

**성능 영향**
- 1,000,000행 DELETE: ~10초 (인덱스 재구성 포함)
- VACUUM 실행 권장: 디스크 공간 회수

**실제 사례 - CMP 장비**
```python
# 매일 자정 실행
deleted = db.cleanup_old_data(days=90)  # 90일 이상 데이터 삭제
print(f"{deleted:,}개 레코드 삭제됨")
# 출력: 2,592,000개 레코드 삭제됨 (90일 전 하루 데이터)
```

**Week 1 HCI 연결**
- **자동화**: 사용자가 직접 관리할 필요 없음 → 인지 부하 감소
- **투명성**: 삭제 건수 표시 → 시스템 상태 이해 가능

</div>

---

## 요약

**Week 7 실습 핵심**
1. **고정밀 타이머**: PreciseTimer + QElapsedTimer로 타이밍 정확도 향상
2. **통계 수집**: 이동 평균으로 성능 모니터링
3. **데이터베이스**: SQLite로 데이터 영속성 확보
4. **인덱싱**: 조회 성능 100배 향상

**반도체 장비 적용**
- CVD/PVD: 가스 유량 고정밀 수집
- ETCH: Plasma 파라미터 DB 저장
- CMP: 장기 트렌드 분석

**다음 주 예고**
- Week 8: Python 고급 기능 (멀티스레딩, 비동기 처리)
- Week 9: 배포 및 패키징

#### **3.2 실시간 차트 및 시각화**

##### **3.2.1 PyQtGraph 실시간 차트**

<div class="visualization-section">

```python
#!/usr/bin/env python3