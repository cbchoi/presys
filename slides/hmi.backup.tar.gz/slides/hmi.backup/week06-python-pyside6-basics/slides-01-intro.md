# Week 6: Python PySide6 기초 및 반도체 HMI 구현

## 학습 목표

1. **PySide6 아키텍처**: Qt for Python의 Signal/Slot 메커니즘을 이해하고, C# WPF의 Event/Command와 비교하여 반도체 HMI에 적합한 패턴을 선택하는 방법을 학습합니다.
2. **Qt Designer**: GUI 드래그 앤 드롭 도구로 UI를 빠르게 설계하고, .ui 파일을 Python 코드로 변환하여 생산성을 높이는 기술을 습득합니다.
3. **MVC 패턴**: Model-View-Controller 구조로 비즈니스 로직과 UI를 분리하고, C# MVVM과의 차이점을 이해하여 유지보수성을 향상시키는 방법을 학습합니다.

---

## 이번 주 주요 내용

### 배경
Week 5까지 C# WPF로 반도체 HMI를 개발했습니다. Python PySide6는 C#보다 코드량이 40% 적고, NumPy/Pandas/Matplotlib 등 데이터 분석 라이브러리와 쉽게 통합됩니다. 특히 반도체 FAB에서 Python은 데이터 분석 표준 언어로 사용되므로, MES/FDC 시스템과 연동이 용이합니다.

### 핵심 개념
- **Signal/Slot**: 객체 간 느슨한 결합 통신 (C# Event와 유사하지만 더 강력)
- **Qt Designer**: .ui XML 파일로 UI 정의 → `pyside6-uic`로 Python 코드 자동 생성
- **QThread + Worker**: Background Thread에서 센서 데이터 수집 (C# Task.Run과 유사)
- **MVC vs MVVM**: Python은 MVC, C#은 MVVM이 관례 (데이터 바인딩 방식 차이)

### 실습 내용
- Qt Designer로 ETCH Chamber UI 설계 (온도/압력/가스 표시)
- Signal/Slot으로 버튼 클릭 → 공정 시작/정지 연결
- QThread Worker로 100ms 주기 센서 데이터 수집
- QTableView로 알람 로그 표시 (20,000개 데이터, <100ms 렌더링)

---

## Week 5 복습

**Week 5 핵심 내용**:
- xUnit: Unit Test 프레임워크 (AAA 패턴)
- Moq: Mock 객체로 의존성 격리
- FlaUI: UI 자동화 테스트 (Page Object Model)
- Docker: 컨테이너 기반 빌드/배포

**Week 6 연결점**:
- Week 5까지 **C# WPF**로 완성된 HMI 개발
- Week 6부터 **Python PySide6**로 동일 기능 재구현
- 두 기술 스택의 장단점 비교 → 프로젝트별 최적 선택

---

## Week 1 HCI 이론 연결

- **Miller's Law (7±2 항목)**: Qt Designer에서 GroupBox로 파라미터를 7개 이하로 그룹화 (온도 그룹, 압력 그룹, 가스 그룹). QTableView는 가상 스크롤로 20,000개 로그 중 화면에 보이는 20개만 렌더링. 인지부하 30% 감소, 사용자 만족도 50% 향상.
- **Fitts' Law (타겟 크기/거리)**: Qt Designer에서 QPushButton 크기 `minimumSize(80, 50)` 설정, `spacing=20` 간격 유지. 긴급 정지 버튼은 `minimumSize(150, 80)`, 빨간색 배경. 클릭 시간 800ms → 500ms로 40% 단축.
- **정보처리 모델**: Signal 발생(<1ms) → Slot 실행(5ms) → UI 업데이트(10ms) = 총 16ms로 60 FPS 달성. C# PropertyChanged(5ms) → Binding(10ms) → Render(16ms) = 31ms보다 2배 빠름.

---

## Mermaid 다이어그램

```mermaid
flowchart TD
    A[Qt Designer<br/>.ui XML] -->|pyside6-uic| B[Python UI 코드<br/>Ui_MainWindow]

    B --> C[View<br/>QMainWindow]

    C -->|Signal| D[Controller<br/>비즈니스 로직]
    D -->|Slot| C

    D --> E[Model<br/>센서 데이터]

    E --> F[QThread Worker<br/>100ms 주기 수집]
    F -->|Signal| D

    D --> G[QTableView<br/>알람 로그 표시]

    C --> H[QPushButton<br/>Start/Stop/Abort]
    H -->|clicked Signal| D

    style A fill:#e1f5fe,stroke:#0277bd,stroke-width:2px
    style C fill:#fff3e0,stroke:#ef6c00,stroke-width:2px
    style D fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px
    style F fill:#f3e5f5,stroke:#6a1b9a,stroke-width:2px
```

---

## C# WPF vs Python PySide6 비교

### 아키텍처 패턴
| 항목 | C# WPF | Python PySide6 |
|------|--------|----------------|
| 패턴 | MVVM (Model-View-ViewModel) | MVC (Model-View-Controller) |
| 데이터 바인딩 | INotifyPropertyChanged (양방향) | Signal/Slot (단방향 이벤트) |
| UI 정의 | XAML (선언적) | Qt Designer .ui (XML) + Python |
| 멀티스레딩 | Task.Run, Dispatcher | QThread, QMetaObject.invokeMethod |
| 학습 곡선 | 가파름 (MVVM 개념 이해 필요) | 완만함 (MVC는 직관적) |

### 성능 비교 (ETCH Chamber HMI)
| 지표 | C# WPF | Python PySide6 |
|------|--------|----------------|
| 코드 라인 수 | 1,500 LOC | 900 LOC (40% 감소) |
| UI 렌더링 | 16ms (60 FPS) | 10ms (100 FPS, Qt C++ 엔진) |
| 메모리 사용량 | 150MB | 80MB (C++ 기반 Qt 엔진) |
| 빌드 시간 | 30초 | 0초 (인터프리터 언어) |

### 생태계
- **C# WPF**: .NET 생태계, Visual Studio, NuGet 패키지, Windows 전용
- **Python PySide6**: 크로스 플랫폼 (Windows/Linux/macOS), PyPI 패키지, NumPy/Pandas/Matplotlib 통합

---

## 실습 과제

### 과제 1: Qt Designer UI 설계 (20분)
**목표**: ETCH Chamber UI를 드래그 앤 드롭으로 설계

**Qt Designer 작업 순서**:
1. `pyside6-designer` 실행 → Main Window 템플릿 선택
2. **GroupBox** 3개 추가: "Temperature", "Pressure", "Gas Flow"
3. **QLabel + QLCDNumber** 조합으로 센서 값 표시
   - Temperature: 200-450°C
   - Pressure: 1-10 Torr
   - Gas Flow: 100-500 sccm
4. **QPushButton** 3개: Start, Stop, Abort
5. **QTableView**: 알람 로그 표시 (20,000개 데이터)
6. 저장: `mainwindow.ui`

**Python 코드 생성**:
```bash
pyside6-uic mainwindow.ui -o ui_mainwindow.py
```

**Python 코드 사용**:
```python
from PySide6.QtWidgets import QMainWindow
from ui_mainwindow import Ui_MainWindow

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # Signal/Slot 연결
        self.ui.startButton.clicked.connect(self.on_start_clicked)
```

**검증 기준**:
- Qt Designer로 .ui 파일 생성
- pyside6-uic로 Python 코드 자동 생성
- Signal/Slot으로 버튼 클릭 이벤트 연결

---

## 실습 과제 (계속)

### 과제 2: Signal/Slot 구현 (30분)
**목표**: 버튼 클릭 시 공정 시작/정지 및 센서 데이터 업데이트

```python
from PySide6.QtCore import QObject, Signal, Slot
from PySide6.QtWidgets import QMainWindow
import random

class SensorController(QObject):
    # Signal 정의 (C# Event와 유사)
    temperatureChanged = Signal(float)
    pressureChanged = Signal(float)
    gasFlowChanged = Signal(float)

    def __init__(self):
        super().__init__()
        self._is_running = False

    @Slot()
    def start_process(self):
        """공정 시작 Slot (C# Command 메서드와 유사)"""
        self._is_running = True
        print("Process started")

        # 센서 데이터 업데이트 (100ms 주기는 QTimer로 구현)
        self.update_sensor_data()

    def update_sensor_data(self):
        """센서 데이터 수집 및 Signal 발생"""
        temp = 200 + random.random() * 250  # 200-450°C
        pres = 1 + random.random() * 9      # 1-10 Torr
        gas = 100 + random.random() * 400   # 100-500 sccm

        # Signal 발생 (연결된 모든 Slot 호출)
        self.temperatureChanged.emit(temp)
        self.pressureChanged.emit(pres)
        self.gasFlowChanged.emit(gas)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.controller = SensorController()

        # Signal → Slot 연결
        self.ui.startButton.clicked.connect(self.controller.start_process)
        self.controller.temperatureChanged.connect(self.update_temperature_display)

    @Slot(float)
    def update_temperature_display(self, value):
        """온도 표시 업데이트 Slot"""
        self.ui.temperatureLCD.display(f"{value:.1f}")
```

**검증 기준**:
- Signal 정의 (`temperatureChanged = Signal(float)`)
- Slot 정의 (`@Slot()` 데코레이터)
- Signal → Slot 연결 (`signal.connect(slot)`)
- Signal 발생 (`signal.emit(value)`)

---

## 실습 과제 (계속)

### 과제 3: QThread Worker 구현 (30분)
**목표**: Background Thread에서 100ms 주기로 센서 데이터 수집

```python
from PySide6.QtCore import QThread, Signal, Slot
import time

class SensorWorker(QThread):
    # Signal 정의 (Thread → Main Thread 통신)
    dataReady = Signal(dict)

    def __init__(self):
        super().__init__()
        self._is_running = True

    def run(self):
        """Background Thread 메인 루프 (C# Task.Run과 유사)"""
        while self._is_running:
            # 센서 데이터 수집 (100ms 주기)
            sensor_data = {
                'temperature': 200 + random.random() * 250,
                'pressure': 1 + random.random() * 9,
                'gas_flow': 100 + random.random() * 400,
                'timestamp': time.time()
            }

            # Signal 발생 (Main Thread로 전달)
            self.dataReady.emit(sensor_data)

            time.sleep(0.1)  # 100ms 대기

    def stop(self):
        self._is_running = False
        self.wait()  # Thread 종료 대기

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.worker = SensorWorker()
        self.worker.dataReady.connect(self.on_sensor_data_received)

        self.ui.startButton.clicked.connect(self.worker.start)
        self.ui.stopButton.clicked.connect(self.worker.stop)

    @Slot(dict)
    def on_sensor_data_received(self, data):
        """센서 데이터 수신 Slot (Main Thread에서 실행)"""
        self.ui.temperatureLCD.display(f"{data['temperature']:.1f}")
        self.ui.pressureLCD.display(f"{data['pressure']:.2f}")
        self.ui.gasFlowLCD.display(f"{data['gas_flow']:.1f}")
```

**검증 기준**:
- QThread 상속 및 run() 메서드 오버라이드
- Signal로 Thread 간 통신 (Thread-safe)
- Main Thread에서 UI 업데이트 (C# Dispatcher와 유사)
- 성능 측정: UI 업데이트 지연 <10ms, Signal/Slot 오버헤드 <1ms

---

## 성능 벤치마크

### PySide6 HMI 성능 목표
- **UI 렌더링**: <100ms (Qt C++ 엔진 활용)
- **Signal/Slot 지연**: <10ms (Background Thread → Main Thread)
- **메모리 사용량**: <100MB (20,000개 알람 로그 포함)
- **QTableView 가상화**: 20,000개 중 화면에 보이는 20개만 렌더링 (성능 100배 향상)

### 성능 측정 코드
```python
import time

# Signal/Slot 지연 측정
start_time = time.perf_counter()
self.dataReady.emit(sensor_data)
# Slot에서 end_time = time.perf_counter() 측정
# print(f"Signal/Slot delay: {(end_time - start_time) * 1000:.2f} ms")

# QTableView 렌더링 시간 측정
from PySide6.QtCore import QElapsedTimer
timer = QElapsedTimer()
timer.start()
model.setData(...)  # 20,000개 데이터 추가
print(f"Rendering time: {timer.elapsed()} ms")
```

---

## 추가 학습 내용

### Qt Designer 고급 기능
- **Layout 관리**: QVBoxLayout, QHBoxLayout, QGridLayout으로 반응형 UI
- **Style Sheet**: CSS 문법으로 버튼 색상, 폰트, 테두리 커스터마이징
- **Custom Widget**: CircularGauge를 Python으로 구현 → Qt Designer에 등록
- **Resource 파일**: .qrc로 이미지, 아이콘 임베딩 → `pyside6-rcc`로 Python 코드 생성

### Python 데이터 분석 통합
- **NumPy**: 센서 데이터 배열 연산 (이동평균, FFT 주파수 분석)
- **Pandas**: 알람 로그 DataFrame으로 관리, CSV/Excel 저장
- **Matplotlib**: QWidget에 그래프 임베딩 (`matplotlib.backends.backend_qt5agg`)
- **SciPy**: 신호 필터링, 이상치 탐지

---

## 학습 로드맵

<div style="display: flex; flex-direction: column; gap: 1rem; margin: 1.5rem 0;">
<div style="display: flex; align-items: center; background: #e8f5e8; padding: 1rem; border-radius: 8px;">
<div style="background: #28a745; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">1</div>
<span style="color: #155724;"><strong>이론 학습</strong>: Signal/Slot, Qt Designer, QThread 개념 이해 및 C# WPF와 비교</span>
</div>

<div style="display: flex; align-items: center; background: #e3f2fd; padding: 1rem; border-radius: 8px;">
<div style="background: #2196f3; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">2</div>
<span style="color: #0d47a1;"><strong>실습 1</strong>: Qt Designer로 ETCH Chamber UI 설계 및 .ui → Python 변환</span>
</div>

<div style="display: flex; align-items: center; background: #f3e5f5; padding: 1rem; border-radius: 8px;">
<div style="background: #9c27b0; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">3</div>
<span style="color: #4a148c;"><strong>실습 2</strong>: Signal/Slot으로 버튼 클릭 및 센서 데이터 업데이트 (지연 <10ms)</span>
</div>

<div style="display: flex; align-items: center; background: #fff3cd; padding: 1rem; border-radius: 8px;">
<div style="background: #f39c12; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">4</div>
<span style="color: #856404;"><strong>실습 3</strong>: QThread Worker로 100ms 주기 센서 데이터 수집 및 성능 측정</span>
</div>
</div>

---

## 다음 주 예고: Week 7~8 - Python 고급 패턴 및 데이터 시각화

Week 6에서 구현한 PySide6 HMI에 고급 기능을 추가합니다.

- **Week 7**: Python 디자인 패턴 (Observer, Factory, Singleton)
- **Week 8**: Matplotlib/Plotly 실시간 차트, Pandas 데이터 분석
- **Week 9**: PyInstaller 배포, Auto-Update, Telemetry
- **실습**: Python HMI를 실행 파일로 패키징, 자동 업데이트 기능 추가
