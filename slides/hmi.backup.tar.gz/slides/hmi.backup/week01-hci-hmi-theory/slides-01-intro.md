# Week 1: HCI/HMI 이론 및 반도체 장비 적용

## 학습 목표

1. **인간-컴퓨터 상호작용 기초**: HCI 핵심 법칙(Miller's Law, Fitts' Law)을 이해하고 반도체 HMI 설계에 적용하는 방법을 학습합니다.
2. **정보처리 모델**: 인간의 감각-인지-운동 시스템을 이해하고 실시간 공정 모니터링 UI 설계 원칙을 습득합니다.
3. **반도체 HMI 특수성**: 클린룸 환경, 고신뢰성 요구사항, SEMI 표준을 기반으로 한 HMI 설계 방법론을 학습합니다.

---

## 이번 주 주요 내용

### 배경
반도체 제조 장비(CVD, PVD, ETCH, CMP)는 24/7 연속 운전되며, 운영자의 실수는 수백억원의 손실로 이어질 수 있습니다. HCI 이론을 적용한 과학적 HMI 설계가 필수적입니다.

### 핵심 개념
- **Miller's Law (7±2)**: 인간의 단기 기억 용량을 고려한 정보 청킹 및 계층화 전략
- **Fitts' Law**: 목표물 크기와 거리를 고려한 버튼 배치 및 터치 영역 설계
- **정보처리 모델**: 감각(250ms) → 인지(100ms-2s) → 운동(70-100ms) 단계별 최적화
- **신호탐지이론 (SDT)**: 알람 민감도(d')와 반응 편향(β)을 통한 False Alarm 최소화

### 실습 내용
- ASML, Applied Materials, Tokyo Electron 실제 HMI 사례 분석
- SEMI E95 표준 기반 에르고노믹 가이드라인 평가
- HMI 사용성 테스트 방법론 (SUS, NASA-TLX, SAGAT) 실습

---

## Week 0 복습

이번 주는 첫 주차로, HCI/HMI 이론의 기초를 다집니다. 앞으로 배울 C# WPF, Python PySide6 구현의 이론적 토대를 마련합니다.

---

## Week 1 HCI 이론 핵심

- **Miller's Law**: 반도체 HMI는 한 화면에 7±2개 이하의 핵심 파라미터만 표시 (온도, 압력, 가스유량 등)
- **Fitts' Law**: 긴급 정지 버튼은 크기 50mm 이상, 중앙에서 300mm 이내 배치
- **정보처리 모델**: 알람 발생 → 인지(250ms) → 판단(500ms) → 조치(100ms) = 총 850ms 이내 처리

---

## Mermaid 다이어그램

```mermaid
flowchart TD
    A[HCI 이론] --> B["Miller's Law<br/>7±2 정보 청킹"]
    A --> C["Fitts' Law<br/>타겟 크기/거리"]
    A --> D[정보처리 모델<br/>감각-인지-운동]
    A --> E["신호탐지이론<br/>d' & β"]

    B --> F[반도체 HMI 설계]
    C --> F
    D --> F
    E --> F

    F --> G[SEMI E95 표준]
    F --> H[사용성 평가]

    style A fill:#667eea,color:#fff,stroke:#333,stroke-width:2px
    style F fill:#f39c12,color:#fff,stroke:#333,stroke-width:2px
    style G fill:#27ae60,color:#fff
    style H fill:#27ae60,color:#fff
```

---

## 반도체 HMI 특수 요구사항

### 클린룸 환경 (ISO 14644-1)
- **Class 1**: 입자 <10개/m³ (0.1μm 기준) - 최첨단 리소그래피
- **온도**: ±0.1°C 정밀 제어 (일부 공정 ±0.05°C)
- **습도**: ±1% RH (포토 공정 45±1% 유지)

### 고신뢰성
- **MTBF** (평균 고장 간격): >8760시간 (1년)
- **MTTR** (평균 수리 시간): <30분
- **가용성** = MTBF/(MTBF+MTTR) = 99.94%

### 실시간 응답
- **일반 HCI**: 100ms-2s 응답 시간
- **반도체 HMI**: 10ms-100ms 응답 시간 (10배 빠름)
- **알람 응답**: <50ms (운영자 인지 250ms 이내)

---

## 이번 주 학습 결과물

### 과제 1: 반도체 HMI 3대 사례 분석 보고서
- ASML 리소그래피, Applied Materials CVD, Tokyo Electron Etcher 중 1개 선택
- Miller's Law, Fitts' Law 적용 사례 분석
- SEMI E95 표준 준수 여부 평가

### 과제 2: SEMI E95 에르고노믹 체크리스트
- 색상 대비비 4:1 이상 확인
- 버튼 크기 12pt 이상 확인
- 시야각 ±15° 이내 정보 배치 확인

### 과제 3: 사용성 평가 실습
- SUS (System Usability Scale) 10개 문항 평가
- NASA-TLX 6개 차원 인지부하 측정
- SAGAT 상황인식 평가

---

## 다음 주 예고: Week 2 - C# WPF MVVM 기초

Week 1에서 배운 HCI 이론을 바탕으로, Week 2에서는 C# WPF MVVM 패턴을 활용한 반도체 HMI 구현을 시작합니다.

- **MVVM 패턴**: View-ViewModel-Model 분리로 유지보수성 향상
- **Data Binding**: INotifyPropertyChanged를 활용한 실시간 데이터 동기화
- **실습**: ETCH Chamber HMI 프로토타입 개발
