# 기초 실습

---
## 실습 개요: Timer 기반 실시간 데이터 수집

### 학습 목표

이번 실습에서는 **반도체 장비의 실시간 데이터를 수집하고 모니터링하는 HMI**를 구현합니다.

**핵심 학습 내용**:
1. System.Threading.Timer를 사용한 주기적 데이터 수집
2. Background Thread에서 센서 데이터 읽기
3. Dispatcher를 통한 Thread-safe UI 업데이트
4. MVVM 패턴에서의 멀티스레딩 적용

### Week 2의 한계와 Week 3의 해결책

**Week 2 아키텍처의 문제점**:
- 모든 로직이 UI Thread에서 실행
- 센서 데이터 읽기 시 UI Freeze 발생
- 네트워크 통신 중 화면 응답 없음
- 사용자 경험 저하

---
## 실습 개요: Timer 기반 실시간 데이터 수집
**Week 3에서의 개선**:
- Background Thread에서 데이터 수집
- UI Thread는 렌더링에만 집중
- 응답성 100% 유지
- 실시간 모니터링 가능

---
## 실습 개요: Timer 기반 실시간 데이터 수집
```mermaid
graph TB
 subgraph Week2["Week 2: 단일 스레드"]
 UI1[UI Thread]
 UI1 -->|센서 읽기 50ms| UI1
 UI1 -->|UI 렌더링 16ms| UI1
 UI1 -->|네트워크 2000ms| UI1
 style UI1 fill:#ffebee
 end

 subgraph Week3["Week 3: 멀티 스레드"]
 UI2[UI Thread<br/>렌더링만]
 BG1[Timer Thread<br/>센서 읽기]

 BG1 -->|250ms 주기| DataStore[ThreadSafeDataStore]
 DataStore -->|Dispatcher| UI2

 style UI2 fill:#e8f5e9
 style BG1 fill:#e1f5fe
 style DataStore fill:#fff9c4
 end

 Week2 -.->|성능 개선| Week3
```

---
## 실습 개요: Timer 기반 실시간 데이터 수집
### Week 1 HCI 이론 적용

**정보처리 모델 (250ms 응답)**:
- 사용자는 250ms 이내 시각적 피드백 기대
- 구현: 250ms 주기 센서 수집 → 즉각 응답

**Miller's Law (작업기억 한계 7±2)**:
- 화면에는 4개 장비만 표시 (CVD, PVD, ETCH, CMP)
- 각 장비당 3개 데이터 (온도, 압력, 유량)
- 총 12개 정보 = 인지 부하 적정

### 완성 화면 미리보기

[IMAGE: 실시간 장비 모니터링 HMI]
**이미지 설명**:
- 상단: 제어 패널 (시작/정지/초기화 버튼, 상태 표시)
- 중앙: 4개 장비 실시간 데이터 (온도/압력/유량, 상태 색상)
- 하단: 성능 지표 (초당 수집률, 총 데이터 포인트 수)

**파일 경로**: `images/week03/realtime-monitoring-ui.png`
---
## Part 1: ViewModel 클래스 구조 설계 (10분)

### 배경: 왜 별도의 ViewModel이 필요한가?

**문제 상황**:
- 반도체 장비 4대 (CVD, PVD, ETCH, CMP)를 동시 모니터링
- 각 장비마다 온도/압력/유량 데이터 실시간 수집
- 250ms마다 총 12개 데이터 갱신 필요

**설계 결정**:
- **BaseViewModel 상속**: INotifyPropertyChanged 구현 재사용
- **IDisposable 구현**: Timer 리소스 정리 필요
- **3개 핵심 객체**: Timer (주기 실행), DataCollector (수집), DataStore (저장)

### 핵심 개념: MVVM + 멀티스레딩 결합

**Week 2 MVVM 복습**:
- ViewModel: 데이터와 로직 분리
- INotifyPropertyChanged: UI 자동 갱신
- Command Pattern: 버튼 클릭 처리

---
## Part 1: ViewModel 클래스 구조 설계 (10분)
**Week 3 추가 개념**:
- Timer: Background Thread에서 주기적 작업
- Dispatcher: UI Thread로 안전하게 마샬링
- Thread-safe 데이터 저장소

### 코드 (Part 1/10)

<div class="grid grid-cols-2 gap-8">
<div>

---
## Part 1: ViewModel 클래스 구조 설계 (10분)
```csharp [1-18]
// RealTimeEquipmentViewModel.cs
public class RealTimeEquipmentViewModel : BaseViewModel, IDisposable
{
 private readonly Timer _dataUpdateTimer;
 private readonly EquipmentDataCollector _dataCollector;
 private readonly ThreadSafeDataStore _dataStore;
 private bool _isCollecting;

 private ObservableCollection<EquipmentViewModel> _equipmentList;
 private EquipmentViewModel _selectedEquipment;
 private double _dataCollectionRate;
 private int _totalDataPoints;
 private string _connectionStatus;
}
```

---
## Part 1: ViewModel 클래스 구조 설계 (10분)
</div>
<div>

### 코드 해설

**Line 2-3: 클래스 선언**
```csharp
public class RealTimeEquipmentViewModel : BaseViewModel, IDisposable
```
- **BaseViewModel 상속**: Week 2에서 구현한 INotifyPropertyChanged 재사용
- **IDisposable 구현**: Timer는 반드시 Dispose 필요 (메모리 누수 방지)
- 실제 반도체 HMI: 24시간 가동 시 리소스 누수는 치명적

---
## Part 1: ViewModel 클래스 구조 설계 (10분)
**Line 4: Timer 객체**
```csharp
private readonly Timer _dataUpdateTimer;
```
- **System.Threading.Timer** 사용 (주의: System.Windows.Forms.Timer 아님)
- Background ThreadPool에서 실행
- UI Thread 블로킹 없음
- readonly: 초기화 후 변경 불가 (Thread-Safety 강화)

**Line 5: DataCollector**
```csharp
private readonly EquipmentDataCollector _dataCollector;
```
- 실제 센서와의 통신 담당 (RS-485, Modbus 등)
- 이 실습에서는 Random 시뮬레이션 사용
- 실무: 장비 제조사 SDK 또는 OPC-UA 프로토콜 사용

---
## Part 1: ViewModel 클래스 구조 설계 (10분)
**Line 6: ThreadSafeDataStore**
```csharp
private readonly ThreadSafeDataStore _dataStore;
```
- 멀티스레드 환경에서 안전한 데이터 저장
- lock 또는 ConcurrentQueue 사용
- Week 1 신호검출이론: False Alarm 방지 (잘못된 데이터 표시 차단)

**Line 7: 수집 상태 플래그**
```csharp
private bool _isCollecting;
```
- 현재 데이터 수집 중인지 여부
- StartCollection/StopCollection 메서드에서 제어
- volatile 키워드 고려 (멀티스레드 가시성)

---
## Part 1: ViewModel 클래스 구조 설계 (10분)
**Line 9-13: UI 바인딩 필드**
```csharp
private ObservableCollection<EquipmentViewModel> _equipmentList;
private EquipmentViewModel _selectedEquipment;
private double _dataCollectionRate;
private int _totalDataPoints;
private string _connectionStatus;
```
- **ObservableCollection**: Week 2 복습, 컬렉션 변경 시 UI 자동 갱신
- **_dataCollectionRate**: 초당 수집 데이터 개수 (성능 지표)
- **_totalDataPoints**: 누적 수집 데이터 개수
- **_connectionStatus**: "준비됨", "수집 중", "오류" 등 상태 메시지

</div>
</div>

### 설계 패턴 분석

---
## Part 1: ViewModel 클래스 구조 설계 (10분)
**Separation of Concerns (관심사 분리)**:
```
Timer → 시간 제어만 담당
DataCollector → 센서 통신만 담당
DataStore → 데이터 저장만 담당
ViewModel → UI 로직만 담당
```

**실제 적용 사례**:
- **CVD 장비**: 챔버 온도 250°C, 압력 0.8 Torr, 100ms 샘플링
- **PVD 장비**: 스퍼터링 온도 180°C, 압력 0.005 Torr
- **ETCH 장비**: 플라즈마 온도 30°C, 압력 0.001 Torr
- **CMP 장비**: 연마 온도 45°C, 압력 0.75 Torr

### 성능 계산

---
## Part 1: ViewModel 클래스 구조 설계 (10분)
**데이터 수집 주기**:
$$
T_{cycle} = 250ms
$$

**초당 데이터 포인트 수**:
$$
N_{points/sec} = \frac{1000ms}{250ms} \times 4_{equipment} = 16 points/sec
$$

**1분간 총 데이터**:
$$
N_{1min} = 16 \times 60 = 960 points
$$

---
## Part 1: ViewModel 클래스 구조 설계 (10분)
**메모리 사용량 (1시간)**:
$$
Memory = 960_{points/min} \times 60_{min} \times 32_{bytes/point} \approx 1.8 MB
$$
---
## Part 2: 프로퍼티 정의 및 INotifyPropertyChanged (8분)

### 핵심 개념: UI 데이터 바인딩

**Week 2 복습**:
- Property Getter/Setter를 통한 데이터 접근
- SetProperty 메서드로 변경 통지
- UI가 자동으로 갱신

**Week 3 추가 고려사항**:
- **멀티스레드 환경**에서도 안전한 Property 변경
- Dispatcher를 통한 UI Thread 접근

### 코드 (Part 2/10)

<div class="grid grid-cols-2 gap-8">
<div>

---
## Part 2: 프로퍼티 정의 및 INotifyPropertyChanged (8분)
```csharp [19-54]
public ObservableCollection<EquipmentViewModel> EquipmentList
{
 get => _equipmentList;
 set => SetProperty(ref _equipmentList, value);
}

public EquipmentViewModel SelectedEquipment
{
 get => _selectedEquipment;
 set => SetProperty(ref _selectedEquipment, value);
}

public double DataCollectionRate
{
 get => _dataCollectionRate;
 set => SetProperty(ref _dataCollectionRate, value);
}

public int TotalDataPoints
{
 get => _totalDataPoints;
 set => SetProperty(ref _totalDataPoints, value);
}

public string ConnectionStatus
{
 get => _connectionStatus;
 set => SetProperty(ref _connectionStatus, value);
}

public bool IsCollecting
{
 get => _isCollecting;
 set
 {
 if (SetProperty(ref _isCollecting, value))
 {
 OnPropertyChanged(nameof(CollectionStatusText));
 OnPropertyChanged(nameof(CollectionButtonText));
 }
 }
}

public string CollectionStatusText => IsCollecting ? "수집 중" : "정지됨";
public string CollectionButtonText => IsCollecting ? "수집 중지" : "수집 시작";

 public ObservableCollection<EquipmentViewModel> EquipmentList
 {
 get => _equipmentList;
 set => SetProperty(ref _equipmentList, value);
 }

 public EquipmentViewModel SelectedEquipment
 {
 get => _selectedEquipment;
 set => SetProperty(ref _selectedEquipment, value);
 }

 public double DataCollectionRate
 {
 get => _dataCollectionRate;
 set => SetProperty(ref _dataCollectionRate, value);
 }

 public int TotalDataPoints
 {
 get => _totalDataPoints;
 set => SetProperty(ref _totalDataPoints, value);
 }

 public string ConnectionStatus
 {
 get => _connectionStatus;
 set => SetProperty(ref _connectionStatus, value);
 }

 public bool IsCollecting
 {
 get => _isCollecting;
 set
 {
 if (SetProperty(ref _isCollecting, value))
 {
 OnPropertyChanged(nameof(CollectionStatusText));
 OnPropertyChanged(nameof(CollectionButtonText));
 }
 }
 }

 public string CollectionStatusText => IsCollecting ? "수집 중" : "정지됨";
 public string CollectionButtonText => IsCollecting ? "수집 중지" : "수집 시작";

 // 커맨드
 public ICommand StartCollectionCommand { get; }
 public ICommand StopCollectionCommand { get; }
 public ICommand ClearDataCommand { get; }

 public RealTimeEquipmentViewModel()
 {
 EquipmentList = new ObservableCollection<EquipmentViewModel>();
 _dataCollector = new EquipmentDataCollector();
 _dataStore = new ThreadSafeDataStore();

 // 1초마다 UI 업데이트
 _dataUpdateTimer = new Timer(UpdateUI, null,
 TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(1));

 InitializeCommands();
 InitializeEquipment();

 ConnectionStatus = "준비됨";
 }

 private void InitializeCommands()
 {
 StartCollectionCommand = new RelayCommand(StartCollection, () => !IsCollecting);
 StopCollectionCommand = new RelayCommand(StopCollection, () => IsCollecting);
 ClearDataCommand = new RelayCommand(ClearData);
 }

 private void InitializeEquipment()
 {
 var equipmentIds = new[] { "CVD-001", "PVD-002", "ETCH-003", "CMP-004" };

 foreach (var id in equipmentIds)
 {
 var equipment = new EquipmentViewModel
 {
 EquipmentId = id,
 Status = EquipmentStatus.Idle,
 Temperature = 0,
 Pressure = 0,
 LastUpdate = DateTime.Now
 };

 EquipmentList.Add(equipment);
 }

 if (EquipmentList.Count > 0)
 SelectedEquipment = EquipmentList[0];
 }

 private async void StartCollection()
 {
 IsCollecting = true;
 ConnectionStatus = "연결 중...";

 try
 {
 // 백그라운드에서 데이터 수집 시작
 _ = Task.Run(async () =>
 {
 var random = new Random();
 var dataPointCount = 0;
 var lastRateCalculation = DateTime.Now;

 while (IsCollecting)
 {
 // 모든 장비에 대해 데이터 수집
 foreach (var equipment in EquipmentList)
 {
 var data = new EquipmentData
 {
 Temperature = GetRandomTemperature(equipment.EquipmentId, random),
 Pressure = GetRandomPressure(equipment.EquipmentId, random),
 FlowRate = GetRandomFlowRate(equipment.EquipmentId, random),
 Timestamp = DateTime.Now
 };

 // 스레드 안전한 저장
 _dataStore.AddDataConcurrent(data);

 // UI 스레드에서 업데이트
 await Application.Current.Dispatcher.InvokeAsync(() =>
 {
 equipment.Temperature = data.Temperature;
 equipment.Pressure = data.Pressure;
 equipment.LastUpdate = data.Timestamp;

 // 상태 업데이트
 equipment.Status = DetermineStatus(data);
 });

 dataPointCount++;
 TotalDataPoints = dataPointCount;
 }

 // 데이터 수집 속도 계산
 var now = DateTime.Now;
 var elapsed = now - lastRateCalculation;
 if (elapsed.TotalSeconds >= 1)
 {
 DataCollectionRate = dataPointCount / elapsed.TotalSeconds;
 dataPointCount = 0;
 lastRateCalculation = now;
 }

 await Task.Delay(250); // 250ms 간격으로 수집
 }
 });

 ConnectionStatus = "데이터 수집 중";
 }
 catch (Exception ex)
 {
 ConnectionStatus = $"오류: {ex.Message}";
 IsCollecting = false;
 }
 }

 private void StopCollection()
 {
 IsCollecting = false;
 ConnectionStatus = "수집 중지됨";
 }

 private void ClearData()
 {
 TotalDataPoints = 0;
 DataCollectionRate = 0;

 foreach (var equipment in EquipmentList)
 {
 equipment.Status = EquipmentStatus.Idle;
 equipment.Temperature = 0;
 equipment.Pressure = 0;
 equipment.LastUpdate = DateTime.Now;
 }
 }

 private double GetRandomTemperature(string equipmentId, Random random)
 {
 return equipmentId switch
 {
 "CVD-001" => 250 + random.NextDouble() * 20 - 10,
 "PVD-002" => 180 + random.NextDouble() * 15 - 7.5,
 "ETCH-003" => 30 + random.NextDouble() * 10 - 5,
 "CMP-004" => 45 + random.NextDouble() * 8 - 4,
 _ => 25 + random.NextDouble() * 5
 };
 }

 private double GetRandomPressure(string equipmentId, Random random)
 {
 return equipmentId switch
 {
 "CVD-001" => 0.8 + random.NextDouble() * 0.4 - 0.2,
 "PVD-002" => 0.005 + random.NextDouble() * 0.01 - 0.005,
 "ETCH-003" => 0.001 + random.NextDouble() * 0.002 - 0.001,
 "CMP-004" => 0.75 + random.NextDouble() * 0.3 - 0.15,
 _ => 0.1 + random.NextDouble() * 0.1
 };
 }

 private double GetRandomFlowRate(string equipmentId, Random random)
 {
 return equipmentId switch
 {
 "CVD-001" => 150 + random.NextDouble() * 30 - 15,
 "PVD-002" => 50 + random.NextDouble() * 20 - 10,
 "ETCH-003" => 0,
 "CMP-004" => 200 + random.NextDouble() * 40 - 20,
 _ => 100 + random.NextDouble() * 20
 };
 }

 private EquipmentStatus DetermineStatus(EquipmentData data)
 {
 // 간단한 상태 결정 로직
 if (data.Temperature > 300 || data.Pressure > 2.0)
 return EquipmentStatus.Error;
 else if (data.Temperature > 280 || data.Pressure > 1.5)
 return EquipmentStatus.Warning;
 else if (data.Temperature > 50)
 return EquipmentStatus.Running;
 else
 return EquipmentStatus.Idle;
 }

 private void UpdateUI(object state)
 {
 if (!IsCollecting) return;

 // 성능 지표 업데이트를 UI 스레드에서 실행
 Application.Current.Dispatcher.InvokeAsync(() =>
 {
 OnPropertyChanged(nameof(DataCollectionRate));
 OnPropertyChanged(nameof(TotalDataPoints));
 });
 }

 public void Dispose()
 {
 IsCollecting = false;
 _dataUpdateTimer?.Dispose();
 _dataCollector?.StopAsync();
 _dataStore?.Dispose();
 }
}
```

---
## Part 2: 프로퍼티 정의 및 INotifyPropertyChanged (8분)
### XAML UI 확장

---
## Part 2: 프로퍼티 정의 및 INotifyPropertyChanged (8분)
```xml
<!-- RealTimeMonitoringView.xaml -->
<UserControl x:Class="SemiconductorHMI.Views.RealTimeMonitoringView"
 xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
 xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml">

 <Grid Margin="10">
 <Grid.RowDefinitions>
 <RowDefinition Height="Auto"/> <!-- 제어 패널 -->
 <RowDefinition Height="Auto"/> <!-- 성능 지표 -->
 <RowDefinition Height="*"/> <!-- 장비 모니터링 -->
 </Grid.RowDefinitions>

 <!-- 제어 패널 -->
 <Border Grid.Row="0" Background="#34495E" CornerRadius="5" Padding="15" Margin="0,0,0,10">
 <Grid>
 <Grid.ColumnDefinitions>
 <ColumnDefinition Width="*"/>
 <ColumnDefinition Width="Auto"/>
 <ColumnDefinition Width="Auto"/>
 <ColumnDefinition Width="Auto"/>
 </Grid.ColumnDefinitions>

 <!-- 상태 정보 -->
 <StackPanel Grid.Column="0" Orientation="Horizontal" VerticalAlignment="Center">
 <TextBlock Text="상태: " Foreground="White" FontWeight="Medium"/>
 <TextBlock Text="{Binding ConnectionStatus}" Foreground="#2ECC71" FontWeight="Bold"/>
 <TextBlock Text=" | " Foreground="White" Margin="10,0"/>
 <TextBlock Text="{Binding CollectionStatusText}" Foreground="#E74C3C" FontWeight="Bold"/>
 </StackPanel>

 <!-- 제어 버튼 -->
 <Button Grid.Column="1"
 Command="{Binding StartCollectionCommand}"
 Background="#27AE60" Foreground="White"
 Padding="15,8" Margin="5,0"
 BorderThickness="0" CornerRadius="3">
 <StackPanel Orientation="Horizontal">
 <TextBlock Text="▶" FontSize="12" Margin="0,0,5,0"/>
 <TextBlock Text="시작"/>
 </StackPanel>
 </Button>

 <Button Grid.Column="2"
 Command="{Binding StopCollectionCommand}"
 Background="#E74C3C" Foreground="White"
 Padding="15,8" Margin="5,0"
 BorderThickness="0" CornerRadius="3">
 <StackPanel Orientation="Horizontal">
 <TextBlock Text="⏹" FontSize="12" Margin="0,0,5,0"/>
 <TextBlock Text="정지"/>
 </StackPanel>
 </Button>

 <Button Grid.Column="3"
 Command="{Binding ClearDataCommand}"
 Background="#95A5A6" Foreground="White"
 Padding="15,8" Margin="5,0"
 BorderThickness="0" CornerRadius="3">
 <StackPanel Orientation="Horizontal">
 <TextBlock Text="" FontSize="12" Margin="0,0,5,0"/>
 <TextBlock Text="초기화"/>
 </StackPanel>
 </Button>
 </Grid>
 </Border>

 <!-- 성능 지표 -->
 <Border Grid.Row="1" Background="White" CornerRadius="5"
 BorderBrush="#E0E0E0" BorderThickness="1" Padding="15" Margin="0,0,0,10">
 <Grid>
 <Grid.ColumnDefinitions>
 <ColumnDefinition Width="*"/>
 <ColumnDefinition Width="*"/>
 <ColumnDefinition Width="*"/>
 </Grid.ColumnDefinitions>

 <!-- 데이터 수집 속도 -->
 <StackPanel Grid.Column="0">
 <TextBlock Text="데이터 수집 속도" FontSize="12" Foreground="#7F8C8D" Margin="0,0,0,5"/>
 <StackPanel Orientation="Horizontal">
 <TextBlock Text="{Binding DataCollectionRate, StringFormat='{}{0:F1}'}"
 FontSize="24" FontWeight="Bold" Foreground="#3498DB"/>
 <TextBlock Text=" 포인트/초" FontSize="14" Foreground="#7F8C8D" VerticalAlignment="Bottom" Margin="5,0,0,2"/>
 </StackPanel>
 </StackPanel>

 <!-- 총 데이터 포인트 -->
 <StackPanel Grid.Column="1">
 <TextBlock Text="총 데이터 포인트" FontSize="12" Foreground="#7F8C8D" Margin="0,0,0,5"/>
 <StackPanel Orientation="Horizontal">
 <TextBlock Text="{Binding TotalDataPoints, StringFormat='{}{0:N0}'}"
 FontSize="24" FontWeight="Bold" Foreground="#E67E22"/>
 <TextBlock Text=" 개" FontSize="14" Foreground="#7F8C8D" VerticalAlignment="Bottom" Margin="5,0,0,2"/>
 </StackPanel>
 </StackPanel>

 <!-- 활성 장비 수 -->
 <StackPanel Grid.Column="2">
 <TextBlock Text="활성 장비" FontSize="12" Foreground="#7F8C8D" Margin="0,0,0,5"/>
 <StackPanel Orientation="Horizontal">
 <TextBlock Text="{Binding EquipmentList.Count}"
 FontSize="24" FontWeight="Bold" Foreground="#27AE60"/>
 <TextBlock Text=" 대" FontSize="14" Foreground="#7F8C8D" VerticalAlignment="Bottom" Margin="5,0,0,2"/>
 </StackPanel>
 </StackPanel>
 </Grid>
 </Border>

 <!-- 장비 모니터링 그리드 -->
 <Border Grid.Row="2" Background="White" CornerRadius="5"
 BorderBrush="#E0E0E0" BorderThickness="1">
 <Grid Margin="15">
 <Grid.ColumnDefinitions>
 <ColumnDefinition Width="2*"/>
 <ColumnDefinition Width="2*"/>
 </Grid.ColumnDefinitions>
 <Grid.RowDefinitions>
 <RowDefinition Height="*"/>
 <RowDefinition Height="*"/>
 </Grid.RowDefinitions>

 <!-- 각 장비별 모니터링 카드 -->
 <Border Grid.Row="0" Grid.Column="0" Background="#F8F9FA" CornerRadius="8"
 Padding="15" Margin="5">
 <StackPanel>
 <TextBlock Text="{Binding EquipmentList[0].EquipmentId}"
 FontSize="16" FontWeight="Bold" Margin="0,0,0,10"/>
 <Grid>
 <Grid.ColumnDefinitions>
 <ColumnDefinition Width="*"/>
 <ColumnDefinition Width="*"/>
 </Grid.ColumnDefinitions>
 <StackPanel Grid.Column="0">
 <TextBlock Text="온도" FontSize="12" Foreground="#7F8C8D"/>
 <TextBlock Text="{Binding EquipmentList[0].TemperatureText}"
 FontSize="20" FontWeight="Bold" Foreground="#E67E22"/>
 </StackPanel>
 <StackPanel Grid.Column="1">
 <TextBlock Text="압력" FontSize="12" Foreground="#7F8C8D"/>
 <TextBlock Text="{Binding EquipmentList[0].PressureText}"
 FontSize="20" FontWeight="Bold" Foreground="#3498DB"/>
 </StackPanel>
 </Grid>
 <Border Background="{Binding EquipmentList[0].StatusColor}"
 CornerRadius="15" Padding="8,4" Margin="0,10,0,0" HorizontalAlignment="Left">
 <TextBlock Text="{Binding EquipmentList[0].StatusText}"
 Foreground="White" FontSize="12" FontWeight="Medium"/>
 </Border>
 </StackPanel>
 </Border>

 <!-- 나머지 장비들도 동일한 패턴으로 구성 -->
 <Border Grid.Row="0" Grid.Column="1" Background="#F8F9FA" CornerRadius="8"
 Padding="15" Margin="5">
 <!-- PVD-002 장비 정보 -->
 </Border>

 <Border Grid.Row="1" Grid.Column="0" Background="#F8F9FA" CornerRadius="8"
 Padding="15" Margin="5">
 <!-- ETCH-003 장비 정보 -->
 </Border>

 <Border Grid.Row="1" Grid.Column="1" Background="#F8F9FA" CornerRadius="8"
 Padding="15" Margin="5">
 <!-- CMP-004 장비 정보 -->
 </Border>
 </Grid>
 </Border>
 </Grid>
</UserControl>
```

---
## Part 2: 프로퍼티 정의 및 INotifyPropertyChanged (8분)
</div>
---
## 실습 2: 비동기 오류 처리

<div style="margin: 2rem 0;">

### ️ 견고한 예외 처리

---
## 실습 2: 비동기 오류 처리
```csharp
// 포괄적인 오류 처리가 포함된 데이터 수집기
public class RobustDataCollector : IDisposable
{
 private readonly ILogger<RobustDataCollector> _logger;
 private readonly SemaphoreSlim _semaphore;
 private readonly CancellationTokenSource _cancellationTokenSource;
 private readonly List<Task> _runningTasks;
 private volatile bool _isDisposed;

 public event EventHandler<DataCollectionErrorEventArgs> ErrorOccurred;
 public event EventHandler<EquipmentDataReceivedEventArgs> DataReceived;

 public RobustDataCollector(ILogger<RobustDataCollector> logger = null)
 {
 _logger = logger ?? NullLogger<RobustDataCollector>.Instance;
 _semaphore = new SemaphoreSlim(1, 1);
 _cancellationTokenSource = new CancellationTokenSource();
 _runningTasks = new List<Task>();
 }

 public async Task StartCollectionAsync()
 {
 if (_isDisposed)
 throw new ObjectDisposedException(nameof(RobustDataCollector));

 await _semaphore.WaitAsync();
 try
 {
 _logger.LogInformation("데이터 수집 시작");

 // 각 장비별로 별도 태스크에서 데이터 수집
 var equipmentIds = new[] { "CVD-001", "PVD-002", "ETCH-003", "CMP-004" };

 foreach (var equipmentId in equipmentIds)
 {
 var task = CollectEquipmentDataAsync(equipmentId, _cancellationTokenSource.Token);
 _runningTasks.Add(task);
 }

 _logger.LogInformation($"{equipmentIds.Length}개 장비의 데이터 수집 태스크 시작됨");
 }
 finally
 {
 _semaphore.Release();
 }
 }

 private async Task CollectEquipmentDataAsync(string equipmentId, CancellationToken cancellationToken)
 {
 var retryCount = 0;
 const int maxRetries = 3;
 const int baseDelayMs = 1000;

 while (!cancellationToken.IsCancellationRequested)
 {
 try
 {
 var data = await CollectSingleDataPointAsync(equipmentId, cancellationToken);

 DataReceived?.Invoke(this, new EquipmentDataReceivedEventArgs(equipmentId, data));

 retryCount = 0; // 성공 시 재시도 카운터 리셋

 await Task.Delay(1000, cancellationToken); // 1초 간격
 }
 catch (OperationCanceledException)
 {
 _logger.LogInformation($"{equipmentId} 데이터 수집이 취소됨");
 break;
 }
 catch (TimeoutException ex)
 {
 _logger.LogWarning($"{equipmentId} 데이터 수집 타임아웃: {ex.Message}");
 await HandleRetryAsync(equipmentId, ex, ref retryCount, maxRetries, baseDelayMs, cancellationToken);
 }
 catch (HttpRequestException ex)
 {
 _logger.LogWarning($"{equipmentId} 네트워크 오류: {ex.Message}");
 await HandleRetryAsync(equipmentId, ex, ref retryCount, maxRetries, baseDelayMs, cancellationToken);
 }
 catch (Exception ex)
 {
 _logger.LogError(ex, $"{equipmentId} 데이터 수집 중 예상치 못한 오류");

 ErrorOccurred?.Invoke(this, new DataCollectionErrorEventArgs(equipmentId, ex));

 // 치명적 오류가 아닌 경우 재시도
 if (!(ex is OutOfMemoryException || ex is StackOverflowException))
 {
 await HandleRetryAsync(equipmentId, ex, ref retryCount, maxRetries, baseDelayMs, cancellationToken);
 }
 else
 {
 _logger.LogCritical($"{equipmentId} 치명적 오류로 인한 수집 중단");
 break;
 }
 }
 }
 }

 private async Task<EquipmentData> CollectSingleDataPointAsync(string equipmentId, CancellationToken cancellationToken)
 {
 using var timeoutCts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
 timeoutCts.CancelAfter(TimeSpan.FromSeconds(5)); // 5초 타임아웃

 try
 {
 // 실제 하드웨어와의 통신 시뮬레이션
 await Task.Delay(Random.Shared.Next(100, 500), timeoutCts.Token);

 // 간헐적으로 오류 발생 시뮬레이션
 if (Random.Shared.NextDouble() < 0.05) // 5% 확률로 타임아웃
 {
 throw new TimeoutException($"{equipmentId} 센서 응답 시간 초과");
 }

 if (Random.Shared.NextDouble() < 0.02) // 2% 확률로 네트워크 오류
 {
 throw new HttpRequestException($"{equipmentId} 네트워크 연결 실패");
 }

 return new EquipmentData
 {
 EquipmentId = equipmentId,
 Temperature = GetSimulatedTemperature(equipmentId),
 Pressure = GetSimulatedPressure(equipmentId),
 FlowRate = GetSimulatedFlowRate(equipmentId),
 Timestamp = DateTime.Now
 };
 }
 catch (OperationCanceledException) when (timeoutCts.Token.IsCancellationRequested && !cancellationToken.IsCancellationRequested)
 {
 throw new TimeoutException($"{equipmentId} 데이터 수집 타임아웃");
 }
 }

 private async Task HandleRetryAsync(string equipmentId, Exception ex, ref int retryCount,
 int maxRetries, int baseDelayMs, CancellationToken cancellationToken)
 {
 retryCount++;

 if (retryCount >= maxRetries)
 {
 _logger.LogError($"{equipmentId} 최대 재시도 횟수 초과. 데이터 수집 중단");
 ErrorOccurred?.Invoke(this, new DataCollectionErrorEventArgs(equipmentId, ex));
 return;
 }

 // 지수 백오프 지연
 var delayMs = baseDelayMs * (int)Math.Pow(2, retryCount - 1);
 _logger.LogInformation($"{equipmentId} {delayMs}ms 후 재시도 ({retryCount}/{maxRetries})");

 try
 {
 await Task.Delay(delayMs, cancellationToken);
 }
 catch (OperationCanceledException)
 {
 _logger.LogInformation($"{equipmentId} 재시도 중 취소됨");
 }
 }

 private double GetSimulatedTemperature(string equipmentId) =>
 equipmentId switch
 {
 "CVD-001" => 250 + (Random.Shared.NextDouble() - 0.5) * 20,
 "PVD-002" => 180 + (Random.Shared.NextDouble() - 0.5) * 15,
 "ETCH-003" => 30 + (Random.Shared.NextDouble() - 0.5) * 10,
 "CMP-004" => 45 + (Random.Shared.NextDouble() - 0.5) * 8,
 _ => 25
 };

 private double GetSimulatedPressure(string equipmentId) =>
 equipmentId switch
 {
 "CVD-001" => 0.8 + (Random.Shared.NextDouble() - 0.5) * 0.4,
 "PVD-002" => 0.005 + (Random.Shared.NextDouble() - 0.5) * 0.01,
 "ETCH-003" => 0.001 + (Random.Shared.NextDouble() - 0.5) * 0.002,
 "CMP-004" => 0.75 + (Random.Shared.NextDouble() - 0.5) * 0.3,
 _ => 0.1
 };

 private double GetSimulatedFlowRate(string equipmentId) =>
 equipmentId switch
 {
 "CVD-001" => 150 + (Random.Shared.NextDouble() - 0.5) * 30,
 "PVD-002" => 50 + (Random.Shared.NextDouble() - 0.5) * 20,
 "ETCH-003" => 0,
 "CMP-004" => 200 + (Random.Shared.NextDouble() - 0.5) * 40,
 _ => 100
 };

 public async Task StopAsync()
 {
 _logger.LogInformation("데이터 수집 중지 요청");

 _cancellationTokenSource.Cancel();

 try
 {
 await Task.WhenAll(_runningTasks);
 _logger.LogInformation("모든 데이터 수집 태스크가 정상 종료됨");
 }
 catch (OperationCanceledException)
 {
 _logger.LogInformation("데이터 수집 태스크들이 취소됨");
 }
 catch (Exception ex)
 {
 _logger.LogError(ex, "데이터 수집 종료 중 오류 발생");
 }
 }

 public void Dispose()
 {
 if (_isDisposed) return;

 _isDisposed = true;

 _cancellationTokenSource?.Cancel();
 _cancellationTokenSource?.Dispose();
 _semaphore?.Dispose();

 _logger.LogInformation("RobustDataCollector 리소스가 해제됨");
 }
}

public class DataCollectionErrorEventArgs : EventArgs
{
 public string EquipmentId { get; }
 public Exception Exception { get; }
 public DateTime Timestamp { get; }

 public DataCollectionErrorEventArgs(string equipmentId, Exception exception)
 {
 EquipmentId = equipmentId;
 Exception = exception;
 Timestamp = DateTime.Now;
 }
}
```

---
## 실습 2: 비동기 오류 처리
</div>
---

