# Week 11: ImGUI C++ 심화 - 고급 렌더링 및 커스텀 시각화

## **이론 강의 - 고급 렌더링 아키텍처 및 3D 통합**

### 1. ImGUI 고급 렌더링 아키텍처

#### 1.1 DrawList API 심화 이해

**배경 설명**

반도체 장비 HMI에서 기본 ImGui 위젯으로는 복잡한 시각화를 구현하기 어렵습니다. CVD 장비의 플라즈마 분포도나 웨이퍼 히트맵 같은 커스텀 시각화가 필요할 때 DrawList API를 직접 활용해야 합니다. DrawList는 GPU로 전달될 정점과 인덱스 버퍼를 직접 제어하여 고성능 커스텀 그래픽을 구현할 수 있게 합니다.

**핵심 개념**

DrawList는 ImGui의 저수준 렌더링 인터페이스로, 정점 버퍼(VtxBuffer)와 인덱스 버퍼(IdxBuffer)를 통해 삼각형 메시를 구성합니다. 각 정점은 위치, 텍스처 좌표, 색상 정보를 포함하며, 인덱스는 이 정점들을 연결하여 프리미티브를 형성합니다. 클리핑 영역(ClipRect)을 통해 특정 영역에만 렌더링을 제한할 수 있어 복잡한 UI 레이아웃에서도 효율적입니다.

---
# Week 11: ImGUI C++ 심화 - 고급 렌더링 및 커스텀 시각화

#### DrawList 렌더링 파이프라인 - Part 1
<div class="grid grid-cols-2 gap-8">
<div>

```cpp
/*
ImGUI 렌더링 파이프라인:
Application Code → ImGUI Draw Commands → Vertex/Index Buffers → GPU

DrawList 구조:
- Commands: 렌더링 명령 목록
- VtxBuffer: 정점 데이터
- IdxBuffer: 인덱스 데이터
- ClipRectStack: 클리핑 영역 스택
*/

#include <imgui.h>
#include <imgui_internal.h>
#include <GL/gl3w.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

namespace SemiconductorHMI {

class AdvancedRenderer {
private:
 struct RenderContext {
 glm::mat4 view_matrix;
 glm::mat4 projection_matrix;
 ImVec2 viewport_size;
 float scale_factor;
 };

 RenderContext context;
 GLuint shader_program;
 GLuint vertex_array;
 GLuint vertex_buffer;
 GLuint element_buffer;

public:
 AdvancedRenderer() : shader_program(0), vertex_array(0), vertex_buffer(0), element_buffer(0) {}

 bool Initialize() {
 // 고급 셰이더 컴파일
 const char* vertex_shader_source = R"(
 #version 450 core
 layout (location = 0) in vec2 aPos;
 layout (location = 1) in vec2 aTexCoord;
 layout (location = 2) in vec4 aColor;

 uniform mat4 uProjection;
 uniform mat4 uView;
 uniform float uTime;

 out vec2 TexCoord;
 out vec4 Color;
 out float Time;

 void main() {
 gl_Position = uProjection * uView * vec4(aPos, 0.0, 1.0);
 TexCoord = aTexCoord;
 Color = aColor;
 Time = uTime;
 }
 )";

 const char* fragment_shader_source = R"(
 #version 450 core
 in vec2 TexCoord;
 in vec4 Color;
 in float Time;

 uniform sampler2D uTexture;
 uniform bool uUseTexture;
 uniform vec4 uTint;

 out vec4 FragColor;

 void main() {
 vec4 baseColor = Color;

 if (uUseTexture) {
 baseColor *= texture(uTexture, TexCoord);
 }

 // 고급 효과: 펄스 애니메이션
 float pulse = 0.5 + 0.5 * sin(Time * 3.14159 * 2.0);
 baseColor.rgb *= (0.8 + 0.2 * pulse);

 FragColor = baseColor * uTint;
 }
 )";

 shader_program = CreateShaderProgram(vertex_shader_source, fragment_shader_source);
 if (shader_program == 0) return false;

 // VAO/VBO 설정
 glGenVertexArrays(1, &vertex_array);
 glGenBuffers(1, &vertex_buffer);
 glGenBuffers(1, &element_buffer);

 return true;
 }

 void BeginFrame(const ImVec2& display_size) {
 context.viewport_size = display_size;
 context.projection_matrix = glm::ortho(0.0f, display_size.x, display_size.y, 0.0f, -1.0f, 1.0f);
 context.view_matrix = glm::mat4(1.0f);
 context.scale_factor = ImGui::GetIO().DisplayFramebufferScale.x;
 }

 // 고급 커스텀 드로잉 함수들
 void DrawGradientRect(const ImVec2& min, const ImVec2& max,
 const ImVec4& color_tl, const ImVec4& color_tr,
 const ImVec4& color_bl, const ImVec4& color_br) {
 ImDrawList* draw_list = ImGui::GetWindowDrawList();

 // 4개 정점으로 그라데이션 사각형 생성
 draw_list->PrimReserve(6, 4);

 // 정점 추가
 ImU32 col_tl = ImGui::ColorConvertFloat4ToU32(color_tl);
 ImU32 col_tr = ImGui::ColorConvertFloat4ToU32(color_tr);
 ImU32 col_bl = ImGui::ColorConvertFloat4ToU32(color_bl);
 ImU32 col_br = ImGui::ColorConvertFloat4ToU32(color_br);

 draw_list->PrimWriteVtx(min, ImVec2(0, 0), col_tl);
 draw_list->PrimWriteVtx(ImVec2(max.x, min.y), ImVec2(1, 0), col_tr);
 draw_list->PrimWriteVtx(ImVec2(min.x, max.y), ImVec2(0, 1), col_bl);
 draw_list->PrimWriteVtx(max, ImVec2(1, 1), col_br);

 // 인덱스 추가 (두 개의 삼각형)
 auto idx = (ImDrawIdx)(draw_list->_VtxCurrentIdx - 4);
 draw_list->PrimWriteIdx(idx); draw_list->PrimWriteIdx(idx + 1); draw_list->PrimWriteIdx(idx + 2);
 draw_list->PrimWriteIdx(idx + 1); draw_list->PrimWriteIdx(idx + 3); draw_list->PrimWriteIdx(idx + 2);
 }

 void DrawBezierCurve(const ImVec2& p0, const ImVec2& p1, const ImVec2& p2, const ImVec2& p3,
 ImU32 color, float thickness, int segments = 50) {
 ImDrawList* draw_list = ImGui::GetWindowDrawList();

 // 베지어 곡선 계산
 std::vector<ImVec2> points;
 points.reserve(segments + 1);

 for (int i = 0; i <= segments; ++i) {
 float t = static_cast<float>(i) / segments;
 float u = 1.0f - t;

 // 3차 베지어 곡선 공식
 ImVec2 point = ImVec2(
 u*u*u * p0.x + 3*u*u*t * p1.x + 3*u*t*t * p2.x + t*t*t * p3.x,
 u*u*u * p0.y + 3*u*u*t * p1.y + 3*u*t*t * p2.y + t*t*t * p3.y
 );
 points.push_back(point);
 }

 // 폴리라인으로 그리기
 draw_list->AddPolyline(points.data(), points.size(), color, false, thickness);
 }

 void DrawCircularProgressBar(const ImVec2& center, float radius, float progress,
 ImU32 bg_color, ImU32 fg_color, float thickness = 4.0f) {
 ImDrawList* draw_list = ImGui::GetWindowDrawList();

 const int segments = 64;
 const float angle_step = 2.0f * IM_PI / segments;
 const float progress_angle = progress * 2.0f * IM_PI - IM_PI * 0.5f; // -90도에서 시작

 // 배경 원
 draw_list->AddCircle(center, radius, bg_color, segments, thickness);

 // 진행률 호 그리기
 if (progress > 0.0f) {
 int progress_segments = static_cast<int>(progress * segments);

 for (int i = 0; i < progress_segments; ++i) {
 float angle1 = -IM_PI * 0.5f + angle_step * i;
 float angle2 = -IM_PI * 0.5f + angle_step * (i + 1);

 ImVec2 p1 = ImVec2(center.x + cos(angle1) * radius, center.y + sin(angle1) * radius);
 ImVec2 p2 = ImVec2(center.x + cos(angle2) * radius, center.y + sin(angle2) * radius);

 draw_list->AddLine(p1, p2, fg_color, thickness);
 }
 }
 }

private:
 GLuint CreateShaderProgram(const char* vertex_source, const char* fragment_source) {
 GLuint vertex_shader = CompileShader(GL_VERTEX_SHADER, vertex_source);
 GLuint fragment_shader = CompileShader(GL_FRAGMENT_SHADER, fragment_source);

 if (vertex_shader == 0 || fragment_shader == 0) {
 return 0;
 }

 GLuint program = glCreateProgram();
 glAttachShader(program, vertex_shader);
 glAttachShader(program, fragment_shader);
 glLinkProgram(program);

 GLint success;
 glGetProgramiv(program, GL_LINK_STATUS, &success);
 if (!success) {
 char info_log[512];
 glGetProgramInfoLog(program, 512, nullptr, info_log);
 printf("Shader program linking failed: %s\n", info_log);
 return 0;
 }

 glDeleteShader(vertex_shader);
 glDeleteShader(fragment_shader);

 return program;
 }

 GLuint CompileShader(GLenum type, const char* source) {
 GLuint shader = glCreateShader(type);
 glShaderSource(shader, 1, &source, nullptr);
 glCompileShader(shader);

 GLint success;
 glGetShaderiv(shader, GL_COMPILE_STATUS, &success);
 if (!success) {
 char info_log[512];
 glGetShaderInfoLog(shader, 512, nullptr, info_log);
 printf("Shader compilation failed: %s\n", info_log);
 return 0;
 }

 return shader;
 }
};

} // namespace SemiconductorHMI
```

</div>
<div>

**코드 해설**

- **Line 118-141**: DrawGradientRect - 4개 정점으로 그라데이션 사각형 생성, PrimReserve로 정점/인덱스 메모리 예약
- **Line 124**: 정점 6개, 인덱스 4개 예약 - 2개 삼각형으로 사각형 구성
- **Line 127-135**: ColorConvertFloat4ToU32로 ImVec4를 32비트 색상으로 변환
- **Line 143-165**: DrawBezierCurve - 3차 베지어 곡선을 50개 세그먼트로 분할하여 부드러운 곡선 생성
- **Line 167-192**: DrawCircularProgressBar - 64개 세그먼트 원형 프로그레스바, 진행률에 따라 호 그리기

**실제 사례**

CVD 장비 압력 게이지: 원형 프로그레스바로 챔버 압력 표시 (1-100 mTorr 범위). 베지어 곡선으로 온도 변화 추이 그래프 구현. 그라데이션으로 온도 구간별 색상 매핑 (150°C=파랑, 450°C=빨강).

**Week 1 HCI 이론**

Gestalt 법칙 중 연속성: 베지어 곡선을 사용하여 데이터 포인트를 부드럽게 연결함으로써 사용자가 트렌드를 쉽게 인지할 수 있습니다.

</div>
</div>

```mermaid
graph TD
    A[DrawGradientRect] --> B[PrimReserve 6,4]
    B --> C[Write 4 Vertices]
    C --> D[Write 6 Indices]
    D --> E[Form 2 Triangles]

    F[DrawBezierCurve] --> G[Calculate 50 Points]
    G --> H[Bezier Formula]
    H --> I[AddPolyline]
```

---
## **기초 실습 - 커스텀 드로잉 및 위젯 개발**

#### 1.2 3D 렌더링과 ImGUI 통합

**배경 설명**

반도체 장비는 웨이퍼 이송 로봇이나 3D 챔버 구조 같은 물리적 시스템을 가지고 있습니다. 2D HMI만으로는 공간 정보를 직관적으로 전달하기 어렵기 때문에 ImGui 위젯 안에 3D 뷰포트를 통합하여 장비 상태를 입체적으로 시각화해야 합니다. 이를 위해 OpenGL 프레임버퍼를 ImGui 텍스처로 바인딩하는 기법이 필요합니다.

**핵심 개념**

3D 렌더링 통합의 핵심은 오프스크린 프레임버퍼입니다. 먼저 별도의 프레임버퍼에 3D 씬을 렌더링한 후, 그 결과를 텍스처로 저장하고 ImGui::Image로 표시합니다. 이를 통해 ImGui UI와 3D 뷰를 동일한 윈도우 내에서 자유롭게 배치할 수 있으며, 마우스/키보드 입력도 통합 관리할 수 있습니다.

---
## **기초 실습 - 커스텀 드로잉 및 위젯 개발**
```cpp
#include <assimp/Importer.hpp>
#include <assimp/scene.h>
#include <assimp/postprocess.h>

namespace SemiconductorHMI {

struct Vertex3D {
 glm::vec3 position;
 glm::vec3 normal;
 glm::vec2 texCoords;
 glm::vec3 tangent;
};

struct Mesh3D {
 std::vector<Vertex3D> vertices;
 std::vector<unsigned int> indices;
 std::vector<GLuint> textures;

 GLuint VAO, VBO, EBO;

 void SetupMesh() {
 glGenVertexArrays(1, &VAO);
 glGenBuffers(1, &VBO);
 glGenBuffers(1, &EBO);

 glBindVertexArray(VAO);

 glBindBuffer(GL_ARRAY_BUFFER, VBO);
 glBufferData(GL_ARRAY_BUFFER, vertices.size() * sizeof(Vertex3D),
 &vertices[0], GL_STATIC_DRAW);

 glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
 glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.size() * sizeof(unsigned int),
 &indices[0], GL_STATIC_DRAW);

 // 정점 속성 설정
 glEnableVertexAttribArray(0);
 glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex3D), (void*)0);

 glEnableVertexAttribArray(1);
 glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex3D),
 (void*)offsetof(Vertex3D, normal));

 glEnableVertexAttribArray(2);
 glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex3D),
 (void*)offsetof(Vertex3D, texCoords));

 glBindVertexArray(0);
 }

 void Draw(GLuint shader_program) {
 glUseProgram(shader_program);
 glBindVertexArray(VAO);
 glDrawElements(GL_TRIANGLES, indices.size(), GL_UNSIGNED_INT, 0);
 glBindVertexArray(0);
 }
};

class Equipment3DModel {
private:
 std::vector<Mesh3D> meshes;
 std::string directory;
 Assimp::Importer importer;

public:
 bool LoadModel(const std::string& path) {
 const aiScene* scene = importer.ReadFile(path,
 aiProcess_Triangulate | aiProcess_FlipUVs | aiProcess_CalcTangentSpace);

 if (!scene || scene->mFlags & AI_SCENE_FLAGS_INCOMPLETE || !scene->mRootNode) {
 printf("ERROR::ASSIMP:: %s\n", importer.GetErrorString());
 return false;
 }

 directory = path.substr(0, path.find_last_of('/'));
 ProcessNode(scene->mRootNode, scene);
 return true;
 }

 void Draw(GLuint shader_program) {
 for (auto& mesh : meshes) {
 mesh.Draw(shader_program);
 }
 }

private:
 void ProcessNode(aiNode* node, const aiScene* scene) {
 // 현재 노드의 모든 메쉬 처리
 for (unsigned int i = 0; i < node->mNumMeshes; i++) {
 aiMesh* mesh = scene->mMeshes[node->mMeshes[i]];
 meshes.push_back(ProcessMesh(mesh, scene));
 }

 // 자식 노드들 재귀 처리
 for (unsigned int i = 0; i < node->mNumChildren; i++) {
 ProcessNode(node->mChildren[i], scene);
 }
 }

 Mesh3D ProcessMesh(aiMesh* mesh, const aiScene* scene) {
 std::vector<Vertex3D> vertices;
 std::vector<unsigned int> indices;
 std::vector<GLuint> textures;

 // 정점 데이터 처리
 for (unsigned int i = 0; i < mesh->mNumVertices; i++) {
 Vertex3D vertex;

 vertex.position = glm::vec3(mesh->mVertices[i].x, mesh->mVertices[i].y, mesh->mVertices[i].z);
 vertex.normal = glm::vec3(mesh->mNormals[i].x, mesh->mNormals[i].y, mesh->mNormals[i].z);

 if (mesh->mTextureCoords[0]) {
 vertex.texCoords = glm::vec2(mesh->mTextureCoords[0][i].x, mesh->mTextureCoords[0][i].y);
 } else {
 vertex.texCoords = glm::vec2(0.0f, 0.0f);
 }

 vertices.push_back(vertex);
 }

 // 인덱스 처리
 for (unsigned int i = 0; i < mesh->mNumFaces; i++) {
 aiFace face = mesh->mFaces[i];
 for (unsigned int j = 0; j < face.mNumIndices; j++) {
 indices.push_back(face.mIndices[j]);
 }
 }

 Mesh3D result;
 result.vertices = vertices;
 result.indices = indices;
 result.textures = textures;
 result.SetupMesh();

 return result;
 }
};

class ImGui3DViewer {
private:
 Equipment3DModel model;
 GLuint framebuffer, color_texture, depth_texture;
 GLuint shader_program;
 glm::mat4 view_matrix, projection_matrix;
 glm::vec3 camera_position;
 glm::vec3 camera_target;
 float camera_distance;
 ImVec2 viewport_size;

public:
 ImGui3DViewer() : framebuffer(0), color_texture(0), depth_texture(0),
 shader_program(0), camera_distance(5.0f),
 camera_position(0, 0, 5), camera_target(0, 0, 0) {}

 bool Initialize(const std::string& model_path) {
 // 3D 모델 로드
 if (!model.LoadModel(model_path)) {
 return false;
 }

 // 셰이더 프로그램 생성
 const char* vertex_shader = R"(
 #version 450 core
 layout (location = 0) in vec3 aPos;
 layout (location = 1) in vec3 aNormal;
 layout (location = 2) in vec2 aTexCoord;

 uniform mat4 model;
 uniform mat4 view;
 uniform mat4 projection;

 out vec3 FragPos;
 out vec3 Normal;
 out vec2 TexCoord;

 void main() {
 FragPos = vec3(model * vec4(aPos, 1.0));
 Normal = mat3(transpose(inverse(model))) * aNormal;
 TexCoord = aTexCoord;

 gl_Position = projection * view * vec4(FragPos, 1.0);
 }
 )";

 const char* fragment_shader = R"(
 #version 450 core
 in vec3 FragPos;
 in vec3 Normal;
 in vec2 TexCoord;

 uniform vec3 lightPos;
 uniform vec3 lightColor;
 uniform vec3 objectColor;
 uniform vec3 viewPos;

 out vec4 FragColor;

 void main() {
 // 앰비언트 라이팅
 float ambientStrength = 0.3;
 vec3 ambient = ambientStrength * lightColor;

 // 디퓨즈 라이팅
 vec3 norm = normalize(Normal);
 vec3 lightDir = normalize(lightPos - FragPos);
 float diff = max(dot(norm, lightDir), 0.0);
 vec3 diffuse = diff * lightColor;

 // 스펙큘러 라이팅
 float specularStrength = 0.5;
 vec3 viewDir = normalize(viewPos - FragPos);
 vec3 reflectDir = reflect(-lightDir, norm);
 float spec = pow(max(dot(viewDir, reflectDir), 0.0), 32);
 vec3 specular = specularStrength * spec * lightColor;

 vec3 result = (ambient + diffuse + specular) * objectColor;
 FragColor = vec4(result, 1.0);
 }
 )";

 shader_program = CreateShaderProgram(vertex_shader, fragment_shader);
 return shader_program != 0;
 }

 void SetViewportSize(const ImVec2& size) {
 if (viewport_size.x != size.x || viewport_size.y != size.y) {
 viewport_size = size;
 SetupFramebuffer();
 }
 }

 void Render() {
 if (framebuffer == 0) return;

 // 프레임버퍼에 렌더링
 glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);
 glViewport(0, 0, static_cast<int>(viewport_size.x), static_cast<int>(viewport_size.y));

 glEnable(GL_DEPTH_TEST);
 glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
 glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

 // 뷰 및 프로젝션 매트릭스 설정
 view_matrix = glm::lookAt(camera_position, camera_target, glm::vec3(0, 1, 0));
 projection_matrix = glm::perspective(glm::radians(45.0f),
 viewport_size.x / viewport_size.y, 0.1f, 100.0f);

 // 셰이더 유니폼 설정
 glUseProgram(shader_program);

 glm::mat4 model_matrix = glm::mat4(1.0f);

 GLint model_loc = glGetUniformLocation(shader_program, "model");
 GLint view_loc = glGetUniformLocation(shader_program, "view");
 GLint projection_loc = glGetUniformLocation(shader_program, "projection");

 glUniformMatrix4fv(model_loc, 1, GL_FALSE, glm::value_ptr(model_matrix));
 glUniformMatrix4fv(view_loc, 1, GL_FALSE, glm::value_ptr(view_matrix));
 glUniformMatrix4fv(projection_loc, 1, GL_FALSE, glm::value_ptr(projection_matrix));

 // 라이팅 설정
 glUniform3f(glGetUniformLocation(shader_program, "lightPos"), 1.2f, 1.0f, 2.0f);
 glUniform3f(glGetUniformLocation(shader_program, "lightColor"), 1.0f, 1.0f, 1.0f);
 glUniform3f(glGetUniformLocation(shader_program, "objectColor"), 0.8f, 0.8f, 0.9f);
 glUniform3f(glGetUniformLocation(shader_program, "viewPos"),
 camera_position.x, camera_position.y, camera_position.z);

 // 3D 모델 렌더링
 model.Draw(shader_program);

 glBindFramebuffer(GL_FRAMEBUFFER, 0);
 }

 void RenderImGuiPanel() {
 if (ImGui::Begin("3D Equipment View")) {
 ImVec2 panel_size = ImGui::GetContentRegionAvail();
 SetViewportSize(panel_size);

 Render();

 // 렌더링된 텍스처를 ImGui 이미지로 표시
 ImGui::Image(reinterpret_cast<void*>(static_cast<intptr_t>(color_texture)),
 viewport_size, ImVec2(0, 1), ImVec2(1, 0));

 // 마우스 인터랙션 처리
 if (ImGui::IsItemHovered()) {
 ImGuiIO& io = ImGui::GetIO();
 if (io.MouseDown[0]) {
 // 카메라 회전
 float sensitivity = 0.01f;
 camera_position = glm::rotate(glm::mat4(1.0f),
 io.MouseDelta.x * sensitivity,
 glm::vec3(0, 1, 0)) * glm::vec4(camera_position, 1.0f);
 }

 // 마우스 휠로 줌
 if (io.MouseWheel != 0) {
 camera_distance *= (1.0f - io.MouseWheel * 0.1f);
 camera_distance = glm::clamp(camera_distance, 1.0f, 20.0f);

 glm::vec3 direction = glm::normalize(camera_position - camera_target);
 camera_position = camera_target + direction * camera_distance;
 }
 }
 }
 ImGui::End();
 }

private:
 void SetupFramebuffer() {
 if (framebuffer != 0) {
 glDeleteFramebuffers(1, &framebuffer);
 glDeleteTextures(1, &color_texture);
 glDeleteTextures(1, &depth_texture);
 }

 // 프레임버퍼 생성
 glGenFramebuffers(1, &framebuffer);
 glBindFramebuffer(GL_FRAMEBUFFER, framebuffer);

 // 컬러 텍스처
 glGenTextures(1, &color_texture);
 glBindTexture(GL_TEXTURE_2D, color_texture);
 glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, static_cast<int>(viewport_size.x),
 static_cast<int>(viewport_size.y), 0, GL_RGB, GL_UNSIGNED_BYTE, nullptr);
 glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
 glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
 glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, color_texture, 0);

 // 깊이 텍스처
 glGenTextures(1, &depth_texture);
 glBindTexture(GL_TEXTURE_2D, depth_texture);
 glTexImage2D(GL_TEXTURE_2D, 0, GL_DEPTH_COMPONENT, static_cast<int>(viewport_size.x),
 static_cast<int>(viewport_size.y), 0, GL_DEPTH_COMPONENT, GL_FLOAT, nullptr);
 glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
 glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
 glFramebufferTexture2D(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT, GL_TEXTURE_2D, depth_texture, 0);

 if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) {
 printf("Framebuffer not complete!\n");
 }

 glBindFramebuffer(GL_FRAMEBUFFER, 0);
 }

 GLuint CreateShaderProgram(const char* vertex_source, const char* fragment_source) {
 // 셰이더 컴파일 로직 (이전 예제와 동일)
 // ... 생략 ...
 return 0; // 실제 구현에서는 컴파일된 프로그램 반환
 }
};

} // namespace SemiconductorHMI
```

</div>
<div>

**코드 해설 - 3D 모델 로딩 및 렌더링**

- **Line 250-327**: Equipment3DModel - Assimp 라이브러리로 3D 모델 파일 로드
- **Line 315-327**: LoadModel - OBJ, FBX, GLTF 등 다양한 포맷 지원, Triangulate로 삼각형화
- **Line 336-347**: ProcessNode - 재귀적 노드 순회로 메시 계층 구조 처리
- **Line 388-603**: ImGui3DViewer - 프레임버퍼 기반 3D 뷰포트 위젯
- **Line 523-556**: RenderImGuiPanel - 3D 텍스처를 ImGui::Image로 표시, 마우스 인터랙션 처리

**실제 사례**

웨이퍼 이송 로봇 시각화: EFEM 로봇의 3D 모델을 실시간으로 표시하여 현재 위치와 동작 상태 파악. 모델 정점 수 약 5000개, 렌더링 시간 1-2ms. 카메라 회전으로 다양한 각도에서 확인 가능.

**Week 1 HCI 이론**

Affordance 이론: 3D 모델을 회전/줌 가능하게 만들어 사용자에게 "조작 가능함"을 시각적으로 암시합니다. 마우스 드래그로 회전, 휠로 줌 인/아웃.

</div>
</div>

```mermaid
sequenceDiagram
    participant App as Application
    participant FBO as Framebuffer
    participant GL as OpenGL
    participant ImGui as ImGui

    App->>FBO: Bind Framebuffer
    App->>GL: Render 3D Scene
    GL->>FBO: Write to Texture
    App->>FBO: Unbind
    App->>ImGui: ImGui::Image(texture)
    ImGui->>App: Display in UI
```

---

## **기초 실습 - 커스텀 드로잉 및 위젯 개발**

### 2. 성능 최적화 및 메모리 관리

**배경 설명**

반도체 장비 HMI는 수백 개의 센서 데이터를 초당 60프레임으로 업데이트해야 합니다. 매 프레임 메모리 할당/해제를 반복하면 힙 단편화와 가비지 컬렉션으로 성능이 저하됩니다. 메모리 풀링 시스템을 통해 미리 할당된 메모리 블록을 재사용함으로써 안정적인 프레임 타임을 유지할 수 있습니다.

#### 2.1 메모리 풀링 시스템
```cpp
#include <memory_resource>
#include <array>

namespace SemiconductorHMI {

template<size_t BlockSize, size_t BlockCount>
class MemoryPool {
private:
 alignas(std::max_align_t) std::array<std::byte, BlockSize * BlockCount> memory;
 std::array<bool, BlockCount> used;
 size_t next_free;

public:
 MemoryPool() : next_free(0) {
 used.fill(false);
 }
