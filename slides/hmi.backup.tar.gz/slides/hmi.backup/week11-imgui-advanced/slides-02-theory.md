---
theme: default
class: text-center
highlighter: shiki
lineNumbers: true
drawings:
persist: false
transition: slide-left
title: Week 11 - C++ Advanced Patterns (Template Metaprogramming, Performance, Modern C++)
mdc: true
---

# Week 11: C++ 고급 패턴

## 템플릿 메타프로그래밍, 성능 최적화, 모던 C++

### 반도체 HMI 고급 기법

```mermaid
graph TD
A[View - UI 렌더링] --> B[ViewModel - 데이터 바인딩]
B --> C[Model - 비즈니스 로직]
C --> D[Data Source - 센서/DB]

style A fill:#e1f5fe
style B fill:#fff3e0
style C fill:#c8e6c9
```

---

## 학습 목표 (1/2)

**Part 1: 템플릿 메타프로그래밍**

1. **함수 템플릿 마스터**
- ImGui 위젯 제네릭 생성
- 실습 목표: 20개 이상 위젯 자동 생성
- 성능 목표: Docking Layout 구현으로 UI 구조화

2. **클래스 템플릿 활용**
- Multi-Viewport 시스템 구축
- 실습 목표: 30개 이상 동시 뷰포트 관리
- 성능 목표: Docking Layout으로 유연한 UI 구성
---

## 학습 목표 (2/2)

**Part 2: 성능 최적화**

3. **프로파일링과 벤치마크**
- Custom ImGui 위젯 성능 측정
- 측정 항목: Docking 지연(ms), Multi-Viewport 렌더링, 메모리 사용량
- 목표 성능: Docking 50ms 이하, Multi-Viewport 4개 이상, 60 FPS 유지

**사전 지식**:
- Week 10 내용 복습
- C++ 템플릿 기초
- OpenGL 렌더링 기본

**핵심 주제**:
- 반도체 HMI 최적화 기법
- 고급 C++ 패턴

---
layout: two-cols
---
# **1. Template Metaprogramming** (1/2) (Part 1)





```cpp
namespace SemiconductorHMI {

//
template<typename T>
T Clamp(T value, T min, T max) {
if (value < min) return min;
if (value > max) return max;
return value;
}

//
void UpdateTemperature(float temp) {
```
---
# **1. Template Metaprogramming** (1/2) (Part 2)

```cpp
// Clamp<float>
float clamped = Clamp(temp, 20.0f, 80.0f);
}

void UpdatePressure(int pressure) {
// Clamp<int>
int clamped = Clamp(pressure, 0, 1000);
}

}
```


::right::
---
# **1. Template Metaprogramming** (2/2) (1/2)

##
** **
- ""
- -
** **
```cpp
//
Clamp<float>(temp, 20.0f, 80.0f);

// (C++17 )
Clamp(temp, 20.0f, 80.0f);
```
---
# **1. Template Metaprogramming** (2/2) (2/2)

****
- - -
****
- - -
---
layout: two-cols
---
### Class Template (Part 1)



```cpp
namespace SemiconductorHMI {

//
template<typename T, size_t Capacity>
class RingBuffer {
private:
std::array<T, Capacity> buffer;
size_t read_index = 0;
size_t write_index = 0;
size_t count = 0;

public:
```
---
### Class Template (Part 2)

```cpp
bool Push(const T& item) {
if (count >= Capacity) {
return false; //
}

buffer[write_index] = item;
write_index = (write_index + 1) % Capacity;
count++;
return true;
}

bool Pop(T& item) {
```
---
### Class Template (Part 3)

```cpp
if (count == 0) {
return false; //
}

item = buffer[read_index];
read_index = (read_index + 1) % Capacity;
count--;
return true;
}

size_t Size() const { return count; }
bool IsEmpty() const { return count == 0; }
```
---
### Class Template (Part 4)

```cpp
bool IsFull() const { return count >= Capacity; }
};

}
```


::right::

## ---
### Class Template (Part 4)

** **
```cpp
// (float, 100)
RingBuffer<float, 100> temp_buffer;

// (string, 50)
RingBuffer<std::string, 50> alarm_buffer;

//
---
### Class Template (Part 4)
struct SensorReading {
float value;
uint64_t timestamp;
};
RingBuffer<SensorReading, 1000> sensor_buffer;
```
---
### Class Template (Part 4)

**Non-Type Template Parameter**
- `size_t Capacity`
- -
****
- - ( )
- ---
### Class Template (Part 4)

** **
```cpp
void ProcessTemperatureData() {
RingBuffer<float, 100> buffer;

buffer.Push(25.3f);
buffer.Push(26.1f);

float temp;
if (buffer.Pop(temp)) {
---
### Class Template (Part 4)
//
}
}
```
---
layout: two-cols
---
## 1.2 SFINAE (Substitution Failure Is Not An Error) (Part 1)




```cpp
namespace SemiconductorHMI {

//
template<typename T>
typename std::enable_if<std::is_integral<T>::value, T>::type
ProcessValue(T value) {
return value * 2;
}

//
template<typename T>
typename std::enable_if<std::is_floating_point<T>::value, T>::type
```
---
## 1.2 SFINAE (Substitution Failure Is Not An Error) (Part 2)

```cpp
ProcessValue(T value) {
return value * 1.5f;
}

//
void Example() {
int i = ProcessValue(10); // 20 ( )
float f = ProcessValue(10.0f); // 15.0 ( )

// ProcessValue("hello"); //!
}

```
---
## 1.2 SFINAE (Substitution Failure Is Not An Error) (Part 3)

```cpp
// C++17
template<typename T>
std::enable_if_t<std::is_integral_v<T>, T>
ProcessValueModern(T value) {
return value * 2;
}

}
```


::right::

## SFINAE

**Substitution Failure Is Not An Error**
- - - ---
## 1.2 SFINAE (Substitution Failure Is Not An Error) (Part 3)

---
## 1.2 SFINAE (Substitution Failure Is Not An Error) (Part 3)
**std::enable_if **
```cpp
// true type
template<bool B, typename T = void>
struct enable_if {
using type = T;
};

// false type
template<typename T>
struct enable_if<false, T> {};
```
---
## 1.2 SFINAE (Substitution Failure Is Not An Error) (Part 3)

** (Type Traits)**
```cpp
std::is_integral<int>::value // true
std::is_integral<float>::value // false
std::is_floating_point<double>::value // true
std::is_pointer<int*>::value // true
std::is_const<const int>::value // true
```

**: **
```cpp
// POD memcpy
template<typename T>
---
## 1.2 SFINAE (Substitution Failure Is Not An Error) (Part 3)

std::enable_if_t<std::is_trivially_copyable_v<T>, void>
Serialize(const T& data, std::vector<uint8_t>& buffer) {
size_t old_size = buffer.size();
buffer.resize(old_size + sizeof(T));
std::memcpy(buffer.data() + old_size, &data, sizeof(T));
}

//
template<typename T>
std::enable_if_t<!std::is_trivially_copyable_v<T>, void>
Serialize(const T& data, std::vector<uint8_t>& buffer) {
data.SerializeToBuffer(buffer);
}
```

---
layout: two-cols
---
## 1.3 C++20 Concepts (Part 1)




```cpp
namespace SemiconductorHMI {

// Concept: Numeric
template<typename T>
concept Numeric = std::is_arithmetic_v<T>;

// Concept: Sensor
template<typename T>
concept Sensor = requires(T sensor) {
{ sensor.Read() } -> std::convertible_to<float>;
{ sensor.GetID() } -> std::convertible_to<int>;
{ sensor.IsOnline() } -> std::same_as<bool>;
```
---
## 1.3 C++20 Concepts (Part 2)

```cpp
};

// Concept:
template<Numeric T>
T Clamp(T value, T min, T max) {
if (value < min) return min;
if (value > max) return max;
return value;
}

// Concept:
template<Sensor S>
```
---
## 1.3 C++20 Concepts (Part 3)

```cpp
class SensorMonitor {
private:
S& sensor;

public:
explicit SensorMonitor(S& s): sensor(s) {}

void Update() {
if (sensor.IsOnline()) {
float value = sensor.Read();
//
}
```
---
## 1.3 C++20 Concepts (Part 4)

```cpp
}
};

}
```


::right::

## Concepts vs SFINAE

**SFINAE (C++17 )**
```cpp
//
template<typename T>
std::enable_if_t<std::is_arithmetic_v<T>, T>
Clamp(T value, T min, T max) {
//...
}
```
---
## 1.3 C++20 Concepts (Part 4)

**Concepts (C++20)**
```cpp
//
template<Numeric T>
T Clamp(T value, T min, T max) {
//...
}
```
---
## 1.3 C++20 Concepts (Part 4)

**Concepts **
- ****:
- ** **:
- ****:

** Concept **
```cpp
// Container Iterator
template<typename T>
concept Container = requires(T container) {
typename T::value_type;
---
## 1.3 C++20 Concepts (Part 4)

typename T::iterator;
{ container.begin() } -> std::same_as<typename T::iterator>;
{ container.end() } -> std::same_as<typename T::iterator>;
{ container.size() } -> std::convertible_to<size_t>;
};

// Callable
template<typename F, typename... Args>
concept Callable = requires(F func, Args... args) {
{ func(args...) };
};
```

---
layout: two-cols
---
###: (Part 1)



```cpp
namespace SemiconductorHMI {

// Concept:
template<typename T>
concept Measurable = requires(const T& equipment) {
{ equipment.GetValue() } -> std::convertible_to<double>;
{ equipment.GetUnit() } -> std::convertible_to<std::string_view>;
{ equipment.GetTimestamp() } -> std::convertible_to<uint64_t>;
};

// Concept:
template<typename T>
```
---
###: (Part 2)

```cpp
concept Controllable = requires(T& equipment, double value) {
{ equipment.SetValue(value) } -> std::same_as<bool>;
{ equipment.GetStatus() } -> std::convertible_to<std::string_view>;
};

//
template<Measurable E>
class MeasurementMonitor {
private:
E& equipment;
std::vector<double> history;

```
---
###: (Part 3)

```cpp
public:
explicit MeasurementMonitor(E& eq): equipment(eq) {}

void Update() {
double value = equipment.GetValue();
history.push_back(value);

if (history.size() > 1000) {
history.erase(history.begin());
}
}

```
---
###: (Part 4) (Code Part 1/3)


```cpp
double GetAverage() const {

```cpp
// ( )
class TemperatureSensor {
public:
double GetValue() const { return temperature; }
std::string_view GetUnit() const { return "°C"; }
uint64_t GetTimestamp() const { return timestamp; }
private:
double temperature = 25.0;
uint64_t timestamp = 0;
};
```
---
###: (Part 4) (Code Part 2/3)

```cpp

// ( + )
class Heater {
public:
double GetValue() const { return temperature; }
std::string_view GetUnit() const { return "°C"; }
uint64_t GetTimestamp() const { return timestamp; }

bool SetValue(double temp) {
target_temperature = temp;
```
---
###: (Part 4) (Code Part 3/3)

```cpp
return true;
}
std::string_view GetStatus() const { return status; }
private:
double temperature = 25.0;
double target_temperature = 25.0;
uint64_t timestamp = 0;
std::string status = "OK";
};
```


****
```cpp
---
layout: center
---

# **2. Performance Optimization**

##,,

---
layout: two-cols
---
## 2.1 (Profiling) (Part 1)




```cpp
namespace SemiconductorHMI::Profiling {

class ScopedTimer {
private:
const char* name;
std::chrono::high_resolution_clock::time_point start;

public:
explicit ScopedTimer(const char* timer_name)
: name(timer_name)
, start(std::chrono::high_resolution_clock::now())
{}
```
---
## 2.1 (Profiling) (Part 2)

```cpp

~ScopedTimer() {
auto end = std::chrono::high_resolution_clock::now();
auto duration = std::chrono::duration_cast<
std::chrono::microseconds>(end - start);

printf("[%s] took %lld μs\n", name, duration.count());
}
};

//
void ProcessSensorData(const std::vector<float>& data) {
```
---
## 2.1 (Profiling) (Part 3) (Code Part 1/2)


```cpp
ScopedTimer timer("ProcessSensorData");

```cpp
void RenderFrame() {
ScopedTimer timer("RenderFrame");

{
ScopedTimer timer("UpdateLogic");
UpdateGameLogic();
} // UpdateLogic

{
ScopedTimer timer("RenderScene");
```
---
## 2.1 (Profiling) (Part 3) (Code Part 2/2)

```cpp
RenderScene();
} // RenderScene

{
ScopedTimer timer("RenderUI");
RenderUI();
} // RenderUI
} // RenderFrame
```


** **
```
---
layout: two-cols
---
## 2.2 (Part 1)




```cpp
namespace SemiconductorHMI {

// Array of Structures (AoS) -
struct Particle_AoS {
float x, y, z; //
float vx, vy, vz; //
float r, g, b, a; //
float life; //
};

std::vector<Particle_AoS> particles_aos(10000);

```
---
## 2.2 (Part 2)

```cpp
void UpdatePositions_AoS() {
for (auto& p: particles_aos) {
//
// 64
p.x += p.vx;
p.y += p.vy;
p.z += p.vz;
}
}

// Structure of Arrays (SoA) -
struct ParticleSystem_SoA {
```
---
## 2.2 (Part 3)

```cpp
std::vector<float> x, y, z; //
std::vector<float> vx, vy, vz; //
std::vector<float> r, g, b, a; //
std::vector<float> life; //
};

ParticleSystem_SoA particles_soa;

void UpdatePositions_SoA() {
for (size_t i = 0; i < particles_soa.x.size(); ++i) {
//
particles_soa.x[i] += particles_soa.vx[i];
```
---
## 2.2 (Part 4)

```cpp
particles_soa.y[i] += particles_soa.vy[i];
particles_soa.z[i] += particles_soa.vz[i];
}
}

}
```


::right::

##
---
## 2.2 (Part 4)
**AoS **
```
[x y z vx vy vz r g b a life] [x y z vx vy vz r g b a life]...
← 64 bytes → ← 64 bytes →
```
-,
- ---
## 2.2 (Part 4)

---
## 2.2 (Part 4)
**SoA **
```
x: [x x x x x x x x...]
y: [y y y y y y y y...]
z: [z z z z z z z z...]
vx: [vx vx vx vx vx...]
...
```
- - ---
## 2.2 (Part 4)

---
## 2.2 (Part 4)
** **
```cpp
// 10,000
AoS: 2.3ms
SoA: 0.8ms ( 3 )
```
---
## 2.2 (Part 4)

** **
- **AoS**:
- **SoA**: (, )

** **
```cpp
//:
struct ParticleSystem_Hybrid {
struct Position { float x, y, z; };
struct Velocity { float vx, vy, vz; };

std::vector<Position> positions;
std::vector<Velocity> velocities;
std::vector<float> life; //
};
```

---
layout: two-cols
---
### (Alignment) (Part 1)



```cpp
namespace SemiconductorHMI {

//: 19 24
struct BadAlignment {
char a; // 1 byte, 3 byte padding
int b; // 4 bytes
char c; // 1 byte, 7 byte padding
double d; // 8 bytes
}; // 24 bytes

//: 16
struct GoodAlignment {
```
---
### (Alignment) (Part 2)

```cpp
double d; // 8 bytes
int b; // 4 bytes
char a; // 1 byte
char c; // 1 byte
// 2 byte padding
}; // 16 bytes

// SIMD
struct alignas(16) Vec4 {
float x, y, z, w;

// SSE
```
---
### (Alignment) (Part 3)

```cpp
Vec4 operator+(const Vec4& other) const {
Vec4 result;
__m128 a = _mm_load_ps(&x);
__m128 b = _mm_load_ps(&other.x);
__m128 c = _mm_add_ps(a, b);
_mm_store_ps(&result.x, c);
return result;
}
};

// (64)
struct alignas(64) CacheLinePadded {
```
---
### (Alignment) (Part 4)

```cpp
std::atomic<int> counter;
// 60
// false sharing
};

}
```


::right::

##
** **
```cpp
//
char buffer[100];
int* unaligned_ptr = reinterpret_cast<int*>(buffer + 1);
---
### (Alignment) (Part 4)

// CPU:
// - ( )
// - ( )
*unaligned_ptr = 42; //!
```

** **
```cpp
sizeof(char) = 1, alignment = 1
sizeof(short) = 2, alignment = 2
sizeof(int) = 4, alignment = 4
sizeof(double) = 8, alignment = 8
sizeof(Vec4) = 16, alignment = 16 ()
```
---
### (Alignment) (Part 4)

**False Sharing **
```cpp
//:
struct BadCounter {
std::atomic<int> counter1; // 1
std::atomic<int> counter2; // 2
}; // 8,

//:
struct GoodCounter {
alignas(64) std::atomic<int> counter1;
alignas(64) std::atomic<int> counter2;
}; // 64
```
---
### (Alignment) (Part 4)

** **
```cpp
// alignof
static_assert(alignof(Vec4) == 16);

// aligned_alloc
void* ptr = std::aligned_alloc(16, sizeof(Vec4) * 100);
```

---
layout: two-cols
---
## 2.3 (Part 1)




```cpp
namespace SemiconductorHMI::Benchmark {

template<typename Func>
auto MeasureTime(Func func, size_t iterations = 1000) {
auto start = std::chrono::high_resolution_clock::now();

for (size_t i = 0; i < iterations; ++i) {
func();
}

auto end = std::chrono::high_resolution_clock::now();
auto duration = std::chrono::duration_cast<
```
---
## 2.3 (Part 2)

```cpp
std::chrono::microseconds>(end - start);

return duration.count() / static_cast<double>(iterations);
}

//
void BenchmarkDataStructures() {
const size_t N = 10000;
std::vector<int> vec;
std::list<int> list;

//
```
---
## 2.3 (Part 3)

```cpp
auto vec_time = MeasureTime([&]() {
vec.clear();
for (size_t i = 0; i < N; ++i) {
vec.push_back(i);
}
});

//
auto list_time = MeasureTime([&]() {
list.clear();
for (size_t i = 0; i < N; ++i) {
list.push_back(i);
```
---
## 2.3 (Part 4) (Code Part 1/3)


```cpp
}

```cpp
//:
void BadBenchmark() {
auto time = MeasureTime([]() {
int sum = 0;
for (int i = 0; i < 1000; ++i) {
sum += i;
}
// sum
});
}
```
---
## 2.3 (Part 4) (Code Part 2/3)

```cpp

//: DoNotOptimize
void GoodBenchmark() {
int result = 0;
auto time = MeasureTime([&]() {
int sum = 0;
for (int i = 0; i < 1000; ++i) {
sum += i;
}
result = sum;
```
---
## 2.3 (Part 4) (Code Part 3/3)

```cpp
});

// result
volatile int sink = result;
(void)sink;
}
```


** (Warm-up)**
```cpp
---
layout: center
---

# **3. Advanced Memory Management**

## Custom Allocators, Memory Pools, Arena Allocation

---
layout: two-cols
---
## 3.1 (Memory Pool) (Part 1)




```cpp
namespace SemiconductorHMI {

template<size_t BlockSize, size_t BlockCount>
class MemoryPool {
private:
std::array<std::byte, BlockSize * BlockCount> memory;
std::array<bool, BlockCount> used;
size_t next_free = 0;

public:
MemoryPool() {
used.fill(false);
```
---
## 3.1 (Memory Pool) (Part 2)

```cpp
}

void* Allocate(size_t size) {
if (size > BlockSize) return nullptr;

//
for (size_t i = next_free; i < BlockCount; ++i) {
if (!used[i]) {
used[i] = true;
next_free = i + 1;
return &memory[i * BlockSize];
}
```
---
## 3.1 (Memory Pool) (Part 3)

```cpp
}

//
for (size_t i = 0; i < next_free; ++i) {
if (!used[i]) {
used[i] = true;
next_free = i + 1;
return &memory[i * BlockSize];
}
}

return nullptr; //
```
---
## 3.1 (Memory Pool) (Part 4)

```cpp
}

void Deallocate(void* ptr) {
if (!ptr) return;

auto* byte_ptr = static_cast<std::byte*>(ptr);
if (byte_ptr < memory.data() ||
byte_ptr >= memory.data() + memory.size()) {
return; //
}

size_t index = (byte_ptr - memory.data()) / BlockSize;
```
---
## 3.1 (Memory Pool) (Part 5)

```cpp
if (index < BlockCount) {
used[index] = false;
next_free = std::min(next_free, index);
}
}

size_t GetUsedCount() const {
return std::count(used.begin(), used.end(), true);
}

float GetUsageRatio() const {
return static_cast<float>(GetUsedCount()) / BlockCount;
```
---
## 3.1 (Memory Pool) (Part 6) (Code Part 1/2)


```cpp
}

```cpp
template<size_t BlockSize, size_t BlockCount>
class ThreadSafeMemoryPool {
private:
MemoryPool<BlockSize, BlockCount> pool;
std::mutex mutex;

public:
void* Allocate(size_t size) {
std::lock_guard lock(mutex);
return pool.Allocate(size);
```
---
## 3.1 (Memory Pool) (Part 6) (Code Part 2/2)

```cpp
}

void Deallocate(void* ptr) {
std::lock_guard lock(mutex);
pool.Deallocate(ptr);
}
};
```


---
layout: two-cols
---
## 3.2 (Arena Allocator) (Part 1)




```cpp
namespace SemiconductorHMI {

class ArenaAllocator {
private:
std::unique_ptr<std::byte[]> memory;
size_t capacity;
size_t offset = 0;

public:
explicit ArenaAllocator(size_t size)
: memory(std::make_unique<std::byte[]>(size))
, capacity(size)
```
---
## 3.2 (Arena Allocator) (Part 2)

```cpp
{}

void* Allocate(size_t size, size_t alignment = alignof(std::max_align_t)) {
//
size_t padding = 0;
size_t current = reinterpret_cast<uintptr_t>(memory.get() + offset);
size_t aligned = (current + alignment - 1) & ~(alignment - 1);
padding = aligned - current;

//
if (offset + padding + size > capacity) {
return nullptr; //
```
---
## 3.2 (Arena Allocator) (Part 3)

```cpp
}

void* ptr = memory.get() + offset + padding;
offset += padding + size;
return ptr;
}

// ( )
void Reset() {
offset = 0;
}

```
---
## 3.2 (Arena Allocator) (Part 4) (Code Part 1/4)


```cpp
size_t GetUsedMemory() const { return offset; }

```cpp
class FrameAllocator {
private:
ArenaAllocator allocator;

public:
FrameAllocator(): allocator(10 * 1024 * 1024) {} // 10MB

void BeginFrame() {
allocator.Reset(); //
}
```
---
## 3.2 (Arena Allocator) (Part 4) (Code Part 2/4)

```cpp

void* Allocate(size_t size) {
return allocator.Allocate(size);
}

// EndFrame
void EndFrame() {
//
printf("Frame memory used: %.2f MB\n",
allocator.GetUsedMemory() / (1024.0f * 1024.0f));
```
---
## 3.2 (Arena Allocator) (Part 4) (Code Part 3/4)

```cpp
}
};

//
FrameAllocator frame_alloc;

void RenderFrame() {
frame_alloc.BeginFrame();

//
```
---
## 3.2 (Arena Allocator) (Part 4) (Code Part 4/4)

```cpp
void* temp = frame_alloc.Allocate(1024);
//...

//!

frame_alloc.EndFrame(); //
}
```


****
- ** **:
---
layout: two-cols
---
## 3.3 Custom Allocator for STL (Part 1)




```cpp
namespace SemiconductorHMI {

template<typename T>
class PoolAllocator {
private:
static constexpr size_t POOL_SIZE = 10000;
static MemoryPool<sizeof(T), POOL_SIZE> pool;

public:
using value_type = T;

PoolAllocator() noexcept = default;
```
---
## 3.3 Custom Allocator for STL (Part 2)

```cpp

template<typename U>
PoolAllocator(const PoolAllocator<U>&) noexcept {}

T* allocate(size_t n) {
if (n == 1) {
return static_cast<T*>(pool.Allocate(sizeof(T)));
}
//
return static_cast<T*>(::operator new(n * sizeof(T)));
}

```
---
## 3.3 Custom Allocator for STL (Part 3)

```cpp
void deallocate(T* ptr, size_t n) noexcept {
if (n == 1) {
pool.Deallocate(ptr);
} else {
::operator delete(ptr);
}
}

template<typename U>
struct rebind {
using other = PoolAllocator<U>;
};
```
---
## 3.3 Custom Allocator for STL (Part 4) (Code Part 1/3)


```cpp
};

```cpp
// vector
std::vector<Particle> normal_particles;

// vector
std::vector<Particle, PoolAllocator<Particle>>
pool_particles;

//
void BenchmarkVectors() {
const size_t N = 10000;
```
---
## 3.3 Custom Allocator for STL (Part 4) (Code Part 2/3)

```cpp

auto normal_time = MeasureTime([&]() {
std::vector<Particle> vec;
for (size_t i = 0; i < N; ++i) {
vec.emplace_back();
}
});

auto pool_time = MeasureTime([&]() {
std::vector<Particle, PoolAllocator<Particle>> vec;
```
---
## 3.3 Custom Allocator for STL (Part 4) (Code Part 3/3)

```cpp
for (size_t i = 0; i < N; ++i) {
vec.emplace_back();
}
});

printf("Normal: %.2f μs\n", normal_time);
printf("Pool: %.2f μs\n", pool_time);
}
```


** **
```cpp
---
layout: center
---

# **4. C++20 Modern Features**

## Ranges, Coroutines, Modules

---
layout: two-cols
---
## 4.1 Ranges (Part 1)




```cpp
#include <ranges>
#include <vector>
#include <algorithm>

namespace SemiconductorHMI {

struct Sensor {
int id;
float temperature;
bool online;
};

```
---
## 4.1 Ranges (Part 2)

```cpp
void ProcessSensors(const std::vector<Sensor>& sensors) {
namespace views = std::ranges::views;

// C++17 ()
std::vector<float> temps_old;
for (const auto& sensor: sensors) {
if (sensor.online && sensor.temperature > 25.0f) {
temps_old.push_back(sensor.temperature);
}
}
std::sort(temps_old.begin(), temps_old.end());

```
---
## 4.1 Ranges (Part 3)

```cpp
// C++20 Ranges ()
auto temps = sensors
| views::filter([](const Sensor& s) {
return s.online && s.temperature > 25.0f;
})
| views::transform([](const Sensor& s) {
return s.temperature;
});

std::vector<float> sorted_temps(temps.begin(), temps.end());
std::ranges::sort(sorted_temps);

```
---
## 4.1 Ranges (Part 4) (Code Part 1/3)


```cpp
// (lazy evaluation)

```cpp
//
std::vector<Sensor> sensors(1000000);

// C++17: 3 vector
auto result_old = [&]() {
std::vector<Sensor> filtered;
std::copy_if(sensors.begin(), sensors.end(),
std::back_inserter(filtered),
[](auto& s) { return s.online; });

```
---
## 4.1 Ranges (Part 4) (Code Part 2/3)

```cpp
std::vector<float> temps;
std::transform(filtered.begin(), filtered.end(),
std::back_inserter(temps),
[](auto& s) { return s.temperature; });
return temps;
}();

// C++20:, view
auto result_new = sensors
| views::filter([](auto& s) { return s.online; })
```
---
## 4.1 Ranges (Part 4) (Code Part 3/3)

```cpp
| views::transform([](auto& s) { return s.temperature; });
```


---
layout: two-cols
---
### Ranges (Part 1)



```cpp
namespace SemiconductorHMI {

void AdvancedRangesExample() {
namespace views = std::ranges::views;

std::vector<int> nums = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

// take, drop
auto first_five = nums | views::take(5);
// [1, 2, 3, 4, 5]

auto skip_five = nums | views::drop(5);
```
---
### Ranges (Part 2)

```cpp
// [6, 7, 8, 9, 10]

// split
std::string csv = "sensor1,25.3,sensor2,26.1,sensor3,24.8";
auto tokens = csv | views::split(',');
// ["sensor1", "25.3", "sensor2", "26.1", "sensor3", "24.8"]

// join
std::vector<std::vector<int>> nested = {{1,2}, {3,4}, {5,6}};
auto flattened = nested | views::join;
// [1, 2, 3, 4, 5, 6]

```
---
### Ranges (Part 3)

```cpp
// zip (C++23)
std::vector<std::string> names = {"Sensor1", "Sensor2", "Sensor3"};
std::vector<float> temps = {25.3f, 26.1f, 24.8f};

for (auto [name, temp]: views::zip(names, temps)) {
printf("%s: %.1f°C\n", name.c_str(), temp);
}

// chunk
auto chunks = nums | views::chunk(3);
// [[1,2,3], [4,5,6], [7,8,9], [10]]

```
---
### Ranges (Part 4) (Code Part 1/4)


```cpp
for (auto chunk: chunks) {

```cpp
struct SensorReading {
int sensor_id;
float value;
uint64_t timestamp;
bool valid;
};

class SensorDataProcessor {
public:
auto GetValidHighTemperatures(
```
---
### Ranges (Part 4) (Code Part 2/4)

```cpp
const std::vector<SensorReading>& readings,
float threshold)
{
namespace views = std::ranges::views;

return readings
| views::filter([](const auto& r) { return r.valid; })
| views::filter([threshold](const auto& r) {
return r.value > threshold;
})
```
---
### Ranges (Part 4) (Code Part 3/4)

```cpp
| views::transform([](const auto& r) {
return std::make_pair(r.sensor_id, r.value);
});
}

//
void Example(const std::vector<SensorReading>& readings) {
for (auto [id, temp]: GetValidHighTemperatures(readings, 80.0f)) {
printf("Sensor %d: %.1f°C (HIGH!)\n", id, temp);
}
```
---
### Ranges (Part 4) (Code Part 4/4)

```cpp
}
};
```


** **
```cpp
---
layout: two-cols
---
## 4.2 Coroutines () (Part 1)




```cpp
#include <coroutine>
#include <optional>

namespace SemiconductorHMI {

// Generator
template<typename T>
struct Generator {
struct promise_type {
T current_value;

Generator get_return_object() {
```
---
## 4.2 Coroutines () (Part 2)

```cpp
return Generator{
std::coroutine_handle<promise_type>::from_promise(*this)
};
}

std::suspend_always initial_suspend() { return {}; }
std::suspend_always final_suspend() noexcept { return {}; }

std::suspend_always yield_value(T value) {
current_value = value;
return {};
}
```
---
## 4.2 Coroutines () (Part 3)

```cpp

void return_void() {}
void unhandled_exception() { std::terminate(); }
};

std::coroutine_handle<promise_type> handle;

Generator(std::coroutine_handle<promise_type> h): handle(h) {}
~Generator() { if (handle) handle.destroy(); }

bool next() {
handle.resume();
```
---
## 4.2 Coroutines () (Part 4) (Code Part 1/4)


```cpp
return!handle.done();

```cpp
Generator<SensorReading> ReadSensorStream(int sensor_id) {
while (true) {
//
float value = ReadFromHardware(sensor_id);
uint64_t timestamp = GetCurrentTime();

co_yield SensorReading{
sensor_id,
value,
timestamp,
```
---
## 4.2 Coroutines () (Part 4) (Code Part 2/4)

```cpp
true
};

// 100ms ( )
std::this_thread::sleep_for(
std::chrono::milliseconds(100)
);
}
}

```
---
## 4.2 Coroutines () (Part 4) (Code Part 3/4)

```cpp
//
void MonitorSensor() {
auto stream = ReadSensorStream(1);

for (int i = 0; i < 10; ++i) {
if (stream.next()) {
auto reading = stream.value();
printf("Sensor %d: %.2f at %llu\n",
reading.sensor_id,
reading.value,
```
---
## 4.2 Coroutines () (Part 4) (Code Part 4/4)

```cpp
reading.timestamp);
}
}
}
```


---
layout: two-cols
---
### Task ( ) (Part 1)



```cpp
namespace SemiconductorHMI {

template<typename T>
struct Task {
struct promise_type {
T value;
std::exception_ptr exception;

Task get_return_object() {
return Task{
std::coroutine_handle<promise_type>::from_promise(*this)
};
```
---
### Task ( ) (Part 2)

```cpp
}

std::suspend_never initial_suspend() { return {}; }
std::suspend_always final_suspend() noexcept { return {}; }

void return_value(T v) { value = v; }
void unhandled_exception() {
exception = std::current_exception();
}
};

std::coroutine_handle<promise_type> handle;
```
---
### Task ( ) (Part 3)

```cpp

Task(std::coroutine_handle<promise_type> h): handle(h) {}
~Task() { if (handle) handle.destroy(); }

T get() {
if (!handle.done()) {
handle.resume();
}
if (handle.promise().exception) {
std::rethrow_exception(handle.promise().exception);
}
return handle.promise().value;
```
---
### Task ( ) (Part 4)

```cpp
}
};

//
Task<float> ReadSensorAsync(int sensor_id) {
// ()
std::this_thread::sleep_for(std::chrono::milliseconds(100));

float value = static_cast<float>(sensor_id) * 10.5f;
co_return value;
}

```
---
### Task ( ) (Part 5) (Code Part 1/3)


```cpp
}

```cpp
Task<std::vector<float>> ReadMultipleSensorsAsync() {
std::vector<float> results;

//
// ( )
for (int i = 1; i <= 5; ++i) {
float value = co_await ReadSensorAsync(i);
results.push_back(value);
}

```
---
### Task ( ) (Part 5) (Code Part 2/3)

```cpp
co_return results;
}

//
void Example() {
auto task = ReadMultipleSensorsAsync();
auto results = task.get();

for (float value: results) {
printf("%.1f\n", value);
```
---
### Task ( ) (Part 5) (Code Part 3/3)

```cpp
}
}
```


** **
```cpp
---
layout: two-cols
---
## 4.3 Modules (C++20) (Part 1)




```cpp
// sensor_module.ixx ( )
export module sensor;

import <vector>;
import <string>;

// export:
export namespace SemiconductorHMI {

class Sensor {
public:
Sensor(int id, std::string name);
```
---
## 4.3 Modules (C++20) (Part 2)

```cpp

float Read() const;
void Calibrate();

private:
int id_;
std::string name_;
float value_ = 0.0f;
};

// export
export template<typename T>
```
---
## 4.3 Modules (C++20) (Part 3)

```cpp
T Clamp(T value, T min, T max) {
if (value < min) return min;
if (value > max) return max;
return value;
}

} // namespace SemiconductorHMI

// (export )
namespace {

float ReadFromHardware(int sensor_id) {
```
---
## 4.3 Modules (C++20) (Part 4) (Code Part 1/2)


```cpp
// ( )

```cpp
// main.cpp
import sensor; //
import <iostream>;

int main() {
SemiconductorHMI::Sensor temp_sensor(1, "Temperature");

float value = temp_sensor.Read();
std::cout << "Temperature: " << value << "\n";

```
---
## 4.3 Modules (C++20) (Part 4) (Code Part 2/2)

```cpp
// Clamp
float clamped = SemiconductorHMI::Clamp(value, 20.0f, 80.0f);
std::cout << "Clamped: " << clamped << "\n";

return 0;
}
```


** vs **

---
layout: two-cols
---
### (Part 1)



```cpp
// equipment_system.ixx
export module equipment_system;

import <memory>;
import <vector>;
import <string>;
import <unordered_map>;

export namespace SemiconductorHMI {

// Equipment
export class IEquipment {
```
---
### (Part 2)

```cpp
public:
virtual ~IEquipment() = default;
virtual float GetValue() const = 0;
virtual void SetValue(float value) = 0;
virtual std::string GetStatus() const = 0;
};

// Equipment Manager
export class EquipmentManager {
private:
std::unordered_map<int, std::unique_ptr<IEquipment>> equipment_map;

```
---
### (Part 3)

```cpp
public:
void RegisterEquipment(int id, std::unique_ptr<IEquipment> equipment) {
equipment_map[id] = std::move(equipment);
}

IEquipment* GetEquipment(int id) {
auto it = equipment_map.find(id);
return it!= equipment_map.end()? it->second.get(): nullptr;
}

std::vector<int> GetAllEquipmentIDs() const {
std::vector<int> ids;
```
---
### (Part 4)

```cpp
for (const auto& [id, _]: equipment_map) {
ids.push_back(id);
}
return ids;
}

size_t GetCount() const {
return equipment_map.size();
}
};

//
```
---
### (Part 5) (Code Part 1/4)


```cpp
export std::unique_ptr<IEquipment> CreateTemperatureSensor(int id);

```cpp
// equipment_system.cpp
module equipment_system;

import <sstream>;

namespace SemiconductorHMI {

// (export )
class TemperatureSensor: public IEquipment {
private:
```
---
### (Part 5) (Code Part 2/4)

```cpp
int id_;
float temperature_ = 25.0f;

public:
explicit TemperatureSensor(int id): id_(id) {}

float GetValue() const override {
return temperature_;
}

```
---
### (Part 5) (Code Part 3/4)

```cpp
void SetValue(float value) override {
temperature_ = value;
}

std::string GetStatus() const override {
std::ostringstream oss;
oss << "Sensor " << id_ << ": " << temperature_ << "°C";
return oss.str();
}
};
```
---
### (Part 5) (Code Part 4/4)

```cpp

//
std::unique_ptr<IEquipment> CreateTemperatureSensor(int id) {
return std::make_unique<TemperatureSensor>(id);
}

} // namespace SemiconductorHMI
```


** **
```cpp
---
layout: center
---

# **Summary**

## C++ Advanced Patterns

---

# Week 11 핵심 정리

## 1. 템플릿 메타프로그래밍

- **함수/클래스 템플릿**: 타입 독립적 코드, 컴파일 타임 생성
- **SFINAE**: `std::enable_if`로 조건부 타입 선택
- **C++20 Concepts**: 명시적 타입 제약
- 반도체 HMI: 센서별 자동 처리, 위젯 제네릭 생성

## 2. 성능 최적화

- **프로파일링**: `ScopedTimer`로 병목 측정
- **메모리 레이아웃**:
  - SoA (Structure of Arrays) vs AoS (Array of Structures)
  - 정렬(alignment)로 SIMD 가속
- **벤치마킹 기법**: 통계적 측정, 반복 실행

## 3. 고급 메모리 관리

- **메모리 풀**: 할당/해제 오버헤드 제거
- **Arena 할당기**: 프레임 단위 일괄 해제
- **STL 커스텀 할당자**: 컨테이너 최적화

## 4. C++20 모던 기능

- **Ranges**: 파이프라인 연산, Lazy evaluation
- **Coroutines**: 비동기 I/O, 제너레이터
- **Modules**: 컴파일 속도 향상, 명시적 API

---

# 반도체 HMI 적용 전략 (1/2)

## 언제 이 기법들을 사용하는가?

### 템플릿 메타프로그래밍
- **사용 시기**: 다양한 센서 타입 처리, 위젯 자동 생성
- **장점**: 타입 안전성, 컴파일 타임 최적화

### 성능 최적화
- **캐시 친화적 설계**: 센서 데이터 배열 처리
- **메모리 정렬**: SIMD 연산으로 4배 가속
- **SoA 패턴**: 벡터 연산 (온도, 압력 배열)

### 메모리 관리
- **메모리 풀**: 센서 객체 빈번한 생성/삭제 (장비 가동 중)
- **Arena 할당기**: 프레임 버퍼 (60 FPS 렌더링)
- **커스텀 할당자**: `new`/`delete` 오버헤드 제거

---

# 반도체 HMI 적용 전략 (2/2)

### 모던 C++ 기능
- **Ranges**: 센서 필터링/변환 파이프라인
- **Coroutines**: 비동기 I/O, 센서 데이터 스트림
- **Modules**: 빌드 시간 단축 (대규모 HMI 프로젝트)

## 실전 HMI 시나리오

| 시나리오 | 적용 기법 |
|------|----------|
| 센서 데이터 수집 | Coroutines (Generator) |
| 실시간 차트 렌더링 | SoA + Ranges |
| 웨이퍼 맵 시각화 | 메모리 풀 + Arena |
| 다중 장비 통합 | Concepts + Modules |

---
layout: end
---

# Week 11

##: ImGUI Advanced Integration

** **:
- Template Metaprogramming
- - - C++20

**!**
