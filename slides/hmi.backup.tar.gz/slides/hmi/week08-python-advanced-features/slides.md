# Week 8: Python PySide6 고급 기능 및 커스텀 UI 컴포넌트

## 🎯 **학습 목표**
- **커스텀 위젯**: 전문적인 반도체 HMI를 위한 고급 UI 컴포넌트 개발
- **3D 시각화**: OpenGL 기반 실시간 3D 렌더링 및 장비 모델링
- **고급 아키텍처**: Model-View 패턴 고도화 및 플러그인 시스템 구축
- **UI/UX 최적화**: 현대적 스타일링 및 국제화 지원

---

## 커스텀 위젯 개발

### 🎨 커스텀 위젯의 필요성
- **표준 위젯 한계**: 산업용 HMI 요구사항에 부족한 기본 컴포넌트
- **브랜딩 일관성**: 회사/제품 고유의 디자인 언어 구현
- **특수 기능**: 반도체 장비 특화 인터페이스 요소
- **성능 최적화**: 특정 용도에 최적화된 렌더링

### 🏗️ 위젯 개발 패턴
1. **Composition Pattern**: 기존 위젯 조합
2. **Inheritance Pattern**: QWidget 직접 상속
3. **Custom Painting**: QPainter 활용 완전 커스텀
4. **Hybrid Approach**: 혼합 방식

---

## QPainter 기반 산업용 게이지

### 핵심 구현 예제

```python
class IndustrialGauge(QWidget):
    """산업용 계기판 위젯"""

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 배경, 눈금, 바늘 순서로 그리기
        self.draw_background(painter)
        self.draw_scale(painter)
        self.draw_needle(painter)
```

### 주요 기능
- **실시간 데이터 반영**: 센서값에 따른 바늘 위치 변경
- **임계값 표시**: 경고/위험 영역 색상 구분
- **부드러운 애니메이션**: QPropertyAnimation 활용

---

## 3D 시각화 및 OpenGL 통합
        if self.value >= self.critical_threshold:
            needle_color = self.colors['critical']
        elif self.value >= self.warning_threshold:
            needle_color = self.colors['warning']
        else:
            needle_color = self.colors['normal']

        painter.setPen(QPen(needle_color, 4))

        # 바늘 그리기
        needle_length = radius - 30
        needle_x = center.x() + needle_length * math.cos(math.radians(current_angle))
        needle_y = center.y() + needle_length * math.sin(math.radians(current_angle))

        painter.drawLine(center, QPoint(int(needle_x), int(needle_y)))

        # 중심점 그리기
        painter.setBrush(QBrush(needle_color))
        painter.drawEllipse(center, 8, 8)

        painter.restore()

    def draw_text(self, painter, rect):
        """텍스트 그리기"""
        painter.setPen(QPen(Qt.white))
        painter.setFont(painter.font())

        # 현재 값 표시
        text_rect = QRect(rect.x(), rect.bottom() - 40, rect.width(), 30)
        painter.drawText(text_rect, Qt.AlignCenter, f"{self.value:.1f}")

        # 단위 표시
        unit_rect = QRect(rect.x(), rect.bottom() - 20, rect.width(), 20)
        painter.drawText(unit_rect, Qt.AlignCenter, "°C")

    def setValue(self, value):
        """값 설정"""
        self.value = max(self.min_value, min(self.max_value, value))
        self.update()

    def setRange(self, min_val, max_val):
        """범위 설정"""
        self.min_value = min_val
        self.max_value = max_val
        self.update()

    def setThresholds(self, warning, critical):
        """임계값 설정"""
        self.warning_threshold = warning
        self.critical_threshold = critical
        self.update()
```

##### **1.1.2 상태 인디케이터 위젯**

<div class="code-block">

```python
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel
from PySide6.QtGui import QPainter, QBrush, QPen, QFont
from PySide6.QtCore import Qt, QRect, QTimer, Signal
from enum import Enum

class EquipmentStatus(Enum):
    """장비 상태 열거형"""
    OFFLINE = "offline"
    IDLE = "idle"
    RUNNING = "running"
    WARNING = "warning"
    ERROR = "error"
    MAINTENANCE = "maintenance"

class StatusIndicator(QWidget):
    """상태 인디케이터 위젯"""

    status_changed = Signal(EquipmentStatus)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(120, 60)

        self.status = EquipmentStatus.OFFLINE
        self.is_blinking = False
        self.blink_state = True

        # 상태별 색상 매핑
        self.status_colors = {
            EquipmentStatus.OFFLINE: Qt.gray,
            EquipmentStatus.IDLE: Qt.blue,
            EquipmentStatus.RUNNING: Qt.green,
            EquipmentStatus.WARNING: Qt.yellow,
            EquipmentStatus.ERROR: Qt.red,
            EquipmentStatus.MAINTENANCE: Qt.magenta
        }

        # 깜빡임 타이머
        self.blink_timer = QTimer()
        self.blink_timer.timeout.connect(self.toggle_blink)

        # 상태별 깜빡임 설정
        self.blinking_statuses = {EquipmentStatus.WARNING, EquipmentStatus.ERROR}

    def paintEvent(self, event):
        """커스텀 페인팅"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = self.rect()

        # 배경 그리기
        painter.setPen(QPen(Qt.darkGray, 2))
        painter.setBrush(QBrush(Qt.black))
        painter.drawRoundedRect(rect.adjusted(2, 2, -2, -2), 8, 8)

        # 상태 LED 그리기
        led_rect = QRect(10, 10, 30, 30)
        self.draw_led(painter, led_rect)

        # 텍스트 그리기
        text_rect = QRect(50, 10, 60, 40)
        self.draw_status_text(painter, text_rect)

    def draw_led(self, painter, rect):
        """LED 그리기"""
        color = self.status_colors[self.status]

        # 깜빡임 처리
        if self.is_blinking and not self.blink_state:
            color = Qt.darkGray

        # LED 외곽
        painter.setPen(QPen(Qt.white, 1))
        painter.setBrush(QBrush(color))
        painter.drawEllipse(rect)

        # LED 하이라이트
        highlight_rect = QRect(rect.x() + 3, rect.y() + 3, 8, 8)
        painter.setBrush(QBrush(Qt.white))
        painter.drawEllipse(highlight_rect)

    def draw_status_text(self, painter, rect):
        """상태 텍스트 그리기"""
        painter.setPen(QPen(Qt.white))
        painter.setFont(QFont("Arial", 9, QFont.Bold))

        status_text = self.status.value.upper()
        painter.drawText(rect, Qt.AlignCenter, status_text)

    def set_status(self, status: EquipmentStatus):
        """상태 설정"""
        if self.status != status:
            self.status = status

            # 깜빡임 제어
            if status in self.blinking_statuses:
                self.start_blinking()
            else:
                self.stop_blinking()

            self.status_changed.emit(status)
            self.update()

    def start_blinking(self):
        """깜빡임 시작"""
        self.is_blinking = True
        self.blink_timer.start(500)  # 500ms 간격

    def stop_blinking(self):
        """깜빡임 중지"""
        self.is_blinking = False
        self.blink_timer.stop()
        self.blink_state = True
        self.update()

    def toggle_blink(self):
        """깜빡임 토글"""
        self.blink_state = not self.blink_state
        self.update()

class EquipmentPanel(QWidget):
    """장비 패널 위젯"""

    def __init__(self, equipment_name, parent=None):
        super().__init__(parent)
        self.equipment_name = equipment_name
        self.setup_ui()

    def setup_ui(self):
        """UI 설정"""
        layout = QVBoxLayout(self)

        # 제목
        title_label = QLabel(self.equipment_name)
        title_label.setFont(QFont("Arial", 12, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(title_label)

        # 상태 인디케이터들
        indicators_layout = QHBoxLayout()

        self.power_indicator = StatusIndicator()
        self.process_indicator = StatusIndicator()
        self.alarm_indicator = StatusIndicator()

        indicators_layout.addWidget(self.create_labeled_indicator("전원", self.power_indicator))
        indicators_layout.addWidget(self.create_labeled_indicator("프로세스", self.process_indicator))
        indicators_layout.addWidget(self.create_labeled_indicator("알람", self.alarm_indicator))

        layout.addLayout(indicators_layout)

        # 초기 상태 설정
        self.power_indicator.set_status(EquipmentStatus.IDLE)
        self.process_indicator.set_status(EquipmentStatus.OFFLINE)
        self.alarm_indicator.set_status(EquipmentStatus.OFFLINE)

    def create_labeled_indicator(self, label_text, indicator):
        """라벨이 있는 인디케이터 생성"""
        widget = QWidget()
        layout = QVBoxLayout(widget)

        label = QLabel(label_text)
        label.setAlignment(Qt.AlignCenter)
        label.setFont(QFont("Arial", 8))

        layout.addWidget(label)
        layout.addWidget(indicator)

        return widget

    def update_equipment_status(self, power_on, process_running, has_alarm):
        """장비 상태 업데이트"""
        # 전원 상태
        if power_on:
            self.power_indicator.set_status(EquipmentStatus.RUNNING)
        else:
            self.power_indicator.set_status(EquipmentStatus.OFFLINE)

        # 프로세스 상태
        if power_on and process_running:
            self.process_indicator.set_status(EquipmentStatus.RUNNING)
        elif power_on:
            self.process_indicator.set_status(EquipmentStatus.IDLE)
        else:
            self.process_indicator.set_status(EquipmentStatus.OFFLINE)

        # 알람 상태
        if has_alarm:
            self.alarm_indicator.set_status(EquipmentStatus.ERROR)
        else:
            self.alarm_indicator.set_status(EquipmentStatus.OFFLINE)
```

</div>

#### **1.2 Model-View 아키텍처 고도화**

##### **1.2.1 고성능 데이터 모델**

<div class="architecture-section">

**🏗️ 대용량 데이터 처리를 위한 Model-View 최적화**:

```python
from PySide6.QtCore import QAbstractTableModel, Qt, QModelIndex, QVariant, Signal
from PySide6.QtGui import QColor, QFont
from datetime import datetime
import numpy as np
from typing import List, Any, Optional

class HighPerformanceDataModel(QAbstractTableModel):
    """고성능 데이터 테이블 모델"""

    data_changed_signal = Signal(int, int)  # row, column

    def __init__(self, parent=None):
        super().__init__(parent)

        # 데이터 저장소 (NumPy 배열 사용으로 성능 최적화)
        self.data_buffer = np.empty((0, 8), dtype=object)  # 초기 빈 배열
        self.max_rows = 10000  # 최대 행 수
        self.current_row_count = 0

        # 헤더 정의
        self.headers = [
            "Timestamp", "Temperature", "Pressure", "Flow Rate",
            "RF Power", "Recipe Step", "Status", "Alarms"
        ]

        # 컬럼별 데이터 타입
        self.column_types = [
            datetime, float, float, float, float, int, str, str
        ]

        # 시각적 포맷팅을 위한 설정
        self.warning_thresholds = {
            1: (300, 400),  # Temperature
            2: (1.0, 10.0), # Pressure
            3: (50, 200),   # Flow Rate
            4: (200, 500)   # RF Power
        }

    def rowCount(self, parent=QModelIndex()):
        """행 수 반환"""
        return self.current_row_count

    def columnCount(self, parent=QModelIndex()):
        """열 수 반환"""
        return len(self.headers)

    def data(self, index, role=Qt.DisplayRole):
        """데이터 반환"""
        if not index.isValid():
            return QVariant()

        row = index.row()
        col = index.column()

        if row >= self.current_row_count or col >= len(self.headers):
            return QVariant()

        value = self.data_buffer[row, col]

        if role == Qt.DisplayRole:
            return self.format_display_value(value, col)
        elif role == Qt.BackgroundRole:
            return self.get_background_color(value, col)
        elif role == Qt.TextAlignmentRole:
            return Qt.AlignCenter if col > 0 else Qt.AlignLeft
        elif role == Qt.FontRole:
            if col == 6:  # Status column
                font = QFont()
                font.setBold(True)
                return font

        return QVariant()

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        """헤더 데이터 반환"""
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return self.headers[section]
        elif orientation == Qt.Vertical and role == Qt.DisplayRole:
            return str(section + 1)

        return QVariant()

    def format_display_value(self, value, column):
        """표시값 포맷팅"""
        if value is None:
            return ""

        if column == 0:  # Timestamp
            if isinstance(value, datetime):
                return value.strftime("%H:%M:%S.%f")[:-3]
        elif column in [1, 2, 3, 4]:  # Numeric columns
            if isinstance(value, (int, float)):
                if column == 1:  # Temperature
                    return f"{value:.1f}°C"
                elif column == 2:  # Pressure
                    return f"{value:.2f}Torr"
                elif column == 3:  # Flow Rate
                    return f"{value:.1f}sccm"
                elif column == 4:  # RF Power
                    return f"{value:.0f}W"
        elif column == 5:  # Recipe Step
            return f"Step {value}" if value else "N/A"

        return str(value)

    def get_background_color(self, value, column):
        """배경색 결정"""
        if column in self.warning_thresholds and isinstance(value, (int, float)):
            min_val, max_val = self.warning_thresholds[column]

            if value < min_val or value > max_val:
                return QColor(255, 200, 200)  # 연한 빨강
            elif abs(value - min_val) < (max_val - min_val) * 0.1 or \
                 abs(value - max_val) < (max_val - min_val) * 0.1:
                return QColor(255, 255, 200)  # 연한 노랑

        return QVariant()

    def add_data_point(self, data_point: dict):
        """데이터 포인트 추가 (최적화된 배치 삽입)"""
        # 배열 크기 확장 필요 시
        if self.current_row_count >= self.data_buffer.shape[0]:
            self.expand_buffer()

        # 최대 행 수 제한
        if self.current_row_count >= self.max_rows:
            self.remove_oldest_rows(1000)  # 1000개 행 제거

        # 데이터 변환 및 삽입
        row_data = [
            data_point.get('timestamp', datetime.now()),
            data_point.get('chamber_temperature', 0.0),
            data_point.get('chamber_pressure', 0.0),
            data_point.get('gas_flow_rate', 0.0),
            data_point.get('rf_power', 0.0),
            data_point.get('recipe_step', 0),
            data_point.get('status', 'Unknown'),
            data_point.get('alarms', '')
        ]

        # 행 삽입 시작
        self.beginInsertRows(QModelIndex(), self.current_row_count, self.current_row_count)

        # 데이터 저장
        self.data_buffer[self.current_row_count] = row_data
        self.current_row_count += 1

        # 행 삽입 완료
        self.endInsertRows()

        # 시그널 발송
        self.data_changed_signal.emit(self.current_row_count - 1, -1)

    def add_data_batch(self, data_points: List[dict]):
        """배치 데이터 추가 (성능 최적화)"""
        if not data_points:
            return

        batch_size = len(data_points)

        # 필요한 공간 확보
        while self.current_row_count + batch_size > self.data_buffer.shape[0]:
            self.expand_buffer()

        # 최대 행 수 제한
        if self.current_row_count + batch_size > self.max_rows:
            remove_count = (self.current_row_count + batch_size) - self.max_rows + 1000
            self.remove_oldest_rows(remove_count)

        # 배치 삽입 시작
        start_row = self.current_row_count
        end_row = start_row + batch_size - 1

        self.beginInsertRows(QModelIndex(), start_row, end_row)

        # 배치 데이터 변환 및 저장
        for i, data_point in enumerate(data_points):
            row_data = [
                data_point.get('timestamp', datetime.now()),
                data_point.get('chamber_temperature', 0.0),
                data_point.get('chamber_pressure', 0.0),
                data_point.get('gas_flow_rate', 0.0),
                data_point.get('rf_power', 0.0),
                data_point.get('recipe_step', 0),
                data_point.get('status', 'Unknown'),
                data_point.get('alarms', '')
            ]
            self.data_buffer[self.current_row_count + i] = row_data

        self.current_row_count += batch_size

        # 배치 삽입 완료
        self.endInsertRows()

    def expand_buffer(self):
        """버퍼 크기 확장"""
        current_size = self.data_buffer.shape[0]
        new_size = max(1000, current_size * 2)  # 최소 1000, 또는 2배로 확장

        new_buffer = np.empty((new_size, self.data_buffer.shape[1]), dtype=object)
        new_buffer[:current_size] = self.data_buffer
        self.data_buffer = new_buffer

    def remove_oldest_rows(self, count):
        """오래된 행 제거"""
        if count >= self.current_row_count:
            self.clear_data()
            return

        # 행 제거 시작
        self.beginRemoveRows(QModelIndex(), 0, count - 1)

        # 데이터 이동
        remaining_count = self.current_row_count - count
        self.data_buffer[:remaining_count] = self.data_buffer[count:self.current_row_count]
        self.current_row_count = remaining_count

        # 행 제거 완료
        self.endRemoveRows()

    def clear_data(self):
        """모든 데이터 클리어"""
        if self.current_row_count == 0:
            return

        self.beginRemoveRows(QModelIndex(), 0, self.current_row_count - 1)
        self.current_row_count = 0
        self.endRemoveRows()

    def get_data_range(self, start_row, end_row):
        """데이터 범위 반환"""
        if start_row < 0 or end_row >= self.current_row_count:
            return []

        return self.data_buffer[start_row:end_row + 1].tolist()

    def export_to_dict_list(self):
        """딕셔너리 리스트로 내보내기"""
        result = []
        for row in range(self.current_row_count):
            row_dict = {}
            for col, header in enumerate(self.headers):
                row_dict[header] = self.data_buffer[row, col]
            result.append(row_dict)
        return result
```

</div>

#### **1.3 3D 시각화 및 그래픽스**

##### **1.3.1 OpenGL 기반 3D 렌더링**

<div class="graphics-section">

**🎮 3D 시각화의 장점**:
- **직관적 표현**: 복잡한 장비 구조의 3차원적 이해
- **실시간 모니터링**: 장비 상태의 시각적 피드백
- **공간적 관계**: 센서 위치 및 프로세스 흐름 표현
- **몰입감**: 사용자 경험 향상

```python
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtOpenGL import QOpenGLShaderProgram, QOpenGLBuffer
from PySide6.QtGui import QMatrix4x4, QVector3D, QQuaternion
from PySide6.QtCore import QTimer, Signal
import numpy as np
from OpenGL.GL import *
import math

class Equipment3DView(QOpenGLWidget):
    """3D 장비 시각화 위젯"""

    equipment_clicked = Signal(str)  # 장비 부품 클릭 시그널

    def __init__(self, parent=None):
        super().__init__(parent)

        # 3D 속성
        self.rotation_x = 15.0
        self.rotation_y = 45.0
        self.zoom = 1.0

        # 마우스 상호작용
        self.last_mouse_pos = None
        self.mouse_buttons = 0

        # 3D 모델 데이터
        self.equipment_models = {}
        self.load_equipment_models()

        # 애니메이션 타이머
        self.animation_timer = QTimer()
        self.animation_timer.timeout.connect(self.animate)
        self.animation_timer.start(16)  # 60 FPS

        # 센서 데이터 시각화
        self.sensor_data = {}
        self.temperature_color_map = {
            'cold': (0.0, 0.0, 1.0),   # 파랑
            'normal': (0.0, 1.0, 0.0), # 녹색
            'hot': (1.0, 1.0, 0.0),    # 노랑
            'critical': (1.0, 0.0, 0.0) # 빨강
        }

    def initializeGL(self):
        """OpenGL 초기화"""
        # 깊이 테스트 활성화
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LESS)

        # 뒷면 제거
        glEnable(GL_CULL_FACE)
        glCullFace(GL_BACK)

        # 조명 설정
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)

        # 조명 속성 설정
        light_position = [2.0, 2.0, 2.0, 1.0]
        light_ambient = [0.2, 0.2, 0.2, 1.0]
        light_diffuse = [0.8, 0.8, 0.8, 1.0]
        light_specular = [1.0, 1.0, 1.0, 1.0]

        glLightfv(GL_LIGHT0, GL_POSITION, light_position)
        glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient)
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse)
        glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular)

        # 배경색 설정
        glClearColor(0.1, 0.1, 0.2, 1.0)

    def resizeGL(self, width, height):
        """뷰포트 크기 변경"""
        glViewport(0, 0, width, height)

        # 투영 행렬 설정
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()

        aspect_ratio = width / height if height != 0 else 1
        fov = 45.0
        near_plane = 0.1
        far_plane = 100.0

        # 원근 투영
        f = 1.0 / math.tan(math.radians(fov) / 2.0)
        glFrustum(-aspect_ratio / f, aspect_ratio / f, -1.0 / f, 1.0 / f, near_plane, far_plane)

    def paintGL(self):
        """3D 렌더링"""
        # 화면 클리어
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        # 모델뷰 행렬 설정
        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

        # 카메라 위치 설정
        glTranslatef(0.0, 0.0, -5.0 * self.zoom)
        glRotatef(self.rotation_x, 1.0, 0.0, 0.0)
        glRotatef(self.rotation_y, 0.0, 1.0, 0.0)

        # 3D 모델 렌더링
        self.render_equipment()

        # 센서 데이터 시각화
        self.render_sensors()

        # 좌표축 표시
        self.render_axes()

    def render_equipment(self):
        """장비 모델 렌더링"""
        # 챔버 렌더링
        self.render_chamber()

        # 가스 라인 렌더링
        self.render_gas_lines()

        # 센서 위치 렌더링
        self.render_sensor_positions()

    def render_chamber(self):
        """반응 챔버 렌더링"""
        glPushMatrix()

        # 재질 속성 설정
        material_ambient = [0.2, 0.2, 0.3, 1.0]
        material_diffuse = [0.3, 0.3, 0.5, 1.0]
        material_specular = [0.8, 0.8, 0.8, 1.0]
        material_shininess = [50.0]

        glMaterialfv(GL_FRONT, GL_AMBIENT, material_ambient)
        glMaterialfv(GL_FRONT, GL_DIFFUSE, material_diffuse)
        glMaterialfv(GL_FRONT, GL_SPECULAR, material_specular)
        glMaterialfv(GL_FRONT, GL_SHININESS, material_shininess)

        # 원통형 챔버 (쿼드릭 사용)
        from OpenGL.GLU import gluNewQuadric, gluCylinder, gluSphere

        quadric = gluNewQuadric()

        # 외벽
        glColor3f(0.7, 0.7, 0.8)
        gluCylinder(quadric, 1.5, 1.5, 2.0, 32, 16)

        # 상단
        glPushMatrix()
        glTranslatef(0.0, 0.0, 2.0)
        gluSphere(quadric, 1.5, 32, 16)
        glPopMatrix()

        # 하단
        gluSphere(quadric, 1.5, 32, 16)

        glPopMatrix()

    def render_gas_lines(self):
        """가스 라인 렌더링"""
        glPushMatrix()

        # 가스 입구 파이프들
        gas_inlets = [
            (2.0, 0.0, 1.0),   # 가스 1
            (1.4, 1.4, 1.0),   # 가스 2
            (0.0, 2.0, 1.0),   # 가스 3
            (-1.4, 1.4, 1.0),  # 가스 4
        ]

        glColor3f(0.8, 0.8, 0.9)
        for x, y, z in gas_inlets:
            glPushMatrix()
            glTranslatef(x, y, z)

            # 파이프 렌더링 (간단한 원통)
            from OpenGL.GLU import gluNewQuadric, gluCylinder
            quadric = gluNewQuadric()
            glRotatef(90, 0, 1, 0)
            gluCylinder(quadric, 0.1, 0.1, 0.5, 8, 4)

            glPopMatrix()

        glPopMatrix()

    def render_sensor_positions(self):
        """센서 위치 렌더링"""
        glPushMatrix()

        # 온도 센서들
        temp_sensors = [
            ('T1', 1.3, 0.0, 0.5),
            ('T2', 0.0, 1.3, 1.0),
            ('T3', -1.3, 0.0, 1.5),
            ('T4', 0.0, -1.3, 1.0),
        ]

        for sensor_id, x, y, z in temp_sensors:
            glPushMatrix()
            glTranslatef(x, y, z)

            # 센서 데이터에 따른 색상 결정
            temp_value = self.sensor_data.get(sensor_id, 25.0)
            color = self.get_temperature_color(temp_value)
            glColor3f(*color)

            # 센서 표시 (작은 구)
            from OpenGL.GLU import gluNewQuadric, gluSphere
            quadric = gluNewQuadric()
            gluSphere(quadric, 0.1, 16, 8)

            glPopMatrix()

        glPopMatrix()

    def render_sensors(self):
        """센서 데이터 시각화"""
        # 온도 분포 시각화 (열화상 효과)
        self.render_temperature_distribution()

        # 압력 게이지 3D 표시
        self.render_pressure_indicators()

    def render_temperature_distribution(self):
        """온도 분포 시각화"""
        glPushMatrix()
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

        # 반투명 온도 층 렌더링
        for i in range(10):
            height = i * 0.2
            alpha = 0.1

            # 현재 높이에서의 평균 온도 계산
            avg_temp = self.calculate_average_temperature_at_height(height)
            color = self.get_temperature_color(avg_temp)

            glColor4f(color[0], color[1], color[2], alpha)

            # 원형 온도 분포 렌더링
            glBegin(GL_TRIANGLE_FAN)
            glVertex3f(0.0, 0.0, height)

            for angle in range(0, 361, 10):
                rad = math.radians(angle)
                x = 1.4 * math.cos(rad)
                y = 1.4 * math.sin(rad)
                glVertex3f(x, y, height)

            glEnd()

        glDisable(GL_BLEND)
        glPopMatrix()

    def render_pressure_indicators(self):
        """압력 인디케이터 렌더링"""
        glPushMatrix()

        # 압력 값에 따른 3D 바 그래프
        pressure_value = self.sensor_data.get('pressure', 5.0)
        bar_height = pressure_value / 10.0  # 정규화

        glTranslatef(2.5, 0.0, 0.0)
        glColor3f(0.0, 0.8, 1.0)

        # 압력 바 렌더링
        glBegin(GL_QUADS)
        # 앞면
        glVertex3f(-0.1, -0.1, 0.0)
        glVertex3f(0.1, -0.1, 0.0)
        glVertex3f(0.1, 0.1, 0.0)
        glVertex3f(-0.1, 0.1, 0.0)

        # 윗면
        glVertex3f(-0.1, -0.1, bar_height)
        glVertex3f(0.1, -0.1, bar_height)
        glVertex3f(0.1, 0.1, bar_height)
        glVertex3f(-0.1, 0.1, bar_height)
        glEnd()

        glPopMatrix()

    def render_axes(self):
        """좌표축 렌더링"""
        glPushMatrix()
        glDisable(GL_LIGHTING)

        glLineWidth(3.0)
        glBegin(GL_LINES)

        # X축 (빨강)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(1.0, 0.0, 0.0)

        # Y축 (녹색)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, 1.0, 0.0)

        # Z축 (파랑)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, 1.0)

        glEnd()
        glLineWidth(1.0)

        glEnable(GL_LIGHTING)
        glPopMatrix()

    def get_temperature_color(self, temperature):
        """온도에 따른 색상 반환"""
        if temperature < 100:
            return self.temperature_color_map['cold']
        elif temperature < 200:
            return self.temperature_color_map['normal']
        elif temperature < 300:
            return self.temperature_color_map['hot']
        else:
            return self.temperature_color_map['critical']

    def calculate_average_temperature_at_height(self, height):
        """특정 높이에서의 평균 온도 계산"""
        # 실제로는 센서 데이터를 기반으로 보간 계산
        base_temp = 25.0
        height_factor = height * 50  # 높이에 따른 온도 증가
        return base_temp + height_factor

    def update_sensor_data(self, sensor_data):
        """센서 데이터 업데이트"""
        self.sensor_data.update(sensor_data)
        self.update()

    def mousePressEvent(self, event):
        """마우스 클릭 이벤트"""
        self.last_mouse_pos = event.position()
        self.mouse_buttons = event.buttons()

    def mouseMoveEvent(self, event):
        """마우스 이동 이벤트"""
        if self.last_mouse_pos is None:
            return

        dx = event.position().x() - self.last_mouse_pos.x()
        dy = event.position().y() - self.last_mouse_pos.y()

        if self.mouse_buttons & Qt.LeftButton:
            # 회전
            self.rotation_y += dx * 0.5
            self.rotation_x += dy * 0.5

            # 회전 제한
            self.rotation_x = max(-90, min(90, self.rotation_x))

            self.update()

        self.last_mouse_pos = event.position()

    def wheelEvent(self, event):
        """마우스 휠 이벤트 (줌)"""
        delta = event.angleDelta().y()
        zoom_factor = 1.1 if delta > 0 else 0.9

        self.zoom *= zoom_factor
        self.zoom = max(0.1, min(5.0, self.zoom))

        self.update()

    def animate(self):
        """애니메이션 업데이트"""
        # 시간에 따른 자동 회전 (옵션)
        # self.rotation_y += 0.5
        self.update()

    def load_equipment_models(self):
        """장비 모델 로드"""
        # 실제로는 3D 모델 파일(.obj, .stl 등)을 로드
        # 여기서는 기본 형태로 구현
        pass

---

## 2️⃣ 기초 실습
### 🛠️ **커스텀 위젯 및 고급 UI 컴포넌트 개발**

#### **2.1 플로우 다이어그램 위젯**

<div class="practice-section">

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout,
                               QPushButton, QLabel, QScrollArea, QMainWindow)
from PySide6.QtGui import QPainter, QPen, QBrush, QPolygon, QFont, QColor
from PySide6.QtCore import Qt, QRect, QPoint, Signal, QPropertyAnimation, QEasingCurve
from enum import Enum
import math

class ProcessStage(Enum):
    """프로세스 단계"""
    IDLE = "idle"
    PREP = "preparation"
    PROCESS = "processing"
    PURGE = "purging"
    COMPLETE = "complete"
    ERROR = "error"

class FlowComponent:
    """플로우 컴포넌트 기본 클래스"""

    def __init__(self, x, y, width, height, component_id, name):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.component_id = component_id
        self.name = name
        self.status = ProcessStage.IDLE
        self.value = 0.0
        self.connections = []  # 연결된 컴포넌트들

    def get_rect(self):
        return QRect(self.x, self.y, self.width, self.height)

    def get_center(self):
        return QPoint(self.x + self.width // 2, self.y + self.height // 2)

    def add_connection(self, target_component):
        if target_component not in self.connections:
            self.connections.append(target_component)

class Chamber(FlowComponent):
    """반응 챔버 컴포넌트"""

    def __init__(self, x, y, component_id="chamber_1", name="Main Chamber"):
        super().__init__(x, y, 120, 80, component_id, name)
        self.temperature = 25.0
        self.pressure = 1.0

    def draw(self, painter):
        rect = self.get_rect()

        # 상태에 따른 색상
        color_map = {
            ProcessStage.IDLE: QColor(200, 200, 200),
            ProcessStage.PREP: QColor(255, 255, 0),
            ProcessStage.PROCESS: QColor(0, 255, 0),
            ProcessStage.PURGE: QColor(255, 165, 0),
            ProcessStage.COMPLETE: QColor(0, 0, 255),
            ProcessStage.ERROR: QColor(255, 0, 0)
        }

        # 챔버 외곽
        painter.setPen(QPen(Qt.black, 2))
        painter.setBrush(QBrush(color_map[self.status]))
        painter.drawRoundedRect(rect, 10, 10)

        # 내부 원 (반응 영역)
        inner_rect = rect.adjusted(15, 15, -15, -15)
        painter.setBrush(QBrush(Qt.darkBlue))
        painter.drawEllipse(inner_rect)

        # 텍스트 정보
        painter.setPen(QPen(Qt.white))
        painter.setFont(QFont("Arial", 9, QFont.Bold))

        text_rect = QRect(rect.x(), rect.y() - 20, rect.width(), 15)
        painter.drawText(text_rect, Qt.AlignCenter, self.name)

        # 온도/압력 표시
        painter.setFont(QFont("Arial", 8))
        temp_text = f"T: {self.temperature:.1f}°C"
        pressure_text = f"P: {self.pressure:.1f}T"

        painter.drawText(rect.x() + 5, rect.y() + rect.height() + 15, temp_text)
        painter.drawText(rect.x() + 5, rect.y() + rect.height() + 28, pressure_text)

class GasLine(FlowComponent):
    """가스 라인 컴포넌트"""

    def __init__(self, x, y, component_id="gas_1", name="N2"):
        super().__init__(x, y, 80, 40, component_id, name)
        self.flow_rate = 0.0
        self.valve_open = False

    def draw(self, painter):
        rect = self.get_rect()

        # 밸브 상태에 따른 색상
        valve_color = QColor(0, 255, 0) if self.valve_open else QColor(255, 0, 0)

        # 가스 라인 (사각형)
        painter.setPen(QPen(Qt.black, 2))
        painter.setBrush(QBrush(QColor(220, 220, 220)))
        painter.drawRect(rect)

        # 밸브 표시 (작은 원)
        valve_rect = QRect(rect.x() + rect.width() - 15, rect.y() + 5, 10, 10)
        painter.setBrush(QBrush(valve_color))
        painter.drawEllipse(valve_rect)

        # 가스명 표시
        painter.setPen(QPen(Qt.black))
        painter.setFont(QFont("Arial", 10, QFont.Bold))
        painter.drawText(rect, Qt.AlignCenter, self.name)

        # 유량 표시
        painter.setFont(QFont("Arial", 8))
        flow_text = f"{self.flow_rate:.1f} sccm"
        flow_rect = QRect(rect.x(), rect.y() + rect.height() + 5, rect.width(), 15)
        painter.drawText(flow_rect, Qt.AlignCenter, flow_text)

class Pump(FlowComponent):
    """진공 펌프 컴포넌트"""

    def __init__(self, x, y, component_id="pump_1", name="Turbo Pump"):
        super().__init__(x, y, 60, 60, component_id, name)
        self.pump_speed = 0.0
        self.is_running = False

    def draw(self, painter):
        rect = self.get_rect()
        center = self.get_center()

        # 펌프 상태에 따른 색상
        pump_color = QColor(0, 255, 0) if self.is_running else QColor(128, 128, 128)

        # 펌프 몸체 (원)
        painter.setPen(QPen(Qt.black, 2))
        painter.setBrush(QBrush(pump_color))
        painter.drawEllipse(rect)

        # 회전 블레이드 표시
        if self.is_running:
            painter.setPen(QPen(Qt.black, 3))
            blade_length = 20

            for i in range(4):
                angle = (i * 90 + self.pump_speed * 10) % 360
                rad = math.radians(angle)

                end_x = center.x() + blade_length * math.cos(rad)
                end_y = center.y() + blade_length * math.sin(rad)

                painter.drawLine(center, QPoint(int(end_x), int(end_y)))

        # 이름 표시
        painter.setPen(QPen(Qt.white))
        painter.setFont(QFont("Arial", 8, QFont.Bold))
        painter.drawText(rect, Qt.AlignCenter, self.name)

class ProcessFlowDiagram(QWidget):
    """프로세스 플로우 다이어그램 위젯"""

    component_clicked = Signal(str)
    component_status_changed = Signal(str, ProcessStage)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(800, 600)

        # 컴포넌트들
        self.components = {}
        self.connections = []  # (from_component, to_component, flow_rate)

        # 마우스 상호작용
        self.selected_component = None
        self.mouse_pos = QPoint()

        # 애니메이션
        self.animation_phase = 0.0
        self.animation_timer = None

        self.setup_components()

    def setup_components(self):
        """컴포넌트 배치 설정"""
        # 가스 라인들 (상단)
        gas_lines = [
            ("N2", 50, 50),
            ("Ar", 200, 50),
            ("SiH4", 350, 50),
            ("NH3", 500, 50)
        ]

        for name, x, y in gas_lines:
            component = GasLine(x, y, f"gas_{name.lower()}", name)
            self.components[component.component_id] = component

        # 메인 챔버 (중앙)
        chamber = Chamber(300, 200, "main_chamber", "CVD Chamber")
        self.components[chamber.component_id] = chamber

        # 펌프들 (하단)
        pumps = [
            ("Roughing Pump", 150, 400),
            ("Turbo Pump", 350, 400),
            ("Dry Pump", 550, 400)
        ]

        for name, x, y in pumps:
            pump = Pump(x, y, f"pump_{name.lower().replace(' ', '_')}", name)
            self.components[pump.component_id] = pump

        # 연결 설정
        self.setup_connections()

    def setup_connections(self):
        """컴포넌트 간 연결 설정"""
        # 가스 라인 -> 챔버
        for comp_id, component in self.components.items():
            if comp_id.startswith("gas_"):
                chamber = self.components["main_chamber"]
                component.add_connection(chamber)
                self.connections.append((component, chamber, 0.0))

        # 챔버 -> 펌프들
        chamber = self.components["main_chamber"]
        for comp_id, component in self.components.items():
            if comp_id.startswith("pump_"):
                chamber.add_connection(component)
                self.connections.append((chamber, component, 0.0))

    def paintEvent(self, event):
        """페인팅 이벤트"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 배경
        painter.fillRect(self.rect(), QColor(240, 240, 240))

        # 연결선 그리기
        self.draw_connections(painter)

        # 컴포넌트들 그리기
        for component in self.components.values():
            component.draw(painter)

        # 선택된 컴포넌트 하이라이트
        if self.selected_component:
            self.highlight_component(painter, self.selected_component)

    def draw_connections(self, painter):
        """연결선 그리기"""
        painter.setPen(QPen(Qt.blue, 3))

        for from_comp, to_comp, flow_rate in self.connections:
            from_center = from_comp.get_center()
            to_center = to_comp.get_center()

            # 화살표 그리기
            self.draw_arrow(painter, from_center, to_center, flow_rate)

    def draw_arrow(self, painter, start, end, flow_rate):
        """화살표 그리기"""
        # 기본 라인
        painter.drawLine(start, end)

        # 화살표 머리
        angle = math.atan2(end.y() - start.y(), end.x() - start.x())
        arrow_length = 15
        arrow_angle = math.pi / 6  # 30도

        # 화살표 점들
        arrow_p1 = QPoint(
            int(end.x() - arrow_length * math.cos(angle - arrow_angle)),
            int(end.y() - arrow_length * math.sin(angle - arrow_angle))
        )
        arrow_p2 = QPoint(
            int(end.x() - arrow_length * math.cos(angle + arrow_angle)),
            int(end.y() - arrow_length * math.sin(angle + arrow_angle))
        )

        arrow = QPolygon([end, arrow_p1, arrow_p2])
        painter.setBrush(QBrush(Qt.blue))
        painter.drawPolygon(arrow)

        # 유량 표시
        if flow_rate > 0:
            mid_point = QPoint((start.x() + end.x()) // 2, (start.y() + end.y()) // 2)
            painter.setPen(QPen(Qt.red))
            painter.setFont(QFont("Arial", 8))
            painter.drawText(mid_point, f"{flow_rate:.1f}")

    def highlight_component(self, painter, component):
        """선택된 컴포넌트 하이라이트"""
        rect = component.get_rect()
        painter.setPen(QPen(Qt.red, 3, Qt.DashLine))
        painter.setBrush(QBrush())  # 투명
        painter.drawRect(rect.adjusted(-5, -5, 5, 5))

    def mousePressEvent(self, event):
        """마우스 클릭 이벤트"""
        click_pos = event.position().toPoint()

        # 클릭된 컴포넌트 찾기
        for component in self.components.values():
            if component.get_rect().contains(click_pos):
                self.selected_component = component
                self.component_clicked.emit(component.component_id)
                self.update()
                break
        else:
            self.selected_component = None
            self.update()

    def update_component_status(self, component_id, status, **kwargs):
        """컴포넌트 상태 업데이트"""
        if component_id in self.components:
            component = self.components[component_id]
            component.status = status

            # 추가 속성 업데이트
            for key, value in kwargs.items():
                if hasattr(component, key):
                    setattr(component, key, value)

            self.component_status_changed.emit(component_id, status)
            self.update()

    def start_simulation(self):
        """시뮬레이션 애니메이션 시작"""
        if not self.animation_timer:
            from PySide6.QtCore import QTimer
            self.animation_timer = QTimer()
            self.animation_timer.timeout.connect(self.animate_flow)
            self.animation_timer.start(100)  # 100ms 간격

    def stop_simulation(self):
        """시뮬레이션 애니메이션 중지"""
        if self.animation_timer:
            self.animation_timer.stop()

    def animate_flow(self):
        """플로우 애니메이션"""
        self.animation_phase += 0.1

        # 펌프 회전 애니메이션
        for component in self.components.values():
            if isinstance(component, Pump) and component.is_running:
                component.pump_speed = self.animation_phase

        self.update()

class ProcessControlPanel(QWidget):
    """프로세스 제어 패널"""

    def __init__(self, flow_diagram, parent=None):
        super().__init__(parent)
        self.flow_diagram = flow_diagram
        self.setup_ui()
        self.setup_connections()

    def setup_ui(self):
        """UI 설정"""
        layout = QVBoxLayout(self)

        # 제어 버튼들
        control_layout = QHBoxLayout()

        self.start_button = QPushButton("프로세스 시작")
        self.stop_button = QPushButton("프로세스 중지")
        self.emergency_button = QPushButton("비상 정지")
        self.emergency_button.setStyleSheet("background-color: red; color: white;")

        control_layout.addWidget(self.start_button)
        control_layout.addWidget(self.stop_button)
        control_layout.addWidget(self.emergency_button)

        layout.addLayout(control_layout)

        # 상태 정보
        self.status_label = QLabel("시스템 대기 중")
        self.status_label.setFont(QFont("Arial", 12, QFont.Bold))
        layout.addWidget(self.status_label)

        # 개별 컴포넌트 제어
        component_layout = QHBoxLayout()

        # 가스 밸브 제어
        gas_control = QVBoxLayout()
        gas_control.addWidget(QLabel("가스 제어"))

        self.gas_buttons = {}
        for gas_name in ["N2", "Ar", "SiH4", "NH3"]:
            button = QPushButton(f"{gas_name} ON/OFF")
            button.setCheckable(True)
            self.gas_buttons[gas_name] = button
            gas_control.addWidget(button)

        component_layout.addLayout(gas_control)

        # 펌프 제어
        pump_control = QVBoxLayout()
        pump_control.addWidget(QLabel("펌프 제어"))

        self.pump_buttons = {}
        for pump_name in ["Roughing Pump", "Turbo Pump", "Dry Pump"]:
            button = QPushButton(f"{pump_name} ON/OFF")
            button.setCheckable(True)
            self.pump_buttons[pump_name] = button
            pump_control.addWidget(button)

        component_layout.addLayout(pump_control)

        layout.addLayout(component_layout)

    def setup_connections(self):
        """시그널 연결"""
        self.start_button.clicked.connect(self.start_process)
        self.stop_button.clicked.connect(self.stop_process)
        self.emergency_button.clicked.connect(self.emergency_stop)

        # 가스 밸브 제어
        for gas_name, button in self.gas_buttons.items():
            button.toggled.connect(lambda checked, name=gas_name: self.toggle_gas(name, checked))

        # 펌프 제어
        for pump_name, button in self.pump_buttons.items():
            button.toggled.connect(lambda checked, name=pump_name: self.toggle_pump(name, checked))

        # 플로우 다이어그램 연결
        self.flow_diagram.component_clicked.connect(self.on_component_clicked)

    def start_process(self):
        """프로세스 시작"""
        self.status_label.setText("프로세스 실행 중")
        self.flow_diagram.start_simulation()

        # 챔버 상태 변경
        self.flow_diagram.update_component_status(
            "main_chamber",
            ProcessStage.PROCESS,
            temperature=350.0,
            pressure=5.0
        )

    def stop_process(self):
        """프로세스 중지"""
        self.status_label.setText("프로세스 중지됨")
        self.flow_diagram.stop_simulation()

        # 모든 컴포넌트 idle 상태로
        for comp_id in self.flow_diagram.components:
            self.flow_diagram.update_component_status(comp_id, ProcessStage.IDLE)

    def emergency_stop(self):
        """비상 정지"""
        self.status_label.setText("비상 정지 - 안전 점검 필요")
        self.flow_diagram.stop_simulation()

        # 모든 컴포넌트 에러 상태로
        for comp_id in self.flow_diagram.components:
            self.flow_diagram.update_component_status(comp_id, ProcessStage.ERROR)

    def toggle_gas(self, gas_name, checked):
        """가스 밸브 토글"""
        component_id = f"gas_{gas_name.lower()}"
        if component_id in self.flow_diagram.components:
            self.flow_diagram.update_component_status(
                component_id,
                ProcessStage.PROCESS if checked else ProcessStage.IDLE,
                valve_open=checked,
                flow_rate=100.0 if checked else 0.0
            )

    def toggle_pump(self, pump_name, checked):
        """펌프 토글"""
        component_id = f"pump_{pump_name.lower().replace(' ', '_')}"
        if component_id in self.flow_diagram.components:
            self.flow_diagram.update_component_status(
                component_id,
                ProcessStage.PROCESS if checked else ProcessStage.IDLE,
                is_running=checked,
                pump_speed=1000.0 if checked else 0.0
            )

    def on_component_clicked(self, component_id):
        """컴포넌트 클릭 처리"""
        component = self.flow_diagram.components.get(component_id)
        if component:
            self.status_label.setText(f"선택됨: {component.name} ({component_id})")

# 메인 애플리케이션
class ProcessMonitorApp(QMainWindow):
    """프로세스 모니터링 애플리케이션"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("반도체 프로세스 플로우 모니터링")
        self.setGeometry(100, 100, 1200, 800)

        # 중앙 위젯
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # 레이아웃
        layout = QHBoxLayout(central_widget)

        # 플로우 다이어그램
        self.flow_diagram = ProcessFlowDiagram()
        scroll_area = QScrollArea()
        scroll_area.setWidget(self.flow_diagram)
        scroll_area.setWidgetResizable(True)

        # 제어 패널
        self.control_panel = ProcessControlPanel(self.flow_diagram)
        self.control_panel.setMaximumWidth(300)

        layout.addWidget(scroll_area, 3)
        layout.addWidget(self.control_panel, 1)

# 메인 실행
if __name__ == "__main__":
    app = QApplication(sys.argv)

    window = ProcessMonitorApp()
    window.show()

    sys.exit(app.exec())
```

</div>

#### **2.2 고급 차트 위젯**

##### **2.2.1 실시간 트렌드 차트**

<div class="chart-widget">

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import math
import time
from datetime import datetime, timedelta
from collections import deque
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton
from PySide6.QtGui import QPainter, QPen, QBrush, QFont, QColor, QLinearGradient
from PySide6.QtCore import Qt, QRect, QPoint, QTimer, Signal
import random

class AdvancedTrendChart(QWidget):
    """고급 트렌드 차트 위젯"""

    point_hovered = Signal(str, float, datetime)
    threshold_exceeded = Signal(str, float, float)

    def __init__(self, title="Trend Chart", parent=None):
        super().__init__(parent)
        self.setMinimumSize(600, 400)

        # 차트 속성
        self.title = title
        self.data_series = {}  # {series_name: {'data': deque, 'color': QColor, 'visible': bool}}
        self.time_range = timedelta(minutes=10)  # 10분 범위
        self.max_points = 1000

        # 축 설정
        self.y_min = 0
        self.y_max = 100
        self.auto_scale = True
        self.grid_enabled = True

        # 임계값 설정
        self.thresholds = {}  # {series_name: {'warning': float, 'critical': float}}

        # 마우스 상호작용
        self.mouse_pos = QPoint()
        self.show_crosshair = True
        self.show_values = True

        # 확대/축소
        self.zoom_factor = 1.0
        self.pan_offset = QPoint(0, 0)

        # 색상 팔레트
        self.default_colors = [
            QColor(255, 0, 0),    # 빨강
            QColor(0, 255, 0),    # 녹색
            QColor(0, 0, 255),    # 파랑
            QColor(255, 165, 0),  # 주황
            QColor(128, 0, 128),  # 보라
            QColor(255, 192, 203), # 분홍
            QColor(0, 255, 255),  # 시안
            QColor(255, 255, 0),  # 노랑
        ]
        self.color_index = 0

    def add_series(self, series_name, color=None, warning_threshold=None, critical_threshold=None):
        """데이터 시리즈 추가"""
        if color is None:
            color = self.default_colors[self.color_index % len(self.default_colors)]
            self.color_index += 1

        self.data_series[series_name] = {
            'data': deque(maxlen=self.max_points),
            'color': color,
            'visible': True
        }

        if warning_threshold is not None or critical_threshold is not None:
            self.thresholds[series_name] = {
                'warning': warning_threshold,
                'critical': critical_threshold
            }

    def add_data_point(self, series_name, value, timestamp=None):
        """데이터 포인트 추가"""
        if series_name not in self.data_series:
            self.add_series(series_name)

        if timestamp is None:
            timestamp = datetime.now()

        # 데이터 추가
        self.data_series[series_name]['data'].append((timestamp, value))

        # 자동 스케일링
        if self.auto_scale:
            self.update_y_range()

        # 임계값 체크
        self.check_thresholds(series_name, value)

        self.update()

    def update_y_range(self):
        """Y축 범위 자동 업데이트"""
        all_values = []

        for series_data in self.data_series.values():
            for timestamp, value in series_data['data']:
                all_values.append(value)

        if all_values:
            min_val = min(all_values)
            max_val = max(all_values)

            # 여백 추가 (10%)
            margin = (max_val - min_val) * 0.1
            self.y_min = min_val - margin
            self.y_max = max_val + margin

    def check_thresholds(self, series_name, value):
        """임계값 체크"""
        if series_name in self.thresholds:
            thresholds = self.thresholds[series_name]

            if thresholds.get('critical') and value > thresholds['critical']:
                self.threshold_exceeded.emit(series_name, value, thresholds['critical'])
            elif thresholds.get('warning') and value > thresholds['warning']:
                self.threshold_exceeded.emit(series_name, value, thresholds['warning'])

    def paintEvent(self, event):
        """페인팅 이벤트"""
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # 배경
        self.draw_background(painter)

        # 차트 영역 계산
        chart_rect = self.get_chart_rect()

        # 그리드
        if self.grid_enabled:
            self.draw_grid(painter, chart_rect)

        # 임계값 라인
        self.draw_threshold_lines(painter, chart_rect)

        # 데이터 시리즈
        self.draw_data_series(painter, chart_rect)

        # 축 라벨
        self.draw_axes(painter, chart_rect)

        # 제목
        self.draw_title(painter)

        # 범례
        self.draw_legend(painter)

        # 크로스헤어
        if self.show_crosshair:
            self.draw_crosshair(painter, chart_rect)

    def draw_background(self, painter):
        """배경 그리기"""
        # 그라디언트 배경
        gradient = QLinearGradient(0, 0, 0, self.height())
        gradient.setColorAt(0.0, QColor(250, 250, 250))
        gradient.setColorAt(1.0, QColor(220, 220, 220))

        painter.fillRect(self.rect(), QBrush(gradient))

    def get_chart_rect(self):
        """차트 영역 계산"""
        margin = 60
        return QRect(
            margin,
            margin + 30,  # 제목 공간
            self.width() - 2 * margin - 150,  # 범례 공간
            self.height() - 2 * margin - 30
        )

    def draw_grid(self, painter, chart_rect):
        """그리드 그리기"""
        painter.setPen(QPen(QColor(200, 200, 200), 1, Qt.DotLine))

        # 수직선 (시간축)
        for i in range(10):
            x = chart_rect.x() + (i * chart_rect.width() / 9)
            painter.drawLine(x, chart_rect.y(), x, chart_rect.bottom())

        # 수평선 (값축)
        for i in range(6):
            y = chart_rect.y() + (i * chart_rect.height() / 5)
            painter.drawLine(chart_rect.x(), y, chart_rect.right(), y)

    def draw_threshold_lines(self, painter, chart_rect):
        """임계값 라인 그리기"""
        for series_name, thresholds in self.thresholds.items():
            # 경고 임계값
            if thresholds.get('warning'):
                y = self.value_to_y(thresholds['warning'], chart_rect)
                painter.setPen(QPen(QColor(255, 165, 0), 2, Qt.DashLine))
                painter.drawLine(chart_rect.x(), y, chart_rect.right(), y)

                # 라벨
                painter.setPen(QPen(QColor(255, 165, 0)))
                painter.drawText(chart_rect.right() + 5, y, f"Warning: {thresholds['warning']}")

            # 위험 임계값
            if thresholds.get('critical'):
                y = self.value_to_y(thresholds['critical'], chart_rect)
                painter.setPen(QPen(QColor(255, 0, 0), 2, Qt.DashLine))
                painter.drawLine(chart_rect.x(), y, chart_rect.right(), y)

                # 라벨
                painter.setPen(QPen(QColor(255, 0, 0)))
                painter.drawText(chart_rect.right() + 5, y, f"Critical: {thresholds['critical']}")

    def draw_data_series(self, painter, chart_rect):
        """데이터 시리즈 그리기"""
        current_time = datetime.now()
        time_start = current_time - self.time_range

        for series_name, series_data in self.data_series.items():
            if not series_data['visible'] or not series_data['data']:
                continue

            # 시간 범위 내 데이터 필터링
            filtered_data = [
                (timestamp, value) for timestamp, value in series_data['data']
                if timestamp >= time_start
            ]

            if len(filtered_data) < 2:
                continue

            # 라인 그리기
            painter.setPen(QPen(series_data['color'], 2))

            points = []
            for timestamp, value in filtered_data:
                x = self.timestamp_to_x(timestamp, chart_rect, current_time)
                y = self.value_to_y(value, chart_rect)
                points.append(QPoint(int(x), int(y)))

            # 연결된 라인 그리기
            for i in range(len(points) - 1):
                painter.drawLine(points[i], points[i + 1])

            # 데이터 포인트 마커
            painter.setBrush(QBrush(series_data['color']))
            for point in points[-10:]:  # 최근 10개만 표시
                painter.drawEllipse(point, 3, 3)

    def timestamp_to_x(self, timestamp, chart_rect, current_time):
        """타임스탬프를 X 좌표로 변환"""
        time_diff = (current_time - timestamp).total_seconds()
        time_range_seconds = self.time_range.total_seconds()

        ratio = 1.0 - (time_diff / time_range_seconds)
        return chart_rect.x() + ratio * chart_rect.width()

    def value_to_y(self, value, chart_rect):
        """값을 Y 좌표로 변환"""
        if self.y_max == self.y_min:
            return chart_rect.center().y()

        ratio = (value - self.y_min) / (self.y_max - self.y_min)
        return chart_rect.bottom() - ratio * chart_rect.height()

    def draw_axes(self, painter, chart_rect):
        """축 라벨 그리기"""
        painter.setPen(QPen(Qt.black))
        painter.setFont(QFont("Arial", 9))

        # Y축 라벨
        for i in range(6):
            y = chart_rect.y() + (i * chart_rect.height() / 5)
            value = self.y_max - (i * (self.y_max - self.y_min) / 5)
            text = f"{value:.1f}"
            painter.drawText(chart_rect.x() - 30, y + 5, text)

        # X축 라벨 (시간)
        current_time = datetime.now()
        for i in range(6):
            x = chart_rect.x() + (i * chart_rect.width() / 5)
            time_offset = timedelta(seconds=(5-i) * self.time_range.total_seconds() / 5)
            timestamp = current_time - time_offset
            text = timestamp.strftime("%H:%M")
            painter.drawText(x - 20, chart_rect.bottom() + 20, text)

    def draw_title(self, painter):
        """제목 그리기"""
        painter.setPen(QPen(Qt.black))
        painter.setFont(QFont("Arial", 14, QFont.Bold))
        title_rect = QRect(0, 10, self.width(), 30)
        painter.drawText(title_rect, Qt.AlignCenter, self.title)

    def draw_legend(self, painter):
        """범례 그리기"""
        legend_x = self.width() - 140
        legend_y = 60

        painter.setPen(QPen(Qt.black))
        painter.setFont(QFont("Arial", 9))

        y_offset = 0
        for series_name, series_data in self.data_series.items():
            if not series_data['visible']:
                continue

            # 색상 박스
            color_rect = QRect(legend_x, legend_y + y_offset, 15, 15)
            painter.fillRect(color_rect, series_data['color'])
            painter.drawRect(color_rect)

            # 시리즈 이름
            painter.drawText(legend_x + 20, legend_y + y_offset + 12, series_name)

            # 현재 값
            if series_data['data']:
                current_value = series_data['data'][-1][1]
                painter.drawText(legend_x + 20, legend_y + y_offset + 25, f"{current_value:.2f}")

            y_offset += 40

    def draw_crosshair(self, painter, chart_rect):
        """크로스헤어 그리기"""
        if not chart_rect.contains(self.mouse_pos):
            return

        painter.setPen(QPen(QColor(100, 100, 100), 1, Qt.DashLine))

        # 수직선
        painter.drawLine(self.mouse_pos.x(), chart_rect.y(),
                        self.mouse_pos.x(), chart_rect.bottom())

        # 수평선
        painter.drawLine(chart_rect.x(), self.mouse_pos.y(),
                        chart_rect.right(), self.mouse_pos.y())

        # 값 표시
        if self.show_values:
            value = self.y_to_value(self.mouse_pos.y(), chart_rect)
            painter.setPen(QPen(Qt.black))
            painter.drawText(self.mouse_pos.x() + 10, self.mouse_pos.y() - 10,
                           f"Value: {value:.2f}")

    def y_to_value(self, y, chart_rect):
        """Y 좌표를 값으로 변환"""
        if chart_rect.height() == 0:
            return 0

        ratio = (chart_rect.bottom() - y) / chart_rect.height()
        return self.y_min + ratio * (self.y_max - self.y_min)

    def mouseMoveEvent(self, event):
        """마우스 이동 이벤트"""
        self.mouse_pos = event.position().toPoint()
        self.update()

    def wheelEvent(self, event):
        """마우스 휠 이벤트 (줌)"""
        delta = event.angleDelta().y()
        zoom_in = delta > 0

        if zoom_in:
            self.zoom_factor *= 1.1
        else:
            self.zoom_factor /= 1.1

        self.zoom_factor = max(0.1, min(10.0, self.zoom_factor))
        self.update()

    def set_time_range(self, minutes):
        """시간 범위 설정"""
        self.time_range = timedelta(minutes=minutes)
        self.update()

    def set_y_range(self, y_min, y_max):
        """Y축 범위 설정"""
        self.y_min = y_min
        self.y_max = y_max
        self.auto_scale = False
        self.update()

    def toggle_series_visibility(self, series_name):
        """시리즈 표시/숨김 토글"""
        if series_name in self.data_series:
            self.data_series[series_name]['visible'] = not self.data_series[series_name]['visible']
            self.update()

    def clear_data(self):
        """모든 데이터 클리어"""
        for series_data in self.data_series.values():
            series_data['data'].clear()
        self.update()

    def export_data(self):
        """데이터 내보내기"""
        data = {}
        for series_name, series_data in self.data_series.items():
            data[series_name] = list(series_data['data'])
        return data
```

</div>

---

## 3️⃣ 심화 실습
### ⚡ **3D 시각화 및 플러그인 아키텍처**

#### **3.1 고급 3D 시각화 구현**

##### **3.1.1 인터랙티브 3D 장비 모델**

<div class="advanced-3d">

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import math
import numpy as np
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QHBoxLayout, QWidget, QSlider, QLabel, QPushButton
from PySide6.QtCore import Qt, QTimer, Signal, QPoint
from PySide6.QtGui import QMatrix4x4, QVector3D, QQuaternion
from OpenGL.GL import *
from OpenGL.GLU import *
import random

class Interactive3DEquipment(QOpenGLWidget):
    """인터랙티브 3D 장비 시각화"""

    component_selected = Signal(str)
    sensor_data_updated = Signal(str, float)

    def __init__(self, parent=None):
        super().__init__(parent)

        # 카메라 제어
        self.camera_distance = 10.0
        self.camera_rotation_x = 15.0
        self.camera_rotation_y = 45.0

        # 마우스 상호작용
        self.last_mouse_pos = None
        self.mouse_sensitivity = 0.5

        # 3D 모델 구성요소
        self.equipment_components = {
            'chamber': {
                'position': [0.0, 0.0, 0.0],
                'rotation': [0.0, 0.0, 0.0],
                'scale': [1.0, 1.0, 1.0],
                'color': [0.7, 0.7, 0.8, 1.0],
                'selected': False,
                'temperature': 25.0
            },
            'gas_inlet_1': {
                'position': [2.0, 0.0, 1.0],
                'rotation': [0.0, 0.0, 90.0],
                'scale': [0.3, 0.3, 1.0],
                'color': [0.2, 0.8, 0.2, 1.0],
                'selected': False,
                'flow_rate': 0.0
            },
            'gas_inlet_2': {
                'position': [0.0, 2.0, 1.0],
                'rotation': [0.0, 0.0, 0.0],
                'scale': [0.3, 0.3, 1.0],
                'color': [0.2, 0.2, 0.8, 1.0],
                'selected': False,
                'flow_rate': 0.0
            },
            'exhaust_port': {
                'position': [0.0, 0.0, -2.0],
                'rotation': [0.0, 0.0, 0.0],
                'scale': [0.5, 0.5, 0.8],
                'color': [0.8, 0.2, 0.2, 1.0],
                'selected': False,
                'pressure': 1.0
            },
            'heater': {
                'position': [0.0, 0.0, 2.5],
                'rotation': [0.0, 0.0, 0.0],
                'scale': [1.2, 1.2, 0.2],
                'color': [1.0, 0.5, 0.0, 1.0],
                'selected': False,
                'power': 0.0
            }
        }

        # 애니메이션
        self.animation_timer = QTimer()
        self.animation_timer.timeout.connect(self.animate)
        self.animation_timer.start(33)  # 30 FPS

        # 파티클 시스템 (가스 플로우 시각화)
        self.particles = []
        self.max_particles = 200

        # 센서 데이터 시뮬레이션
        self.sensor_timer = QTimer()
        self.sensor_timer.timeout.connect(self.update_sensor_data)
        self.sensor_timer.start(1000)  # 1초마다 센서 데이터 업데이트

    def initializeGL(self):
        """OpenGL 초기화"""
        # 깊이 테스트
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LESS)

        # 조명 설정
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)
        glEnable(GL_LIGHT1)

        # 메인 조명
        light0_pos = [5.0, 5.0, 5.0, 1.0]
        light0_ambient = [0.3, 0.3, 0.3, 1.0]
        light0_diffuse = [0.8, 0.8, 0.8, 1.0]
        light0_specular = [1.0, 1.0, 1.0, 1.0]

        glLightfv(GL_LIGHT0, GL_POSITION, light0_pos)
        glLightfv(GL_LIGHT0, GL_AMBIENT, light0_ambient)
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse)
        glLightfv(GL_LIGHT0, GL_SPECULAR, light0_specular)

        # 보조 조명
        light1_pos = [-3.0, -3.0, 3.0, 1.0]
        light1_ambient = [0.1, 0.1, 0.1, 1.0]
        light1_diffuse = [0.4, 0.4, 0.4, 1.0]

        glLightfv(GL_LIGHT1, GL_POSITION, light1_pos)
        glLightfv(GL_LIGHT1, GL_AMBIENT, light1_ambient)
        glLightfv(GL_LIGHT1, GL_DIFFUSE, light1_diffuse)

        # 블렌딩 (투명도)
        glEnable(GL_BLEND)
        glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA)

        # 배경색
        glClearColor(0.05, 0.05, 0.1, 1.0)

    def resizeGL(self, width, height):
        """뷰포트 크기 변경"""
        glViewport(0, 0, width, height)
        glMatrixMode(GL_PROJECTION)
        glLoadIdentity()

        aspect_ratio = width / height if height != 0 else 1.0
        gluPerspective(45.0, aspect_ratio, 0.1, 100.0)

    def paintGL(self):
        """3D 렌더링"""
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

        # 카메라 설정
        glTranslatef(0.0, 0.0, -self.camera_distance)
        glRotatef(self.camera_rotation_x, 1.0, 0.0, 0.0)
        glRotatef(self.camera_rotation_y, 0.0, 1.0, 0.0)

        # 좌표축 렌더링
        self.render_axes()

        # 장비 컴포넌트 렌더링
        self.render_equipment_components()

        # 파티클 시스템 렌더링 (가스 플로우)
        self.render_particles()

        # 센서 데이터 시각화
        self.render_sensor_overlays()

    def render_axes(self):
        """좌표축 렌더링"""
        glDisable(GL_LIGHTING)
        glLineWidth(3.0)

        glBegin(GL_LINES)
        # X축 (빨강)
        glColor3f(1.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(2.0, 0.0, 0.0)

        # Y축 (녹색)
        glColor3f(0.0, 1.0, 0.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, 2.0, 0.0)

        # Z축 (파랑)
        glColor3f(0.0, 0.0, 1.0)
        glVertex3f(0.0, 0.0, 0.0)
        glVertex3f(0.0, 0.0, 2.0)
        glEnd()

        glLineWidth(1.0)
        glEnable(GL_LIGHTING)

    def render_equipment_components(self):
        """장비 컴포넌트 렌더링"""
        for comp_name, comp_data in self.equipment_components.items():
            glPushMatrix()

            # 변환 적용
            pos = comp_data['position']
            rot = comp_data['rotation']
            scale = comp_data['scale']

            glTranslatef(pos[0], pos[1], pos[2])
            glRotatef(rot[0], 1.0, 0.0, 0.0)
            glRotatef(rot[1], 0.0, 1.0, 0.0)
            glRotatef(rot[2], 0.0, 0.0, 1.0)
            glScalef(scale[0], scale[1], scale[2])

            # 재질 설정
            self.set_material(comp_data)

            # 컴포넌트별 렌더링
            if comp_name == 'chamber':
                self.render_chamber(comp_data)
            elif comp_name.startswith('gas_inlet'):
                self.render_gas_inlet(comp_data)
            elif comp_name == 'exhaust_port':
                self.render_exhaust_port(comp_data)
            elif comp_name == 'heater':
                self.render_heater(comp_data)

            glPopMatrix()

    def set_material(self, comp_data):
        """재질 속성 설정"""
        color = comp_data['color']
        selected = comp_data['selected']

        # 선택된 컴포넌트는 밝게 표시
        if selected:
            ambient = [color[0] * 0.5, color[1] * 0.5, color[2] * 0.5, color[3]]
            diffuse = [min(1.0, color[0] * 1.5), min(1.0, color[1] * 1.5),
                      min(1.0, color[2] * 1.5), color[3]]
        else:
            ambient = [color[0] * 0.3, color[1] * 0.3, color[2] * 0.3, color[3]]
            diffuse = color

        specular = [0.8, 0.8, 0.8, 1.0]
        shininess = [50.0]

        glMaterialfv(GL_FRONT, GL_AMBIENT, ambient)
        glMaterialfv(GL_FRONT, GL_DIFFUSE, diffuse)
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular)
        glMaterialfv(GL_FRONT, GL_SHININESS, shininess)

    def render_chamber(self, comp_data):
        """반응 챔버 렌더링"""
        # 외부 챔버 (원통)
        quadric = gluNewQuadric()
        gluQuadricNormals(quadric, GLU_SMOOTH)

        # 원통 몸체
        gluCylinder(quadric, 1.5, 1.5, 2.0, 32, 16)

        # 상단
        glPushMatrix()
        glTranslatef(0.0, 0.0, 2.0)
        gluDisk(quadric, 0.0, 1.5, 32, 16)
        glPopMatrix()

        # 하단
        gluDisk(quadric, 0.0, 1.5, 32, 16)

        # 온도에 따른 내부 글로우 효과
        temperature = comp_data.get('temperature', 25.0)
        if temperature > 100.0:
            glDisable(GL_LIGHTING)
            glow_intensity = min(1.0, (temperature - 100.0) / 300.0)
            glColor4f(1.0, 0.5 * glow_intensity, 0.0, 0.3 * glow_intensity)

            # 내부 구
            glPushMatrix()
            glTranslatef(0.0, 0.0, 1.0)
            gluSphere(quadric, 1.3, 16, 16)
            glPopMatrix()

            glEnable(GL_LIGHTING)

    def render_gas_inlet(self, comp_data):
        """가스 입구 렌더링"""
        quadric = gluNewQuadric()
        gluQuadricNormals(quadric, GLU_SMOOTH)

        # 파이프
        gluCylinder(quadric, 0.15, 0.15, 1.0, 16, 8)

        # 밸브 (구)
        glPushMatrix()
        glTranslatef(0.0, 0.0, 0.5)
        gluSphere(quadric, 0.2, 16, 16)
        glPopMatrix()

        # 가스 플로우 표시
        flow_rate = comp_data.get('flow_rate', 0.0)
        if flow_rate > 0:
            self.generate_gas_particles(comp_data['position'], flow_rate)

    def render_exhaust_port(self, comp_data):
        """배기구 렌더링"""
        quadric = gluNewQuadric()
        gluQuadricNormals(quadric, GLU_SMOOTH)

        # 배기 파이프
        gluCylinder(quadric, 0.3, 0.5, 1.0, 16, 8)

        # 플랜지
        glPushMatrix()
        glTranslatef(0.0, 0.0, 1.0)
        gluDisk(quadric, 0.3, 0.7, 24, 4)
        glPopMatrix()

    def render_heater(self, comp_data):
        """히터 렌더링"""
        quadric = gluNewQuadric()
        gluQuadricNormals(quadric, GLU_SMOOTH)

        # 히터 플레이트
        gluCylinder(quadric, 1.0, 1.0, 0.1, 32, 4)

        # 히터 코일 (스프링 형태)
        power = comp_data.get('power', 0.0)
        if power > 0:
            glDisable(GL_LIGHTING)
            heat_intensity = min(1.0, power / 1000.0)
            glColor4f(1.0, heat_intensity * 0.5, 0.0, 0.8)

            glBegin(GL_LINE_STRIP)
            for i in range(0, 360 * 3, 10):  # 3회전
                angle = math.radians(i)
                radius = 0.8 - (i / (360 * 3)) * 0.2
                x = radius * math.cos(angle)
                y = radius * math.sin(angle)
                z = 0.05 + (i / (360 * 3)) * 0.1

                glVertex3f(x, y, z)
            glEnd()

            glEnable(GL_LIGHTING)

    def generate_gas_particles(self, inlet_pos, flow_rate):
        """가스 파티클 생성"""
        particle_count = int(flow_rate / 10.0)  # 유량에 비례한 파티클 수

        for _ in range(particle_count):
            if len(self.particles) < self.max_particles:
                particle = {
                    'position': list(inlet_pos),
                    'velocity': [
                        random.uniform(-0.1, 0.1),
                        random.uniform(-0.1, 0.1),
                        random.uniform(-0.5, -0.2)
                    ],
                    'life': random.uniform(1.0, 3.0),
                    'size': random.uniform(0.02, 0.05),
                    'color': [0.8, 0.8, 1.0, 0.6]
                }
                self.particles.append(particle)

    def render_particles(self):
        """파티클 렌더링"""
        glDisable(GL_LIGHTING)
        glEnable(GL_POINT_SMOOTH)

        for particle in self.particles:
            alpha = particle['life'] / 3.0  # 생명력에 따른 투명도
            glColor4f(particle['color'][0], particle['color'][1],
                     particle['color'][2], alpha)

            glPointSize(particle['size'] * 100)
            glBegin(GL_POINTS)
            glVertex3f(particle['position'][0], particle['position'][1], particle['position'][2])
            glEnd()

        glDisable(GL_POINT_SMOOTH)
        glEnable(GL_LIGHTING)

    def render_sensor_overlays(self):
        """센서 데이터 오버레이 렌더링"""
        glDisable(GL_LIGHTING)
        glDisable(GL_DEPTH_TEST)

        # 온도 센서 위치에 텍스트 표시
        chamber_data = self.equipment_components['chamber']
        temp = chamber_data.get('temperature', 25.0)

        # 3D 위치를 2D 스크린 좌표로 변환 (간단한 구현)
        glColor3f(1.0, 1.0, 0.0)
        self.render_text_3d([0.0, 2.5, 0.0], f"T: {temp:.1f}°C")

        # 압력 센서
        exhaust_data = self.equipment_components['exhaust_port']
        pressure = exhaust_data.get('pressure', 1.0)
        self.render_text_3d([0.0, -2.5, -2.0], f"P: {pressure:.2f}T")

        glEnable(GL_DEPTH_TEST)
        glEnable(GL_LIGHTING)

    def render_text_3d(self, position, text):
        """3D 공간에 텍스트 렌더링 (간단한 구현)"""
        # 실제로는 QOpenGLWidget에서 텍스트 렌더링은 복잡함
        # 여기서는 간단한 라인으로 대체
        glPushMatrix()
        glTranslatef(position[0], position[1], position[2])

        # 텍스트 배경 (사각형)
        glBegin(GL_QUADS)
        glVertex3f(-0.5, -0.1, 0.0)
        glVertex3f(0.5, -0.1, 0.0)
        glVertex3f(0.5, 0.1, 0.0)
        glVertex3f(-0.5, 0.1, 0.0)
        glEnd()

        glPopMatrix()

    def animate(self):
        """애니메이션 업데이트"""
        # 파티클 업데이트
        dt = 0.033  # 33ms

        for particle in self.particles[:]:
            # 위치 업데이트
            particle['position'][0] += particle['velocity'][0] * dt
            particle['position'][1] += particle['velocity'][1] * dt
            particle['position'][2] += particle['velocity'][2] * dt

            # 생명력 감소
            particle['life'] -= dt

            # 중력 효과
            particle['velocity'][2] -= 0.1 * dt

            # 생명력이 다한 파티클 제거
            if particle['life'] <= 0:
                self.particles.remove(particle)

        self.update()

    def update_sensor_data(self):
        """센서 데이터 업데이트 (시뮬레이션)"""
        # 온도 시뮬레이션
        heater_power = self.equipment_components['heater'].get('power', 0.0)
        current_temp = self.equipment_components['chamber']['temperature']

        # 히터 파워에 따른 온도 변화
        target_temp = 25.0 + (heater_power / 1000.0) * 400.0  # 최대 425°C
        temp_change = (target_temp - current_temp) * 0.1  # 느린 온도 변화

        new_temp = current_temp + temp_change + random.uniform(-2.0, 2.0)
        new_temp = max(20.0, min(500.0, new_temp))  # 온도 제한

        self.equipment_components['chamber']['temperature'] = new_temp
        self.sensor_data_updated.emit('chamber_temperature', new_temp)

        # 압력 시뮬레이션
        gas_flow_total = sum([
            comp.get('flow_rate', 0.0) for comp in self.equipment_components.values()
            if 'flow_rate' in comp
        ])

        base_pressure = 0.1 + (gas_flow_total / 1000.0) * 10.0
        new_pressure = base_pressure + random.uniform(-0.1, 0.1)
        new_pressure = max(0.01, min(20.0, new_pressure))

        self.equipment_components['exhaust_port']['pressure'] = new_pressure
        self.sensor_data_updated.emit('chamber_pressure', new_pressure)

    def mousePressEvent(self, event):
        """마우스 클릭 이벤트"""
        self.last_mouse_pos = event.position()

        # 레이캐스팅을 통한 컴포넌트 선택 (간단한 구현)
        # 실제로는 더 복잡한 3D 피킹 알고리즘 필요
        if event.button() == Qt.LeftButton:
            self.select_component_at_mouse(event.position())

    def mouseMoveEvent(self, event):
        """마우스 이동 이벤트"""
        if self.last_mouse_pos is None:
            return

        dx = event.position().x() - self.last_mouse_pos.x()
        dy = event.position().y() - self.last_mouse_pos.y()

        if event.buttons() & Qt.LeftButton:
            # 카메라 회전
            self.camera_rotation_y += dx * self.mouse_sensitivity
            self.camera_rotation_x += dy * self.mouse_sensitivity

            # 회전 제한
            self.camera_rotation_x = max(-90, min(90, self.camera_rotation_x))

        self.last_mouse_pos = event.position()
        self.update()

    def wheelEvent(self, event):
        """마우스 휠 이벤트 (줌)"""
        delta = event.angleDelta().y()
        zoom_factor = 1.1 if delta > 0 else 0.9

        self.camera_distance *= zoom_factor
        self.camera_distance = max(3.0, min(20.0, self.camera_distance))

        self.update()

    def select_component_at_mouse(self, mouse_pos):
        """마우스 위치의 컴포넌트 선택"""
        # 간단한 거리 기반 선택 (실제로는 레이캐스팅 사용)
        # 모든 컴포넌트 선택 해제
        for comp_data in self.equipment_components.values():
            comp_data['selected'] = False

        # 첫 번째 컴포넌트 선택 (데모용)
        component_names = list(self.equipment_components.keys())
        if component_names:
            selected_comp = component_names[0]
            self.equipment_components[selected_comp]['selected'] = True
            self.component_selected.emit(selected_comp)

    def set_component_parameter(self, component_name, parameter, value):
        """컴포넌트 파라미터 설정"""
        if component_name in self.equipment_components:
            self.equipment_components[component_name][parameter] = value

class Equipment3DController(QWidget):
    """3D 장비 제어 패널"""

    def __init__(self, equipment_3d, parent=None):
        super().__init__(parent)
        self.equipment_3d = equipment_3d
        self.setup_ui()
        self.setup_connections()

    def setup_ui(self):
        """UI 설정"""
        layout = QVBoxLayout(self)

        # 히터 제어
        heater_group = QVBoxLayout()
        heater_group.addWidget(QLabel("히터 제어"))

        self.heater_slider = QSlider(Qt.Horizontal)
        self.heater_slider.setRange(0, 1000)
        self.heater_slider.setValue(0)
        self.heater_label = QLabel("Power: 0W")

        heater_group.addWidget(self.heater_label)
        heater_group.addWidget(self.heater_slider)

        layout.addLayout(heater_group)

        # 가스 유량 제어
        gas_group = QVBoxLayout()
        gas_group.addWidget(QLabel("가스 유량 제어"))

        self.gas1_slider = QSlider(Qt.Horizontal)
        self.gas1_slider.setRange(0, 200)
        self.gas1_label = QLabel("Gas 1: 0 sccm")

        self.gas2_slider = QSlider(Qt.Horizontal)
        self.gas2_slider.setRange(0, 200)
        self.gas2_label = QLabel("Gas 2: 0 sccm")

        gas_group.addWidget(self.gas1_label)
        gas_group.addWidget(self.gas1_slider)
        gas_group.addWidget(self.gas2_label)
        gas_group.addWidget(self.gas2_slider)

        layout.addLayout(gas_group)

        # 센서 데이터 표시
        sensor_group = QVBoxLayout()
        sensor_group.addWidget(QLabel("센서 데이터"))

        self.temp_label = QLabel("Temperature: --°C")
        self.pressure_label = QLabel("Pressure: --T")

        sensor_group.addWidget(self.temp_label)
        sensor_group.addWidget(self.pressure_label)

        layout.addLayout(sensor_group)

    def setup_connections(self):
        """시그널 연결"""
        self.heater_slider.valueChanged.connect(self.on_heater_changed)
        self.gas1_slider.valueChanged.connect(self.on_gas1_changed)
        self.gas2_slider.valueChanged.connect(self.on_gas2_changed)

        self.equipment_3d.component_selected.connect(self.on_component_selected)
        self.equipment_3d.sensor_data_updated.connect(self.on_sensor_data_updated)

    def on_heater_changed(self, value):
        """히터 파워 변경"""
        self.heater_label.setText(f"Power: {value}W")
        self.equipment_3d.set_component_parameter('heater', 'power', value)

    def on_gas1_changed(self, value):
        """가스1 유량 변경"""
        self.gas1_label.setText(f"Gas 1: {value} sccm")
        self.equipment_3d.set_component_parameter('gas_inlet_1', 'flow_rate', value)

    def on_gas2_changed(self, value):
        """가스2 유량 변경"""
        self.gas2_label.setText(f"Gas 2: {value} sccm")
        self.equipment_3d.set_component_parameter('gas_inlet_2', 'flow_rate', value)

    def on_component_selected(self, component_name):
        """컴포넌트 선택 시"""
        print(f"Selected component: {component_name}")

    def on_sensor_data_updated(self, sensor_name, value):
        """센서 데이터 업데이트"""
        if sensor_name == 'chamber_temperature':
            self.temp_label.setText(f"Temperature: {value:.1f}°C")
        elif sensor_name == 'chamber_pressure':
            self.pressure_label.setText(f"Pressure: {value:.2f}T")

class Equipment3DViewer(QMainWindow):
    """3D 장비 뷰어 메인 윈도우"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("3D Equipment Viewer")
        self.setGeometry(100, 100, 1200, 800)

        # 중앙 위젯
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        # 레이아웃
        layout = QHBoxLayout(central_widget)

        # 3D 뷰
        self.equipment_3d = Interactive3DEquipment()

        # 제어 패널
        self.controller = Equipment3DController(self.equipment_3d)
        self.controller.setMaximumWidth(300)

        layout.addWidget(self.equipment_3d, 3)
        layout.addWidget(self.controller, 1)

# 메인 실행
if __name__ == "__main__":
    app = QApplication(sys.argv)

    window = Equipment3DViewer()
    window.show()

    sys.exit(app.exec())
```

</div>

#### **3.2 플러그인 아키텍처 시스템**

##### **3.2.1 동적 모듈 로딩 시스템**

<div class="plugin-architecture">

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
import importlib
import importlib.util
from abc import ABC, abstractmethod
from typing import Dict, List, Any, Optional
from PySide6.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout,
                               QWidget, QListWidget, QPushButton, QLabel, QTextEdit,
                               QSplitter, QGroupBox, QComboBox, QTabWidget)
from PySide6.QtCore import Qt, Signal, QObject, QThread
import json

class PluginInterface(ABC):
    """플러그인 인터페이스 기본 클래스"""

    @abstractmethod
    def get_name(self) -> str:
        """플러그인 이름 반환"""
        pass

    @abstractmethod
    def get_version(self) -> str:
        """플러그인 버전 반환"""
        pass

    @abstractmethod
    def get_description(self) -> str:
        """플러그인 설명 반환"""
        pass

    @abstractmethod
    def initialize(self, context: Dict[str, Any]) -> bool:
        """플러그인 초기화"""
        pass

    @abstractmethod
    def cleanup(self) -> None:
        """플러그인 정리"""
        pass

    @abstractmethod
    def get_widget(self) -> Optional[QWidget]:
        """플러그인 UI 위젯 반환"""
        pass

class DataProcessorPlugin(PluginInterface):
    """데이터 처리 플러그인 인터페이스"""

    @abstractmethod
    def process_data(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """데이터 처리"""
        pass

    @abstractmethod
    def get_supported_data_types(self) -> List[str]:
        """지원하는 데이터 타입 목록"""
        pass

class VisualizationPlugin(PluginInterface):
    """시각화 플러그인 인터페이스"""

    @abstractmethod
    def create_visualization(self, data: Dict[str, Any]) -> QWidget:
        """시각화 위젯 생성"""
        pass

    @abstractmethod
    def update_visualization(self, data: Dict[str, Any]) -> None:
        """시각화 업데이트"""
        pass

class CommunicationPlugin(PluginInterface):
    """통신 플러그인 인터페이스"""

    @abstractmethod
    def connect(self, config: Dict[str, Any]) -> bool:
        """연결 설정"""
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """연결 해제"""
        pass

    @abstractmethod
    def send_data(self, data: Dict[str, Any]) -> bool:
        """데이터 전송"""
        pass

    @abstractmethod
    def receive_data(self) -> Optional[Dict[str, Any]]:
        """데이터 수신"""
        pass

class PluginManager(QObject):
    """플러그인 관리자"""

    plugin_loaded = Signal(str)
    plugin_unloaded = Signal(str)
    plugin_error = Signal(str, str)

    def __init__(self):
        super().__init__()

        self.plugins: Dict[str, PluginInterface] = {}
        self.plugin_configs: Dict[str, Dict] = {}
        self.plugin_paths: List[str] = ["plugins/"]

        # 플러그인 카테고리별 관리
        self.data_processors: Dict[str, DataProcessorPlugin] = {}
        self.visualizers: Dict[str, VisualizationPlugin] = {}
        self.communicators: Dict[str, CommunicationPlugin] = {}

    def add_plugin_path(self, path: str):
        """플러그인 경로 추가"""
        if path not in self.plugin_paths:
            self.plugin_paths.append(path)

    def discover_plugins(self) -> List[str]:
        """플러그인 발견"""
        discovered = []

        for plugin_path in self.plugin_paths:
            if not os.path.exists(plugin_path):
                continue

            for item in os.listdir(plugin_path):
                item_path = os.path.join(plugin_path, item)

                if os.path.isdir(item_path):
                    # 디렉토리 형태 플러그인
                    plugin_file = os.path.join(item_path, "plugin.py")
                    if os.path.exists(plugin_file):
                        discovered.append(plugin_file)

                elif item.endswith(".py") and item != "__init__.py":
                    # 단일 파일 플러그인
                    discovered.append(item_path)

        return discovered

    def load_plugin(self, plugin_path: str) -> bool:
        """플러그인 로드"""
        try:
            # 모듈 이름 생성
            module_name = os.path.splitext(os.path.basename(plugin_path))[0]

            # 모듈 스펙 생성
            spec = importlib.util.spec_from_file_location(module_name, plugin_path)
            if spec is None or spec.loader is None:
                raise ImportError(f"Cannot load plugin spec from {plugin_path}")

            # 모듈 생성 및 실행
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # 플러그인 클래스 찾기
            plugin_class = None
            for attr_name in dir(module):
                attr = getattr(module, attr_name)
                if (isinstance(attr, type) and
                    issubclass(attr, PluginInterface) and
                    attr != PluginInterface):
                    plugin_class = attr
                    break

            if plugin_class is None:
                raise ImportError("No valid plugin class found")

            # 플러그인 인스턴스 생성
            plugin_instance = plugin_class()

            # 플러그인 초기화
            context = {
                'plugin_manager': self,
                'config': self.plugin_configs.get(plugin_instance.get_name(), {})
            }

            if not plugin_instance.initialize(context):
                raise RuntimeError("Plugin initialization failed")

            # 플러그인 등록
            plugin_name = plugin_instance.get_name()
            self.plugins[plugin_name] = plugin_instance

            # 카테고리별 등록
            if isinstance(plugin_instance, DataProcessorPlugin):
                self.data_processors[plugin_name] = plugin_instance
            elif isinstance(plugin_instance, VisualizationPlugin):
                self.visualizers[plugin_name] = plugin_instance
            elif isinstance(plugin_instance, CommunicationPlugin):
                self.communicators[plugin_name] = plugin_instance

            self.plugin_loaded.emit(plugin_name)
            return True

        except Exception as e:
            error_msg = f"Failed to load plugin {plugin_path}: {str(e)}"
            self.plugin_error.emit(plugin_path, error_msg)
            return False

    def unload_plugin(self, plugin_name: str) -> bool:
        """플러그인 언로드"""
        try:
            if plugin_name not in self.plugins:
                return False

            plugin = self.plugins[plugin_name]

            # 플러그인 정리
            plugin.cleanup()

            # 카테고리별 제거
            if plugin_name in self.data_processors:
                del self.data_processors[plugin_name]
            elif plugin_name in self.visualizers:
                del self.visualizers[plugin_name]
            elif plugin_name in self.communicators:
                del self.communicators[plugin_name]

            # 메인 목록에서 제거
            del self.plugins[plugin_name]

            self.plugin_unloaded.emit(plugin_name)
            return True

        except Exception as e:
            error_msg = f"Failed to unload plugin {plugin_name}: {str(e)}"
            self.plugin_error.emit(plugin_name, error_msg)
            return False

    def get_plugin(self, plugin_name: str) -> Optional[PluginInterface]:
        """플러그인 인스턴스 반환"""
        return self.plugins.get(plugin_name)

    def get_plugins_by_type(self, plugin_type: type) -> Dict[str, PluginInterface]:
        """타입별 플러그인 목록 반환"""
        result = {}
        for name, plugin in self.plugins.items():
            if isinstance(plugin, plugin_type):
                result[name] = plugin
        return result

    def load_plugin_config(self, config_path: str):
        """플러그인 설정 로드"""
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                self.plugin_configs = json.load(f)
        except Exception as e:
            print(f"Failed to load plugin config: {e}")

    def save_plugin_config(self, config_path: str):
        """플러그인 설정 저장"""
        try:
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(self.plugin_configs, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Failed to save plugin config: {e}")

    def process_data_with_plugins(self, data: Dict[str, Any], data_type: str) -> Dict[str, Any]:
        """데이터 처리 플러그인들로 데이터 처리"""
        result = data.copy()

        for processor in self.data_processors.values():
            if data_type in processor.get_supported_data_types():
                try:
                    result = processor.process_data(result)
                except Exception as e:
                    error_msg = f"Data processing error in {processor.get_name()}: {str(e)}"
                    self.plugin_error.emit(processor.get_name(), error_msg)

        return result

class PluginManagerWidget(QWidget):
    """플러그인 관리자 UI"""

    def __init__(self, plugin_manager: PluginManager, parent=None):
        super().__init__(parent)
        self.plugin_manager = plugin_manager
        self.setup_ui()
        self.setup_connections()

    def setup_ui(self):
        """UI 설정"""
        layout = QVBoxLayout(self)

        # 플러그인 발견 및 로드
        discovery_layout = QHBoxLayout()

        self.discover_button = QPushButton("플러그인 검색")
        self.load_button = QPushButton("선택된 플러그인 로드")
        self.unload_button = QPushButton("선택된 플러그인 언로드")

        discovery_layout.addWidget(self.discover_button)
        discovery_layout.addWidget(self.load_button)
        discovery_layout.addWidget(self.unload_button)
        discovery_layout.addStretch()

        layout.addLayout(discovery_layout)

        # 플러그인 목록
        splitter = QSplitter(Qt.Horizontal)

        # 발견된 플러그인 목록
        discovered_group = QGroupBox("발견된 플러그인")
        discovered_layout = QVBoxLayout(discovered_group)

        self.discovered_list = QListWidget()
        discovered_layout.addWidget(self.discovered_list)

        splitter.addWidget(discovered_group)

        # 로드된 플러그인 목록
        loaded_group = QGroupBox("로드된 플러그인")
        loaded_layout = QVBoxLayout(loaded_group)

        self.loaded_list = QListWidget()
        loaded_layout.addWidget(self.loaded_list)

        # 플러그인 상세 정보
        self.plugin_info = QTextEdit()
        self.plugin_info.setMaximumHeight(100)
        loaded_layout.addWidget(QLabel("플러그인 정보:"))
        loaded_layout.addWidget(self.plugin_info)

        splitter.addWidget(loaded_group)

        layout.addWidget(splitter)

        # 플러그인 카테고리별 탭
        self.plugin_tabs = QTabWidget()

        # 데이터 처리 탭
        self.data_processor_tab = QWidget()
        data_processor_layout = QVBoxLayout(self.data_processor_tab)
        self.data_processor_list = QListWidget()
        data_processor_layout.addWidget(self.data_processor_list)
        self.plugin_tabs.addTab(self.data_processor_tab, "데이터 처리")

        # 시각화 탭
        self.visualization_tab = QWidget()
        visualization_layout = QVBoxLayout(self.visualization_tab)
        self.visualization_list = QListWidget()
        visualization_layout.addWidget(self.visualization_list)
        self.plugin_tabs.addTab(self.visualization_tab, "시각화")

        # 통신 탭
        self.communication_tab = QWidget()
        communication_layout = QVBoxLayout(self.communication_tab)
        self.communication_list = QListWidget()
        communication_layout.addWidget(self.communication_list)
        self.plugin_tabs.addTab(self.communication_tab, "통신")

        layout.addWidget(self.plugin_tabs)

    def setup_connections(self):
        """시그널 연결"""
        self.discover_button.clicked.connect(self.discover_plugins)
        self.load_button.clicked.connect(self.load_selected_plugin)
        self.unload_button.clicked.connect(self.unload_selected_plugin)

        self.loaded_list.currentItemChanged.connect(self.on_plugin_selected)

        self.plugin_manager.plugin_loaded.connect(self.on_plugin_loaded)
        self.plugin_manager.plugin_unloaded.connect(self.on_plugin_unloaded)
        self.plugin_manager.plugin_error.connect(self.on_plugin_error)

    def discover_plugins(self):
        """플러그인 검색"""
        self.discovered_list.clear()

        plugins = self.plugin_manager.discover_plugins()
        for plugin_path in plugins:
            plugin_name = os.path.basename(plugin_path)
            self.discovered_list.addItem(f"{plugin_name} ({plugin_path})")

    def load_selected_plugin(self):
        """선택된 플러그인 로드"""
        current_item = self.discovered_list.currentItem()
        if current_item:
            # 경로 추출
            text = current_item.text()
            plugin_path = text.split(" (")[1].rstrip(")")

            self.plugin_manager.load_plugin(plugin_path)

    def unload_selected_plugin(self):
        """선택된 플러그인 언로드"""
        current_item = self.loaded_list.currentItem()
        if current_item:
            plugin_name = current_item.text().split(" - ")[0]
            self.plugin_manager.unload_plugin(plugin_name)

    def on_plugin_loaded(self, plugin_name):
        """플러그인 로드됨"""
        plugin = self.plugin_manager.get_plugin(plugin_name)
        if plugin:
            item_text = f"{plugin_name} - {plugin.get_version()}"
            self.loaded_list.addItem(item_text)

            # 카테고리별 목록 업데이트
            if isinstance(plugin, DataProcessorPlugin):
                self.data_processor_list.addItem(plugin_name)
            elif isinstance(plugin, VisualizationPlugin):
                self.visualization_list.addItem(plugin_name)
            elif isinstance(plugin, CommunicationPlugin):
                self.communication_list.addItem(plugin_name)

    def on_plugin_unloaded(self, plugin_name):
        """플러그인 언로드됨"""
        # 로드된 목록에서 제거
        for i in range(self.loaded_list.count()):
            item = self.loaded_list.item(i)
            if item.text().startswith(plugin_name):
                self.loaded_list.takeItem(i)
                break

        # 카테고리별 목록에서 제거
        for list_widget in [self.data_processor_list, self.visualization_list, self.communication_list]:
            for i in range(list_widget.count()):
                item = list_widget.item(i)
                if item.text() == plugin_name:
                    list_widget.takeItem(i)
                    break

    def on_plugin_error(self, plugin_name, error_message):
        """플러그인 오류"""
        print(f"Plugin Error [{plugin_name}]: {error_message}")

    def on_plugin_selected(self, current, previous):
        """플러그인 선택됨"""
        if current:
            plugin_name = current.text().split(" - ")[0]
            plugin = self.plugin_manager.get_plugin(plugin_name)

            if plugin:
                info_text = f"""
이름: {plugin.get_name()}
버전: {plugin.get_version()}
설명: {plugin.get_description()}
타입: {type(plugin).__name__}
"""
                self.plugin_info.setText(info_text)

class ModularHMISystem(QMainWindow):
    """모듈형 HMI 시스템"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("모듈형 HMI 시스템")
        self.setGeometry(100, 100, 1400, 900)

        # 플러그인 매니저 초기화
        self.plugin_manager = PluginManager()

        # 플러그인 디렉토리 생성
        self.create_plugin_directories()

        # 샘플 플러그인 생성
        self.create_sample_plugins()

        self.setup_ui()

    def create_plugin_directories(self):
        """플러그인 디렉토리 생성"""
        os.makedirs("plugins", exist_ok=True)

    def create_sample_plugins(self):
        """샘플 플러그인 생성"""
        # 간단한 데이터 필터 플러그인
        sample_plugin_code = '''
from plugin_interfaces import DataProcessorPlugin
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel

class SimpleFilterPlugin(DataProcessorPlugin):
    def get_name(self):
        return "Simple Data Filter"

    def get_version(self):
        return "1.0.0"

    def get_description(self):
        return "간단한 데이터 필터링 플러그인"

    def initialize(self, context):
        return True

    def cleanup(self):
        pass

    def get_widget(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.addWidget(QLabel("Simple Filter Plugin"))
        return widget

    def process_data(self, data):
        # 간단한 필터링 로직
        filtered_data = data.copy()
        for key, value in data.items():
            if isinstance(value, (int, float)):
                # 이상치 제거 (간단한 예)
                if abs(value) > 1000:
                    filtered_data[key] = 0
        return filtered_data

    def get_supported_data_types(self):
        return ["sensor_data", "process_data"]
'''

        # 플러그인 파일 생성
        with open("plugins/simple_filter.py", "w", encoding="utf-8") as f:
            f.write(sample_plugin_code)

    def setup_ui(self):
        """UI 설정"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QHBoxLayout(central_widget)

        # 플러그인 관리자 UI
        plugin_manager_widget = PluginManagerWidget(self.plugin_manager)
        plugin_manager_widget.setMaximumWidth(600)

        # 메인 작업 영역
        work_area = QWidget()
        work_layout = QVBoxLayout(work_area)
        work_layout.addWidget(QLabel("메인 작업 영역"))
        work_layout.addWidget(QLabel("여기에 플러그인들이 통합됩니다"))

        layout.addWidget(plugin_manager_widget, 1)
        layout.addWidget(work_area, 2)

# 메인 실행
if __name__ == "__main__":
    app = QApplication(sys.argv)

    window = ModularHMISystem()
    window.show()

    sys.exit(app.exec())
```

</div>

---

## 4️⃣ Hands-on 실습
### 🚀 **통합 모듈형 HMI 플랫폼 구축**

#### **4.1 최종 프로젝트 개요**

<div class="final-project">

**🎯 목표**: 모든 고급 기능을 통합한 완전한 모듈형 HMI 플랫폼 구축

**📋 핵심 구성요소**:
- 커스텀 위젯 기반 전문적 UI
- 3D 시각화를 통한 직관적 장비 모니터링
- 플러그인 시스템을 통한 확장 가능성
- 국제화 및 테마 지원
- 고성능 실시간 데이터 처리

</div>

#### **4.2 통합 플랫폼 구현**

##### **4.2.1 메인 플랫폼 클래스**

<div class="integrated-platform">

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import os
from datetime import datetime
from PySide6.QtWidgets import (QApplication, QMainWindow, QVBoxLayout, QHBoxLayout,
                               QWidget, QMenuBar, QStatusBar, QDockWidget, QTabWidget,
                               QSplitter, QToolBar, QAction, QLabel, QPushButton,
                               QMessageBox, QFileDialog, QProgressBar)
from PySide6.QtCore import Qt, QTimer, Signal, QSettings, QTranslator, QLocale
from PySide6.QtGui import QIcon, QFont, QPixmap, QActionGroup

# 이전에 구현한 클래스들 import
from advanced_3d_equipment import Interactive3DEquipment, Equipment3DController
from plugin_manager import PluginManager, PluginManagerWidget
from advanced_trend_chart import AdvancedTrendChart
from process_flow_diagram import ProcessFlowDiagram, ProcessControlPanel
from industrial_gauge import IndustrialGauge

class AdvancedHMIPlatform(QMainWindow):
    """통합 고급 HMI 플랫폼"""

    # 시그널 정의
    data_updated = Signal(dict)
    equipment_status_changed = Signal(str, str)
    alarm_triggered = Signal(dict)

    def __init__(self):
        super().__init__()

        # 애플리케이션 설정
        self.settings = QSettings("SemiconductorHMI", "AdvancedPlatform")

        # 국제화 설정
        self.translator = QTranslator()
        self.current_language = "ko"

        # 플러그인 시스템
        self.plugin_manager = PluginManager()

        # UI 컴포넌트들
        self.main_tabs = None
        self.status_widgets = {}
        self.charts = {}
        self.equipment_3d = None

        # 데이터 관리
        self.equipment_data = {}
        self.alarm_history = []

        # 타이머들
        self.data_timer = QTimer()
        self.status_timer = QTimer()

        self.setup_ui()
        self.setup_menus()
        self.setup_toolbars()
        self.setup_status_bar()
        self.setup_dock_widgets()
        self.load_settings()
        self.setup_connections()

        # 초기화 완료
        self.statusBar().showMessage("고급 HMI 플랫폼 준비 완료", 3000)

    def setup_ui(self):
        """메인 UI 설정"""
        self.setWindowTitle("고급 반도체 HMI 플랫폼 v2.0")
        self.setGeometry(100, 100, 1600, 1000)

        # 중앙 위젯 - 탭 기반 인터페이스
        self.main_tabs = QTabWidget()
        self.setCentralWidget(self.main_tabs)

        # 1. 실시간 모니터링 탭
        self.create_monitoring_tab()

        # 2. 3D 시각화 탭
        self.create_3d_visualization_tab()

        # 3. 프로세스 플로우 탭
        self.create_process_flow_tab()

        # 4. 데이터 분석 탭
        self.create_data_analysis_tab()

        # 5. 플러그인 관리 탭
        self.create_plugin_management_tab()

    def create_monitoring_tab(self):
        """실시간 모니터링 탭 생성"""
        monitoring_widget = QWidget()
        layout = QHBoxLayout(monitoring_widget)

        # 좌측 - 게이지 패널
        gauge_panel = self.create_gauge_panel()

        # 우측 - 차트 패널
        chart_panel = self.create_chart_panel()

        # 스플리터로 구성
        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(gauge_panel)
        splitter.addWidget(chart_panel)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 2)

        layout.addWidget(splitter)
        self.main_tabs.addTab(monitoring_widget, "실시간 모니터링")

    def create_gauge_panel(self):
        """게이지 패널 생성"""
        panel = QWidget()
        layout = QVBoxLayout(panel)

        # 온도 게이지
        temp_gauge = IndustrialGauge()
        temp_gauge.setRange(0, 500)
        temp_gauge.setThresholds(300, 400)
        temp_gauge.setValue(25)
        self.status_widgets['temperature'] = temp_gauge

        # 압력 게이지
        pressure_gauge = IndustrialGauge()
        pressure_gauge.setRange(0, 20)
        pressure_gauge.setThresholds(15, 18)
        pressure_gauge.setValue(1)
        self.status_widgets['pressure'] = pressure_gauge

        # 유량 게이지
        flow_gauge = IndustrialGauge()
        flow_gauge.setRange(0, 300)
        flow_gauge.setThresholds(250, 280)
        flow_gauge.setValue(0)
        self.status_widgets['flow'] = flow_gauge

        layout.addWidget(QLabel("챔버 온도"))
        layout.addWidget(temp_gauge)
        layout.addWidget(QLabel("챔버 압력"))
        layout.addWidget(pressure_gauge)
        layout.addWidget(QLabel("가스 유량"))
        layout.addWidget(flow_gauge)
        layout.addStretch()

        return panel

    def create_chart_panel(self):
        """차트 패널 생성"""
        panel = QWidget()
        layout = QVBoxLayout(panel)

        # 온도 트렌드 차트
        temp_chart = AdvancedTrendChart("온도 트렌드")
        temp_chart.add_series("챔버온도", warning_threshold=350, critical_threshold=400)
        self.charts['temperature'] = temp_chart

        # 압력 트렌드 차트
        pressure_chart = AdvancedTrendChart("압력 트렌드")
        pressure_chart.add_series("챔버압력", warning_threshold=15, critical_threshold=18)
        self.charts['pressure'] = pressure_chart

        # 차트 탭 위젯
        chart_tabs = QTabWidget()
        chart_tabs.addTab(temp_chart, "온도")
        chart_tabs.addTab(pressure_chart, "압력")

        layout.addWidget(chart_tabs)
        return panel

    def create_3d_visualization_tab(self):
        """3D 시각화 탭 생성"""
        viz_widget = QWidget()
        layout = QHBoxLayout(viz_widget)

        # 3D 뷰
        self.equipment_3d = Interactive3DEquipment()

        # 3D 제어 패널
        controller_3d = Equipment3DController(self.equipment_3d)

        layout.addWidget(self.equipment_3d, 3)
        layout.addWidget(controller_3d, 1)

        self.main_tabs.addTab(viz_widget, "3D 시각화")

    def create_process_flow_tab(self):
        """프로세스 플로우 탭 생성"""
        flow_widget = QWidget()
        layout = QHBoxLayout(flow_widget)

        # 플로우 다이어그램
        flow_diagram = ProcessFlowDiagram()

        # 제어 패널
        control_panel = ProcessControlPanel(flow_diagram)

        layout.addWidget(flow_diagram, 3)
        layout.addWidget(control_panel, 1)

        self.main_tabs.addTab(flow_widget, "프로세스 플로우")

    def create_data_analysis_tab(self):
        """데이터 분석 탭 생성"""
        analysis_widget = QWidget()
        layout = QVBoxLayout(analysis_widget)

        # 분석 도구들
        tools_layout = QHBoxLayout()

        export_button = QPushButton("데이터 내보내기")
        export_button.clicked.connect(self.export_data)

        import_button = QPushButton("데이터 가져오기")
        import_button.clicked.connect(self.import_data)

        analyze_button = QPushButton("통계 분석")
        analyze_button.clicked.connect(self.analyze_data)

        tools_layout.addWidget(export_button)
        tools_layout.addWidget(import_button)
        tools_layout.addWidget(analyze_button)
        tools_layout.addStretch()

        layout.addLayout(tools_layout)

        # 분석 결과 표시 영역
        analysis_display = QLabel("분석 결과가 여기에 표시됩니다.")
        analysis_display.setMinimumHeight(400)
        analysis_display.setStyleSheet("border: 1px solid gray; background-color: white;")
        layout.addWidget(analysis_display)

        self.main_tabs.addTab(analysis_widget, "데이터 분석")

    def create_plugin_management_tab(self):
        """플러그인 관리 탭 생성"""
        plugin_widget = PluginManagerWidget(self.plugin_manager)
        self.main_tabs.addTab(plugin_widget, "플러그인 관리")

    def setup_menus(self):
        """메뉴 설정"""
        menubar = self.menuBar()

        # 파일 메뉴
        file_menu = menubar.addMenu("파일")

        new_action = QAction("새 프로젝트", self)
        new_action.setShortcut("Ctrl+N")
        new_action.triggered.connect(self.new_project)
        file_menu.addAction(new_action)

        open_action = QAction("프로젝트 열기", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self.open_project)
        file_menu.addAction(open_action)

        save_action = QAction("프로젝트 저장", self)
        save_action.setShortcut("Ctrl+S")
        save_action.triggered.connect(self.save_project)
        file_menu.addAction(save_action)

        file_menu.addSeparator()

        exit_action = QAction("종료", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)

        # 보기 메뉴
        view_menu = menubar.addMenu("보기")

        # 테마 선택
        theme_menu = view_menu.addMenu("테마")
        self.theme_group = QActionGroup(self)

        themes = [("기본", "default"), ("다크", "dark"), ("산업용", "industrial")]
        for name, theme_id in themes:
            action = QAction(name, self)
            action.setCheckable(True)
            action.setData(theme_id)
            action.triggered.connect(lambda checked, t=theme_id: self.change_theme(t))
            self.theme_group.addAction(action)
            theme_menu.addAction(action)

        # 언어 선택
        language_menu = view_menu.addMenu("언어")
        self.language_group = QActionGroup(self)

        languages = [("한국어", "ko"), ("English", "en"), ("日本語", "ja")]
        for name, lang_code in languages:
            action = QAction(name, self)
            action.setCheckable(True)
            action.setData(lang_code)
            action.triggered.connect(lambda checked, l=lang_code: self.change_language(l))
            self.language_group.addAction(action)
            language_menu.addAction(action)

        # 도구 메뉴
        tools_menu = menubar.addMenu("도구")

        calibration_action = QAction("센서 캘리브레이션", self)
        calibration_action.triggered.connect(self.calibrate_sensors)
        tools_menu.addAction(calibration_action)

        maintenance_action = QAction("유지보수 모드", self)
        maintenance_action.triggered.connect(self.enter_maintenance_mode)
        tools_menu.addAction(maintenance_action)

        # 도움말 메뉴
        help_menu = menubar.addMenu("도움말")

        about_action = QAction("정보", self)
        about_action.triggered.connect(self.show_about)
        help_menu.addAction(about_action)

    def setup_toolbars(self):
        """툴바 설정"""
        # 메인 툴바
        main_toolbar = QToolBar("메인")
        self.addToolBar(main_toolbar)

        # 시작/중지 버튼
        start_action = QAction("시작", self)
        start_action.setIcon(QIcon("icons/start.png"))
        start_action.triggered.connect(self.start_monitoring)
        main_toolbar.addAction(start_action)

        stop_action = QAction("중지", self)
        stop_action.setIcon(QIcon("icons/stop.png"))
        stop_action.triggered.connect(self.stop_monitoring)
        main_toolbar.addAction(stop_action)

        main_toolbar.addSeparator()

        # 비상 정지
        emergency_action = QAction("비상 정지", self)
        emergency_action.setIcon(QIcon("icons/emergency.png"))
        emergency_action.triggered.connect(self.emergency_stop)
        main_toolbar.addAction(emergency_action)

        main_toolbar.addSeparator()

        # 스크린샷
        screenshot_action = QAction("스크린샷", self)
        screenshot_action.triggered.connect(self.take_screenshot)
        main_toolbar.addAction(screenshot_action)

    def setup_status_bar(self):
        """상태바 설정"""
        status_bar = QStatusBar()
        self.setStatusBar(status_bar)

        # 연결 상태
        self.connection_label = QLabel("연결: 대기")
        status_bar.addPermanentWidget(self.connection_label)

        # 데이터 수집 상태
        self.data_status_label = QLabel("데이터: 대기")
        status_bar.addPermanentWidget(self.data_status_label)

        # 시간 표시
        self.time_label = QLabel()
        status_bar.addPermanentWidget(self.time_label)

        # 진행률 바
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        status_bar.addPermanentWidget(self.progress_bar)

    def setup_dock_widgets(self):
        """도킹 위젯 설정"""
        # 알람 히스토리 도크
        alarm_dock = QDockWidget("알람 히스토리", self)
        alarm_widget = QWidget()
        alarm_layout = QVBoxLayout(alarm_widget)

        from PySide6.QtWidgets import QListWidget
        self.alarm_list = QListWidget()
        alarm_layout.addWidget(self.alarm_list)

        alarm_dock.setWidget(alarm_widget)
        self.addDockWidget(Qt.RightDockWidgetArea, alarm_dock)

        # 시스템 로그 도크
        log_dock = QDockWidget("시스템 로그", self)
        log_widget = QWidget()
        log_layout = QVBoxLayout(log_widget)

        from PySide6.QtWidgets import QTextEdit
        self.log_text = QTextEdit()
        self.log_text.setMaximumHeight(150)
        log_layout.addWidget(self.log_text)

        log_dock.setWidget(log_widget)
        self.addDockWidget(Qt.BottomDockWidgetArea, log_dock)

    def setup_connections(self):
        """시그널 연결"""
        # 데이터 타이머
        self.data_timer.timeout.connect(self.update_data)

        # 상태 타이머
        self.status_timer.timeout.connect(self.update_status)
        self.status_timer.start(1000)  # 1초마다

        # 플러그인 매니저 연결
        self.plugin_manager.plugin_loaded.connect(self.on_plugin_loaded)
        self.plugin_manager.plugin_error.connect(self.on_plugin_error)

        # 알람 연결
        self.alarm_triggered.connect(self.handle_alarm)

        # 3D 장비 연결
        if self.equipment_3d:
            self.equipment_3d.sensor_data_updated.connect(self.update_sensor_display)

    def start_monitoring(self):
        """모니터링 시작"""
        self.data_timer.start(100)  # 100ms 간격
        self.connection_label.setText("연결: 활성")
        self.data_status_label.setText("데이터: 수집 중")
        self.log_message("모니터링 시작됨")

    def stop_monitoring(self):
        """모니터링 중지"""
        self.data_timer.stop()
        self.connection_label.setText("연결: 대기")
        self.data_status_label.setText("데이터: 대기")
        self.log_message("모니터링 중지됨")

    def emergency_stop(self):
        """비상 정지"""
        self.data_timer.stop()
        self.connection_label.setText("연결: 비상정지")
        self.data_status_label.setText("데이터: 정지")

        # 모든 장비 비상 정지
        if self.equipment_3d:
            for comp_name in self.equipment_3d.equipment_components:
                self.equipment_3d.set_component_parameter(comp_name, 'power', 0)

        self.log_message("⚠️ 비상 정지 활성화")

    def update_data(self):
        """데이터 업데이트"""
        import random

        # 시뮬레이션 데이터 생성
        temp = 25 + random.uniform(-50, 400)
        pressure = 1 + random.uniform(-0.5, 15)
        flow = random.uniform(0, 250)

        # 게이지 업데이트
        if 'temperature' in self.status_widgets:
            self.status_widgets['temperature'].setValue(temp)
        if 'pressure' in self.status_widgets:
            self.status_widgets['pressure'].setValue(pressure)
        if 'flow' in self.status_widgets:
            self.status_widgets['flow'].setValue(flow)

        # 차트 업데이트
        if 'temperature' in self.charts:
            self.charts['temperature'].add_data_point("챔버온도", temp)
        if 'pressure' in self.charts:
            self.charts['pressure'].add_data_point("챔버압력", pressure)

        # 알람 체크
        if temp > 400:
            self.trigger_alarm("온도 과열", f"온도가 {temp:.1f}°C로 임계값을 초과했습니다.", "critical")
        elif temp > 350:
            self.trigger_alarm("온도 경고", f"온도가 {temp:.1f}°C로 경고 수준입니다.", "warning")

    def update_status(self):
        """상태 업데이트"""
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.time_label.setText(current_time)

    def update_sensor_display(self, sensor_name, value):
        """센서 디스플레이 업데이트"""
        if sensor_name in self.status_widgets:
            self.status_widgets[sensor_name].setValue(value)

    def trigger_alarm(self, title, message, severity):
        """알람 발생"""
        alarm_data = {
            'title': title,
            'message': message,
            'severity': severity,
            'timestamp': datetime.now()
        }

        self.alarm_triggered.emit(alarm_data)

    def handle_alarm(self, alarm_data):
        """알람 처리"""
        # 알람 히스토리에 추가
        self.alarm_history.append(alarm_data)

        # 알람 리스트 업데이트
        timestamp = alarm_data['timestamp'].strftime("%H:%M:%S")
        severity_icon = "🔴" if alarm_data['severity'] == "critical" else "🟡"
        item_text = f"{severity_icon} [{timestamp}] {alarm_data['title']}"
        self.alarm_list.addItem(item_text)

        # 로그 메시지
        self.log_message(f"알람: {alarm_data['title']} - {alarm_data['message']}")

    def log_message(self, message):
        """로그 메시지 추가"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.log_text.append(f"[{timestamp}] {message}")

    def change_theme(self, theme_id):
        """테마 변경"""
        themes = {
            'default': "",
            'dark': """
                QMainWindow { background-color: #2b2b2b; color: white; }
                QWidget { background-color: #2b2b2b; color: white; }
                QTabWidget::pane { background-color: #3c3c3c; }
                QTabBar::tab { background-color: #4a4a4a; color: white; padding: 8px; }
                QTabBar::tab:selected { background-color: #5a5a5a; }
            """,
            'industrial': """
                QMainWindow { background-color: #1a1a2e; color: #eee; }
                QWidget { background-color: #1a1a2e; color: #eee; }
                QPushButton { background-color: #16213e; border: 2px solid #0f3460;
                             color: #eee; padding: 8px; border-radius: 4px; }
                QPushButton:hover { background-color: #0f3460; }
            """
        }

        self.setStyleSheet(themes.get(theme_id, ""))
        self.settings.setValue("theme", theme_id)

    def change_language(self, language_code):
        """언어 변경"""
        self.current_language = language_code
        self.settings.setValue("language", language_code)

        # 실제 번역 적용 (간단한 예시)
        if language_code == "en":
            self.setWindowTitle("Advanced Semiconductor HMI Platform v2.0")
        elif language_code == "ja":
            self.setWindowTitle("高度半導体HMIプラットフォーム v2.0")
        else:
            self.setWindowTitle("고급 반도체 HMI 플랫폼 v2.0")

    def load_settings(self):
        """설정 로드"""
        # 윈도우 크기 및 위치
        geometry = self.settings.value("geometry")
        if geometry:
            self.restoreGeometry(geometry)

        # 테마
        theme = self.settings.value("theme", "default")
        self.change_theme(theme)

        # 언어
        language = self.settings.value("language", "ko")
        self.change_language(language)

    def save_settings(self):
        """설정 저장"""
        self.settings.setValue("geometry", self.saveGeometry())

    def new_project(self):
        """새 프로젝트"""
        self.log_message("새 프로젝트 생성")

    def open_project(self):
        """프로젝트 열기"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "프로젝트 열기", "", "HMI Project Files (*.hmi)"
        )
        if file_path:
            self.log_message(f"프로젝트 열기: {file_path}")

    def save_project(self):
        """프로젝트 저장"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "프로젝트 저장", "", "HMI Project Files (*.hmi)"
        )
        if file_path:
            self.log_message(f"프로젝트 저장: {file_path}")

    def export_data(self):
        """데이터 내보내기"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "데이터 내보내기", "", "CSV Files (*.csv);;JSON Files (*.json)"
        )
        if file_path:
            self.log_message(f"데이터 내보내기: {file_path}")

    def import_data(self):
        """데이터 가져오기"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "데이터 가져오기", "", "CSV Files (*.csv);;JSON Files (*.json)"
        )
        if file_path:
            self.log_message(f"데이터 가져오기: {file_path}")

    def analyze_data(self):
        """데이터 분석"""
        self.log_message("데이터 분석 시작")

        # 진행률 바 표시
        self.progress_bar.setVisible(True)
        self.progress_bar.setValue(0)

        # 분석 시뮬레이션
        for i in range(101):
            self.progress_bar.setValue(i)
            QApplication.processEvents()

        self.progress_bar.setVisible(False)
        self.log_message("데이터 분석 완료")

    def calibrate_sensors(self):
        """센서 캘리브레이션"""
        reply = QMessageBox.question(
            self, "센서 캘리브레이션",
            "센서 캘리브레이션을 시작하시겠습니까?",
            QMessageBox.Yes | QMessageBox.No
        )

        if reply == QMessageBox.Yes:
            self.log_message("센서 캘리브레이션 시작")

    def enter_maintenance_mode(self):
        """유지보수 모드 진입"""
        self.log_message("유지보수 모드 진입")

    def take_screenshot(self):
        """스크린샷 촬영"""
        pixmap = self.grab()
        file_path, _ = QFileDialog.getSaveFileName(
            self, "스크린샷 저장",
            f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png",
            "PNG Files (*.png)"
        )

        if file_path:
            pixmap.save(file_path)
            self.log_message(f"스크린샷 저장: {file_path}")

    def show_about(self):
        """정보 대화상자"""
        QMessageBox.about(
            self, "정보",
            "고급 반도체 HMI 플랫폼 v2.0\n\n"
            "Python PySide6 기반 모듈형 HMI 시스템\n"
            "© 2024 Semiconductor Manufacturing Co."
        )

    def on_plugin_loaded(self, plugin_name):
        """플러그인 로드됨"""
        self.log_message(f"플러그인 로드됨: {plugin_name}")

    def on_plugin_error(self, plugin_name, error_message):
        """플러그인 오류"""
        self.log_message(f"플러그인 오류 [{plugin_name}]: {error_message}")

    def closeEvent(self, event):
        """윈도우 종료 이벤트"""
        self.save_settings()

        # 데이터 수집 중지
        self.data_timer.stop()
        self.status_timer.stop()

        event.accept()

# 메인 실행
def main():
    app = QApplication(sys.argv)

    # 애플리케이션 정보 설정
    app.setApplicationName("Advanced HMI Platform")
    app.setApplicationVersion("2.0")
    app.setOrganizationName("Semiconductor Manufacturing Co.")

    # 메인 윈도우 생성 및 표시
    window = AdvancedHMIPlatform()
    window.show()

    return app.exec()

if __name__ == "__main__":
    sys.exit(main())
```

</div>

#### **4.3 실습 과제 및 평가**

##### **🎯 실습 과제**

<div class="assignments">

**Phase 1: 플랫폼 통합**
1. **기본 플랫폼 실행**: 통합 HMI 플랫폼 실행 및 기본 기능 확인
2. **플러그인 시스템**: 샘플 플러그인 로드 및 동작 확인
3. **3D 시각화**: 3D 장비 모델과 실시간 데이터 연동 확인

**Phase 2: 고급 기능 구현**
1. **커스텀 위젯**: 새로운 산업용 위젯 개발 및 통합
2. **데이터 처리**: 플러그인을 통한 고급 데이터 분석 기능 추가
3. **테마 시스템**: 다크 모드 및 산업용 테마 구현

**Phase 3: 최적화 및 확장**
1. **성능 최적화**: 대용량 데이터 처리 성능 개선
2. **국제화**: 다국어 지원 기능 완성
3. **배포 준비**: 실제 배포를 위한 패키징 설정

</div>

##### **📊 평가 기준**

<div class="evaluation">

**💯 평가 항목**:
- **아키텍처 설계 (30%)**: 모듈성, 확장성, 유지보수성
- **기능 구현 (30%)**: 요구사항 충족도, 완성도, 안정성
- **사용자 경험 (25%)**: UI/UX 품질, 직관성, 전문성
- **코드 품질 (15%)**: 구조화, 문서화, 최적화

**🏆 우수 기준**:
- 실제 산업 환경에서 사용 가능한 수준의 완성도
- 플러그인을 통한 확장 가능한 아키텍처 구현
- 직관적이고 전문적인 3D 시각화 구현
- 다국어 및 테마 지원을 통한 사용자 맞춤형 환경

</div>

---

## 📝 **학습 정리 및 다음 주차 예고**

### **🎓 오늘 학습한 핵심 내용**
1. **커스텀 위젯 개발**: QPainter 활용한 전문적 산업용 UI 컴포넌트
2. **고급 3D 시각화**: OpenGL 기반 인터랙티브 장비 모델링
3. **플러그인 아키텍처**: 동적 모듈 로딩을 통한 확장 가능한 시스템
4. **통합 플랫폼**: 모든 고급 기능이 통합된 모듈형 HMI 시스템
5. **국제화 및 테마**: 다국어 지원 및 사용자 맞춤형 테마 시스템

### **🔄 Python PySide6 고급 기능 완성도**
| 기능 영역 | 완성도 | 실제 적용 가능성 |
|----------|--------|-----------------|
| **커스텀 위젯** | 95% | 산업용 수준 |
| **3D 시각화** | 90% | 고급 모니터링 |
| **플러그인 시스템** | 85% | 확장성 확보 |
| **성능 최적화** | 90% | 대용량 처리 |
| **사용자 경험** | 95% | 전문적 UI/UX |

### **📅 다음 주차 예고: Python PySide6 배포 및 운영**
- **패키징 및 배포**: PyInstaller, cx_Freeze를 활용한 배포 패키지 생성
- **크로스 플랫폼 최적화**: Windows/Linux/macOS 호환성 확보
- **자동 업데이트**: 원격 업데이트 시스템 구현
- **모니터링 및 로깅**: 운영 환경에서의 시스템 모니터링
- **보안 및 인증**: 산업용 보안 요구사항 충족