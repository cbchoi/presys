
## 실습 1 개요

### 배경: 왜 고급 시각화가 필요한가?

**문제 상황**:
반도체 제조 현장에서는 수백 개의 센서가 실시간으로 데이터를 생성합니다. CVD(Chemical Vapor Deposition) 장비의 경우, 챔버 온도, 압력, 가스 유량, RF 파워 등 다양한 파라미터를 동시에 모니터링해야 합니다. 기본적인 라인 차트로는 다음과 같은 문제가 발생합니다:

- **데이터 과부하**: 10개 이상의 시계열 데이터를 한 화면에 표시하면 가독성 저하
- **상황 파악 지연**: 장비 내부 상태를 2D 차트만으로는 직관적으로 이해하기 어려움
- **이상 징후 감지 어려움**: 임계값 초과, 트렌드 변화 등을 실시간으로 인지하기 힘듦

**해결책**:
- **고급 트렌드 차트**: 임계값 표시, 자동 스케일링, 줌/팬 기능, 마우스 오버 값 표시
- **3D 장비 시각화**: OpenGL 기반 실시간 3D 렌더링으로 장비 내부 상태를 직관적으로 표현
- **인터랙티브 제어**: 슬라이더로 파라미터 조정, 실시간 피드백

---
## 1️⃣ 고급 트렌드 차트 구현

### 핵심 개념

**트렌드 차트(Trend Chart)**는 시간에 따른 데이터 변화를 시각화하는 도구입니다. 산업용 HMI에서는 다음 기능이 필수적입니다:

1. **다중 시리즈 지원**: 여러 센서 데이터를 동시에 표시
2. **임계값 라인**: 경고(Warning)와 위험(Critical) 수준 시각화
3. **자동 스케일링**: Y축 범위를 데이터에 맞춰 자동 조정
4. **시간 윈도우**: 최근 N분간의 데이터만 표시
5. **사용자 인터랙션**: 줌, 팬, 크로스헤어, 값 표시

**동작 원리**:
- `deque`를 사용해 고정 크기 버퍼로 메모리 효율성 확보
- `QPainter`로 커스텀 렌더링하여 성능 최적화
- 좌표 변환 함수(`value_to_y`, `timestamp_to_x`)로 데이터를 픽셀 좌표로 매핑

### 코드 구현 (Part 1/3)

```python
# -*- coding: utf-8 -*-
import sys
import math
import time
from datetime import datetime, timedelta
from collections import deque
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton
from PySide6.QtGui import QPainter, QPen, QBrush, QFont, QColor, QLinearGradient
from PySide6.QtCore import Qt, QRect, QPoint, QTimer, Signal
import random

---
## 1️⃣ 고급 트렌드 차트 구현
class AdvancedTrendChart(QWidget):
    """고급 트렌드 차트 위젯"""

    # 시그널 정의
    point_hovered = Signal(str, float, datetime)  # 마우스 오버 시
    threshold_exceeded = Signal(str, float, float)  # 임계값 초과 시

    def __init__(self, title="Trend Chart", parent=None):
        super().__init__(parent)
        self.setMinimumSize(600, 400)

        # 차트 기본 설정
        self.title = title
        self.data_series = {}  # {series_name: {'data': deque, 'color': QColor, 'visible': bool}}
        self.time_range = timedelta(minutes=10)  # 10분간 데이터 표시
        self.max_points = 1000
```

**코드 핵심 해설**:

- **Line 10**: `deque` 사용으로 FIFO 버퍼 구현 (메모리 효율적)
- **Line 16-17**: 커스텀 시그널로 이벤트 기반 프로그래밍 (HCI 원칙: 피드백)
- **Line 25**: `data_series` 딕셔너리로 다중 시리즈 관리 (확장성)
- **Line 26**: `timedelta`로 시간 범위 관리 (Python 표준 라이브러리 활용)
---
## 1️⃣ 고급 트렌드 차트 구현

### 코드 구현 (Part 2/3)

```python
    # Y축 설정
    self.y_min = 0
    self.y_max = 100
    self.auto_scale = True  # 자동 스케일링
    self.grid_enabled = True

    # 임계값 설정
    self.thresholds = {}  # {series_name: {'warning': float, 'critical': float}}

    # 마우스 상호작용
    self.mouse_pos = QPoint()
    self.show_crosshair = True  # 크로스헤어 표시
    self.show_values = True  # 값 표시

    # 줌/팬 기능
    self.zoom_factor = 1.0
    self.pan_offset = QPoint(0, 0)

    # 색상 팔레트
    self.default_colors = [
        QColor(255, 0, 0),      # 빨강
        QColor(0, 255, 0),      # 녹색
        QColor(0, 0, 255),      # 파랑
        QColor(255, 165, 0),    # 주황
        QColor(128, 0, 128),    # 보라
        QColor(255, 192, 203),  # 분홍
        QColor(0, 255, 255),    # 청록
        QColor(255, 255, 0),    # 노랑
    ]
    self.color_index = 0
```

---
## 1️⃣ 고급 트렌드 차트 구현
**코드 핵심 해설**:

- **Line 3**: `auto_scale` 플래그로 Y축 자동 조정 (사용자 편의성)
- **Line 7**: 시리즈별 임계값 관리 (경고/위험 수준 시각화)
- **Line 11-12**: 크로스헤어와 값 표시로 정밀한 데이터 확인 가능
- **Line 19-28**: 8가지 색상 팔레트로 시리즈 구분 (Miller's Law: 7±2개 항목)
---
## 1️⃣ 고급 트렌드 차트 구현

### 코드 구현 (Part 3/3)

```python
    def add_series(self, series_name, color=None,
                   warning_threshold=None, critical_threshold=None):
        """새로운 데이터 시리즈 추가"""
        if color is None:
            color = self.default_colors[self.color_index % len(self.default_colors)]
            self.color_index += 1

        self.data_series[series_name] = {
            'data': deque(maxlen=self.max_points),  # 고정 크기 버퍼
            'color': color,
            'visible': True
        }

        # 임계값 설정
        if warning_threshold is not None or critical_threshold is not None:
            self.thresholds[series_name] = {
                'warning': warning_threshold,
                'critical': critical_threshold
            }

    def add_data_point(self, series_name, value, timestamp=None):
        """데이터 포인트 추가"""
        if series_name not in self.data_series:
            self.add_series(series_name)

---
## 1️⃣ 고급 트렌드 차트 구현
        if timestamp is None:
            timestamp = datetime.now()

        # 데이터 추가
        self.data_series[series_name]['data'].append((timestamp, value))

        # 자동 스케일링
        if self.auto_scale:
            self.update_y_range()

        # 임계값 체크
        self.check_thresholds(series_name, value)

        self.update()  # 화면 갱신
```

**코드 핵심 해설**:

- **Line 9**: `deque(maxlen=...)` 사용으로 오래된 데이터 자동 제거 (메모리 최적화)
- **Line 32-33**: 데이터 추가 시 자동 스케일링 (사용자 개입 불필요)
- **Line 36**: 임계값 체크로 이상 징후 자동 감지
- **Line 38**: `update()` 호출로 화면 갱신 (Qt 이벤트 루프 활용)

**실제 적용 사례**:

**CVD 장비 온도 모니터링**:
- 시리즈 1: 챔버 온도 (0-500°C, Warning: 350°C, Critical: 400°C)
- 시리즈 2: 히터 온도 (0-600°C, Warning: 500°C, Critical: 550°C)
- 10분간 데이터 표시, 100ms 주기로 업데이트
- 임계값 초과 시 자동 알람 발생
---
## 2️⃣ OpenGL 기반 3D 장비 시각화

### 배경: 왜 3D 시각화가 필요한가?

**문제 상황**:
반도체 장비는 내부 구조가 복잡합니다. CVD 챔버의 경우:
- 반응 챔버 (원통형, 지름 300mm)
- 가스 입구 2개 (측면, 상단)
- 배기구 1개 (하단)
- 히터 (챔버 하단, 웨이퍼 가열)

2D 도면으로는 장비 내부의 공간적 관계, 가스 흐름, 온도 분포 등을 직관적으로 파악하기 어렵습니다.

**해결책**:
OpenGL을 사용한 실시간 3D 렌더링:
- 장비 구조를 3D로 표현 (원통, 파이프, 히터 등)
- 센서 데이터를 시각적으로 매핑 (온도 → 색상, 유량 → 파티클)
- 마우스로 회전, 줌 인/아웃 가능
- 실시간 애니메이션 (가스 플로우, 히터 글로우)

**핵심 개념**:

**OpenGL (Open Graphics Library)**는 2D/3D 그래픽 렌더링을 위한 크로스 플랫폼 API입니다. Qt는 `QOpenGLWidget`을 통해 OpenGL 컨텍스트를 제공합니다.

---
## 2️⃣ OpenGL 기반 3D 장비 시각화
**주요 구성요소**:
1. **기하학적 모델**: 3D 객체를 정점(Vertex)과 면(Face)으로 정의
2. **변환(Transformation)**: 이동, 회전, 스케일링
3. **조명(Lighting)**: 광원과 재질 속성으로 현실감 표현
4. **카메라**: 시점과 시야각 설정
---
## 2️⃣ OpenGL 기반 3D 장비 시각화

### 코드 구현 (Part 1/4)

```python
# -*- coding: utf-8 -*-
import sys
import math
import numpy as np
from PySide6.QtOpenGLWidgets import QOpenGLWidget
from PySide6.QtWidgets import QApplication, QWidget, QSlider, QLabel
from PySide6.QtCore import Qt, QTimer, Signal, QPoint
from PySide6.QtGui import QMatrix4x4, QVector3D, QQuaternion
from OpenGL.GL import *
from OpenGL.GLU import *
import random

class Interactive3DEquipment(QOpenGLWidget):
    """인터랙티브 3D 장비 시각화"""

    component_selected = Signal(str)  # 컴포넌트 선택 시그널
    sensor_data_updated = Signal(str, float)  # 센서 데이터 업데이트

    def __init__(self, parent=None):
        super().__init__(parent)

        # 카메라 제어
        self.camera_distance = 10.0  # 카메라 거리
        self.camera_rotation_x = 15.0  # X축 회전
        self.camera_rotation_y = 45.0  # Y축 회전

---
## 2️⃣ OpenGL 기반 3D 장비 시각화
        # 마우스 상호작용
        self.last_mouse_pos = None
        self.mouse_sensitivity = 0.5  # 마우스 감도
```

**코드 핵심 해설**:

- **Line 5**: `QOpenGLWidget` 상속으로 OpenGL 렌더링 컨텍스트 획득
- **Line 9-10**: PyOpenGL 사용 (OpenGL 파이썬 바인딩)
- **Line 22-24**: 구형 좌표계(Spherical Coordinates)로 카메라 위치 제어
- **Line 27-28**: 마우스 드래그로 카메라 회전 구현
---
## 2️⃣ OpenGL 기반 3D 장비 시각화

### 코드 구현 (Part 2/4)

```python
        # 3D 모델 구성요소
        self.equipment_components = {
            'chamber': {  # 반응 챔버
                'position': [0.0, 0.0, 0.0],
                'rotation': [0.0, 0.0, 0.0],
                'scale': [1.0, 1.0, 1.0],
                'color': [0.7, 0.7, 0.8, 1.0],  # RGBA
                'selected': False,
                'temperature': 25.0  # 센서 데이터
            },
            'gas_inlet_1': {  # 가스 입구 1
                'position': [2.0, 0.0, 1.0],
                'rotation': [0.0, 0.0, 90.0],
                'scale': [0.3, 0.3, 1.0],
                'color': [0.2, 0.8, 0.2, 1.0],  # 녹색
                'selected': False,
                'flow_rate': 0.0  # sccm
            },
            'heater': {  # 히터
                'position': [0.0, 0.0, 2.5],
                'rotation': [0.0, 0.0, 0.0],
                'scale': [1.2, 1.2, 0.2],
                'color': [1.0, 0.5, 0.0, 1.0],  # 주황
                'selected': False,
                'power': 0.0  # Watt
            }
        }
```

---
## 2️⃣ OpenGL 기반 3D 장비 시각화
**코드 핵심 해설**:

- **Line 2-27**: 딕셔너리로 장비 컴포넌트 관리 (확장 용이)
- **Line 4-6**: 3D 변환 파라미터 (위치, 회전, 스케일)
- **Line 7**: RGBA 색상 (A=알파 채널, 투명도)
- **Line 9, 17, 25**: 각 컴포넌트별 센서 데이터 저장

**실제 사례**:

**PECVD 장비 3D 모델**:
- Chamber: 지름 300mm, 높이 400mm 원통
- Gas Inlet 1: N2 (질소), 0-200 sccm
- Gas Inlet 2: SiH4 (실란), 0-100 sccm
- Heater: 0-1000W, 목표 온도 350°C
---
## 2️⃣ OpenGL 기반 3D 장비 시각화

### 코드 구현 (Part 3/4)

```python
        # 파티클 시스템 (가스 플로우 시각화)
        self.particles = []
        self.max_particles = 200

        # 센서 데이터 시뮬레이션
        self.sensor_timer = QTimer()
        self.sensor_timer.timeout.connect(self.update_sensor_data)
        self.sensor_timer.start(1000)  # 1초마다 센서 데이터 업데이트

    def initializeGL(self):
        """OpenGL 초기화"""
        # 깊이 테스트 (3D 렌더링 필수)
        glEnable(GL_DEPTH_TEST)
        glDepthFunc(GL_LESS)

        # 조명 설정
        glEnable(GL_LIGHTING)
        glEnable(GL_LIGHT0)  # 메인 조명
        glEnable(GL_LIGHT1)  # 보조 조명

        # 메인 조명 속성
        light0_pos = [5.0, 5.0, 5.0, 1.0]  # 위치 (오른쪽 위)
        light0_ambient = [0.3, 0.3, 0.3, 1.0]  # 주변광
        light0_diffuse = [0.8, 0.8, 0.8, 1.0]  # 확산광
        light0_specular = [1.0, 1.0, 1.0, 1.0]  # 반사광

        glLightfv(GL_LIGHT0, GL_POSITION, light0_pos)
        glLightfv(GL_LIGHT0, GL_AMBIENT, light0_ambient)
        glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse)
        glLightfv(GL_LIGHT0, GL_SPECULAR, light0_specular)
```

---
## 2️⃣ OpenGL 기반 3D 장비 시각화
**코드 핵심 해설**:

- **Line 1-3**: 파티클 시스템으로 가스 흐름 시각화 (최대 200개)
- **Line 12-13**: 깊이 테스트로 3D 객체 가림 처리 (Z-buffering)
- **Line 16-18**: Phong 조명 모델 사용 (현실감 있는 렌더링)
- **Line 21-29**: 광원 속성 설정 (위치, 주변광, 확산광, 반사광)

**Phong 조명 모델**:
$$
I = I_a \cdot k_a + I_d \cdot k_d \cdot (N \cdot L) + I_s \cdot k_s \cdot (R \cdot V)^n
$$

- $I_a$: 주변광 강도
- $I_d$: 확산광 강도
- $I_s$: 반사광 강도
- $N$: 표면 법선 벡터
- $L$: 광원 방향 벡터
- $R$: 반사 벡터
- $V$: 시점 벡터
- $n$: 광택도
---
## 2️⃣ OpenGL 기반 3D 장비 시각화

### 코드 구현 (Part 4/4)

```python
    def paintGL(self):
        """3D 렌더링"""
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        glMatrixMode(GL_MODELVIEW)
        glLoadIdentity()

        # 카메라 설정
        glTranslatef(0.0, 0.0, -self.camera_distance)  # 카메라 후진
        glRotatef(self.camera_rotation_x, 1.0, 0.0, 0.0)  # X축 회전
        glRotatef(self.camera_rotation_y, 0.0, 1.0, 0.0)  # Y축 회전

        # 좌표축 렌더링
        self.render_axes()

        # 장비 컴포넌트 렌더링
        self.render_equipment_components()

        # 파티클 시스템 렌더링 (가스 플로우)
        self.render_particles()

    def mouseMoveEvent(self, event):
        """마우스 이동 이벤트 (카메라 회전)"""
        if self.last_mouse_pos is None:
            return

        dx = event.position().x() - self.last_mouse_pos.x()
        dy = event.position().y() - self.last_mouse_pos.y()

        if event.buttons() & Qt.LeftButton:
            # 카메라 회전
            self.camera_rotation_y += dx * self.mouse_sensitivity
            self.camera_rotation_x += dy * self.mouse_sensitivity

---
## 2️⃣ OpenGL 기반 3D 장비 시각화
            # 회전 제한 (X축: -90° ~ 90°)
            self.camera_rotation_x = max(-90, min(90, self.camera_rotation_x))

        self.last_mouse_pos = event.position()
        self.update()  # 화면 갱신
```

**코드 핵심 해설**:

- **Line 3**: 색상 버퍼와 깊이 버퍼 초기화 (프레임 시작)
- **Line 9-11**: 카메라 변환 (이동 + 회전) - 행렬 연산 순서 중요
- **Line 27-28**: 마우스 이동량(dx, dy) 계산
- **Line 31-32**: 마우스 감도 적용하여 카메라 회전
- **Line 35**: 회전 제한으로 사용성 향상 (Fitts' Law)

**HCI 이론 적용**:

**Fitts' Law (타겟 크기와 거리)**:
- 마우스 감도 0.5로 설정 → 정밀한 제어 가능
- 회전 제한(-90° ~ 90°) → 예측 가능한 동작

**250ms 응답성 규칙**:
- `update()` 호출로 즉각적인 시각 피드백
- 30 FPS 타이머로 부드러운 애니메이션
---

## Week 7 복습 및 연결

### Week 7 핵심 내용

**Week 7에서 배운 내용**:
- `QTimer`를 사용한 주기적 작업
- `QThread`와 Worker 패턴으로 멀티스레딩
- `SQLite` 데이터베이스 연동

**Week 8로의 진화**:
- Week 7: 기본적인 타이머와 스레드 사용
- Week 8: 고급 시각화와 3D 렌더링으로 확장

**연결점**:
- `QTimer` → 센서 데이터 시뮬레이션, 애니메이션 업데이트
- 커스텀 위젯 → 트렌드 차트, 3D 뷰어
- 시그널/슬롯 → 컴포넌트 간 통신

---

## Week 1 HCI 이론 적용

### Miller's Law (작업기억 한계 7±2)

**적용 사례**:
- 트렌드 차트: 기본 색상 팔레트 8가지 (7±2 범위 내)
- 3D 장비 모델: 주요 컴포넌트 5개 (Chamber, Inlet×2, Exhaust, Heater)
- 임계값: 2단계 (Warning, Critical) - 단순화

**설계 원칙**:
- 한 화면에 표시하는 시계열 데이터 5-7개로 제한
- 범례(Legend)에 최대 7개 항목 표시

### 정보처리 모델 (250ms 응답성)

**적용 사례**:
- 트렌드 차트: `update()` 호출로 즉각 갱신 (<16ms at 60 FPS)
- 3D 뷰: 30 FPS 타이머로 부드러운 애니메이션 (33ms 주기)
- 마우스 드래그: 실시간 카메라 회전 (<10ms 응답)

**성능 측정**:
- 렌더링 시간: 평균 8-12ms (60 FPS 목표)
- 데이터 업데이트: 1-2ms (1000 포인트 기준)

---
## 직접 해보세요

### 실습 과제

**과제 1: 트렌드 차트 확장 (30분)**
1. 새로운 시리즈 추가 (예: Pressure, Flow Rate)
2. 임계값 설정 (Warning: 15 Torr, Critical: 18 Torr)
3. 시간 범위 변경 슬라이더 추가 (5분, 10분, 30분)

**예상 결과**:
- 3개 시리즈 동시 표시 (Temperature, Pressure, Flow)
- 임계값 초과 시 시그널 발생
- 시간 범위 동적 조정 가능

**과제 2: 3D 장비 모델 개선 (40분)**
1. 새로운 컴포넌트 추가 (예: Wafer Stage)
2. 온도에 따른 히터 색상 변화 (25°C: 주황 → 400°C: 빨강)
3. 가스 유량에 따른 파티클 생성 속도 조정

**예상 결과**:
- 6개 컴포넌트 렌더링
- 온도 350°C 이상 시 히터 빨강색 글로우
- 유량 100 sccm → 초당 10개 파티클 생성

---
## 직접 해보세요
**과제 3: 통합 테스트 (30분)**
1. 트렌드 차트와 3D 뷰 동시 실행
2. 슬라이더로 히터 파워 조정 시 차트와 3D 뷰 동기화
3. 성능 측정 (FPS, 메모리 사용량)

**성능 목표**:
- 렌더링: 60 FPS 유지
- 메모리: <500 MB
- 응답 시간: <100ms
---

## 정리

### 핵심 요약

**고급 트렌드 차트**:
- `deque`로 고정 크기 버퍼 구현 → 메모리 효율
- `QPainter` 커스텀 렌더링 → 성능 최적화
- 임계값 시각화 → 이상 징후 조기 감지

**3D 장비 시각화**:
- OpenGL 파이프라인: 정점 → 변환 → 조명 → 래스터화
- 마우스 인터랙션: 회전, 줌으로 직관적 탐색
- 파티클 시스템: 가스 플로우 실시간 시각화

**HCI 이론 연결**:
- Miller's Law: 화면당 7±2개 요소
- 정보처리 모델: 250ms 응답성 보장

### 다음 단계

**실습 2 (슬라이드 04)**: 플러그인 아키텍처 구현
**실습 3 (슬라이드 05)**: 통합 HMI 플랫폼 구축
