# Week 2: C# WPF MVVM 기초

## 학습 목표

1. **MVVM 패턴 이해**: View-ViewModel-Model 구조를 이해하고 반도체 HMI에 적용하여 UI와 비즈니스 로직을 분리하는 방법을 학습합니다.
2. **Data Binding 구현**: INotifyPropertyChanged, ObservableCollection을 활용하여 실시간 공정 데이터를 UI에 자동 반영하는 기술을 습득합니다.
3. **Command 패턴**: RelayCommand를 구현하여 버튼 클릭, 공정 시작/정지 등의 사용자 액션을 처리하는 방법을 학습합니다.

---

## 이번 주 주요 내용

### 배경
반도체 장비 HMI는 실시간으로 수백 개의 센서 데이터를 표시하고, 운영자 조작에 즉각 반응해야 합니다. MVVM 패턴은 복잡한 데이터 흐름을 체계적으로 관리하고, 유지보수성을 크게 향상시킵니다.

### 핵심 개념
- **MVVM 아키텍처**: View(XAML UI) ↔ ViewModel(데이터/명령) ↔ Model(공정 데이터/로직)
- **INotifyPropertyChanged**: 속성 변경 시 UI 자동 업데이트 (온도, 압력, 가스 유량 등)
- **ObservableCollection**: 리스트 데이터 추가/삭제 시 UI 자동 갱신 (알람 로그, 레시피 목록)
- **RelayCommand**: 버튼 클릭 → Command 실행 → ViewModel 메서드 호출

### 실습 내용
- ETCH Chamber HMI 프로토타입 개발 (온도 200-450°C, 압력 1-10 Torr, 가스 100-500 sccm)
- EquipmentViewModel 구현 및 Data Binding 연결
- RelayCommand로 Start/Stop/Abort 명령 처리
- ObservableCollection으로 10,000개 알람 로그 성능 최적화

---

## Week 1 복습

**Week 1 핵심 내용**:
- Miller's Law (7±2): HMI 한 화면에 7개 이하 파라미터 표시
- Fitts' Law: 버튼 크기/거리 최적화
- 정보처리 모델: 감각(250ms) → 인지 → 운동

**Week 2 연결점**:
- Miller's Law → ViewModel에서 7개 핵심 속성만 노출 (온도, 압력, 가스 등)
- Fitts' Law → XAML에서 버튼 크기 50px 이상, 간격 20px 이상 설정
- 실시간 응답 → INotifyPropertyChanged로 100ms 이내 UI 업데이트

---

## Week 1 HCI 이론 연결

- **Miller's Law**: ViewModel에서 7±2개 핵심 속성만 노출 (Temperature, Pressure, GasFlow, RfPower, ProcessTime, WaferCount, AlarmCount)
- **Fitts' Law**: XAML 버튼 크기 Width="80" Height="50" 설정, Margin="10" 간격 유지
- **정보처리 모델**: PropertyChanged 이벤트 발생(5ms) → UI Binding 업데이트(10ms) → 화면 렌더링(16ms) = 총 31ms 이내

---

## Mermaid 다이어그램

```mermaid
flowchart TD
    A[View - XAML UI] -->|Data Binding| B[ViewModel]
    B -->|INotifyPropertyChanged| A
    A -->|Command| B

    B -->|비즈니스 로직| C[Model - 공정 데이터]
    C -->|센서 데이터| D[ETCH Chamber<br/>온도/압력/가스]

    B -->|ObservableCollection| E[AlarmLog<br/>RecipeList]

    style A fill:#e1f5fe,stroke:#0277bd,stroke-width:2px
    style B fill:#fff3e0,stroke:#ef6c00,stroke-width:2px
    style C fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px
    style D fill:#ffccbc,stroke:#d84315
    style E fill:#f3e5f5,stroke:#6a1b9a
```

---
## 실습 과제

### 과제 1: EquipmentViewModel 구현 (20분)
**목표**: ETCH Chamber 데이터를 관리하는 ViewModel 클래스 작성

```csharp
public class EquipmentViewModel : INotifyPropertyChanged
{
    private double _temperature; // 200-450°C
    private double _pressure;    // 1-10 Torr
    private double _gasFlow;     // 100-500 sccm

    public event PropertyChangedEventHandler PropertyChanged;

    public double Temperature
    {
        get => _temperature;
        set
        {
            _temperature = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Temperature)));
        }
    }
    // Pressure, GasFlow 속성도 동일하게 구현
}
```

---
## 실습 과제
**검증 기준**:
- INotifyPropertyChanged 구현 완료
- 7개 핵심 속성 정의 (Miller's Law 준수)
- PropertyChanged 이벤트 정상 발생
---
## 실습 과제 (계속)

### 과제 2: RelayCommand 구현 (30분)
**목표**: 버튼 클릭 시 공정 시작/정지 명령 처리

```csharp
public class RelayCommand : ICommand
{
    private readonly Action<object> _execute;
    private readonly Func<object, bool> _canExecute;

    public RelayCommand(Action<object> execute, Func<object, bool> canExecute = null)
    {
        _execute = execute;
        _canExecute = canExecute;
    }

    public bool CanExecute(object parameter) => _canExecute?.Invoke(parameter) ?? true;
    public void Execute(object parameter) => _execute(parameter);
}

// ViewModel에서 사용
public ICommand StartCommand { get; }

public EquipmentViewModel()
{
    StartCommand = new RelayCommand(_ => StartProcess(), _ => !IsProcessRunning);
}
```

---
## 실습 과제 (계속)
**검증 기준**:
- ICommand 인터페이스 구현
- CanExecute로 버튼 활성화/비활성화 제어
- XAML Button Command Binding 연결
---

## 실습 과제 (계속)

### 과제 3: ObservableCollection 성능 최적화 (30분)
**목표**: 10,000개 알람 로그를 UI에 표시하되, 60 FPS 유지

```csharp
public ObservableCollection<AlarmLog> AlarmLogs { get; set; } = new();

// 성능 측정
var stopwatch = Stopwatch.StartNew();
for (int i = 0; i < 10000; i++)
{
    AlarmLogs.Add(new AlarmLog { Message = $"Alarm {i}", Timestamp = DateTime.Now });
}
stopwatch.Stop();
Console.WriteLine($"Elapsed: {stopwatch.ElapsedMilliseconds} ms");
```

**검증 기준**:
- 렌더링 시간(ms) 측정: 목표 <16ms (60 FPS)
- 메모리 사용량(MB): 목표 <50MB
- CPU 사용률(%): 목표 <5%

**최적화 기법**:
- VirtualizingStackPanel 사용 (XAML)
- UI 가상화로 보이는 항목만 렌더링
- CollectionChanged 이벤트 일괄 처리

---

## 성능 벤치마크

### ETCH Chamber HMI 성능 목표
- **UI 응답 시간**: <16ms (60 FPS 유지)
- **데이터 바인딩 지연**: <10ms (PropertyChanged 발생 → UI 업데이트)
- **메모리 사용량**: <200MB (10,000개 알람 로그 포함)
- **CPU 사용률**: <5% (유휴 상태), <30% (공정 실행 중)

### 측정 도구
- **Visual Studio Diagnostic Tools**: CPU, 메모리, UI 스레드 분석
- **WPF Performance Suite**: 렌더링 FPS, 바인딩 성능 측정
- **PerfView**: .NET CLR 이벤트 추적

---

## 다음 주 예고: Week 3 - C# 실시간 데이터 처리

Week 2에서 구현한 MVVM 기반 HMI에 실시간 데이터 처리 기능을 추가합니다.

- **Background Thread**: System.Threading.Timer로 100ms 주기 센서 데이터 수집
- **Thread-safe 큐**: ConcurrentQueue로 멀티스레드 안전성 확보
- **Dispatcher**: UI Thread와 Background Thread 동기화
- **실습**: 100ms 주기로 온도/압력/가스 데이터 업데이트, UI 60 FPS 유지
