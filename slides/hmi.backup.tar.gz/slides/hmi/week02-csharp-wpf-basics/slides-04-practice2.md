## 실습 3: MVVM 패턴 적용

<div style="margin: 2rem 0;">

### 배경: 왜 MVVM 패턴이 필요한가?

**문제 상황**: 반도체 장비 HMI에서 UI 로직과 비즈니스 로직이 혼재하면 테스트가 불가능하고, UI 변경 시 전체 코드를 수정해야 합니다. 디자이너와 개발자의 협업도 어렵습니다.

**해결책**: MVVM 패턴은 View(UI), ViewModel(로직), Model(데이터)을 분리하여 각자의 책임을 명확히 합니다. View는 UI만, ViewModel은 프레젠테이션 로직만, Model은 데이터와 비즈니스 로직만 담당합니다.

### 핵심 개념

**MVVM(Model-View-ViewModel)**은 WPF에 최적화된 아키텍처 패턴으로 UI와 비즈니스 로직을 완전히 분리합니다.

**동작 원리**:
1. **View**: XAML로 정의된 UI, 사용자 입력을 Command로 전달
2. **ViewModel**: View의 상태를 속성으로 관리, Command로 사용자 액션 처리
3. **Model**: 순수 데이터 클래스와 비즈니스 로직
4. **Data Binding**: View와 ViewModel을 INotifyPropertyChanged로 자동 동기화

**설계 철학**: 관심사의 분리(Separation of Concerns), 테스트 가능성, 재사용성, 유지보수성

### 실제 적용 사례 (CVD 장비)

**PVD-002 장비 모니터링**:
- Model: 온도(185.2°C), 압력(1.250 Torr), 상태(Warning)
- ViewModel: 알람 카운트 계산, 상태 색상 변환, 명령 실행 로직
- View: 온도 표시, 진행바, 버튼 UI
- 성능: 100개 장비 동시 모니터링, UI 업데이트 < 16ms (60 FPS)

---
## 실습 3: MVVM 패턴 적용
### Week 1 HCI 이론 연결

**Miller's Law (작업기억 7±2 청크)**:
- ViewModel의 속성을 7개 이하로 그룹화 (온도, 압력, 유량, 상태, 시간, 알람, 메시지)
- 복잡한 데이터는 하위 ViewModel로 분리하여 인지 부하 감소

**Fitts' Law (타겟 크기와 거리)**:
- Command 버튼 크기: 최소 48x48px (손가락 터치 고려)
- 주요 기능 버튼을 화면 중앙에 배치하여 거리 최소화
---
## 실습 3: MVVM 패턴 - RelayCommand 구현

### 배경 설명

**문제**: WPF는 ICommand 인터페이스만 제공하고 기본 구현체가 없어 매번 Command 클래스를 만들어야 합니다.

**해결책**: RelayCommand는 Action 델리게이트를 받아 간단하게 Command를 생성하는 재사용 가능한 클래스입니다.

### 핵심 개념

**RelayCommand**는 실행 로직과 실행 가능 여부 로직을 델리게이트로 받아 ICommand를 구현합니다.

### 간단한 코드 해설

- `Action<object> _execute`: 실행할 메서드를 저장
- `Predicate<object> _canExecute`: 실행 가능 여부를 판단하는 메서드
- `Execute(object parameter)`: Command 실행 시 호출
- `CanExecute(object parameter)`: 버튼 활성화/비활성화 판단

```csharp
using System;
using System.Windows.Input;

namespace SemiconductorHMI.Commands
{
    public class RelayCommand : ICommand
    {
        private readonly Action<object> _execute;
        private readonly Predicate<object> _canExecute;

        public RelayCommand(Action<object> execute, Predicate<object> canExecute = null)
        {
            _execute = execute ?? throw new ArgumentNullException(nameof(execute));
            _canExecute = canExecute;
        }

---
## 실습 3: MVVM 패턴 - RelayCommand 구현
        public event EventHandler CanExecuteChanged
        {
            add { CommandManager.RequerySuggested += value; }
            remove { CommandManager.RequerySuggested -= value; }
        }

        public bool CanExecute(object parameter)
        {
            return _canExecute == null || _canExecute(parameter);
        }

        public void Execute(object parameter)
        {
            _execute(parameter);
        }
    }
}
```

**실제 사례**: `StartMaintenanceCommand`는 선택된 장비가 Idle이나 Error 상태일 때만 실행 가능하도록 `CanExecute`를 사용합니다.
---
## 실습 3: ViewModel에서 Command 사용

### 배경 설명

**문제**: 반도체 장비 HMI에서 "새로고침", "정비 시작", "장비 정지", "알람 초기화" 4가지 기능이 필요합니다.

**해결책**: RelayCommand를 사용하여 각 기능을 Command로 구현하고 XAML 버튼과 바인딩합니다.

### 핵심 개념

**Command 패턴**은 사용자 액션을 객체로 캡슐화하여 View와 ViewModel을 느슨하게 결합합니다.

**동작 원리**:
1. ViewModel에서 ICommand 속성 정의
2. 생성자에서 RelayCommand 인스턴스 생성
3. Execute 메서드에 실행 로직 작성
4. CanExecute 메서드에 실행 조건 작성
5. XAML에서 `Command="{Binding RefreshCommand}"` 바인딩

### 간단한 코드 해설

- `RefreshCommand`: 모든 장비 데이터를 갱신하고 알람 개수 재계산
- `StartMaintenanceCommand`: 선택된 장비를 정비 모드로 전환 (Idle/Error 상태만 가능)
- `StopEquipmentCommand`: 선택된 장비를 정지 (Running/Warning 상태만 가능)
- `ClearAlarmsCommand`: Warning 상태 장비를 Running으로 전환

```csharp
// MainWindowViewModel.cs
public class MainWindowViewModel : BaseViewModel
{
    //... 기존 속성들 ...

    public ICommand RefreshCommand { get; }
    public ICommand StartMaintenanceCommand { get; }
    public ICommand StopEquipmentCommand { get; }
    public ICommand ClearAlarmsCommand { get; }

---
## 실습 3: ViewModel에서 Command 사용
    public MainWindowViewModel()
    {
        //... 기존 초기화 ...

        // Command 초기화
        RefreshCommand = new RelayCommand(ExecuteRefresh);
        StartMaintenanceCommand = new RelayCommand(ExecuteStartMaintenance, CanStartMaintenance);
        StopEquipmentCommand = new RelayCommand(ExecuteStopEquipment, CanStopEquipment);
        ClearAlarmsCommand = new RelayCommand(ExecuteClearAlarms, CanClearAlarms);
    }

    // 새로고침 실행
    private void ExecuteRefresh()
    {
        StatusMessage = "데이터 갱신 중...";

        // 모든 장비의 시간과 센서값 업데이트
        foreach (var equipment in EquipmentList)
        {
            equipment.LastUpdate = DateTime.Now;
            // 센서값 변동 시뮬레이션
            var random = new Random();
            equipment.Temperature += (random.NextDouble() - 0.5) * 2;
            equipment.Pressure += (random.NextDouble() - 0.5) * 0.1;
        }

---
## 실습 3: ViewModel에서 Command 사용
        UpdateAlarmCount();
        StatusMessage = "데이터 갱신 완료";
    }

    // 정비 시작 실행
    private void ExecuteStartMaintenance()
    {
        if (SelectedEquipment != null)
        {
            SelectedEquipment.Status = EquipmentStatus.Maintenance;
            StatusMessage = $"{SelectedEquipment.EquipmentId} 정비 모드 전환";
            UpdateAlarmCount();
        }
    }

    private bool CanStartMaintenance()
    {
        return SelectedEquipment?.Status == EquipmentStatus.Idle ||
               SelectedEquipment?.Status == EquipmentStatus.Error;
    }

---
## 실습 3: ViewModel에서 Command 사용
    // 장비 정지 실행
    private void ExecuteStopEquipment()
    {
        if (SelectedEquipment != null)
        {
            SelectedEquipment.Status = EquipmentStatus.Idle;
            StatusMessage = $"{SelectedEquipment.EquipmentId} 장비 정지";
            UpdateAlarmCount();
        }
    }
---
## 실습 3: ViewModel에서 Command 사용
    private bool CanStopEquipment()
    {
        return SelectedEquipment?.Status == EquipmentStatus.Running ||
               SelectedEquipment?.Status == EquipmentStatus.Warning;
    }

    // 알람 초기화 실행
    private void ExecuteClearAlarms()
    {
        foreach (var equipment in EquipmentList)
        {
            if (equipment.Status == EquipmentStatus.Warning)
            {
                equipment.Status = EquipmentStatus.Running;
            }
        }
        UpdateAlarmCount();
        StatusMessage = "알람 초기화 완료";
    }

    private bool CanClearAlarms()
    {
        return EquipmentList.Any(e => e.Status == EquipmentStatus.Warning);
    }
}
```

---
## 실습 3: ViewModel에서 Command 사용
**실제 사례 (PVD 장비)**:
- RefreshCommand: 5초마다 자동 실행되어 온도 ±2°C, 압력 ±0.1 Torr 변동 반영
- StartMaintenanceCommand: PVD-002가 Warning 상태일 때 클릭 가능, Maintenance로 전환
- 성능: Command 실행 시간 < 5ms, UI 응답성 250ms 이내
---
## 실습 4: Value Converter 구현

### 배경: 왜 Converter가 필요한가?

**문제 상황**: ViewModel의 `EquipmentStatus` enum 값을 UI에서 색상으로 표시해야 합니다. 직접 변환하면 ViewModel에 UI 로직이 들어갑니다.

**해결책**: Value Converter는 데이터 바인딩 과정에서 값을 변환하는 중간 계층입니다. ViewModel은 순수 데이터만 다루고, Converter가 UI 표현을 담당합니다.

### 핵심 개념

**IValueConverter**는 바인딩 소스(ViewModel)와 타겟(View) 간의 데이터 형식을 변환하는 인터페이스입니다.

**동작 원리**:
1. `Convert`: ViewModel → View 방향, 데이터를 UI 표현으로 변환
2. `ConvertBack`: View → ViewModel 방향 (양방향 바인딩 시)
3. XAML에서 `{StaticResource}`로 Converter 등록
4. 바인딩 시 `Converter={StaticResource StatusToColorConverter}` 지정

**설계 철학**: 단일 책임 원칙(SRP), 재사용성, View와 ViewModel의 완전한 분리

### 간단한 코드 해설

**StatusToColorConverter**:
- `Running → 녹색 (#4CAF50)`: 정상 운전
- `Warning → 주황색 (#FF9800)`: 주의 필요
- `Error → 빨간색 (#F44336)`: 긴급 조치 필요
- `Maintenance → 파란색 (#2196F3)`: 정비 중
- `Idle → 회색 (#9E9E9E)`: 대기

**TemperatureToColorConverter**:
- 온도 범위에 따라 파란색(저온) → 빨간색(고온) 단계적 변화
- CVD: 250°C 이하 정상(녹색), 250-280°C 주의(주황), 280°C 이상 위험(빨강)

```csharp
using System;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media;

---
## 실습 4: Value Converter 구현
namespace SemiconductorHMI.Converters
{
    public class StatusToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is EquipmentStatus status)
            {
                return status switch
                {
                    EquipmentStatus.Running => new SolidColorBrush(Color.FromRgb(76, 175, 80)), // 녹색
                    EquipmentStatus.Warning => new SolidColorBrush(Color.FromRgb(255, 152, 0)), // 주황색
                    EquipmentStatus.Error => new SolidColorBrush(Color.FromRgb(244, 67, 54)), // 빨간색
                    EquipmentStatus.Maintenance => new SolidColorBrush(Color.FromRgb(33, 150, 243)), // 파란색
                    _ => new SolidColorBrush(Color.FromRgb(158, 158, 158)) // 회색
                };
            }
            return new SolidColorBrush(Colors.Gray);
        }

---
## 실습 4: Value Converter 구현
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
---
## 실습 4: Value Converter 구현
    // 온도 색상 변환기
    public class TemperatureToColorConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is double temperature)
            {
                if (temperature < 50)
                    return new SolidColorBrush(Color.FromRgb(33, 150, 243)); // 파란색 (저온)
                else if (temperature < 150)
                    return new SolidColorBrush(Color.FromRgb(76, 175, 80)); // 녹색 (정상)
                else if (temperature < 250)
                    return new SolidColorBrush(Color.FromRgb(255, 193, 7)); // 노란색 (주의)
                else if (temperature < 300)
                    return new SolidColorBrush(Color.FromRgb(255, 152, 0)); // 주황색 (경고)
                else
                    return new SolidColorBrush(Color.FromRgb(244, 67, 54)); // 빨간색 (위험)
            }
            return new SolidColorBrush(Colors.Gray);
        }

---
## 실습 4: Value Converter 구현
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }

    // 압력 단위 변환기
    public class PressureToStringConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value is double pressure)
            {
                if (pressure < 0.001)
                    return $"{pressure * 1000000:F1} µTorr";
                else if (pressure < 1.0)
                    return $"{pressure * 1000:F1} mTorr";
                else
                    return $"{pressure:F3} Torr";
            }
            return "N/A";
        }

---
## 실습 4: Value Converter 구현
        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
```

**실제 적용 사례**:
- PVD-002 장비: 압력 0.005 Torr → "5.0 mTorr"로 자동 변환
- 온도 185°C → 녹색 표시 (정상 범위)
- Warning 상태 → 주황색 배경으로 시각적 경고

### MVVM 패턴 아키텍처 다이어그램

```mermaid
graph LR
    A[View<br/>XAML UI] -->|Data Binding| B[ViewModel<br/>속성 + Command]
    B -->|PropertyChanged<br/>Event| A
    A -->|Command<br/>Execution| B
    B -->|비즈니스 로직<br/>호출| C[Model<br/>데이터 + 로직]
    C -->|데이터 반환| B

    D[IValueConverter<br/>데이터 변환] -.->|변환| A
    B -.->|데이터 전달| D

---
## 실습 4: Value Converter 구현
    style A fill:#e3f2fd
    style B fill:#fff3e0
    style C fill:#e8f5e9
    style D fill:#f3e5f5
```

**패턴 설명**: View는 ViewModel만 알고, ViewModel은 Model만 알아 의존성이 단방향으로 흐릅니다.

</div>