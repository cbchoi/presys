
## .NET 플랫폼 개요

### Week 1 복습

**Week 1 핵심 내용**:
- Miller's Law (7±2): 인간의 단기 기억 용량 제한
- Fitts' Law: 타겟 크기와 거리의 상관관계
- 정보처리 모델: 감각 → 인지 → 운동

**Week 2 연결점**:
- Week 1: HCI 이론적 기초
- Week 2: WPF → MVVM 구현으로 이론 적용

### Week 1 HCI 이론 연결

**Miller's Law (7±2 항목)**:
- 적용: ViewModel에서 7개 이하 핵심 속성만 노출
- 효과: 인지부하 30%, 사용성 50% 향상

**정보처리 모델 (250ms 반응시간)**:
- 적용: PropertyChanged 16ms(60 FPS) 이내 UI 업데이트
- 효과: 응답성 40% 개선

---

### 실습 과제 개요 (1/2)

**과제 구성**:

1. **과제 1: 기본 XAML 구조**
- EquipmentViewModel 작성 및 Data Binding 연결
- 소요시간: 20분
- 학습목표: MVVM 패턴의 WPF 적용

2. **과제 2: Command 패턴 구현**
- RelayCommand로 Start/Stop/Abort 명령 처리
- 소요시간: 30분
- 학습목표: MVVM 패턴의 WPF 적용

---
### 실습 과제 개요 (2/2)

3. **과제 3: 성능 최적화**
- ObservableCollection 대용량 데이터 (10000 items) 처리
- 측정항목: 업데이트 시간(ms), 메모리 사용량(MB), CPU 사용률(%)
- 목표지표: UI 업데이트 <16ms (60 FPS), 메모리 <50MB, CPU <5%

**제출 사항**:
- [ ] 프로젝트 소스코드
- [ ] 성능 측정 결과 스크린샷
- [ ] 구현 보고서

### .NET 플랫폼 진화
- **.NET Framework (2002)**: Windows 전용, 레거시
- **.NET Core (2016)**: 크로스플랫폼, 오픈소스
- **.NET 5+ (2020)**: 통합 플랫폼, 고성능
- **.NET 6 LTS (2021)**: 장기지원, 안정성
---
### .NET 플랫폼 비교 다이어그램 (1/2)

### .NET 플랫폼 진화 과정
> 반도체 HMI는 24/7 운영되므로 LTS 버전 필수입니다.

```mermaid
graph LR
A[.NET Framework - 2002] -->|레거시| B[.NET Core - 2016]
B -->|통합| C[.NET 5+ - 2020]
C -->|LTS| D[.NET 6+ - 2021]

style A fill:#ffcccc
style B fill:#cce5ff
style C fill:#ccffcc
style D fill:#ccffcc
```
---
### .NET 플랫폼 비교 다이어그램 (2/2)

<!-- IMAGE PLACEHOLDER: .NET Evolution Timeline -->
<!--
시각화 제안:
- .NET 플랫폼 진화 타임라인
- 버전별 주요 기능 비교표
- 반도체 HMI 권장 버전 표시
-->

---

## CLR (Common Language Runtime) 아키텍처 (1/2)

### CLR 핵심 구성요소
- **JIT 컴파일러**: IL → 네이티브 코드 변환
- **가비지 컬렉터**: 자동 메모리 관리
- **타입 시스템**: 형식 안전성 보장
- **예외 처리**: 구조적 예외 처리

### 반도체 HMI 적용
- **실시간성**: AOT 컴파일로 JIT 지연 제거
- **메모리 안정성**: GC 튜닝으로 JIT 지연 최소화
- **타입 안전성**: 컴파일 타임 오류 검출
---
## CLR (Common Language Runtime) 아키텍처 (2/2)

```mermaid
flowchart TD
A[C# 소스코드] -->|컴파일| B[IL 바이트코드]
B -->|CLR 로딩| C[CLR]
C -->|JIT 컴파일| D[네이티브 코드]
D --> E[실행]

C -->|메모리 관리| F[가비지 컬렉터]
C -->|예외 처리| G[예외 핸들러]

style C fill:#e1f5ff
style F fill:#c8e6c9
style G fill:#fff9c4
```

---

## SOLID 설계 원칙 (1/2)

**SOLID 5대 원칙**:
- **S**: Single Responsibility (단일 책임 원칙)
- **O**: Open/Closed (개방-폐쇄 원칙)
- **L**: Liskov Substitution (리스코프 치환 원칙)
- **I**: Interface Segregation (인터페이스 분리 원칙)
- **D**: Dependency Inversion (의존성 역전 원칙)

```mermaid
graph TD
SOLID[SOLID 설계 원칙]
SOLID --> S[S: 단일 책임]
---
## SOLID 설계 원칙 (2/2)

SOLID --> O[O: 개방-폐쇄]
SOLID --> L[L: 리스코프 치환]
SOLID --> I[I: 인터페이스 분리]
SOLID --> D[D: 의존성 역전]

style S fill:#c5cae9
style O fill:#b2dfdb
style L fill:#ffe0b2
style I fill:#f8bbd0
style D fill:#c5e1a5
```

> 반도체 HMI는 SOLID 원칙으로 유지보수성 향상

---

## SRP: 단일 책임 원칙 (1/2) (Part 1)

### 배경: 왜 단일 책임이 중요한가?
**문제 상황**: 반도체 장비 ViewModel이 UI 업데이트, DB 저장, 서버 통신을 모두 담당하면 유지보수가 어렵고 테스트가 불가능합니다.

<div class="grid grid-cols-2 gap-8">
<div>

**위반 사례 (Bad)**
```csharp
public class EquipmentViewModel
{
public void UpdateUI()
{
// UI 업데이트
}
---
## SRP: 단일 책임 원칙 (1/2) (Part 2)

public void SaveToDatabase()
{
// DB 저장
}

public void SendToServer()
{
// 서버 통신
}
}
```

</div>
<div>
---
## SRP: 단일 책임 원칙 (2/2) (1/2)

**문제점**:
- ViewModel이 3가지 책임 담당
- UI, DB, 네트워크 변경 시 모두 수정 필요
- 테스트 불가능 - DB/서버 Mock 불가
```mermaid
graph TD
VM[EquipmentViewModel - 단일 클래스]
VM -->|책임 1| UI[UI 업데이트]
VM -->|책임 2| DB[DB 저장]
---
## SRP: 단일 책임 원칙 (2/2) (2/2)

VM -->|책임 3| NET[서버 통신]

style VM fill:#ffcdd2
style UI fill:#fff9c4
style DB fill:#fff9c4
style NET fill:#fff9c4
```

**SRP 적용 효과**:
- ViewModel에서 DB/네트워크 책임 분리
- Repository/Service 패턴으로 ViewModel 경량화
- 테스트 가능성 향상 (Mock 주입)
</div>
</div>

---
## SRP: 단일 책임 원칙 개선안 (Part 1)



<div class="grid grid-cols-2 gap-8">
<div>

**개선 사례 (Good)**

```csharp
// ViewModel은 UI 관련 책임만
public class EquipmentViewModel
{
private readonly IEquipmentRepository _repository;
---
## SRP: 단일 책임 원칙 개선안 (Part 1)

private readonly IDataService _dataService;

public EquipmentViewModel(
IEquipmentRepository repository,
IDataService dataService)
{
_repository = repository;
_dataService = dataService;
```
---
## SRP: 단일 책임 원칙 개선안 (Part 2)

```csharp
}

public void UpdateUI()
{
OnPropertyChanged(nameof(Status));
}

public async Task SaveAsync()
{
await _repository.SaveAsync(Equipment);
}
}
```
---
## SRP: 단일 책임 원칙 개선안 (Part 3)

```csharp

// Repository는 DB 책임만
public class EquipmentRepository
: IEquipmentRepository
{
public async Task SaveAsync(
Equipment equipment)
{
// DB 저장 로직
}
}

```
---
## SRP: 단일 책임 원칙 개선안 (Part 4) (Code Part 1/2)


```csharp
// Service는 서버 통신 책임만

```csharp
// 테스트 가능
[Test]
public void UpdateUI_Test()
{
var mockRepo = new Mock<IEquipmentRepository>();
var mockService = new Mock<IDataService>();

var vm = new EquipmentViewModel(
mockRepo.Object,
mockService.Object);
```
---
## SRP: 단일 책임 원칙 개선안 (Part 4) (Code Part 2/2)

```csharp

vm.UpdateUI();

Assert.IsTrue(vm.PropertyChanged
.WasRaised());
}
```


</div>
</div>
---
## OCP: Open/Closed 개방-폐쇄 원칙 (Part 1)



**핵심**: 확장에는 열려있고, 수정에는 닫혀있어야 함

<div class="grid grid-cols-2 gap-8">
<div>

```csharp
// 인터페이스 정의
public interface IAlarmStrategy
{
bool ShouldTrigger(double value);
---
## OCP: Open/Closed 개방-폐쇄 원칙 (Part 1)

AlarmLevel GetLevel();
string GetMessage();
}

// 임계값 알람 구현
public class ThresholdAlarm: IAlarmStrategy
{
private readonly double _threshold;
```
---
## OCP: Open/Closed 개방-폐쇄 원칙 (Part 2)

```csharp
private readonly AlarmLevel _level;

public ThresholdAlarm(
double threshold,
AlarmLevel level)
{
_threshold = threshold;
_level = level;
}

public bool ShouldTrigger(double value)
{
```
---
## OCP: Open/Closed 개방-폐쇄 원칙 (Part 3) (Code Part 1/4)


```csharp
return value > _threshold;

```csharp
// 변화율 알람 추가 (기존 코드 수정 없음)
public class RateOfChangeAlarm: IAlarmStrategy
{
private readonly double _maxRate;
private double _previousValue;

public bool ShouldTrigger(double value)
{
var rate = Math.Abs(
value - _previousValue);
```
---
## OCP: Open/Closed 개방-폐쇄 원칙 (Part 3) (Code Part 2/4)

```csharp
_previousValue = value;
return rate > _maxRate;
}

public AlarmLevel GetLevel()
{
return AlarmLevel.Warning;
}

public string GetMessage()
```
---
## OCP: Open/Closed 개방-폐쇄 원칙 (Part 3) (Code Part 3/4)

```csharp
{
return "급격한 변화 감지";
}
}

// 패턴 알람 추가
public class PatternAlarm: IAlarmStrategy
{
private readonly Queue<double> _history;

```
---
## OCP: Open/Closed 개방-폐쇄 원칙 (Part 3) (Code Part 4/4)

```csharp
public bool ShouldTrigger(double value)
{
_history.Enqueue(value);
return DetectPattern(_history);
}
}
```


**효과**: 새로운 알람 타입 추가 시 기존 코드 수정 불필요
---
## 디자인 패턴: Observer 옵저버 패턴 (Part 1)



<div class="grid grid-cols-2 gap-8">
<div>

---
## OCP: Open/Closed 개방-폐쇄 원칙 (Part 3) (Code Part 4/4)
```mermaid
sequenceDiagram
participant VM as ViewModel - 데이터 소스 (Subject)
participant V1 as View 1 - 그래프 (Observer)
participant V2 as View 2 - 테이블 (Observer)
participant V3 as View 3 - 알람 (Observer)
---
## 디자인 패턴: Observer 옵저버 패턴 (Part 1)

Note over VM: 온도 데이터 변경
VM->>V1: PropertyChanged 이벤트
VM->>V2: PropertyChanged 이벤트
VM->>V3: PropertyChanged 이벤트
V1->>V1: 그래프 UI 업데이트
V2->>V2: 테이블 UI 업데이트
V3->>V3: 알람 UI 업데이트
```
---
## 디자인 패턴: Observer 옵저버 패턴 (Part 1)

**구조 설명**:
- Subject: ViewModel (데이터 소스)
- Observer: View (UI 컴포넌트)
- 느슨한 결합 (Loose Coupling) 구조

```csharp
// Subject 인터페이스
public interface ISubject
{
---
## 디자인 패턴: Observer 옵저버 패턴 (Part 1)

void Attach(IObserver observer);
void Detach(IObserver observer);
void Notify();
}

// Observer 인터페이스
public interface IObserver
{
void Update(ISubject subject);
}
```

</div>
<div>

**WPF 구현 방식**:
---
## 디자인 패턴: Observer 옵저버 패턴 (Part 1)

```csharp
// INotifyPropertyChanged가 Subject 역할
public class EquipmentViewModel
: INotifyPropertyChanged
{
private string _status;

public string Status
{
get => _status;
set
{
if (_status!= value)
```
---
## 디자인 패턴: Observer 옵저버 패턴 (Part 2)

```csharp
{
_status = value;
// Observer들에게 알림
OnPropertyChanged();
}
}
}

public event PropertyChangedEventHandler
PropertyChanged;

protected virtual void OnPropertyChanged(
```
---
## 디자인 패턴: Observer 옵저버 패턴 (Part 3)

```csharp
[CallerMemberName] string propertyName = null)
{
PropertyChanged?.Invoke(this,
new PropertyChangedEventArgs(propertyName));
}
}
```


**효과**:
- View는 ViewModel 변경 자동 감지
- 다대다 관계 지원
- 런타임 구독/해제 가능
</div>
</div>

---
## 디자인 패턴: Command 커맨드 패턴 (Part 1)



<div class="grid grid-cols-2 gap-8">
<div>

**Command 패턴 구조**:
- 요청을 객체로 캡슐화 - 실행 취소(Undo) 가능
- 요청과 실행 분리 - 매개변수화 가능
---
## 디자인 패턴: Command 커맨드 패턴 (Part 1)
```csharp
public interface ICommand
{
bool CanExecute(object parameter);
void Execute(object parameter);
event EventHandler CanExecuteChanged;
}

// RelayCommand 구현
public class RelayCommand: ICommand
{
private readonly Action<object> _execute;
private readonly Predicate<object> _canExecute;
```
---
## 디자인 패턴: Command 커맨드 패턴 (Part 2)

```csharp

public RelayCommand(
Action<object> execute,
Predicate<object> canExecute = null)
{
_execute = execute
?? throw new ArgumentNullException(
nameof(execute));
_canExecute = canExecute;
}

public bool CanExecute(object parameter)
```
---
## 디자인 패턴: Command 커맨드 패턴 (Part 3)

```csharp
{
return _canExecute?.Invoke(parameter)
?? true;
}

public void Execute(object parameter)
{
_execute(parameter);
}

public event EventHandler CanExecuteChanged
{
```
---
## 디자인 패턴: Command 커맨드 패턴 (Part 4) (Code Part 1/4)


```csharp
add => CommandManager.RequerySuggested += value;

```csharp
public class EquipmentViewModel
{
private string _status = "Idle";

public ICommand StartCommand { get; }
public ICommand StopCommand { get; }

public EquipmentViewModel()
{
StartCommand = new RelayCommand(
```
---
## 디자인 패턴: Command 커맨드 패턴 (Part 4) (Code Part 2/4)

```csharp
execute: _ => Start(),
canExecute: _ => _status == "Idle");

StopCommand = new RelayCommand(
execute: _ => Stop(),
canExecute: _ => _status == "Running");
}

private void Start()
{
```
---
## 디자인 패턴: Command 커맨드 패턴 (Part 4) (Code Part 3/4)

```csharp
_status = "Running";
OnPropertyChanged(nameof(Status));
// CommandManager가 자동으로
// CanExecute 재평가
}

private void Stop()
{
_status = "Idle";
OnPropertyChanged(nameof(Status));
```
---
## 디자인 패턴: Command 커맨드 패턴 (Part 4) (Code Part 4/4)

```csharp
}
}
```


**XAML 바인딩**:
```xml
<Button Command="{Binding StartCommand}" Content="시작"/>
<Button Command="{Binding StopCommand}" Content="정지"/>
```

</div>
</div>

---
## 의존성 주입 (Dependency Injection) (Part 1)



<div class="grid grid-cols-2 gap-8">
<div>

**Without DI (의존성 주입 없음)**:
```csharp
public class EquipmentViewModel
{
// 강한 결합
private DatabaseService _db
= new DatabaseService();
---
## 의존성 주입 (Dependency Injection) (Part 1)

private NetworkService _network
= new NetworkService();

public void Save()
{
_db.Save(Equipment);
_network.Send(Equipment);
}
}
```
---
## 의존성 주입 (Dependency Injection) (Part 1)

**문제점**:
- 구체 클래스에 의존 (DB, 네트워크)
- 테스트 불가능 - Mock 주입 불가
- 변경 시 ViewModel 수정 필요

</div>
<div>

**With DI (의존성 주입 사용)**:
---
## 의존성 주입 (Dependency Injection) (Part 1)

```csharp
public class EquipmentViewModel
{
// 인터페이스 의존
private readonly IRepository _repository;
private readonly IDataService _dataService;

// 생성자 주입
public EquipmentViewModel(
IRepository repository,
IDataService dataService)
{
_repository = repository;
```
---
## 의존성 주입 (Dependency Injection) (Part 2)

```csharp
_dataService = dataService;
}

public async Task SaveAsync()
{
await _repository.SaveAsync(Equipment);
await _dataService.SendAsync(Equipment);
}
}

// 운영 환경
var vm = new EquipmentViewModel(
```
---
## 의존성 주입 (Dependency Injection) (Part 3)

```csharp
new SqlRepository(),
new HttpDataService());

// 테스트 환경
var vm = new EquipmentViewModel(
new MockRepository(),
new MockDataService());
```


**효과**:
- 테스트 가능 (Mock 주입)
- 느슨한 결합 (인터페이스 의존)
- 유연한 구성 (런타임 변경 가능)
</div>
</div>

---

## 스레드 동기화 문제 (1/2) (Part 1)

### 배경: Race Condition의 위험성
```mermaid
sequenceDiagram
participant T1 as Thread A
participant M as Memory (_count=0)
participant T2 as Thread B

Note over T1,T2: Race Condition 발생
T1->>M: Read: 0
T2->>M: Read: 0
T1->>M: Write: 1
T2->>M: Write: 1
Note over M: 최종값: 1 (예상값: 2)

Note over T1,T2: With lock 동기화
T1->>M: Lock & Read: 0
---
## 스레드 동기화 문제 (1/2) (Part 2)

Note over T2: 대기중...
T1->>M: Write: 1 & Unlock
T2->>M: Lock & Read: 1
T2->>M: Write: 2 & Unlock
Note over M: 최종값: 2 (정상)
```

<!-- IMAGE PLACEHOLDER: Thread Synchronization Visualization -->
<!--
시각화 제안:
- Race condition 발생 과정
- lock 동기화 메커니즘
- 반도체 HMI 동기화 시나리오
-->
---
## 스레드 동기화 문제 (1/2) (Part 3)

<div class="grid grid-cols-2 gap-8">
<div>

**Race Condition 예시**:
```csharp
public class DataCollector
{
private int _count = 0;

public void Collect()
{
---
## 스레드 동기화 문제 (1/2) (Part 4)

// Thread-unsafe
_count++; // Read-Modify-Write
}
}

// 멀티스레드 실행
Task.Run(() => collector.Collect());
Task.Run(() => collector.Collect());
// _count는 2가 아닌 1!
```
---
## 스레드 동기화 해결 (2/2) (1/2)

**발생 과정**:
1. Thread A가 _count 읽기 (0)
2. Thread B가 _count 읽기 (0)
3. Thread A가 쓰기 (1)
4. Thread B가 쓰기 (1)
5. 결과: 2번 증가했지만 1

</div>
<div>
---
## 스레드 동기화 해결 (2/2) (2/2)

**lock 동기화**:
```csharp
public class DataCollector
{
private int _count = 0;
private readonly object _lock = new object();

public void Collect()
{
// Thread-safe
lock (_lock)
{
_count++;
}
---
## 스레드 동기화 해결 (2/2) (1/2)

}

public int GetCount()
{
lock (_lock)
{
return _count;
}
}
}
```

**동기화 메커니즘**:
---
## 스레드 동기화 해결 (2/2) (2/2)

- **lock**: 상호 배제 (Mutual Exclusion)
- **Monitor**: lock의 저수준 API
- **Mutex**: 프로세스 간 동기화
- **Semaphore**: 동시 접근 수 제한
- **ReaderWriterLock**: 읽기/쓰기 분리

**반도체 적용**:
- critical section 최소화
- 데드락 방지 설계
</div>
</div>

---
## WPF 아키텍처 계층 구조 (Part 1)



```mermaid
graph TB
subgraph APP[Application Layer]
A1[애플리케이션 로직]
end

subgraph FW[Framework Layer]
F1[Controls]
F2[Data Binding]
F3[Layout]
end

subgraph CORE[Core Layer]
```
---
## WPF 아키텍처 계층 구조 (Part 2)

```mermaid
C1[Visual System]
C2[Animation]
C3[Media]
end

subgraph BASE[Base Layer]
B1[Threading]
B2[Input]
B3[Resources]
end

APP --> FW
```
---
## WPF 아키텍처 계층 구조 (Part 3)

```mermaid
FW --> CORE
CORE --> BASE

style APP fill:#e1f5fe
style FW fill:#b2ebf2
style CORE fill:#80deea
style BASE fill:#4dd0e1
```
---
## WPF 아키텍처 계층 구조 (Part 3)

<!-- IMAGE PLACEHOLDER: WPF Architecture Detailed View -->
<!--
시각화 제안:
- WPF 계층별 상세 구조
- 각 계층의 역할 및 DirectX 연결
- 반도체 HMI 최적화 포인트
-->

---
## 시각적 트리 구조 (Part 1)



- **논리 트리**: XAML에서 정의한 요소
- **시각 트리**: 렌더링되는 실제 요소
- **성능 최적화**: 시각 트리 최소화

```mermaid
graph TD
subgraph "논리 트리 (Logical Tree)"
L1[Window]
L2[Grid]
---
## 시각적 트리 구조 (Part 1)

L3[Button]
L1 --> L2
L2 --> L3
end

subgraph "시각 트리 (Visual Tree)"
V1[Window]
V2[Border]
```
---
## 시각적 트리 구조 (Part 2)

```mermaid
V3[Grid]
V4[Border]
V5[ContentPresenter]
V6[TextBlock]

V1 --> V2
V2 --> V3
V3 --> V4
V4 --> V5
V5 --> V6
end

```
---
## 시각적 트리 구조 (Part 3)

```mermaid
style L1 fill:#e8f5e9
style L2 fill:#e8f5e9
style L3 fill:#e8f5e9
style V1 fill:#e3f2fd
style V2 fill:#e3f2fd
style V3 fill:#e3f2fd
style V4 fill:#e3f2fd
style V5 fill:#e3f2fd
style V6 fill:#e3f2fd
```


### 반도체 HMI 최적화
- UserControl로 논리 트리 단순화
- Container 재활용으로 시각 트리 최소화
- 가상화(Virtualization)로 성능 향상

---

## WPF 렌더링 엔진

### 핵심 기술
- **DirectX 기반**: GPU 가속 렌더링
- **보존 모드**: UI 상태 자동 유지
- **벡터 그래픽**: 해상도 독립적

### 반도체 HMI 적용
- **고해상도 지원**: 4K, 8K 모니터 대응
- **부드러운 UI**: 60fps 애니메이션
- **리소스 효율**: GPU 활용으로 CPU 부하 감소

---

## Dependency Property 심화 (1/2)

<div style="margin: 2rem 0;">

### 배경: 왜 Dependency Property인가?
<div style="background: #f3e5f5; padding: 1.5rem; border-radius: 8px; border-left: 4px solid #9c27b0; margin: 1rem 0;">
<ul style="margin: 0; line-height: 1.8;">
<li><strong style="color: #4a148c;">데이터 바인딩:</strong> UI와 데이터 자동 동기화</li>
<li><strong style="color: #4a148c;">속성 변경 알림:</strong> 변경 시 자동 이벤트 발생</li>
<li><strong style="color: #4a148c;">스타일링:</strong> 동적 스타일 적용 가능</li>
<li><strong style="color: #4a148c;">애니메이션:</strong> 속성 기반 애니메이션</li>
</ul>
</div>

### 구현 예제 - Part 1

<div class="grid grid-cols-2 gap-8">
<div>
---
## Dependency Property 심화 (2/2)

```csharp [1-25]
// Custom Control 정의
public class EquipmentStatusControl: Control
{
// Dependency Property 등록
public static readonly DependencyProperty StatusProperty =
DependencyProperty.Register(
"Status",
typeof(EquipmentStatus),
typeof(EquipmentStatusControl),
new PropertyMetadata(EquipmentStatus.Idle, OnStatusChanged));

// CLR 속성 래퍼
public EquipmentStatus Status
{
get { return (EquipmentStatus)GetValue(StatusProperty); }
---
## Dependency Property 심화 (2/2)

set { SetValue(StatusProperty, value); }
}

// 속성 변경 콜백
private static void OnStatusChanged(DependencyObject d,
DependencyPropertyChangedEventArgs e)
{
var control = (EquipmentStatusControl)d;
control.UpdateVisualState((EquipmentStatus)e.NewValue);
}
```

</div>
<div>

**코드 해설**
---
## Dependency Property 심화 (2/2)

- **DependencyProperty 등록**
  - 속성명: "Status"
  - 속성 타입: EquipmentStatus enum
  - 소유자 타입: EquipmentStatusControl

- **CLR 속성 래퍼**
  - GetValue()로 값 읽기
  - SetValue()로 값 쓰기

- **변경 콜백**
  - 속성 변경 시 자동 호출
  - UI 업데이트 로직 실행

</div>
</div>

---

### 구현 예제 - Part 2 (1/2)

<div class="grid grid-cols-2 gap-8">
<div>

```csharp [26-56]

private void UpdateVisualState(EquipmentStatus newStatus)
{
// 상태별 시각적 표현
switch (newStatus)
{
case EquipmentStatus.Running:
Background = Brushes.Green;
break;
case EquipmentStatus.Warning:
---
### 구현 예제 - Part 2 (2/2)

Background = Brushes.Orange;
break;
case EquipmentStatus.Error:
Background = Brushes.Red;
break;
default:
Background = Brushes.Gray;
break;
}
}
}

public enum EquipmentStatus
{
---
### 구현 예제 - Part 2 (2/2)

Idle, // 대기
Running, // 가동 중
Warning, // 경고
Error, // 에러
Maintenance // 정비
}

```

</div>
<div>

**코드 해설**
- **UpdateVisualState 메서드**
  - switch 문으로 상태별 처리
  - Running: 녹색 배경
---
### 구현 예제 - Part 2 (2/2)

  - Warning: 주황색 배경
  - Error: 빨간색 배경
  - 기타: 회색 배경

- **EquipmentStatus Enum**
  - Idle: 대기 상태
  - Running: 가동 중
  - Warning: 경고 상태
  - Error: 에러 상태
  - Maintenance: 정비 중

**실제 적용 사례**: CVD 장비 온도, 압력, 가스 상태별 색상 표시

</div>
</div>

</div>

---

## MVVM 패턴 심화 (1/2)

<div style="margin: 2rem 0;">

### MVVM 구조 다이어그램

```mermaid
graph TB
View[View - XAML UI]
ViewModel[ViewModel - Presentation Logic]
Model[Model - Business Logic & Data]

View -->|Data Binding| ViewModel
View -->|Command| ViewModel
ViewModel -->|Property Changed| View
ViewModel -->|Query/Update| Model
Model -->|Notify| ViewModel

style View fill:#fff3e0
style ViewModel fill:#e1f5fe
style Model fill:#f3e5f5
```
---
## MVVM 패턴 심화 (2/2)

<!-- IMAGE PLACEHOLDER: MVVM Pattern in Semiconductor HMI -->
<!--
시각화 제안:
- MVVM 패턴 전체 구조
- View(XAML UI), ViewModel(프레젠테이션 로직), Model(비즈니스 로직) 역할
- 반도체 HMI 적용 사례
-->

### 각 계층의 역할
---
## MVVM 패턴 심화 (2/2)

<div style="display: flex; flex-direction: column; gap: 1rem; margin: 1.5rem 0;">
<div style="display: flex; align-items: center; background: #e8f5e8; padding: 1rem; border-radius: 8px;">
<div style="background: #28a745; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">V</div>
<span style="color: #155724;"><strong>View:</strong> XAML로 UI 정의, 사용자 입력 처리</span>
</div>
<div style="display: flex; align-items: center; background: #e3f2fd; padding: 1rem; border-radius: 8px;">
<div style="background: #2196f3; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">VM</div>
---
## MVVM 패턴 심화 (2/2)
<span style="color: #0d47a1;"><strong>ViewModel:</strong> 데이터 바인딩, 명령 처리, 검증 로직</span>
</div>
<div style="display: flex; align-items: center; background: #f3e5f5; padding: 1rem; border-radius: 8px;">
<div style="background: #9c27b0; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">M</div>
<span style="color: #4a148c;"><strong>Model:</strong> 비즈니스 로직, 데이터 액세스, 도메인 모델</span>
</div>
</div>
---
## MVVM 패턴 심화 (2/2)

### MVVM 패턴의 장점

<div style="background: #fff3cd; padding: 1.5rem; border-radius: 8px; border: 1px solid #f39c12; margin: 1.5rem 0;">
<ul style="margin: 0; line-height: 1.8; color: #856404;">
<li><strong>관심사 분리:</strong> UI와 ViewModel 독립적 개발</li>
<li><strong>테스트 용이성:</strong> ViewModel 단위 테스트 가능</li>
<li><strong>유지보수성:</strong> ViewModel 변경 시 View 영향 없음</li>
<li><strong>디자이너 협업:</strong> XAML 수정으로 UI/UX 개선 가능</li>
</ul>
</div>

</div>

---

## INotifyPropertyChanged 구현

### 핵심 개념
**속성 변경 알림 메커니즘**:
- **이벤트 발생**: 속성 변경 시 UI에 알림
- **자동 업데이트**: Data Binding을 통한 자동 갱신
- **양방향 바인딩**: UI ↔ ViewModel 실시간 동기화

---

## BaseViewModel 구현 (1/4) (1/2)

<div class="grid grid-cols-2 gap-8">
<div>

```csharp [1-25]
// 모든 ViewModel의 기반 클래스
public abstract class BaseViewModel: INotifyPropertyChanged
{
public event PropertyChangedEventHandler PropertyChanged;
// 속성 변경 알림
protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
{
---
## BaseViewModel 구현 (1/4) (2/2)

PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
}
// 속성 값 설정 헬퍼
protected bool SetProperty<T>(ref T backingField, T value, [CallerMemberName] string propertyName = null)
{
if (EqualityComparer<T>.Default.Equals(backingField, value))
return false;
backingField = value;
OnPropertyChanged(propertyName);
return true;
---
## BaseViewModel 구현 (1/4) (2/2)

}
}
// 실제 ViewModel 구현
public class EquipmentViewModel: BaseViewModel
```

</div>
<div>

**BaseViewModel 구조 설명**
- INotifyPropertyChanged 인터페이스 구현
- PropertyChanged 이벤트 정의
---
## BaseViewModel 구현 (1/4) (2/2)

- **OnPropertyChanged 메서드**
  - **[CallerMemberName]**: 호출한 속성명 자동 전달
  - propertyName이 null이면 자동 설정

- **SetProperty 제네릭 메서드**
  - 기존 값과 비교하여 변경 시만 이벤트 발생
  - 백킹 필드 업데이트
- **상속 구조**
  - BaseViewModel을 상속받아 사용
  - 중복 코드 제거

</div>
</div>

---

## BaseViewModel 구현 (2/4) (1/2)

<div class="grid grid-cols-2 gap-8">
<div>

```csharp [26-50]
{
private string _equipmentId;
private EquipmentStatus _status;
private double _temperature;
private double _pressure;
private DateTime _lastUpdate;
public string EquipmentId
{
---
## BaseViewModel 구현 (2/4) (2/2)

get => _equipmentId;
set => SetProperty(ref _equipmentId, value);
}
public EquipmentStatus Status
{
get => _status;
set
{
if (SetProperty(ref _status, value))
{
// 관련 속성도 업데이트
---
## BaseViewModel 구현 (2/4) (2/2)

OnPropertyChanged(nameof(StatusColor));
OnPropertyChanged(nameof(StatusText));
}
}
```

</div>
<div>

**코드 해설**
- private 백킹 필드 정의
- **equipmentId**: 장비 고유 ID
- **status**: 장비 상태
---
## BaseViewModel 구현 (2/4) (2/2)

- **temperature**: 온도 값
- **pressure**: 압력 값
- **lastUpdate**: 마지막 업데이트 시간

- EquipmentId 속성
- get/set 구현
- SetProperty로 자동 알림

- Status 속성 (연쇄 업데이트)
- SetProperty가 true 반환 (값 변경됨)
- 관련 속성도 업데이트 알림
  - **nameof**: 문자열 하드코딩 방지

</div>
</div>

---
## BaseViewModel 구현 (3/4) (1/2) (Part 1)


<div class="grid grid-cols-2 gap-8">
<div>

```csharp [51-75]
}
public double Temperature
{
get => _temperature;
set => SetProperty(ref _temperature, value);
---
## BaseViewModel 구현 (3/4) (1/2) (Part 1)

}
public double Pressure
{
get => _pressure;
set => SetProperty(ref _pressure, value);
}
public DateTime LastUpdate
```
---
## BaseViewModel 구현 (3/4) (1/2) (Part 2)

```csharp [51-75]
{
get => _lastUpdate;
set => SetProperty(ref _lastUpdate, value);
}
// 계산된 속성 (Computed Property)
public string StatusColor => Status switch
{
EquipmentStatus.Running => "#4CAF50", // 녹색
EquipmentStatus.Warning => "#FF9800", // 주황색
```
---
## BaseViewModel 구현 (3/4) (2/2)

</div>
<div>

**코드 해설**
- **Temperature 속성**
  - double 타입
  - 온도 센서 값 저장
- **Pressure 속성**
  - double 타입
  - 압력 센서 값 저장 - Torr 단위
---
## BaseViewModel 구현 (3/4) (2/2)

- **LastUpdate 속성**
  - DateTime 타입
  - 마지막 업데이트 시간

- **StatusColor 계산 속성**
  - **switch 표현식**: C# 8.0 기능
  - Running 상태: 녹색 (#4CAF50)
  - Warning 상태: 주황색 (#FF9800)

</div>
</div>

---

## BaseViewModel 구현 (4/4) (1/2) (Part 1)

<div class="grid grid-cols-2 gap-8">
<div>

```csharp [76-95]
EquipmentStatus.Error => "#F44336", // 빨간색
EquipmentStatus.Maintenance => "#2196F3", // 파란색
_ => "#9E9E9E" // 회색 (기본값)
};
public string StatusText => Status switch
{
EquipmentStatus.Idle => "대기",
---
## BaseViewModel 구현 (4/4) (1/2) (Part 2)

EquipmentStatus.Running => "가동 중",
EquipmentStatus.Warning => "경고",
EquipmentStatus.Error => "에러",
EquipmentStatus.Maintenance => "정비 중",
_ => "알 수 없음"
};
public string TemperatureText => $"{Temperature:F1}°C";
public string PressureText => $"{Pressure:F3} Torr";
public string LastUpdateText => LastUpdate.ToString("yyyy-MM-dd HH:mm:ss");
}
```
---
## BaseViewModel 구현 (4/4) (2/2)

</div>
<div>

**코드 해설**
- **StatusColor 계속**
  - Error 상태: 빨간색 (#F44336)
  - Maintenance 상태: 파란색 (#2196F3)
  - 기본값: 회색 (#9E9E9E)

- **StatusText 속성**
  - 상태별 한글 텍스트 반환
  - UI에 표시할 문자열
---
## BaseViewModel 구현 (4/4) (2/2)

- **TemperatureText**
  - 온도 포맷팅: 소수점 1자리 + °C 단위
- **PressureText**
  - 압력 포맷팅: 소수점 3자리 + Torr 단위
- **LastUpdateText**
  - datetime 포맷팅: yyyy-MM-dd HH:mm:ss 형식

**MVVM 효과**: View는 이 속성들만 바인딩하면 자동 업데이트

</div>
</div>

</div>

---
## RelayCommand 구현 (Part 1)



<div style="margin: 2rem 0;">


<div style="background: #e3f2fd; padding: 1.5rem; border-radius: 8px; border-left: 4px solid #2196f3; margin: 1rem 0;">
<ul style="margin: 0; line-height: 1.8;">
<li><strong style="color: #0d47a1;">Execute:</strong> 명령 실행 로직</li>
<li><strong style="color: #0d47a1;">CanExecute:</strong> 실행 가능 여부 판단</li>
<li><strong style="color: #0d47a1;">CanExecuteChanged:</strong> 실행 가능 여부 변경 이벤트</li>
</ul>
</div>
---
## RelayCommand 구현 (Part 1)

```csharp
// RelayCommand 구현
public class RelayCommand: ICommand
{
private readonly Action _execute;
private readonly Func<bool> _canExecute;

public RelayCommand(Action execute, Func<bool> canExecute = null)
{
_execute = execute?? throw new ArgumentNullException(nameof(execute));
_canExecute = canExecute;
}

```
---
## RelayCommand 구현 (Part 2)

```csharp
public event EventHandler CanExecuteChanged
{
add { CommandManager.RequerySuggested += value; }
remove { CommandManager.RequerySuggested -= value; }
}

public bool CanExecute(object parameter)
{
return _canExecute?.Invoke()?? true;
}

public void Execute(object parameter)
```
---
## RelayCommand 구현 (Part 3)

```csharp
{
_execute.Invoke();
}

// CanExecute 강제 재평가
public void RaiseCanExecuteChanged()
{
CommandManager.InvalidateRequerySuggested();
}
}

// 제네릭 버전 (파라미터 전달)
```
---
## RelayCommand 구현 (Part 4)

```csharp
public class RelayCommand<T>: ICommand
{
private readonly Action<T> _execute;
private readonly Predicate<T> _canExecute;

public RelayCommand(Action<T> execute, Predicate<T> canExecute = null)
{
_execute = execute?? throw new ArgumentNullException(nameof(execute));
_canExecute = canExecute;
}

public event EventHandler CanExecuteChanged
```
---
## RelayCommand 구현 (Part 5)

```csharp
{
add { CommandManager.RequerySuggested += value; }
remove { CommandManager.RequerySuggested -= value; }
}

public bool CanExecute(object parameter)
{
return _canExecute?.Invoke((T)parameter)?? true;
}

public void Execute(object parameter)
{
```
---
## RelayCommand 구현 (Part 6)

```csharp
_execute.Invoke((T)parameter);
}
}
```


</div>
