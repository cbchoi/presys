## 실습 1: 기본 XAML 구조 생성

<div style="margin: 2rem 0;">

### 배경: 왜 XAML 기반 구조가 필요한가?

**문제 상황**: 반도체 공장의 CVD/PVD 장비는 수백 개의 센서 데이터를 실시간으로 표시해야 합니다. 기존 Windows Forms는 UI와 로직이 혼재되어 유지보수가 어렵고, 디자이너와 개발자의 협업이 불가능했습니다.

**해결책**: WPF의 XAML은 UI 정의와 로직을 분리하여 디자이너는 UI를, 개발자는 비즈니스 로직에 집중할 수 있습니다. 데이터 바인딩을 통해 센서 값 변경 시 자동으로 화면이 업데이트됩니다.

### 핵심 개념

**XAML(eXtensible Application Markup Language)**은 WPF 애플리케이션의 UI를 선언적으로 정의하는 XML 기반 언어입니다.

**동작 원리**:
1. XAML 파일은 컴파일 시 .NET 객체로 변환됩니다
2. Grid, Border, TextBlock 등의 요소는 각각 클래스 인스턴스가 됩니다
3. 속성(Attribute)은 객체의 프로퍼티로 매핑됩니다
4. 계층 구조는 부모-자식 관계를 형성합니다

**설계 철학**: 선언적 UI 정의로 코드 가독성 향상, 디자이너 도구 지원, UI/로직 분리

### ️ 프로젝트 생성

<div style="background: #e8f5e8; padding: 1.5rem; border-radius: 8px; border-left: 4px solid #28a745; margin: 1rem 0;">

**Visual Studio에서 새 프로젝트 생성:**
1. WPF Application (.NET 6.0) 선택
2. 프로젝트명: `SemiconductorHMI`
3. 솔루션명: `SemiconductorEquipmentMonitor`

---
## 실습 1: 기본 XAML 구조 생성
</div>

### 기본 MainWindow.xaml 구조

**실제 적용 사례 (PVD 장비)**:
- 화면 크기: 1920x1080 (공장 모니터 표준)
- 헤더 영역: 장비 ID, 현재 시간, 알람 개수 표시
- 메인 영역: 온도(150-200°C), 압력(0.001-0.01 Torr), 가스 유량(10-100 sccm) 실시간 표시
- 상태바: 통신 상태, 마지막 업데이트 시간

**HCI 이론 연결 (Miller's Law)**:
헤더, 메인, 상태바 3개 영역으로 분할하여 사용자가 한 번에 처리할 정보를 7±2 청크 이내로 제한합니다.
---
## 실습 1: 기본 XAML 구조 생성

### 간단한 코드 해설

**주요 코드 라인 설명**:
- `<Window>`: 최상위 컨테이너, 윈도우 창을 나타냄
- `xmlns`: XML 네임스페이스 선언, WPF 컨트롤 접근
- `WindowState="Maximized"`: 전체화면 시작 (공장 모니터용)
- `<Grid.RowDefinitions>`: 행 기반 레이아웃 정의 (헤더/메인/상태바)
- `{Binding CurrentTime}`: 데이터 바인딩, ViewModel 속성과 연결

```xml
<Window x:Class="SemiconductorHMI.MainWindow"
 xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
 xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
 Title="반도체 장비 모니터링 시스템"
 Height="800" Width="1200"
 WindowState="Maximized"
 Background="#F5F5F5">

 <!-- 메인 레이아웃 -->
 <Grid>
 <Grid.RowDefinitions>
 <RowDefinition Height="80"/> <!-- 헤더 -->
 <RowDefinition Height="*"/> <!-- 메인 콘텐츠 -->
 <RowDefinition Height="30"/> <!-- 상태바 -->
 </Grid.RowDefinitions>

---
## 실습 1: 기본 XAML 구조 생성
 <!-- 헤더 영역 -->
 <Border Grid.Row="0" Background="#2C3E50" Padding="20,10">
 <Grid>
 <Grid.ColumnDefinitions>
 <ColumnDefinition Width="*"/>
 <ColumnDefinition Width="Auto"/>
 <ColumnDefinition Width="Auto"/>
 </Grid.ColumnDefinitions>

 <!-- 시스템 제목 -->
 <StackPanel Grid.Column="0" VerticalAlignment="Center">
 <TextBlock Text="반도체 장비 모니터링 시스템"
 FontSize="24" FontWeight="Bold"
 Foreground="White"/>
 <TextBlock Text="Semiconductor Equipment Monitoring System"
 FontSize="12"
 Foreground="#BDC3C7"/>
 </StackPanel>

---
## 실습 1: 기본 XAML 구조 생성
 <!-- 현재 시간 -->
 <TextBlock Grid.Column="1"
 Text="{Binding CurrentTime}"
 FontSize="16" FontWeight="Medium"
 Foreground="White"
 VerticalAlignment="Center"
 Margin="20,0"/>
---
## 실습 1: 기본 XAML 구조 생성
 <!-- 알람 요약 -->
 <Border Grid.Column="2"
 Background="#E74C3C"
 CornerRadius="15"
 Padding="10,5"
 VerticalAlignment="Center">
 <StackPanel Orientation="Horizontal">
 <TextBlock Text="" FontSize="16" Margin="0,0,5,0"/>
 <TextBlock Text="{Binding AlarmCount}"
 FontSize="14" FontWeight="Bold"
 Foreground="White"/>
 <TextBlock Text="건"
 FontSize="14"
 Foreground="White" Margin="2,0,0,0"/>
 </StackPanel>
 </Border>
 </Grid>
 </Border>

---
## 실습 1: 기본 XAML 구조 생성
 <!-- 메인 콘텐츠 영역 -->
 <Grid Grid.Row="1" Margin="10">
 <Grid.ColumnDefinitions>
 <ColumnDefinition Width="250"/> <!-- 사이드바 -->
 <ColumnDefinition Width="*"/> <!-- 메인 영역 -->
 </Grid.ColumnDefinitions>
---
## 실습 1: 기본 XAML 구조 생성
 <!-- 사이드바 -->
 <Border Grid.Column="0"
 Background="White"
 CornerRadius="5"
 BorderBrush="#E0E0E0"
 BorderThickness="1"
 Margin="0,0,10,0">
 <StackPanel Margin="10">
 <TextBlock Text="장비 목록"
 FontSize="16" FontWeight="Bold"
 Margin="0,0,0,10"/>

 <!-- 장비 목록 리스트박스 -->
 <ListBox x:Name="EquipmentListBox"
 ItemsSource="{Binding EquipmentList}"
 SelectedItem="{Binding SelectedEquipment}"
 Background="Transparent"
 BorderThickness="0">
 <ListBox.ItemTemplate>
 <DataTemplate>
 <Border Background="{Binding StatusColor}"
 CornerRadius="3"
 Padding="8,5"
 Margin="0,2">
 <StackPanel>
 <TextBlock Text="{Binding EquipmentId}"
 FontWeight="Bold"
 Foreground="White"/>
 <TextBlock Text="{Binding StatusText}"
 FontSize="12"
 Foreground="White"/>
 </StackPanel>
 </Border>
 </DataTemplate>
 </ListBox.ItemTemplate>
 </ListBox>
 </StackPanel>
 </Border>

---
## 실습 1: 기본 XAML 구조 생성
 <!-- 메인 모니터링 영역 -->
 <Border Grid.Column="1"
 Background="White"
 CornerRadius="5"
 BorderBrush="#E0E0E0"
 BorderThickness="1">
 <Grid Margin="20">
 <Grid.RowDefinitions>
 <RowDefinition Height="Auto"/>
 <RowDefinition Height="*"/>
 </Grid.RowDefinitions>

 <!-- 선택된 장비 정보 헤더 -->
 <StackPanel Grid.Row="0" Margin="0,0,0,20">
 <TextBlock Text="{Binding SelectedEquipment.EquipmentId}"
 FontSize="24" FontWeight="Bold"/>
 <TextBlock Text="{Binding SelectedEquipment.LastUpdateText}"
 FontSize="12"
 Foreground="#666666"/>
 </StackPanel>

---
## 실습 1: 기본 XAML 구조 생성
 <!-- 상세 모니터링 정보 -->
 <Grid Grid.Row="1">
 <Grid.ColumnDefinitions>
 <ColumnDefinition Width="*"/>
 <ColumnDefinition Width="*"/>
 </Grid.ColumnDefinitions>
---
## 실습 1: 기본 XAML 구조 생성
 <!-- 온도 정보 -->
 <Border Grid.Column="0"
 Background="#F8F9FA"
 CornerRadius="8"
 Padding="20"
 Margin="0,0,10,0">
 <StackPanel>
 <TextBlock Text="챔버 온도"
 FontSize="16" FontWeight="Medium"
 Margin="0,0,0,10"/>
 <TextBlock Text="{Binding SelectedEquipment.TemperatureText}"
 FontSize="36" FontWeight="Bold"
 Foreground="#E67E22"/>
 <ProgressBar Value="{Binding SelectedEquipment.Temperature}"
 Minimum="0" Maximum="300"
 Height="10"
 Background="#E0E0E0"
 Foreground="#E67E22"
 Margin="0,10,0,0"/>
 </StackPanel>
 </Border>

---
## 실습 1: 기본 XAML 구조 생성
 <!-- 압력 정보 -->
 <Border Grid.Column="1"
 Background="#F8F9FA"
 CornerRadius="8"
 Padding="20"
 Margin="10,0,0,0">
 <StackPanel>
 <TextBlock Text="챔버 압력"
 FontSize="16" FontWeight="Medium"
 Margin="0,0,0,10"/>
 <TextBlock Text="{Binding SelectedEquipment.PressureText}"
 FontSize="36" FontWeight="Bold"
 Foreground="#3498DB"/>
 <ProgressBar Value="{Binding SelectedEquipment.Pressure}"
 Minimum="0" Maximum="2"
 Height="10"
 Background="#E0E0E0"
 Foreground="#3498DB"
 Margin="0,10,0,0"/>
 </StackPanel>
 </Border>
 </Grid>
 </Grid>
 </Border>
 </Grid>

---
## 실습 1: 기본 XAML 구조 생성
 <!-- 상태바 -->
 <Border Grid.Row="2" Background="#34495E" Padding="10,5">
 <Grid>
 <Grid.ColumnDefinitions>
 <ColumnDefinition Width="*"/>
 <ColumnDefinition Width="Auto"/>
 </Grid.ColumnDefinitions>

 <TextBlock Grid.Column="0"
 Text="{Binding StatusMessage}"
 Foreground="White"
 VerticalAlignment="Center"/>

 <TextBlock Grid.Column="1"
 Text="시스템 정상"
 Foreground="#2ECC71"
 VerticalAlignment="Center"/>
 </Grid>
 </Border>
 </Grid>
</Window>
```
---
## 실습 1: 기본 XAML 구조 생성

### XAML 레이아웃 구조 다이어그램

```mermaid
graph TD
    A[Window<br/>최상위 컨테이너] --> B[Grid<br/>3행 레이아웃]
    B --> C[Row 0: Header<br/>80px 고정]
    B --> D[Row 1: Content<br/>*가변]
    B --> E[Row 2: StatusBar<br/>30px 고정]

    C --> C1[Border<br/>배경 #2C3E50]
    C1 --> C2[장비 ID + 시간 + 알람]

    D --> D1[Grid<br/>2열 레이아웃]
    D1 --> D2[Col 0: Sidebar<br/>250px]
    D1 --> D3[Col 1: Main<br/>*가변]

    D2 --> D2A[장비 목록<br/>ListBox]
    D3 --> D3A[온도/압력<br/>Progress + Value]

    E --> E1[상태 메시지 + 시스템 상태]

    style A fill:#e3f2fd
    style B fill:#fff3e0
    style C fill:#ffebee
    style D fill:#e8f5e9
    style E fill:#f3e5f5
```

**구조 설명**: Window → Grid(3행) → 헤더/콘텐츠/상태바로 명확히 분리하여 역할 구분

</div>
---
## 실습 2: 데이터 바인딩 설정

<div style="margin: 2rem 0;">

### 배경: 왜 데이터 바인딩이 필요한가?

**문제 상황**: CVD 장비의 온도 센서가 1초마다 값을 전송할 때, 기존 방식은 `textBox.Text = temperature.ToString()`처럼 수동으로 UI를 업데이트해야 했습니다. 100개 센서라면 100줄의 코드가 필요합니다.

**해결책**: 데이터 바인딩을 사용하면 ViewModel의 속성이 변경될 때 자동으로 UI가 업데이트됩니다. `{Binding Temperature}` 한 줄로 완료됩니다.

### 핵심 개념

**데이터 바인딩**은 View와 ViewModel 간의 자동 동기화 메커니즘입니다.

**동작 원리**:
1. ViewModel이 `INotifyPropertyChanged` 인터페이스를 구현합니다
2. 속성 변경 시 `PropertyChanged` 이벤트를 발생시킵니다
3. WPF 바인딩 엔진이 이벤트를 감지하고 UI를 자동 업데이트합니다
4. `DataContext`를 통해 View와 ViewModel을 연결합니다

**설계 철학**: 선언적 바인딩으로 코드 감소, 자동 업데이트로 버그 방지, MVVM 패턴의 핵심 요소

### MainWindow.xaml.cs 코드-비하인드

**실제 적용 사례 (CVD 장비)**:
- DataContext 설정으로 4개 장비의 실시간 데이터 자동 바인딩
- 온도/압력/유량 변경 시 코드 없이 UI 즉시 반영
- 알람 개수 자동 계산 및 표시

<div class="grid grid-cols-2 gap-8">
<div>

---
## 실습 2: 데이터 바인딩 설정
```csharp [1-17]
using System.Windows;
namespace SemiconductorHMI
{
 public partial class MainWindow : Window
 {
 public MainWindow()
 {
 InitializeComponent();
 // ViewModel 설정
 DataContext = new MainWindowViewModel();
 }
 }
}
```

---
## 실습 2: 데이터 바인딩 설정
</div>
<div>

**코드-비하인드 기본 구조**
- System.Windows 네임스페이스 사용
- SemiconductorHMI 네임스페이스 정의
- MainWindow가 Window 클래스 상속
- 생성자 메서드
 - InitializeComponent() - XAML 초기화
 - DataContext 설정으로 MVVM 바인딩 활성화

**MVVM 패턴 핵심**:
- View(XAML)와 ViewModel 연결점
- 최소한의 코드-비하인드로 관심사 분리
- DataContext를 통한 자동 데이터 바인딩

</div>
</div>
---
### MainWindowViewModel 구현 - Part 1

<div class="grid grid-cols-2 gap-8">
<div>

---
### MainWindowViewModel 구현 - Part 1
```csharp [18-42]
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Threading;
namespace SemiconductorHMI
{
 public class MainWindowViewModel : BaseViewModel
 {
 private EquipmentViewModel _selectedEquipment;
 private string _currentTime;
 private int _alarmCount;
 private string _statusMessage;
 private DispatcherTimer _clockTimer;
 public ObservableCollection<EquipmentViewModel> EquipmentList { get; }
 public EquipmentViewModel SelectedEquipment
 {
 get => _selectedEquipment;
 set => SetProperty(ref _selectedEquipment, value);
 }
 public string CurrentTime
```

---
### MainWindowViewModel 구현 - Part 1
</div>
<div>

**ViewModel 클래스 기본 구조**
- 필요한 네임스페이스 import
 - ObservableCollection: 컬렉션 바인딩용
 - DispatcherTimer: UI 스레드 타이머
- BaseViewModel 상속으로 INotifyPropertyChanged 구현

- private 백킹 필드들
 - **selectedEquipment**: 현재 선택된 장비
 - **currentTime**: 실시간 시계 표시
 - **alarmCount**: 알람 발생 개수
 - **statusMessage**: 상태 메시지
 - **clockTimer**: 시계 업데이트용 타이머

- ObservableCollection으로 UI 자동 업데이트
- 선택된 장비 속성 (읽기전용 프로퍼티 사용)

---
### MainWindowViewModel 구현 - Part 1
</div>
</div>
---
### MainWindowViewModel 구현 - Part 2

<div class="grid grid-cols-2 gap-8">
<div>

---
### MainWindowViewModel 구현 - Part 2
```csharp [43-67]
 {
 get => _currentTime;
 set => SetProperty(ref _currentTime, value);
 }
 public int AlarmCount
 {
 get => _alarmCount;
 set => SetProperty(ref _alarmCount, value);
 }
 public string StatusMessage
 {
 get => _statusMessage;
 set => SetProperty(ref _statusMessage, value);
 }
 public MainWindowViewModel()
 {
 EquipmentList = new ObservableCollection<EquipmentViewModel>();
 InitializeEquipmentData();
 InitializeClock();
 // 첫 번째 장비를 기본 선택
 if (EquipmentList.Count > 0)
```

---
### MainWindowViewModel 구현 - Part 2
</div>
<div>

**속성 정의 및 생성자**
- CurrentTime 속성
 - 실시간 시계 표시용
 - UI에서 바인딩하여 자동 업데이트

- AlarmCount 속성
 - Warning/Error 상태 장비 개수
 - 헤더 영역 알람 표시용

- StatusMessage 속성
 - 시스템 상태 메시지
 - 사용자에게 현재 상태 안내

---
### MainWindowViewModel 구현 - Part 2
- 생성자 메서드 시작
 - ObservableCollection 초기화
 - 샘플 장비 데이터 생성
 - 실시간 시계 초기화
 - 첫 번째 장비를 기본 선택

</div>
</div>
---
### MainWindowViewModel 구현 - Part 3

<div class="grid grid-cols-2 gap-8">
<div>

---
### MainWindowViewModel 구현 - Part 3
```csharp [68-92]
 SelectedEquipment = EquipmentList[0];
 StatusMessage = "시스템 초기화 완료";
 }
 private void InitializeEquipmentData()
 {
 // 샘플 반도체 장비 데이터 생성
 EquipmentList.Add(new EquipmentViewModel
 {
 EquipmentId = "CVD-001",
 Status = EquipmentStatus.Running,
 Temperature = 250.5,
 Pressure = 0.850,
 LastUpdate = DateTime.Now
 });
 EquipmentList.Add(new EquipmentViewModel
 {
 EquipmentId = "PVD-002",
 Status = EquipmentStatus.Warning,
 Temperature = 185.2,
 Pressure = 1.250,
 LastUpdate = DateTime.Now.AddMinutes(-2)
 });
```

---
### MainWindowViewModel 구현 - Part 3
</div>
<div>

**샘플 데이터 초기화 - Part 1**
- 첫 번째 장비를 기본 선택으로 설정
- 초기화 완료 메시지 설정

- CVD-001 장비 데이터
 - **CVD**: Chemical Vapor Deposition (화학기상증착)
 - Running 상태 - 정상 운전 중
 - 250.5°C - 일반적인 CVD 공정 온도
 - 0.850 Torr - 공정 압력

- PVD-002 장비 데이터
 - **PVD**: Physical Vapor Deposition (물리기상증착)
 - Warning 상태 - 주의 필요
 - 1.250 Torr - 경고 상태 압력
 - 2분 전 업데이트 - 통신 지연 시뮬레이션

---
### MainWindowViewModel 구현 - Part 3
</div>
</div>
---
### MainWindowViewModel 구현 - Part 4

<div class="grid grid-cols-2 gap-8">
<div>

---
### MainWindowViewModel 구현 - Part 4
```csharp [93-117]
 EquipmentList.Add(new EquipmentViewModel
 {
 EquipmentId = "ETCH-003",
 Status = EquipmentStatus.Idle,
 Temperature = 25.0,
 Pressure = 0.001,
 LastUpdate = DateTime.Now.AddMinutes(-15)
 });
 EquipmentList.Add(new EquipmentViewModel
 {
 EquipmentId = "CMP-004",
 Status = EquipmentStatus.Error,
 Temperature = 95.8,
 Pressure = 0.750,
 LastUpdate = DateTime.Now.AddMinutes(-5)
 });
 // 알람 개수 계산
 UpdateAlarmCount();
 }
 private void InitializeClock()
 {
```

---
### MainWindowViewModel 구현 - Part 4
</div>
<div>

**샘플 데이터 초기화 - Part 2**
- ETCH-003 장비 데이터
 - **ETCH**: 식각 공정 장비
 - Idle 상태 - 대기 중
 - 25.0°C - 상온 상태
 - 0.001 Torr - 고진공 상태
 - 15분 전 업데이트 - 오프라인 상태

- CMP-004 장비 데이터
 - **CMP**: Chemical Mechanical Planarization (화학기계평탄화)
 - Error 상태 - 오류 발생
 - 95.8°C - 비정상 온도
 - 5분 전 업데이트

---
### MainWindowViewModel 구현 - Part 4
- 알람 개수 계산 메서드 호출
- 실시간 시계 초기화 메서드 시작

</div>
</div>
---
### MainWindowViewModel 구현 - Part 5

<div class="grid grid-cols-2 gap-8">
<div>

---
### MainWindowViewModel 구현 - Part 5
```csharp [118-142]
 // 1초마다 시간 업데이트
 _clockTimer = new DispatcherTimer
 {
 Interval = TimeSpan.FromSeconds(1)
 };
 _clockTimer.Tick += (s, e) => UpdateCurrentTime();
 _clockTimer.Start();
 UpdateCurrentTime();
 }
 private void UpdateCurrentTime()
 {
 CurrentTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
 }
 private void UpdateAlarmCount()
 {
 int count = 0;
 foreach (var equipment in EquipmentList)
 {
 if (equipment.Status == EquipmentStatus.Warning ||
 equipment.Status == EquipmentStatus.Error)
 {
 count++;
```

---
### MainWindowViewModel 구현 - Part 5
</div>
<div>

**타이머 및 업데이트 메서드**
- DispatcherTimer 설정
 - 1초 간격으로 설정
 - UI 스레드에서 안전한 타이머 사용

- 람다식으로 이벤트 핸들러 등록
 - 간결한 문법으로 콜백 설정
- 타이머 시작
- 즉시 시간 업데이트

- 현재 시간 업데이트 메서드
 - 표준 날짜/시간 포맷 사용

---
### MainWindowViewModel 구현 - Part 5
- 알람 개수 계산 메서드
 - 전체 장비 리스트 순회
 - Warning 또는 Error 상태 체크
 - 카운터 증가

</div>
</div>
---
### MainWindowViewModel 구현 - Part 6

<div class="grid grid-cols-2 gap-8">
<div>

```csharp [143-152]
 }
 }
 AlarmCount = count;
 }
 }
}
```

</div>
<div>

---
### MainWindowViewModel 구현 - Part 6
**메서드 완료 및 클래스 종료**
- 계산된 알람 개수를 속성에 설정
 - SetProperty 호출로 UI 자동 업데이트
- 메서드 및 클래스 종료

**MainWindowViewModel의 핵심 기능**:
1. **실시간 데이터 바인딩**: ObservableCollection 사용
2. **자동 UI 업데이트**: INotifyPropertyChanged 구현
3. **타이머 기반 갱신**: DispatcherTimer로 시계 업데이트
4. **알람 모니터링**: 상태 기반 알람 개수 계산
5. **샘플 데이터**: 4가지 반도체 장비 시뮬레이션

**MVVM 패턴 완성**: View는 ViewModel과 바인딩만으로 동작

</div>
</div>

</div>