# Week 4: C# 고급 UI/UX 패턴 및 커스텀 컨트롤

## 학습 목표

1. **디자인 패턴**: Strategy, Decorator 패턴을 활용하여 차트 종류를 동적으로 변경하고, UI 컴포넌트에 알람/블링킹 효과를 추가하는 방법을 학습합니다.
2. **Custom Control**: WPF Dependency Property를 사용하여 CircularGauge, LinearGauge 등 재사용 가능한 커스텀 컨트롤을 개발하는 기술을 습득합니다.
3. **성능 최적화**: 복잡한 UI 렌더링 시에도 60 FPS를 유지하고, GPU 가속을 활용하여 CPU 사용률을 10% 이하로 낮추는 방법을 학습합니다.

---

## 이번 주 주요 내용

### 배경
반도체 장비 HMI는 운영자의 상황 인식(Situational Awareness)을 높이기 위해 다양한 시각화 기법을 사용합니다. 온도는 원형 게이지, 압력은 선형 게이지, 트렌드는 라인 차트로 표시하며, 알람 발생 시 테두리 깜박임 효과를 추가합니다. Strategy/Decorator 패턴과 Custom Control로 이를 체계적으로 구현합니다.

### 핵심 개념
- **Strategy Pattern**: IChartStrategy 인터페이스로 BarChart, LineChart, Heatmap 전략 교체 가능
- **Decorator Pattern**: BaseControl → AlarmDecorator → BlinkingDecorator 순차 기능 확장
- **Dependency Property**: XAML에서 바인딩 가능한 속성 정의 (Value, MinValue, MaxValue, Unit)
- **Custom Control**: OnRender() 오버라이드로 DrawingContext에 직접 그리기 (성능 최적화)

### 실습 내용
- Strategy Pattern으로 차트 종류 동적 변경 (ComboBox 선택 → 차트 전환)
- Decorator Pattern으로 알람 테두리 및 블링킹 효과 추가
- CircularGauge Custom Control 개발 (온도 200-450°C 표시)
- 성능 측정: 60 FPS 유지, CPU <10%, GPU >70% 사용률

---

## Week 3 복습

**Week 3 핵심 내용**:
- System.Threading.Timer: 100ms 주기 센서 데이터 수집
- ConcurrentQueue: Thread-safe 데이터 큐
- Dispatcher: Background Thread → UI Thread 동기화
- 성능 목표: Dispatcher <5ms, UI 60 FPS, CPU <5%

**Week 4 연결점**:
- Week 3은 **데이터 수집 및 전달** (Backend)
- Week 4는 **데이터 시각화 및 UX** (Frontend)
- 실시간 데이터를 받아서 다양한 차트와 게이지로 시각화

---

## Week 1 HCI 이론 연결

- **Miller's Law (7±2 항목)**: 메인 화면에 CircularGauge 6개만 배치 (온도, 압력, 가스1, 가스2, RF파워, 진공도). 추가 파라미터는 Detail View로 분리하여 인지부하 30% 감소, 운영자 만족도 50% 향상.
- **Fitts' Law (타겟 크기/거리)**: 알람 발생 시 CircularGauge 크기 50% 확대 (직경 100mm → 150mm), 긴급 정지 버튼과 거리 200mm 이내 배치. 반응시간 800ms → 500ms로 40% 단축.
- **정보처리 모델**: 센서 데이터 업데이트(5ms) → Custom Control OnRender()(8ms) → GPU 렌더링(3ms) = 총 16ms로 60 FPS 달성. 운영자 인지 250ms 이내 시각적 피드백 제공.

---

## Mermaid 다이어그램

```mermaid
flowchart TD
    A[실시간 센서 데이터] --> B{Strategy Pattern}

    B -->|BarChart 선택| C[BarChartStrategy]
    B -->|LineChart 선택| D[LineChartStrategy]
    B -->|Heatmap 선택| E[HeatmapStrategy]

    C --> F[Decorator Pattern]
    D --> F
    E --> F

    F -->|AlarmDecorator| G[알람 테두리 추가]
    G -->|BlinkingDecorator| H[깜박임 효과 추가]

    H --> I[Custom Control]
    I -->|CircularGauge| J[온도 표시]
    I -->|LinearGauge| K[압력 표시]
    I -->|TrendChart| L[트렌드 표시]

    J --> M[WPF 렌더링 60 FPS]
    K --> M
    L --> M

    style B fill:#fff3e0,stroke:#ef6c00,stroke-width:2px
    style F fill:#e1f5fe,stroke:#0277bd,stroke-width:2px
    style I fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px
    style M fill:#f3e5f5,stroke:#6a1b9a,stroke-width:2px
```

---
## 실습 과제

### 과제 1: Strategy Pattern 구현 (20분)
**목표**: ComboBox 선택 시 차트 종류 동적 변경

```csharp
// 1. Strategy 인터페이스 정의
public interface IChartStrategy
{
    void Render(DrawingContext dc, List<double> data);
}

// 2. BarChart 전략 구현
public class BarChartStrategy : IChartStrategy
{
    public void Render(DrawingContext dc, List<double> data)
    {
        for (int i = 0; i < data.Count; i++)
        {
            var rect = new Rect(i * 50, 200 - data[i], 40, data[i]);
            dc.DrawRectangle(Brushes.SteelBlue, null, rect);
        }
    }
}

// 3. LineChart 전략 구현
public class LineChartStrategy : IChartStrategy
{
    public void Render(DrawingContext dc, List<double> data)
    {
        var points = data.Select((value, index) => new Point(index * 50, 200 - value)).ToList();
        var geometry = new PathGeometry(new[] { new PathFigure(points[0],
            points.Skip(1).Select(p => new LineSegment(p, true)), false) });
        dc.DrawGeometry(null, new Pen(Brushes.OrangeRed, 2), geometry);
    }
}

---
## 실습 과제
// 4. ViewModel에서 전략 교체
public class ChartViewModel
{
    private IChartStrategy _chartStrategy = new BarChartStrategy();

    public void ChangeChartType(string chartType)
    {
        _chartStrategy = chartType switch
        {
            "Bar" => new BarChartStrategy(),
            "Line" => new LineChartStrategy(),
            "Heatmap" => new HeatmapStrategy(),
            _ => _chartStrategy
        };
    }
}
```

**검증 기준**:
- IChartStrategy 인터페이스 정의
- 3가지 전략 구현 (Bar, Line, Heatmap)
- ComboBox 선택 시 차트 실시간 전환
---
## 실습 과제 (계속)

### 과제 2: Decorator Pattern 구현 (30분)
**목표**: 알람 발생 시 테두리 및 블링킹 효과 추가

```csharp
// 1. 기본 Control
public class BaseControl : Control
{
    protected override void OnRender(DrawingContext dc)
    {
        dc.DrawEllipse(Brushes.LightGray, null, new Point(50, 50), 40, 40);
    }
}

// 2. Alarm Decorator
public class AlarmDecorator : BaseControl
{
    public bool IsAlarm { get; set; } = false;

    protected override void OnRender(DrawingContext dc)
    {
        base.OnRender(dc);

        if (IsAlarm)
        {
            var pen = new Pen(Brushes.Red, 3);
            dc.DrawRectangle(null, pen, new Rect(0, 0, ActualWidth, ActualHeight));
        }
    }
}

---
## 실습 과제 (계속)
// 3. Blinking Decorator
public class BlinkingDecorator : AlarmDecorator
{
    private DispatcherTimer _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(500) };
    private bool _isVisible = true;

    public BlinkingDecorator()
    {
        _timer.Tick += (s, e) => { _isVisible = !_isVisible; InvalidateVisual(); };
        _timer.Start();
    }

    protected override void OnRender(DrawingContext dc)
    {
        if (_isVisible)
            base.OnRender(dc);
    }
}
```

**검증 기준**:
- BaseControl → AlarmDecorator → BlinkingDecorator 상속 구조
- IsAlarm = true 시 빨간 테두리 표시
- 500ms 주기로 깜박임 효과
---
## 실습 과제 (계속)

### 과제 3: CircularGauge Custom Control (30분)
**목표**: Dependency Property를 사용한 재사용 가능한 온도 게이지

```csharp
public class CircularGauge : Control
{
    // Dependency Property 정의
    public static readonly DependencyProperty ValueProperty =
        DependencyProperty.Register("Value", typeof(double), typeof(CircularGauge),
            new PropertyMetadata(0.0, OnValueChanged));

    public double Value
    {
        get => (double)GetValue(ValueProperty);
        set => SetValue(ValueProperty, value);
    }

    private static void OnValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        (d as CircularGauge)?.InvalidateVisual(); // 다시 그리기
    }

    // MinValue, MaxValue, Unit 속성도 동일하게 정의

    protected override void OnRender(DrawingContext dc)
    {
        // 1. 배경 원 그리기
        dc.DrawEllipse(Brushes.LightGray, null, new Point(100, 100), 80, 80);

---
## 실습 과제 (계속)
        // 2. 값에 따른 호 그리기 (0-270도)
        double angle = (Value - MinValue) / (MaxValue - MinValue) * 270;
        var geometry = new PathGeometry(/* ... */);
        dc.DrawGeometry(Brushes.SteelBlue, new Pen(Brushes.SteelBlue, 10), geometry);

        // 3. 텍스트 표시
        var text = new FormattedText($"{Value:F1} {Unit}", /* ... */);
        dc.DrawText(text, new Point(70, 90));
    }
}
```

**XAML 사용**:
```xml
<local:CircularGauge Value="{Binding Temperature}" MinValue="200" MaxValue="450" Unit="°C" />
```

**검증 기준**:
- DependencyProperty로 Value, MinValue, MaxValue, Unit 정의
- OnRender()에서 DrawingContext로 원형 게이지 그리기
- XAML에서 데이터 바인딩 가능
---

## 성능 벤치마크

### Custom Control 성능 목표
- **렌더링 FPS**: 60 유지 (16.67ms per frame)
- **CPU 사용률**: <10% (OnRender() 최적화)
- **GPU 사용률**: >70% (WPF 하드웨어 가속 활용)
- **메모리 사용량**: <50MB (10개 CircularGauge 동시 렌더링)

### 최적화 기법
1. **DrawingContext 직접 사용**: UserControl 대신 Control 상속으로 성능 30% 향상
2. **GPU 가속 활성화**: `<RenderOptions.ProcessRenderMode="Default">` 설정
3. **InvalidateVisual() 최소화**: 값 변경 시에만 다시 그리기
4. **Freezable 객체 사용**: Brush, Pen을 Freeze()하여 성능 20% 향상

```csharp
private static readonly Brush FrozenBrush = Brushes.SteelBlue.Clone();
static CircularGauge()
{
    FrozenBrush.Freeze(); // UI Thread 공유 가능
}
```

---

## 추가 학습 내용

### 반도체 HMI 시각화 베스트 프랙티스
- **게이지 선택**: 온도/압력 → CircularGauge, 유량 → LinearGauge, 파워 → BarChart
- **색상 코딩**: 정상(초록), 주의(노랑), 위험(빨강) - SEMI E95 표준
- **애니메이션**: Storyboard로 부드러운 값 전환 (Easing Function)
- **3D 시각화**: Viewport3D로 Chamber 내부 구조 표시 (선택 사항)
- **반응형 UI**: 해상도별 레이아웃 자동 조정 (1920×1080, 3840×2160)

---

## 학습 로드맵

<div style="display: flex; flex-direction: column; gap: 1rem; margin: 1.5rem 0;">
<div style="display: flex; align-items: center; background: #e8f5e8; padding: 1rem; border-radius: 8px;">
<div style="background: #28a745; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">1</div>
<span style="color: #155724;"><strong>이론 학습</strong>: Strategy/Decorator 패턴, Dependency Property 개념 이해</span>
</div>

<div style="display: flex; align-items: center; background: #e3f2fd; padding: 1rem; border-radius: 8px;">
<div style="background: #2196f3; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">2</div>
<span style="color: #0d47a1;"><strong>실습 1</strong>: Strategy Pattern으로 차트 종류 동적 변경 (Bar/Line/Heatmap)</span>
</div>

<div style="display: flex; align-items: center; background: #f3e5f5; padding: 1rem; border-radius: 8px;">
<div style="background: #9c27b0; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">3</div>
<span style="color: #4a148c;"><strong>실습 2</strong>: Decorator Pattern으로 알람 테두리 및 블링킹 효과 추가</span>
</div>

<div style="display: flex; align-items: center; background: #fff3cd; padding: 1rem; border-radius: 8px;">
<div style="background: #f39c12; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">4</div>
<span style="color: #856404;"><strong>실습 3</strong>: CircularGauge Custom Control 개발 (60 FPS, GPU >70%)</span>
</div>
</div>

---

## 다음 주 예고: Week 5 - C# 테스트 및 배포

Week 4에서 개발한 고급 UI/UX를 테스트하고 배포합니다.

- **Unit Test**: xUnit + Moq로 ViewModel 로직 테스트 (커버리지 80% 목표)
- **UI Test**: FlaUI로 자동화된 UI 테스트 (Page Object Model 적용)
- **CI/CD**: Docker 컨테이너로 빌드 및 배포 (배포 시간 <30초)
- **실습**: GitHub Actions로 자동 테스트 파이프라인 구축, 성공률 95% 달성
