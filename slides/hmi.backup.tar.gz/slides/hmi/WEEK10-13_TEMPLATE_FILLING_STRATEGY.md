# Week 10-13 ImGui Template Filling Strategy

**Date**: 2025-10-03
**Status**: Analysis Complete - Strategic Approach Defined

## Executive Summary

The Week 10-13 ImGui project slides contain **3,568 placeholders** across **130 template sections** in 4 high-priority files. This represents approximately **260 hours** of detailed technical writing work.

## Scope Analysis

### Files Requiring Template Filling

| File | Placeholders | Templates | Est. Hours |
|------|--------------|-----------|------------|
| **week10-imgui-basics/slides-05-practice3.md** | 1,399 | 50 | 100h |
| **week11-imgui-advanced/slides-01-intro.md** | 640 | 25 | 50h |
| **week12-imgui-advanced-features/slides-01-intro.md** | 745 | 28 | 56h |
| **week13-imgui-integrated-project/slides-05-practice3.md** | 684 | 27 | 54h |
| **TOTAL** | **3,468** | **130** | **260h** |

## Content Requirements per Template Section

Each of the 130 template sections requires:

### 1. Background Explanation (150-200 words)
- **Problem situation**: Real semiconductor equipment issues
  - CVD/PVD/ETCH/CMP specific examples
  - Data value ranges (temperature: 200-800°C, pressure: 1-100 Torr, etc.)
- **Existing approach limitations**: WPF (Week 2-5) and PySide6 (Week 6-9) comparison
- **Solution approach**: How ImGui solves it
- **Evolution from Week 10**: Progressive improvement narrative

### 2. Core Concepts (200-300 words)
- **Operating principles**: Immediate Mode GUI (IMGUI) vs Retained Mode
- **Internal mechanisms**:
  - ImGui rendering pipeline: App Code → Draw Commands → Vertex/Index Buffers → GPU
  - DrawList structure (Commands, VtxBuffer, IdxBuffer, ClipRectStack)
- **Design philosophy**: Why immediate mode for real-time HMI
- **Week 10 review**: Connection to previous concepts

### 3. Line-by-Line Code Explanation (500-800 words)
- **Each significant line** (typically 15-25 lines per section):
  ```
  Line X: `actual code from file`
  - Detailed explanation (3-5 sentences)
  - Parameter/type descriptions
  - Design intent and rationale
  - Performance implications
  ```
- **Logic flow**: 3-5 step breakdown
- **ImGui API specifics**: ImGui::Begin/End, ImPlot::PlotLine, DrawList operations

### 4. Real Application Cases (200-300 words)
- **Semiconductor HMI examples**:
  - CVD equipment dashboard: Real-time temperature/pressure monitoring
  - Etch chamber visualization: 3D wafer rendering with status overlay
  - Actual data ranges:
    - Temperature: 200-800°C (±2°C precision)
    - Pressure: 1-100 Torr (±0.1 Torr)
    - Flow rate: 10-1000 sccm
    - Update rate: 60 FPS for critical parameters
- **Performance requirements**: < 16ms frame time, < 50MB memory

### 5. Comparison Sections
- **vs WPF (Week 2-5)**:
  - WPF: XAML bindings, heavier runtime, Windows-only
  - ImGui: Direct rendering, lightweight, cross-platform
- **vs PySide6 (Week 6-9)**:
  - PySide6: Qt widgets, signal/slot overhead
  - ImGui: Immediate mode, minimal abstraction

### 6. HCI Theory Application (100-150 words)
- **Miller's Law (7±2 items)**: Dashboard layout with max 7 critical parameters
- **Information Processing Model (250ms response)**: Visual feedback timing
- **Fitts's Law**: Button sizing for industrial touchscreens

### 7. Analogies (50-100 words)
- Real-world comparisons for complex concepts
- Example: "ImGui is like a chef calling out orders (immediate) vs. writing them down (retained)"

### 8. Hands-on Exercises (100-150 words)
- 2-3 practice tasks
- Expected results
- Common pitfalls

## ImGui-Specific Content Focus

### Week 10: ImGui Basics
- **Core topics**: Rendering loop, ImGui::Begin/End, basic widgets
- **Key APIs**:
  ```cpp
  ImGui::Begin("Window");
  ImGui::Text("Hello");
  ImGui::Button("Click");
  ImGui::End();
  ```
- **Examples**: Simple CVD parameter display panel

### Week 11: ImGui Advanced
- **Core topics**: Custom widgets, ImPlot integration, advanced rendering
- **Key APIs**:
  ```cpp
  ImPlot::BeginPlot("Temperature");
  ImPlot::PlotLine("Sensor1", xdata, ydata, count);
  ImGui::GetWindowDrawList()->AddRect(...);
  ```
- **Examples**: Real-time process parameter plots

### Week 12: ImGui Advanced Features
- **Core topics**: Docking, viewports, multi-window management
- **Key APIs**:
  ```cpp
  ImGui::DockSpaceOverViewport();
  ImGuiConfigFlags_ViewportsEnable
  ImGuiConfigFlags_DockingEnable
  ```
- **Examples**: Multi-chamber equipment monitoring system

### Week 13: Integrated Project
- **Core topics**: Full HMI system integration
- **Architecture**: Equipment controller ↔ Data layer ↔ ImGui HMI
- **Examples**: Complete semiconductor fab line monitoring

## Sample Filled Template

### Part 1: Advanced Renderer Setup (Week 11)

#### Background: Why This Technology is Needed

**Problem Situation**:
- Semiconductor CVD equipment requires real-time visualization of 3D chamber状态 (temperature distribution, gas flow patterns)
- Traditional WPF 3D rendering (Week 2-5) has 100-200ms latency due to XAML binding overhead
- PySide6 Qt3D (Week 6-9) consumes 200MB+ memory for complex chamber models
- Operators need instant visual feedback when adjusting process parameters (temperature setpoint changes must reflect within 50ms)

**Solution**:
- ImGui with custom OpenGL rendering provides direct GPU access
- Advanced renderer class manages View/Projection matrices for 3D visualization
- Immediate mode paradigm eliminates binding update delays
- Memory footprint < 50MB even with complex 3D models

**Evolution from Week 10**:
- Week 10: Basic 2D ImGui widgets (buttons, sliders)
- Week 11: 3D rendering integration with advanced shader pipelines

#### Core Concepts

**Operating Principles**:
ImGui's immediate mode rendering requires explicit frame-by-frame state management. Unlike retained mode (WPF), where the framework maintains scene graph, ImGui rebuilds the entire UI each frame. For 3D visualization, we must:
1. Set up render context (view/projection matrices) every frame
2. Issue draw commands via ImDrawList or custom OpenGL calls
3. ImGui handles windowing; we handle 3D content

**Internal Mechanisms**:
The `AdvancedRenderer` class encapsulates:
- **RenderContext struct**: Stores view/projection matrices, viewport size, DPI scale
- **OpenGL state**: Shader program, VAO/VBO handles for geometry
- **Integration point**: Renders to framebuffer texture, displays in ImGui::Image()

**Design Philosophy**:
Separation of concerns: ImGui manages UI layout/input, custom renderer handles 3D content. This allows:
- 60 FPS UI updates independent of 3D complexity
- Easy integration with existing semiconductor equipment control systems
- Cross-platform compatibility (Windows/Linux fab environments)

**Week 10 Review**:
- Week 10: `ImGui::GetWindowDrawList()->AddRect()` for 2D shapes
- Week 11: Full 3D pipeline with model/view/projection transforms

#### Code (Part 1/10)

```cpp [1-23]
/*
ImGUI 렌더링 파이프라인:
Application Code → ImGUI Draw Commands → Vertex/Index Buffers → GPU

DrawList 구조:
- Commands: 렌더링 명령 목록
- VtxBuffer: 정점 데이터
- IdxBuffer: 인덱스 데이터
- ClipRectStack: 클리핑 영역 스택
*/

#include <imgui.h>
#include <imgui_internal.h>
#include <GL/gl3w.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

namespace SemiconductorHMI {

class AdvancedRenderer {
private:
    struct RenderContext {
        glm::mat4 view_matrix;
```

#### Code Explanation

**Line 11-12: `#include <imgui.h>` / `#include <imgui_internal.h>`**
- `imgui.h`: Core ImGui API for window management and widgets
- `imgui_internal.h`: Low-level access to DrawList and rendering internals
- Required for custom rendering that integrates with ImGui's pipeline
- Internal header allows direct manipulation of vertex/index buffers

**Line 13: `#include <GL/gl3w.h>`**
- GL3W: OpenGL 3.x/4.x function loader
- Alternative to GLEW, lighter weight (~50KB vs 500KB)
- Essential for modern OpenGL features (shaders, VAOs, FBOs)
- Cross-platform: Works on Windows, Linux (fab control PCs)

**Line 14-15: `#include <glm/glm.hpp>` / `#include <glm/gtc/matrix_transform.hpp>`**
- GLM: OpenGL Mathematics library, header-only C++ math for graphics
- `glm.hpp`: Core vectors (vec2, vec3, vec4) and matrices (mat4)
- `matrix_transform.hpp`: View/projection matrix helpers (lookAt, perspective, ortho)
- Performance: SIMD-optimized, zero overhead vs hand-written matrix math

**Line 17: `namespace SemiconductorHMI {`**
- Encapsulates all equipment HMI code to avoid symbol conflicts
- Naming convention: Reflects industrial domain (semiconductor manufacturing)
- Allows multiple equipment types (CVD, PVD, ETCH) to coexist in same application

**Line 19-22: `class AdvancedRenderer` / `struct RenderContext`**
- Separation of concerns: AdvancedRenderer manages lifecycle, RenderContext holds per-frame state
- RenderContext is POD (Plain Old Data) for easy copying between threads if needed
- Design pattern: State object pattern for clean frame-by-frame updates

**Line 22: `glm::mat4 view_matrix;`**
- 4x4 view matrix (camera transform in 3D space)
- Transforms world coordinates → camera space
- For CVD chamber: Allows operator to orbit around equipment 3D model
- Updated every frame based on mouse drag input (camera rotation)

**Logic Flow**:
1. **Include dependencies**: ImGui (UI), OpenGL (rendering), GLM (math)
2. **Define namespace**: Organize semiconductor-specific code
3. **Create AdvancedRenderer class**: Main facade for 3D rendering
4. **Define RenderContext struct**: Encapsulate per-frame rendering state
5. **Declare view_matrix**: First step in 3D transform pipeline (world → camera)

### Real Application Cases

**Semiconductor HMI Example**:
- **CVD Equipment 3D Chamber Visualization**:
  - Renders real-time 3D model of deposition chamber (12,000 triangles)
  - Color-coded temperature gradient: 200°C (blue) → 800°C (red)
  - Operator can rotate view with mouse, zoom with wheel
  - Updates 60 FPS with live temperature sensor data (16 thermocouples)

- **Performance Requirements**:
  - Frame time: < 16.6ms (60 FPS target)
  - GPU memory: < 100MB for full 3D model + textures
  - CPU overhead: < 5% on fab control PC (Intel i5, 8GB RAM)
  - Latency: Sensor data → visual update < 50ms

**Analogy**:
Think of ImGui rendering like a whiteboard presentation: Every frame, you erase and redraw everything (immediate mode). The AdvancedRenderer is your set of colored markers and rulers. The RenderContext is your current camera position looking at the whiteboard. In contrast, WPF (retained mode) is like a digital document where you update specific elements—flexible but with overhead.

### Week 1 HCI Theory Application

**Miller's Law (作業記憶限界 7±2)**:
- RenderContext struct has only 4 members (view_matrix, projection_matrix, viewport_size, scale_factor)
- Stays well under cognitive load limit for developers reading code
- Each matrix serves clear purpose: view (camera), projection (perspective), viewport (screen), scale (DPI)

**Information Processing Model (250ms Response)**:
- Advanced renderer setup (Initialize()) completes < 100ms
- Meets human perception threshold for "instant" feedback
- Shader compilation deferred to startup, not runtime (prevents UI lag)

**Fitts's Law (Target Size vs Reach Time)**:
- 3D viewport sized 800x600px minimum (large target for mouse interaction)
- Rotation/zoom controls are direct manipulation (drag/scroll) not buttons
- Touch-friendly for industrial panel PCs: 10mm minimum hit targets

### Hands-on Exercise

1. **Task 1**: Modify RenderContext to add a `zoom_level` float member (range 0.5 - 5.0)
   - Update constructor to initialize zoom_level = 1.0
   - Apply zoom to projection matrix calculation: `fov = 45.0f / zoom_level`

2. **Task 2**: Add debug visualization
   - Draw 3D axis lines (X=red, Y=green, Z=blue) at world origin
   - Use `ImGui::GetWindowDrawList()->AddLine()` for 2D projection of 3D lines

3. **Expected Results**:
   - Zooming in narrows field of view (larger equipment model on screen)
   - Axis lines help operators understand camera orientation
   - Performance remains 60 FPS (minimal overhead)

**Common Pitfall**: Forgetting to update projection matrix when zoom changes → visual stays same despite zoom value change.

---

## Recommended Filling Strategy

### Phase 1: Core Concept Standardization (Week 1-2)
1. Create reusable content modules:
   - ImGui architecture overview (reuse across all weeks)
   - WPF/PySide6 comparison template
   - Semiconductor equipment examples database
   - HCI theory application templates

2. Define data value standards:
   - Temperature ranges per equipment type
   - Pressure/flow/power typical values
   - Performance benchmarks (FPS, memory, latency)

### Phase 2: Automated Template Filling (Week 3-4)
1. Build Python script to:
   - Parse placeholder patterns `[text]`
   - Match code line numbers to explanations
   - Insert standardized content blocks
   - Validate consistency across weeks

2. Semi-automated approach:
   - Auto-fill repeating structures (HCI theory, analogies)
   - Manual review for code-specific explanations
   - Quality check against IMPROVEMENT_GUIDE checklists

### Phase 3: Manual Refinement (Week 5-6)
1. Review all auto-filled content
2. Add week-specific nuances
3. Ensure progressive difficulty (Week 10 → 13)
4. Cross-reference between weeks for consistency

### Phase 4: Quality Assurance (Week 7)
1. Technical accuracy review
2. Pedagogical flow check
3. Code example testing
4. Completeness verification against IMPROVEMENT_GUIDE

## Content Database Structure

### Semiconductor Equipment Examples
```yaml
CVD:
  parameters:
    - temperature: {range: "200-800°C", precision: "±2°C"}
    - pressure: {range: "1-100 Torr", precision: "±0.1 Torr"}
    - gas_flow: {range: "10-1000 sccm", precision: "±5 sccm"}
  use_cases:
    - "Real-time temperature distribution visualization"
    - "Multi-zone heater control interface"
    - "Recipe parameter trending (24h history)"

PVD:
  parameters:
    - power: {range: "100-5000W", precision: "±10W"}
    - vacuum: {range: "1e-6 - 1e-8 Torr"}
  use_cases:
    - "Plasma impedance matching visualization"
    - "Target utilization 3D heatmap"
```

### ImGui API Reference
```yaml
Week10_APIs:
  - ImGui::Begin/End: "Window management"
  - ImGui::Text: "Static text display"
  - ImGui::Button: "Interactive button"
  - ImGui::SliderFloat: "Real-time parameter adjustment"

Week11_APIs:
  - ImPlot::BeginPlot: "Chart container setup"
  - ImPlot::PlotLine: "Time-series data visualization"
  - ImGui::GetWindowDrawList: "Custom rendering access"
  - DrawList->AddRect/AddLine: "Primitive shape drawing"

Week12_APIs:
  - ImGui::DockSpaceOverViewport: "Docking system root"
  - ImGuiConfigFlags_DockingEnable: "Enable docking feature"
  - ImGuiConfigFlags_ViewportsEnable: "Multi-monitor support"
```

### WPF/PySide6 Comparison
```yaml
Architecture:
  WPF: "XAML binding → Dependency properties → Render tree"
  PySide6: "Signal/slot → Qt widgets → QPainter"
  ImGui: "Direct function calls → DrawList → GPU"

Performance:
  WPF: "100-200ms update latency, 200MB memory baseline"
  PySide6: "50-100ms latency, 150MB memory"
  ImGui: "<16ms latency, 20-50MB memory"

Platform:
  WPF: "Windows only (.NET Framework)"
  PySide6: "Cross-platform (Qt 6 runtime required)"
  ImGui: "Cross-platform (native code, minimal deps)"
```

## Automation Script Specification

```python
# template_filler.py
import re
from typing import Dict, List

class TemplateFiller:
    def __init__(self, content_db: Dict):
        self.content_db = content_db

    def fill_background(self, equipment: str, week: int) -> str:
        """Generate background explanation"""
        problem = self.content_db[equipment]['problems'][week]
        solution = self.content_db['imgui']['solutions'][week]
        evolution = self.content_db['weekly_evolution'][f'week{week}']
        return format_background(problem, solution, evolution)

    def fill_code_explanation(self, code_lines: List[str], start_line: int) -> str:
        """Generate line-by-line explanations"""
        explanations = []
        for i, line in enumerate(code_lines):
            line_num = start_line + i
            api_match = find_imgui_api(line)
            if api_match:
                exp = self.content_db['api_explanations'][api_match]
                explanations.append(format_line_explanation(line_num, line, exp))
        return "\n\n".join(explanations)

    def fill_hci_theory(self, code_context: str) -> str:
        """Apply HCI principles"""
        millers_law = analyze_complexity(code_context)
        response_time = estimate_response_time(code_context)
        return format_hci_section(millers_law, response_time)

# Usage
filler = TemplateFiller(content_database)
for week in [10, 11, 12, 13]:
    for part in week_parts[week]:
        background = filler.fill_background('CVD', week)
        code_exp = filler.fill_code_explanation(part.code_lines, part.start_line)
        hci = filler.fill_hci_theory(part.code)
        update_markdown_file(part.file, background, code_exp, hci)
```

## Next Steps

### Immediate (This Week)
1. ✅ Complete scope analysis
2. ⏳ Build content database (YAML files)
3. ⏳ Create one fully-filled example (Part 1 above)
4. ⏳ Validate example against IMPROVEMENT_GUIDE

### Short-term (Week 2-3)
1. Develop automation script
2. Test on Week 11 slides (smallest scope)
3. Refine based on output quality
4. Scale to all 4 files

### Long-term (Week 4-6)
1. Complete all template filling
2. Cross-reference consistency check
3. Technical review with SMEs
4. Final QA pass

## Estimated Resource Requirements

- **Development time**: 40 hours (automation script + content DB)
- **Automation run time**: 10 hours (script execution + review)
- **Manual refinement**: 80 hours (details, examples, validation)
- **QA**: 20 hours
- **Total**: **150 hours** (vs 260 hours fully manual)

## Success Metrics

1. **Completeness**: 100% of placeholders filled
2. **Consistency**: Same terminology/values across weeks
3. **Accuracy**: All code explanations technically correct
4. **Pedagogical quality**: Progressive difficulty Week 10 → 13
5. **Performance**: Example code meets stated requirements (60 FPS, <50MB memory)

---

**Status**: Strategy document complete. Ready for Phase 1 content database creation.
**Next Action**: Build YAML content database with standardized semiconductor examples and ImGui API references.
