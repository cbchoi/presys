---
layout: cover
---

# Week 10 - ImGUI + C++
## Immediate Mode GUI 기초 이론
### 반도체 HMI를 위한 고성능 렌더링 시스템

```mermaid
graph TD
A[View - UI 렌더링] --> B[ViewModel - 데이터 바인딩]
B --> C[Model - 비즈니스 로직]
C --> D[Data Source - 센서/DB]

style A fill:#e1f5fe
style B fill:#fff3e0
style C fill:#c8e6c9
```

---

## 학습 목표

### Part 1: ImGui 기초 개념 이해

**학습 목표**:
- ImGui의 Immediate Mode 개념 이해
- Retained Mode GUI와의 차이점 파악
- 반도체 HMI에서 ImGui를 사용하는 이유

**실습 목표**:
- 기본 ImGui 위젯 생성
- 실시간 데이터 시각화 구현
- 60 FPS 유지하며 반도체 HMI 구축

### Part 2: 고성능 렌더링

**학습 목표**:
- ImGui 렌더링 파이프라인 이해
- OpenGL 통합 원리
- 메모리 효율적인 UI 설계

**실습 목표**:
- PlotLines를 활용한 센서 데이터 차트
- 실시간 웨이퍼 맵 시각화
- 60 FPS 유지하며 대용량 데이터 렌더링
---
### Part 3: 성능 측정 및 최적화

**학습 목표**:
- ImGui 성능 프로파일링 기법
- 16ms 렌더링 제약 이해
- CPU/GPU 최적화 전략

**측정 지표**:
- 프레임 시간(ms)
- CPU 사용률(%)
- 메모리 사용량(MB)

**목표 성능**:
- 프레임 시간: 16ms 이하 (60 FPS 유지)
- CPU 사용률: 3% 이하
- 메모리: 30MB 이하

**사전 지식**:
- C++ 기초 문법
- OpenGL 기본 개념
- 렌더링 파이프라인

---
### Part 3: 성능 측정 및 최적화
**핵심 C++ 개념**:
- RAII (Resource Acquisition Is Initialization)
- Smart Pointers (unique_ptr, shared_ptr)
- Move Semantics (우측값 참조)
---

# 1. RAII (Resource Acquisition Is Initialization)

## 배경: 왜 RAII가 필요한가?

**문제 상황**:
- 반도체 HMI는 수백 개의 센서 데이터를 파일로 로깅
- 파일 핸들, 메모리 버퍼 등 리소스 관리 필수
- 예외 발생 시 리소스 누수 위험

**해결책**:
- RAII 패턴으로 자동 리소스 관리
- 생성자에서 획득, 소멸자에서 해제
- 예외 안전성 보장

## 핵심 개념

RAII는 **객체의 생명주기**와 **리소스 관리**를 결합하는 C++ 핵심 패턴입니다.

**동작 원리**:
1. 객체 생성 시 리소스 획득 (생성자)
2. 객체 사용 중 리소스 활용
3. 객체 소멸 시 리소스 자동 해제 (소멸자)

---
# 1. RAII - 잘못된 예제 (Part 1)

<div class="grid grid-cols-2 gap-8">
<div>

```cpp
// 나쁜 예: 수동 리소스 관리
class BadFileHandler {
private:
FILE* file;

public:
BadFileHandler(const char* filename) {
file = fopen(filename, "r");
if (!file) {
throw std::runtime_error("Failed to open file");
}
}
```

</div>
<div>

**문제점 분석**:

**Line 3-5: 생성자에서 파일 열기**
- fopen으로 파일 핸들 획득
- 실패 시 예외 발생
- 하지만 리소스 누수 위험

---
# 1. RAII - 잘못된 예제 (Part 1)
**예외 발생 시 문제**:
- Process() 중 예외 발생
- fclose() 호출되지 않음
- 파일 핸들 누수 발생
- 반도체 장비에서 치명적

</div>
</div>
---
# 1. RAII - 잘못된 예제 (Part 2)

<div class="grid grid-cols-2 gap-8">
<div>

```cpp
~BadFileHandler() {
// 소멸자에서 파일 닫기
if (file) {
fclose(file);
}
}

void Process() {
char buffer[1024];
// 예외 발생 가능 지점
if (fgets(buffer, sizeof(buffer), file) == nullptr) {
```

</div>
<div>

**소멸자의 역할**:

**Line 1-5: 소멸자**
- 객체 파괴 시 자동 호출
- 파일 핸들 확인 후 닫기
- 하지만 예외 발생 시 미호출

---
# 1. RAII - 잘못된 예제 (Part 2)
**Line 7-10: 데이터 처리**
- fgets로 파일 읽기
- 실패 시 예외 발생
- 이 시점에서 소멸자 미호출
- 리소스 누수 발생

**반도체 HMI 영향**:
- 24시간 운영 중 파일 핸들 누적
- 시스템 리소스 고갈
- 장비 다운타임 발생

</div>
</div>
---

# 1. RAII - 올바른 예제 (Part 1)

<div class="grid grid-cols-2 gap-8">
<div>

```cpp
throw std::runtime_error("Read error");
}
}
};
```

```cpp
// 좋은 예: RAII 패턴
class GoodFileHandler {
private:
std::unique_ptr<FILE, decltype(&fclose)> file;

public:
GoodFileHandler(const char* filename)
: file(fopen(filename, "r"), &fclose) {
if (!file) {
throw std::runtime_error("Failed to open file");
```
---
# 1. RAII (Resource Acquisition Is Initialization) (Part 3) (Code Part 2/3)

```cpp
}
}

// ( )
// file unique_ptr fclose

void Process() {
char buffer[1024];
//
if (fgets(buffer, sizeof(buffer), file.get()) == nullptr) {
```
---
# 1. RAII (Resource Acquisition Is Initialization) (Part 3) (Code Part 3/3)

```cpp
throw std::runtime_error("Read error");
}
}
};
```


</div>
<div>
---
## 1.2 OpenGL RAII (Part 1)



<div class="grid grid-cols-2 gap-8">
<div>

```cpp
// OpenGL RAII
class GLTexture {
private:
GLuint texture_id = 0;
int width, height;

public:
GLTexture(int w, int h, GLenum format = GL_RGBA)
: width(w), height(h) {
// ()
glGenTextures(1, &texture_id);
glBindTexture(GL_TEXTURE_2D, texture_id);
```
---
## 1.2 OpenGL RAII (Part 2)

```cpp
glTexImage2D(GL_TEXTURE_2D, 0, format,
width, height, 0, format,
GL_UNSIGNED_BYTE, nullptr);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
}

~GLTexture() {
// ()
if (texture_id!= 0) {
glDeleteTextures(1, &texture_id);
}
```
---
## 1.2 OpenGL RAII (Part 3)

```cpp
}

// ( )
GLTexture(const GLTexture&) = delete;
GLTexture& operator=(const GLTexture&) = delete;

// ( )
GLTexture(GLTexture&& other) noexcept
: texture_id(other.texture_id)
, width(other.width)
, height(other.height) {
other.texture_id = 0; //
```
---
## 1.2 OpenGL RAII (Part 4)

```cpp
}

GLTexture& operator=(GLTexture&& other) noexcept {
if (this!= &other) {
//
if (texture_id!= 0) {
glDeleteTextures(1, &texture_id);
}
//
texture_id = other.texture_id;
width = other.width;
height = other.height;
```
---
## 1.2 OpenGL RAII (Part 5)

```cpp
other.texture_id = 0;
}
return *this;
}

//
GLuint GetID() const { return texture_id; }
int GetWidth() const { return width; }
int GetHeight() const { return height; }

//
void UpdateData(const void* data) {
```
---
## 1.2 OpenGL RAII (Part 6) (Code Part 1/6)


```cpp
glBindTexture(GL_TEXTURE_2D, texture_id);

```cpp
// OpenGL VAO/VBO RAII
class GLBuffer {
private:
GLuint buffer_id = 0;
GLenum target;
size_t size_bytes;

public:
GLBuffer(GLenum target_type)
: target(target_type), size_bytes(0) {
```
---
## 1.2 OpenGL RAII (Part 6) (Code Part 2/6)

```cpp
glGenBuffers(1, &buffer_id);
}

~GLBuffer() {
if (buffer_id!= 0) {
glDeleteBuffers(1, &buffer_id);
}
}

// / ( )
```
---
## 1.2 OpenGL RAII (Part 6) (Code Part 3/6)

```cpp
GLBuffer(const GLBuffer&) = delete;
GLBuffer& operator=(const GLBuffer&) = delete;
GLBuffer(GLBuffer&& other) noexcept
: buffer_id(other.buffer_id)
, target(other.target)
, size_bytes(other.size_bytes) {
other.buffer_id = 0;
}

GLBuffer& operator=(GLBuffer&& other) noexcept {
```
---
## 1.2 OpenGL RAII (Part 6) (Code Part 4/6)

```cpp
if (this!= &other) {
if (buffer_id!= 0) {
glDeleteBuffers(1, &buffer_id);
}
buffer_id = other.buffer_id;
target = other.target;
size_bytes = other.size_bytes;
other.buffer_id = 0;
}
return *this;
```
---
## 1.2 OpenGL RAII (Part 6) (Code Part 5/6)

```cpp
}

template<typename T>
void SetData(const std::vector<T>& data, GLenum usage = GL_STATIC_DRAW) {
size_bytes = data.size() * sizeof(T);
glBindBuffer(target, buffer_id);
glBufferData(target, size_bytes, data.data(), usage);
}

void Bind() const {
```
---
## 1.2 OpenGL RAII (Part 6) (Code Part 6/6)

```cpp
glBindBuffer(target, buffer_id);
}

GLuint GetID() const { return buffer_id; }
};
```


```cpp
//:
---
# 2. Smart Pointers ( ) (Part 1)




<div class="grid grid-cols-2 gap-8">
<div>

```cpp
#include <memory>
#include <vector>
#include <string>

//: Raw pointer
class BadUIComponent {
private:
UIWidget* widget; //

public:
BadUIComponent() {
widget = new UIWidget(); // new
```
---
# 2. Smart Pointers ( ) (Part 2) (Code Part 1/5)


```cpp
}

```cpp
// unique_ptr UI
class UIComponent {
public:
virtual ~UIComponent() = default;
virtual void Render() = 0;
virtual void Update(float dt) {}
};

class Panel: public UIComponent {
private:
```
---
# 2. Smart Pointers ( ) (Part 2) (Code Part 2/5)

```cpp
std::string name;
std::vector<std::unique_ptr<UIComponent>> children; //

public:
explicit Panel(std::string panel_name)
: name(std::move(panel_name)) {}

// ()
void AddChild(std::unique_ptr<UIComponent> child) {
children.push_back(std::move(child));
```
---
# 2. Smart Pointers ( ) (Part 2) (Code Part 3/5)

```cpp
}

//
template<typename T, typename... Args>
T* CreateChild(Args&&... args) {
auto child = std::make_unique<T>(std::forward<Args>(args)...);
T* ptr = child.get();
children.push_back(std::move(child));
return ptr; //
}
```
---
# 2. Smart Pointers ( ) (Part 2) (Code Part 4/5)

```cpp

void Render() override {
ImGui::Begin(name.c_str());
for (auto& child: children) {
child->Render(); // ->
}
ImGui::End();
}

~Panel() override {
```
---
# 2. Smart Pointers ( ) (Part 2) (Code Part 5/5)

```cpp
// children unique_ptr
// ()
}
};
```


```cpp
//
---
## 2.2 shared_ptr - (Part 1)



<div class="grid grid-cols-2 gap-8">
<div>

```cpp
#include <memory>
#include <vector>
#include <unordered_map>
#include <string>

// shared_ptr
class Equipment {
private:
std::string equipment_id;
int status;

public:
```
---
## 2.2 shared_ptr - (Part 2)

```cpp
explicit Equipment(std::string id)
: equipment_id(std::move(id)), status(0) {}

void UpdateStatus(int new_status) {
status = new_status;
}

const std::string& GetID() const { return equipment_id; }
int GetStatus() const { return status; }

~Equipment() {
std::cout << "Equipment " << equipment_id << " destroyed\n";
```
---
## 2.2 shared_ptr - (Part 3)

```cpp
}
};

// Equipment
class EquipmentManager {
private:
// Equipment ()
std::unordered_map<std::string, std::shared_ptr<Equipment>> equipments;

public:
// Equipment
std::shared_ptr<Equipment> CreateEquipment(const std::string& id) {
```
---
## 2.2 shared_ptr - (Part 4)

```cpp
auto equipment = std::make_shared<Equipment>(id);
equipments[id] = equipment;
return equipment; // shared_ptr (ref count )
}

// Equipment
std::shared_ptr<Equipment> GetEquipment(const std::string& id) {
auto it = equipments.find(id);
if (it!= equipments.end()) {
return it->second; // shared_ptr
}
return nullptr;
```
---
## 2.2 shared_ptr - (Part 5)

```cpp
}

// Equipment
void RemoveEquipment(const std::string& id) {
equipments.erase(id);
// ref count
//
}

size_t GetEquipmentCount() const {
return equipments.size();
}
```
---
## 2.2 shared_ptr - (Part 6) (Code Part 1/4)


```cpp
};

```cpp
// shared_ptr
class DataLogger {
private:
std::shared_ptr<Equipment> equipment; //
std::string log_file;

public:
DataLogger(std::shared_ptr<Equipment> eq, std::string file)
: equipment(eq) // shared_ptr (ref count++)
, log_file(std::move(file)) {}
```
---
## 2.2 shared_ptr - (Part 6) (Code Part 2/4)

```cpp

void LogStatus() {
if (equipment) { // nullptr
std::cout << "Logging " << equipment->GetID()
<< ": " << equipment->GetStatus() << "\n";
}
}

// DataLogger ref count
// Equipment
```
---
## 2.2 shared_ptr - (Part 6) (Code Part 3/4)

```cpp
};

class UIDisplay {
private:
std::shared_ptr<Equipment> equipment; // Equipment

public:
UIDisplay(std::shared_ptr<Equipment> eq)
: equipment(eq) {} // ref count++

```
---
## 2.2 shared_ptr - (Part 6) (Code Part 4/4)

```cpp
void Render() {
if (equipment) {
ImGui::Text("Equipment: %s", equipment->GetID().c_str());
ImGui::Text("Status: %d", equipment->GetStatus());
}
}
};
```


```cpp
//: Equipment
---
## 2.3 weak_ptr - (Part 1)



<div class="grid grid-cols-2 gap-8">
<div>

```cpp
#include <memory>
#include <vector>
#include <iostream>

//
class BadNode {
public:
std::shared_ptr<BadNode> next;
std::shared_ptr<BadNode> prev; //
int data;

BadNode(int d): data(d) {}
```
---
## 2.3 weak_ptr - (Part 2)

```cpp
~BadNode() {
std::cout << "Node " << data << " destroyed\n";
}
};

void CircularReferenceDemo() {
auto node1 = std::make_shared<BadNode>(1); // ref count = 1
auto node2 = std::make_shared<BadNode>(2); // ref count = 1

node1->next = node2; // node2 ref count = 2
node2->prev = node1; // node1 ref count = 2

```
---
## 2.3 weak_ptr - (Part 3) (Code Part 1/5)


```cpp
//:

```cpp
// weak_ptr
class DataCache {
private:
// weak_ptr ( expired)
std::unordered_map<std::string, std::weak_ptr<CachedData>> cache;

public:
std::shared_ptr<CachedData> GetOrLoad(const std::string& key) {
// 1.
auto it = cache.find(key);
```
---
## 2.3 weak_ptr - (Part 3) (Code Part 2/5)

```cpp
if (it!= cache.end()) {
// weak_ptr shared_ptr
if (auto cached = it->second.lock()) {
std::cout << "Cache hit: " << key << "\n";
return cached; //
} else {
// →
cache.erase(it);
}
}
```
---
## 2.3 weak_ptr - (Part 3) (Code Part 3/5)

```cpp

// 2. →
std::cout << "Cache miss: " << key << "\n";
auto data = std::make_shared<CachedData>(key);
cache[key] = data; // weak_ptr (ref count )
return data;
}

void CleanupExpired() {
// weak_ptr
```
---
## 2.3 weak_ptr - (Part 3) (Code Part 4/5)

```cpp
for (auto it = cache.begin(); it!= cache.end(); ) {
if (it->second.expired()) {
it = cache.erase(it);
} else {
++it;
}
}
}

size_t GetCacheSize() const { return cache.size(); }
```
---
## 2.3 weak_ptr - (Part 3) (Code Part 5/5)

```cpp
};
```


```cpp
//: Observer
---
# 3. Move Semantics ( ) (Part 1)




<div class="grid grid-cols-2 gap-8">
<div>

```cpp

// L-value R-value
void ValueCategoryDemo() {
int x = 10; // x L-value (, )
int y = x + 5; // (x + 5) R-value (, )

int* ptr = &x; // L-value
// int* ptr2 = &(x + 5); // R-value ( )

std::string s1 = "Hello"; // s1: L-value, "Hello": R-value
std::string s2 = s1; // s1: L-value ()
std::string s3 = s1 + " World"; // (s1 + " World"): R-value ( )
}
```
---
# 3. Move Semantics ( ) (Part 1)

```cpp
// (L-value )
class CopyExample {
private:
int* data;
size_t size;

public:
//
CopyExample(const CopyExample& other)
: size(other.size) {
std::cout << "Copy constructor\n";
data = new int[size]; //
```
---
# 3. Move Semantics ( ) (Part 2)

```cpp
std::memcpy(data, other.data, size * sizeof(int)); //
}

//
CopyExample& operator=(const CopyExample& other) {
std::cout << "Copy assignment\n";
if (this!= &other) {
delete[] data; //
size = other.size;
data = new int[size]; //
std::memcpy(data, other.data, size * sizeof(int)); //
}
```
---
# 3. Move Semantics ( ) (Part 3) (Code Part 1/4)


```cpp
return *this;

```cpp
// (R-value )
class MoveExample {
private:
int* data;
size_t size;

public:
// (R-value &&)
MoveExample(MoveExample&& other) noexcept
: data(other.data) // ( )
```
---
# 3. Move Semantics ( ) (Part 3) (Code Part 2/4)

```cpp
, size(other.size) {
std::cout << "Move constructor\n";
// ( )
other.data = nullptr;
other.size = 0;
}

//
MoveExample& operator=(MoveExample&& other) noexcept {
std::cout << "Move assignment\n";
```
---
# 3. Move Semantics ( ) (Part 3) (Code Part 3/4)

```cpp
if (this!= &other) {
delete[] data; //

// ( )
data = other.data;
size = other.size;

//
other.data = nullptr;
other.size = 0;
```
---
# 3. Move Semantics ( ) (Part 3) (Code Part 4/4)

```cpp
}
return *this;
}

~MoveExample() {
delete[] data; // nullptr
}
};
```


```cpp
// vs
---
## 3.2 Perfect Forwarding ( ) (Part 1)



<div class="grid grid-cols-2 gap-8">
<div>

```cpp
#include <utility>
#include <memory>
#include <iostream>

//: ( )
template<typename T>
std::unique_ptr<T> BadMakeUnique(T value) {
// value ()
return std::unique_ptr<T>(new T(value));
}

//: L-value (R-value )
```
---
## 3.2 Perfect Forwarding ( ) (Part 2)

```cpp
template<typename T>
std::unique_ptr<T> BadMakeUnique2(T& value) {
return std::unique_ptr<T>(new T(value));
}
// BadMakeUnique2(Widget()); // (R-value )

//: Const L-value ( )
template<typename T>
std::unique_ptr<T> BadMakeUnique3(const T& value) {
// L-value R-value
// ( )
return std::unique_ptr<T>(new T(value));
```
---
## 3.2 Perfect Forwarding ( ) (Part 3) (Code Part 1/5)


```cpp
}

```cpp
// Perfect Forwarding:
template<typename T, typename... Args>
std::unique_ptr<T> CreateComponent(Args&&... args) {
//
// Perfect Forwarding
return std::make_unique<T>(std::forward<Args>(args)...);
}

class TemperatureWidget {
private:
```
---
## 3.2 Perfect Forwarding ( ) (Part 3) (Code Part 2/5)

```cpp
std::string label;
double min_temp, max_temp;

public:
TemperatureWidget(std::string lbl, double min_t, double max_t)
: label(std::move(lbl)), min_temp(min_t), max_temp(max_t) {
std::cout << "TemperatureWidget created: " << label << "\n";
}
};

```
---
## 3.2 Perfect Forwarding ( ) (Part 3) (Code Part 3/5)

```cpp
void FactoryDemo() {
//
// - "Temperature": R-value →
// - 0.0, 100.0: R-value →
auto widget = CreateComponent<TemperatureWidget>(
"Temperature", // R-value ( )
0.0, // R-value
100.0 // R-value
);

```
---
## 3.2 Perfect Forwarding ( ) (Part 3) (Code Part 4/5)

```cpp
std::string label = "Pressure";
// label L-value →
auto widget2 = CreateComponent<TemperatureWidget>(
label, // L-value →
0.0,
10.0
);

// std::move label
auto widget3 = CreateComponent<TemperatureWidget>(
```
---
## 3.2 Perfect Forwarding ( ) (Part 3) (Code Part 5/5)

```cpp
std::move(label), // R-value →
0.0,
10.0
);
}
```


```cpp
// emplace_back vs push_back
---
# 4. (Part 1)




<div class="grid grid-cols-2 gap-8">
<div>

```cpp
#include <memory>
#include <vector>
#include <array>
#include <cstddef>

// Memory Pool Allocator ( )
template<typename T, size_t BlockSize = 4096>
class PoolAllocator {
private:
//
struct Block {
std::array<std::byte, BlockSize> data;
```
---
# 4. (Part 2)

```cpp
Block* next;
};

Block* free_blocks = nullptr;
std::vector<std::unique_ptr<Block>> all_blocks;

public:
using value_type = T;

PoolAllocator() = default;

template<typename U>
```
---
# 4. (Part 3)

```cpp
PoolAllocator(const PoolAllocator<U, BlockSize>&) noexcept {}

T* allocate(std::size_t n) {
const size_t bytes = n * sizeof(T);

if (bytes > BlockSize) {
// →
return static_cast<T*>(::operator new(bytes));
}

if (!free_blocks) {
//
```
---
# 4. (Part 4)

```cpp
auto new_block = std::make_unique<Block>();
free_blocks = new_block.get();
free_blocks->next = nullptr;
all_blocks.push_back(std::move(new_block));
}

//
Block* block = free_blocks;
free_blocks = free_blocks->next;

return reinterpret_cast<T*>(block->data.data());
}
```
---
# 4. (Part 5)

```cpp

void deallocate(T* p, std::size_t n) noexcept {
const size_t bytes = n * sizeof(T);

if (bytes > BlockSize) {
//
::operator delete(p);
return;
}

//
Block* block = reinterpret_cast<Block*>(p);
```
---
# 4. (Part 6)

```cpp
block->next = free_blocks;
free_blocks = block;
}

template<typename U>
struct rebind {
using other = PoolAllocator<U, BlockSize>;
};
};

template<typename T, typename U, size_t BlockSize>
bool operator==(const PoolAllocator<T, BlockSize>&,
```
---
# 4. (Part 7) (Code Part 1/5)


```cpp
const PoolAllocator<U, BlockSize>&) noexcept {

```cpp
// Stack Allocator ( )
template<typename T, size_t N>
class StackAllocator {
private:
alignas(T) std::byte buffer[N * sizeof(T)];
std::byte* current = buffer;

public:
using value_type = T;

```
---
# 4. (Part 7) (Code Part 2/5)

```cpp
StackAllocator() = default;

template<typename U>
StackAllocator(const StackAllocator<U, N>&) noexcept {}

T* allocate(std::size_t n) {
const size_t bytes = n * sizeof(T);
const size_t remaining = (buffer + sizeof(buffer)) - current;

if (bytes > remaining) {
```
---
# 4. (Part 7) (Code Part 3/5)

```cpp
throw std::bad_alloc(); //
}

T* result = reinterpret_cast<T*>(current);
current += bytes;
return result;
}

void deallocate(T*, std::size_t) noexcept {
//
```
---
# 4. (Part 7) (Code Part 4/5)

```cpp
//
}

void reset() noexcept {
current = buffer; //
}

template<typename U>
struct rebind {
using other = StackAllocator<U, N>;
```
---
# 4. (Part 7) (Code Part 5/5)

```cpp
};
};
```


```cpp
//:
---
## 4.2 RAII + Custom Deleter (Part 1)



<div class="grid grid-cols-2 gap-8">
<div>

```cpp
#include <memory>
#include <cstdio>
#include <GL/gl.h>

//: C
void BadFileHandling() {
FILE* file = fopen("data.txt", "r");
if (!file) return;

//......

fclose(file); //
```
---
## 4.2 RAII + Custom Deleter (Part 2)

```cpp
}

//: unique_ptr + custom deleter
void GoodFileHandling() {
auto file = std::unique_ptr<FILE, decltype(&fclose)>(
fopen("data.txt", "r"),
&fclose // Custom deleter
);

if (!file) return;

//......
```
---
## 4.2 RAII + Custom Deleter (Part 3) (Code Part 1/4)


```cpp

```cpp
// Functor Custom Deleter
struct SocketDeleter {
void operator()(int* socket_fd) const {
if (socket_fd && *socket_fd >= 0) {
close(*socket_fd);
std::cout << "Socket closed: " << *socket_fd << "\n";
}
delete socket_fd;
}
};
```
---
## 4.2 RAII + Custom Deleter (Part 3) (Code Part 2/4)

```cpp

class NetworkConnection {
private:
std::unique_ptr<int, SocketDeleter> socket;

public:
NetworkConnection(const char* host, int port) {
int* fd = new int;
*fd = socket(AF_INET, SOCK_STREAM, 0);

```
---
## 4.2 RAII + Custom Deleter (Part 3) (Code Part 3/4)

```cpp
if (*fd < 0) {
delete fd;
throw std::runtime_error("Socket creation failed");
}

//... connect...

socket.reset(fd); // SocketDeleter
}

```
---
## 4.2 RAII + Custom Deleter (Part 3) (Code Part 4/4)

```cpp
void Send(const char* data, size_t len) {
if (socket && *socket >= 0) {
write(*socket, data, len);
}
}

// SocketDeleter
};
```


```cpp
// shared_ptr with custom deleter
---

# Week 10 핵심 요약 (1/3)

## C++ 메모리 관리 핵심 개념

<div class="grid grid-cols-2 gap-8">
<div>

**1. RAII (Resource Acquisition Is Initialization)**
- 리소스 획득 = 객체 생성
- 리소스 해제 = 객체 소멸
- 예외 안전성 자동 보장
- 반도체 HMI 필수 패턴

**장점**:
- 리소스 누수 방지
- 코드 간결성
- 예외 안전성

**2. Smart Pointers (스마트 포인터)**
---

# Week 10 핵심 요약 (2/3)

**unique_ptr (고유 포인터)**:
- 단독 소유권 - 복사 불가, 이동만 가능
- 오버헤드 최소 (8바이트)
- 용도: OpenGL 텍스처, UI 컴포넌트

**shared_ptr (공유 포인터)**:
- 공유 소유권 - 참조 카운팅
- 자동 메모리 해제
- 오버헤드 중간 (16바이트 + 제어 블록)
- 용도: 센서 데이터, 로그 시스템

---

# Week 10 핵심 요약 (3/3)

**weak_ptr (약한 포인터)**:
- 순환 참조 방지
- 소유권 없음 - 관찰만 가능
- lock()으로 임시 접근
- 용도: Observer 패턴, 캐시 시스템

**3. Move Semantics (이동 의미론)**
- L-value vs R-value 구분
- 복사 비용 제거 / 소유권 이전
- std::move로 명시적 변환 (복사 방지)
- 성능 향상 (대용량 데이터 처리)

---
# C++ 고급 기법 요약

**4. Perfect Forwarding (완벽한 전달)**
- Universal Reference (T&&)
- std::forward로 타입 보존
- 팩토리 패턴에 필수
- emplace_back vs push_back

</div>
<div>

**반도체 HMI 적용 사례**:
- 센서 데이터 수집: unique_ptr
- 레시피 공유: shared_ptr
- 로깅 시스템: weak_ptr
- OpenGL 리소스: RAII

**성능 최적화**:
- Move Semantics로 50% 복사 감소
- Smart Pointer로 메모리 누수 제거
- RAII로 예외 안전성 보장

---
# C++ 고급 기법 요약
</div>
</div>
---

# 반도체 장비 제어 시스템 예제 (Part 1)

## 실제 적용 사례

**CVD 장비 제어기 아키텍처**:

```cpp
// 실제 반도체 장비 제어기 구조
class EquipmentController {
// 시리얼 포트 → unique_ptr (단독 소유)
unique_ptr<SerialPort> port;

// 레시피 데이터 → shared_ptr (다중 참조)
shared_ptr<RecipeData> current_recipe;

// 로거 시스템 → weak_ptr (순환 참조 방지)
weak_ptr<Logger> logger;

// OpenGL 텍스처 → RAII 패턴
```
---

# 반도체 장비 제어 시스템 예제 (Part 2)

```cpp
GLTexture wafer_map_texture;
GLBuffer vertex_buffer;

public:
// Perfect forwarding으로 컴포넌트 생성
template<typename T, typename... Args>
unique_ptr<T> CreateComponent(Args&&... args) {
return make_unique<T>(forward<Args>(args)...);
}

// Move-only API (복사 방지)
void SetRecipe(shared_ptr<RecipeData> recipe) {
current_recipe = move(recipe);
}
};
```

---

# C++ 메모리 관리 베스트 프랙티스

**권장 사항**:
- 리소스 관리는 unique_ptr 사용
- 공유 필요 시에만 shared_ptr
- 반환값 최적화 (RVO) 활용
- const& (읽기) vs && (이동) 구분
- emplace_back > push_back (생성 비용 절감)
- make_unique/make_shared로 생성
- std::move로 명시적 이동

**금지 사항**:
- raw pointer 직접 관리 금지
- 명시적 new/delete 사용 금지

</div>
</div>
