# 파일별 조치 항목 리스트

이 문서는 각 파일에 대한 구체적인 조치 사항을 제공합니다.

## 🚨 최우선 조치 파일 (High Priority)

### Week 13 (158 이슈)

#### slides-01-intro.md
**위치**: `/home/cbchoi/Projects/presys/slides/hmi/week13-imgui-integrated-project/slides-01-intro.md`

**이슈**: 빈 섹션 30개
- Part 1/16 ~ Part 16/16: 모든 Part 헤더가 빈 섹션

**조치**:
```
삭제 권장: 라인 17, 78, 139, 200, 261, 326, 387, 449, 509, 563, 616, 685, 747 등
이유: Part X/Y 헤더는 구조적 구분일 뿐 실제 내용 불필요
```

#### slides-02-theory.md
**위치**: `/home/cbchoi/Projects/presys/slides/hmi/week13-imgui-integrated-project/slides-02-theory.md`

**이슈**:
- 빈 섹션 40+개
- 코드 설명 누락 7개 (라인 403, 492, 673, 1587, 1831, 1928, 3068)
- 템플릿 잔여물 3개 (라인 2098, 2145, 2192)

**조치**:
1. 코드 설명 추가 (라인 403, 492, 673, 1587, 1831, 1928, 3068):
   ```markdown
   각 코드 블록 뒤에 다음 형식으로 설명 추가:

   **주요 기능**:
   - 기능 1 설명
   - 기능 2 설명

   **사용 이유**:
   - 디자인 결정 이유
   ```

2. 템플릿 잔여물 검토:
   - 라인 2098: `.Add({{"endpoint", endpoint}, {"method", method}})`
   - 확인 필요: C++ 초기화 리스트인지 템플릿인지 구분

#### slides-04-practice2.md
**위치**: `/home/cbchoi/Projects/presys/slides/hmi/week13-imgui-integrated-project/slides-04-practice2.md`

**이슈**: Part 1/19 ~ Part 19/19 빈 섹션 (30+개)

**조치**: Part 헤더 대부분 삭제

---

### Week 12 (131 이슈)

#### slides-01-intro.md
**위치**: `/home/cbchoi/Projects/presys/slides/hmi/week12-imgui-advanced-features/slides-01-intro.md`

**이슈**: 빈 섹션 35+개

**조치**:
1. Part X/Y 헤더 삭제 (라인 158, 333, 491, 622, 704, 757, 813, 887, 948, 1000 등)
2. 실제 내용 섹션 검토:
   - 라인 5: "실습 개요: 🎯 이번 주 학습 목표" - 내용 추가 필요
   - 라인 7: "학습 목표" - 3-5개 bullet point 추가

#### slides-02-theory.md
**위치**: `/home/cbchoi/Projects/presys/slides/hmi/week12-imgui-advanced-features/slides-02-theory.md`

**이슈**: 빈 섹션 11개

**조치**:
1. 라인 5: "실습 개요: 📚 플러그인 시스템 아키텍처"
   ```markdown
   추가할 내용:
   - 플러그인 아키텍처의 핵심 개념
   - 확장 가능한 시스템 설계 원칙
   - 실습에서 구현할 주요 컴포넌트
   ```

2. 라인 37, 485, 939: 주요 주제 섹션 - 각각 내용 추가 필요

#### slides-03-practice1.md ~ slides-05-practice3.md
**조치**: 대부분 Part X/Y 헤더 삭제

---

### Week 10 (129 이슈)

#### slides-02-theory.md ⚠️ 최다 코드 설명 누락
**위치**: `/home/cbchoi/Projects/presys/slides/hmi/week10-imgui-basics/slides-02-theory.md`

**이슈**: 코드 설명 누락 19개

**코드 블록 위치 및 권장 설명**:

1. **라인 58**: RAII 패턴 코드
   ```markdown
   추가할 설명:
   - RAII를 사용한 자동 리소스 해제
   - 예외 안전성 보장
   - 수동 메모리 관리 대비 장점
   ```

2. **라인 177**: Smart Pointer 예제
   ```markdown
   추가할 설명:
   - unique_ptr을 사용한 단독 소유권 관리
   - 자동 메모리 해제로 메모리 누수 방지
   - 성능 오버헤드 없는 안전한 메모리 관리
   ```

3. **라인 251**: Move Semantics
   ```markdown
   추가할 설명:
   - 불필요한 복사 제거로 성능 최적화
   - 소유권 이전을 명시적으로 표현
   - 대용량 데이터 처리 시 필수적인 기법
   ```

4. **라인 415, 439, 468**: 각 코드 블록에 설명 추가

**조치 우선순위**: 최우선 (ImGui 기초 주차로 학습자가 많이 참고)

---

### Week 09 (122 이슈)

#### slides-05-practice3.md
**위치**: `/home/cbchoi/Projects/presys/slides/hmi/week09-python-deployment/slides-05-practice3.md`

**이슈**: 템플릿 잔여물 15개 (GitHub Actions 변수)

**조치**:
```
⚠️ 삭제하지 말 것!
이것들은 실제 GitHub Actions 문법입니다:
- ${{ env.PYTHON_VERSION }}
- ${{ matrix.os }}
- ${{ github.actor }}

이슈에서 제외 처리 (False Positive)
```

#### slides-02-theory.md
**이슈**: 코드 설명 누락 12개

**조치**: Python 배포 관련 코드에 설명 추가

---

### Week 11 (121 이슈)

#### slides-02-theory.md
**위치**: `/home/cbchoi/Projects/presys/slides/hmi/week11-imgui-advanced/slides-02-theory.md`

**이슈**:
- 코드 설명 누락 16개
- 템플릿 잔여물 9개 (C++ 초기화 리스트)

**조치**:
1. 템플릿 잔여물 재검토:
   ```cpp
   // 라인 1466: C++ 정상 문법 - 유지
   std::vector<std::vector<int>> nested = {{1,2}, {3,4}, {5,6}};
   ```

2. 코드 설명 추가 (라인 201, 290, 388, 496, 597, 703, 807, 920, 1063, 1194)

#### slides-04-practice2.md
**이슈**: 템플릿 잔여물 8개 (Mesh 정점 데이터)

**조치**:
```cpp
// 라인 491-499: 3D 큐브 정점 데이터 - C++ 초기화 리스트
// 이슈에서 제외 (False Positive)
{{-size, -size,  size}, {0, 0, 1}, {0, 0}, {1, 0, 0}},
```

---

## 📝 주차별 우선순위

### 긴급 (이번 주)
1. ✅ Week 13 (158 이슈) - 최종 프로젝트 주차
2. ✅ Week 12 (131 이슈) - 고급 기능
3. ✅ Week 10 (129 이슈) - 기초 주차로 많이 참조됨

### 중요 (다음 주)
4. Week 11 (121 이슈)
5. Week 09 (122 이슈)
6. Week 04 (121 이슈)

### 일반 (점진적)
7. Week 06 (115 이슈)
8. Week 03 (111 이슈)
9. Week 02 (102 이슈)
10. Week 05 (100 이슈)
11. Week 08 (93 이슈)
12. Week 01 (84 이슈)
13. Week 07 (36 이슈) - 이슈 가장 적음

---

## 🔧 작업 스크립트

### 빈 섹션 일괄 검색
```bash
# Week 13의 모든 빈 섹션 찾기
grep -n "^## Part" /home/cbchoi/Projects/presys/slides/hmi/week13-imgui-integrated-project/*.md
```

### 코드 블록 뒤 빈 줄 확인
```bash
# 코드 블록 직후 --- 또는 ## 로 시작하는 경우 찾기
cd /home/cbchoi/Projects/presys/slides/hmi/week10-imgui-basics
grep -A 2 "^```" slides-02-theory.md | grep -E "^(---|##)"
```

### 템플릿 잔여물 찾기
```bash
# TODO, FIXME, [Insert] 등 찾기
grep -rn "TODO\|FIXME\|\[Insert\]\|\[Add\]" /home/cbchoi/Projects/presys/slides/hmi/week*/slides-*.md
```

---

## 📋 체크리스트 (작업 진행 표시)

### Week 13
- [ ] slides-01-intro.md - Part 헤더 삭제
- [ ] slides-02-theory.md - 코드 설명 7개 추가
- [ ] slides-02-theory.md - 템플릿 잔여물 3개 검토
- [ ] slides-03-practice1.md - Part 헤더 삭제
- [ ] slides-04-practice2.md - Part 헤더 삭제
- [ ] slides-05-practice3.md - Part 헤더 삭제

### Week 12
- [ ] slides-01-intro.md - Part 헤더 삭제, 학습 목표 작성
- [ ] slides-02-theory.md - 주요 섹션 내용 추가
- [ ] slides-03-practice1.md - Part 헤더 삭제
- [ ] slides-04-practice2.md - Part 헤더 삭제
- [ ] slides-05-practice3.md - Part 헤더 삭제

### Week 10
- [ ] slides-02-theory.md - 코드 설명 19개 추가 ⚠️ 최우선

### Week 09
- [ ] slides-02-theory.md - 코드 설명 12개 추가
- [ ] slides-05-practice3.md - GitHub Actions 템플릿 이슈 무시 처리

### Week 11
- [ ] slides-02-theory.md - 코드 설명 16개 추가
- [ ] slides-04-practice2.md - C++ 초기화 리스트 이슈 무시 처리

---

## 💡 작업 팁

### 빈 섹션 처리 결정 플로우차트
```
빈 섹션 발견
    ↓
"Part X/Y" 패턴인가?
    ├─ YES → 삭제
    └─ NO → 섹션 제목 확인
            ↓
        "학습 목표", "실습 개요" 등인가?
            ├─ YES → 내용 작성 (필수)
            └─ NO → 이론/실습 주제인가?
                    ├─ YES → 내용 작성
                    └─ NO → 컨텍스트 검토 후 결정
```

### 코드 설명 템플릿
```markdown
**핵심 기능**:
- [이 코드가 하는 일]
- [주요 클래스/함수 설명]

**설계 이유**:
- [왜 이 방식을 선택했는가]
- [어떤 문제를 해결하는가]

**주의사항**:
- [성능 고려사항]
- [스레드 안전성 등]
```

---

**작성일**: 2025-10-04
**총 작업 예상 시간**: 30-40시간
**권장 작업 순서**: Week 13 → Week 12 → Week 10 → 나머지
