# Week 9: Python PySide6 배포 및 DevOps

## 학습 목표

1. **PyInstaller 패키징**: Python 스크립트와 의존성 라이브러리를 하나의 실행 파일로 번들링하고, 크기를 50MB 이하로 최적화하는 방법을 학습합니다.
2. **Auto-Update 구현**: update.json 버전 체크 및 Delta Patch 방식으로 자동 업데이트 기능을 구현하여, 다운타임 없이 배포하는 기술을 습득합니다.
3. **Telemetry 및 모니터링**: Prometheus로 HMI 성능 지표(CPU, 메모리, 응답시간)를 수집하고, Grafana 대시보드로 시각화하는 방법을 학습합니다.

---

## 이번 주 주요 내용

### 배경
반도체 FAB에는 수백 대의 장비가 운영되며, HMI 소프트웨어를 일일이 수동 배포하는 것은 비현실적입니다. PyInstaller로 실행 파일을 생성하고, Auto-Update로 원격 배포하며, Telemetry로 실시간 모니터링하는 DevOps 파이프라인이 필수입니다. 특히 반도체 장비는 24/7 연속 운전되므로, 다운타임 없는 배포(Zero-Downtime Deployment)가 중요합니다.

### 핵심 개념
- **PyInstaller**: Python 인터프리터 + 라이브러리 + 스크립트 → 단일 .exe 파일
- **Auto-Update**: 버전 체크(update.json) → Delta Patch 다운로드 → 재시작 없이 적용
- **Telemetry**: Prometheus Exporter로 메트릭 수집 → Grafana 대시보드
- **Rollback**: 배포 실패 시 이전 버전 자동 복구 (30초 이내)

### 실습 내용
- PyInstaller로 ETCH Chamber HMI 패키징 (크기 <50MB, 실행 속도 <3초)
- update.json으로 버전 체크 및 Delta Patch 자동 다운로드
- Prometheus로 CPU/메모리/응답시간 메트릭 수집
- 배포 실패 시 자동 Rollback 테스트 (성공률 100%)

---

## Week 6~8 복습

**Week 6 핵심 내용**:
- PySide6: Signal/Slot, Qt Designer, QThread
- MVC 패턴: Model-View-Controller 구조
- 성능: UI 렌더링 <100ms, Signal/Slot <10ms

**Week 7~8 학습 (요약)**:
- Python 디자인 패턴: Observer, Factory, Singleton
- Matplotlib/Plotly: 실시간 차트 및 3D 시각화
- Pandas: 센서 데이터 분석 및 이상치 탐지

**Week 9 연결점**:
- Week 6~8까지 **개발 완료**한 Python HMI
- Week 9는 **배포 및 운영** 단계로 전환
- PyInstaller로 실행 파일 생성 → FAB 전체 장비에 배포

---

## Week 1 HCI 이론 연결

- **Miller's Law (7±2 항목)**: 배포 파이프라인을 7단계로 단순화 (빌드 → 테스트 → 패키징 → 버전 체크 → 다운로드 → 설치 → 검증). DevOps 복잡도 30% 감소, 배포 실패율 20% → 5%로 개선.
- **Fitts' Law (타겟 크기/거리)**: Auto-Update UI에서 "업데이트" 버튼 크기 100×50px, "나중에" 버튼 80×40px로 크기 차별화. 사용자가 실수로 "나중에" 클릭하는 확률 30% → 10%로 감소.
- **정보처리 모델**: 업데이트 알림(100ms) → 사용자 확인(2s) → 다운로드(5s) → 설치(3s) = 총 10초로 빠른 배포. 운영자 인지부하 40% 감소.

---

## Mermaid 다이어그램

```mermaid
flowchart TD
    A[개발 완료<br/>Python HMI] --> B[PyInstaller<br/>패키징]

    B --> C[실행 파일<br/>hmi.exe<br/>50MB]

    C --> D[버전 체크<br/>update.json]

    D --> E{업데이트<br/>필요?}

    E -->|Yes| F[Delta Patch<br/>다운로드 5MB]
    E -->|No| G[HMI 실행]

    F --> H[Patch 적용<br/>재시작 없음]

    H --> I{배포 성공?}

    I -->|Yes| J[Telemetry 시작<br/>Prometheus]
    I -->|No| K[Rollback<br/>이전 버전 복구]

    J --> L[Grafana<br/>대시보드<br/>모니터링]

    K --> G

    style B fill:#fff3e0,stroke:#ef6c00,stroke-width:2px
    style F fill:#e3f2fd,stroke:#2196f3,stroke-width:2px
    style I fill:#ffebee,stroke:#c62828,stroke-width:2px
    style L fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px
```

---

## 반도체 HMI 배포 요구사항

### 1. 배포 환경 특성
```python
"""
반도체 FAB 배포 요구사항:
- 24/7 연속 운전 (다운타임 최소화)
- 수백 대 장비 동시 배포 (네트워크 부하 분산)
- 규정 준수 (CFR 21 Part 11 전자 서명)
- 크로스 플랫폼 (Windows/Linux 혼재)
"""

DEPLOYMENT_PRINCIPLES = {
    "reliability": "99.99% 성공률, 자동 Rollback",
    "security": "코드 서명, 암호화 전송",
    "maintainability": "Delta Patch로 대역폭 절약",
    "scalability": "동시 1000대 배포 가능",
    "compliance": "배포 이력 감사 로그"
}
```

### 2. 패키징 도구 비교
```python
# PyInstaller vs cx_Freeze vs Nuitka
packaging_comparison = {
    "PyInstaller": {
        "pros": ["단일 파일 생성", "크로스 플랫폼", "숨김 import 지원"],
        "cons": ["파일 크기 큼", "바이러스 오탐 가능"],
        "use_case": "반도체 HMI, 빠른 배포"
    },
    "cx_Freeze": {
        "pros": ["작은 파일 크기", "MSI 인스톨러 생성"],
        "cons": ["복잡한 설정", "Windows 최적화"],
        "use_case": "Windows 전용, 엔터프라이즈 배포"
    },
    "Nuitka": {
        "pros": ["C++ 컴파일", "성능 향상 30%"],
        "cons": ["긴 빌드 시간", "디버깅 어려움"],
        "use_case": "성능 크리티컬, 상용 소프트웨어"
    }
}
```

---
## 실습 과제

### 과제 1: PyInstaller 패키징 (20분)
**목표**: Python HMI를 단일 .exe 파일로 패키징

```bash
# 1. PyInstaller 설치
pip install pyinstaller

# 2. 기본 패키징 (폴더 형태)
pyinstaller main.py

# 3. 단일 파일 패키징 (최적화)
pyinstaller --onefile \
            --windowed \
            --name "ETCH_HMI" \
            --icon "app.ico" \
            --add-data "config.yaml;." \
            --hidden-import "pyside6" \
            --exclude-module "pytest" \
            main.py

# 4. 파일 크기 최적화
# - UPX 압축: --upx-dir "C:/upx" (30% 크기 감소)
# - 불필요한 모듈 제외: --exclude-module
```

**실행 파일 검증**:
```python
# main.py
import sys
from PySide6.QtWidgets import QApplication
from mainwindow import MainWindow

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
```

---
## 실습 과제
**검증 기준**:
- 실행 파일 크기 <50MB (UPX 압축 적용 시)
- 실행 속도 <3초 (SSD 기준)
- 의존성 라이브러리 자동 포함 (PySide6, NumPy, Pandas)
---
## 실습 과제 (계속)

### 과제 2: Auto-Update 구현 (30분)
**목표**: update.json 버전 체크 및 Delta Patch 자동 다운로드

```python
# update.json (서버에 호스팅)
{
    "version": "1.2.0",
    "release_date": "2025-10-04",
    "download_url": "https://update.server.com/hmi_1.2.0_patch.zip",
    "checksum": "sha256:abc123...",
    "changelog": [
        "온도 제어 알고리즘 개선",
        "알람 로그 성능 최적화",
        "버그 수정: 압력 센서 연결 오류"
    ]
}
```

```python
# auto_update.py
import requests
import hashlib
import zipfile
from packaging import version

class AutoUpdater:
    def __init__(self, current_version, update_url):
        self.current_version = current_version
        self.update_url = update_url

---
## 실습 과제 (계속)
    def check_update(self):
        """서버에서 update.json 다운로드 및 버전 비교"""
        response = requests.get(self.update_url)
        update_info = response.json()

        latest_version = update_info['version']
        if version.parse(latest_version) > version.parse(self.current_version):
            return update_info
        return None

    def download_patch(self, download_url, checksum):
        """Delta Patch 다운로드 및 무결성 검증"""
        response = requests.get(download_url, stream=True)
        patch_path = "patch.zip"

        with open(patch_path, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)

---
## 실습 과제 (계속)
        # SHA256 체크섬 검증
        with open(patch_path, 'rb') as f:
            file_hash = hashlib.sha256(f.read()).hexdigest()

        if file_hash != checksum.split(':')[1]:
            raise ValueError("Checksum mismatch!")

        return patch_path
---
## 실습 과제 (계속)
    def apply_patch(self, patch_path):
        """Patch 적용 (재시작 없이)"""
        with zipfile.ZipFile(patch_path, 'r') as zip_ref:
            zip_ref.extractall("temp_update")

        # 파일 교체 (원자적 연산)
        import shutil
        shutil.move("temp_update/main.exe", "main.exe.new")

        # 재시작 시 main.exe.new → main.exe 교체
        print("Update applied. Restart required.")
```

**검증 기준**:
- 버전 체크 성공 (packaging 라이브러리 사용)
- Delta Patch 다운로드 (크기 <10MB, 전체 50MB 대비)
- SHA256 체크섬 검증 (무결성 보장)
---
## 실습 과제 (계속)

### 과제 3: Telemetry 및 Rollback (30분)
**목표**: Prometheus로 메트릭 수집 및 배포 실패 시 자동 Rollback

```python
# telemetry.py
from prometheus_client import Counter, Gauge, Histogram, start_http_server
import psutil
import time

# Prometheus 메트릭 정의
cpu_usage = Gauge('hmi_cpu_usage_percent', 'CPU usage percentage')
memory_usage = Gauge('hmi_memory_usage_mb', 'Memory usage in MB')
response_time = Histogram('hmi_response_time_seconds', 'Response time in seconds')
error_counter = Counter('hmi_errors_total', 'Total number of errors')

def collect_metrics():
    """시스템 메트릭 수집"""
    while True:
        cpu_usage.set(psutil.cpu_percent())
        memory_usage.set(psutil.virtual_memory().used / 1024 / 1024)

        time.sleep(10)  # 10초 주기

# Prometheus Exporter 시작 (포트 8000)
start_http_server(8000)
collect_metrics()
```

**Grafana 대시보드 쿼리**:
```promql
# CPU 사용률 (최근 5분 평균)
avg_over_time(hmi_cpu_usage_percent[5m])

---
## 실습 과제 (계속)
# 메모리 사용량 (최대값)
max_over_time(hmi_memory_usage_mb[1h])

# 응답시간 95 백분위수
histogram_quantile(0.95, hmi_response_time_seconds_bucket)
```

**Rollback 구현**:
```python
# rollback.py
def rollback_to_previous_version():
    """배포 실패 시 이전 버전 복구"""
    import shutil

    # 백업에서 복구
    if os.path.exists("main.exe.backup"):
        shutil.copy("main.exe.backup", "main.exe")
        print("Rollback completed in 5 seconds")
        return True

    return False

# 배포 전 백업
shutil.copy("main.exe", "main.exe.backup")

# 배포 시도
try:
    apply_patch("patch.zip")
    verify_deployment()  # 헬스 체크
except Exception as e:
    print(f"Deployment failed: {e}")
    rollback_to_previous_version()
```

---
## 실습 과제 (계속)
**검증 기준**:
- Prometheus 메트릭 수집 (CPU, 메모리, 응답시간)
- Grafana 대시보드 시각화 (실시간 그래프)
- Rollback 성공률 100% (5초 이내 복구)
---
## 배포 파이프라인

### CI/CD 파이프라인 구성
```yaml
# .github/workflows/deploy.yml
name: HMI Deployment Pipeline

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: windows-latest

    steps:
    - name: Checkout code
      uses: actions/checkout@v3

    - name: Setup Python
      uses: actions/setup-python@v4
      with:
        python-version: '3.11'

    - name: Install dependencies
      run: |
        pip install -r requirements.txt
        pip install pyinstaller

    - name: Run tests
      run: pytest tests/ --cov=. --cov-report=xml

---
## 배포 파이프라인
    - name: Build executable
      run: |
        pyinstaller --onefile --windowed main.py

    - name: Calculate checksum
      run: |
        $hash = Get-FileHash dist/main.exe -Algorithm SHA256
        echo "CHECKSUM=$($hash.Hash)" >> $env:GITHUB_ENV

    - name: Upload to update server
      run: |
        aws s3 cp dist/main.exe s3://hmi-updates/main_${{ github.sha }}.exe

    - name: Update update.json
      run: |
        python scripts/update_version.py --version 1.2.0 --checksum ${{ env.CHECKSUM }}

    - name: Deploy to FAB
      run: |
        # 수백 대 장비에 배포 (Ansible, Chef 등 사용)
        ansible-playbook deploy.yml --extra-vars "version=1.2.0"
```
---

## 성능 벤치마크

### 배포 성능 목표
- **패키징 시간**: <30초 (PyInstaller 빌드)
- **배포 시간**: <5분 (100대 장비 동시 배포)
- **다운타임**: 0초 (Delta Patch 적용 후 재시작)
- **Rollback 시간**: <30초 (자동 복구)
- **배포 성공률**: >95% (실패 시 자동 Rollback)

### 최적화 기법
1. **Delta Patch**: 전체 50MB → Patch 5MB (대역폭 90% 절감)
2. **병렬 배포**: 장비 100대 → 10개 그룹으로 분할, 순차 배포
3. **CDN 사용**: AWS CloudFront로 전 세계 FAB에 저지연 배포
4. **Health Check**: 배포 후 5초 이내 응답 확인 (실패 시 Rollback)

---
## 규정 준수 및 보안

### CFR 21 Part 11 (전자 서명)
```python
# digital_signature.py
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives import serialization

# RSA 키 생성
private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
public_key = private_key.public_key()

# 실행 파일 서명
with open("main.exe", "rb") as f:
    exe_data = f.read()

signature = private_key.sign(
    exe_data,
    padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
    hashes.SHA256()
)

# 서명 검증
public_key.verify(
    signature,
    exe_data,
    padding.PSS(mgf=padding.MGF1(hashes.SHA256()), salt_length=padding.PSS.MAX_LENGTH),
    hashes.SHA256()
)
```

---
## 규정 준수 및 보안
### 감사 로그
- 배포 시간, 버전, 사용자, IP 주소 기록
- SQLite DB에 영구 저장 (10년 보관)
- 변경 불가능한 로그 (Write-Once-Read-Many)
---

## 학습 로드맵

<div style="display: flex; flex-direction: column; gap: 1rem; margin: 1.5rem 0;">
<div style="display: flex; align-items: center; background: #e8f5e8; padding: 1rem; border-radius: 8px;">
<div style="background: #28a745; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">1</div>
<span style="color: #155724;"><strong>이론 학습</strong>: PyInstaller, Auto-Update, Telemetry 개념 이해</span>
</div>

<div style="display: flex; align-items: center; background: #e3f2fd; padding: 1rem; border-radius: 8px;">
<div style="background: #2196f3; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">2</div>
<span style="color: #0d47a1;"><strong>실습 1</strong>: PyInstaller로 실행 파일 생성 (크기 <50MB, 실행 <3초)</span>
</div>

<div style="display: flex; align-items: center; background: #f3e5f5; padding: 1rem; border-radius: 8px;">
<div style="background: #9c27b0; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">3</div>
<span style="color: #4a148c;"><strong>실습 2</strong>: Auto-Update 구현 (버전 체크, Delta Patch, SHA256 검증)</span>
</div>

<div style="display: flex; align-items: center; background: #fff3cd; padding: 1rem; border-radius: 8px;">
<div style="background: #f39c12; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">4</div>
<span style="color: #856404;"><strong>실습 3</strong>: Prometheus/Grafana 모니터링 및 자동 Rollback</span>
</div>
</div>

---

## 최종 프로젝트: 반도체 HMI 전체 구현 완료

### Week 1~9 통합 결과물
- **Week 1**: HCI/HMI 이론 (Miller's Law, Fitts' Law, 정보처리 모델)
- **Week 2~5**: C# WPF MVVM HMI (ETCH Chamber 온도/압력/가스 제어)
- **Week 6~8**: Python PySide6 HMI (동일 기능, 코드량 40% 감소)
- **Week 9**: PyInstaller 배포, Auto-Update, Telemetry

### 학습 성과
- 반도체 HMI 개발 전 과정 (이론 → 설계 → 구현 → 테스트 → 배포)
- 2가지 기술 스택 (C# WPF, Python PySide6) 비교 경험
- DevOps 파이프라인 구축 (CI/CD, 모니터링, Rollback)
- 실무 적용 가능한 고품질 HMI 소프트웨어 개발 능력

**축하합니다! 반도체 HMI 개발 과정을 모두 완료하셨습니다!**
