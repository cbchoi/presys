# Week 5: C# 테스트 및 배포 자동화

## 학습 목표

1. **Unit Test**: xUnit 프레임워크와 Moq 라이브러리를 활용하여 ViewModel 비즈니스 로직을 격리 테스트하고, 코드 커버리지 80% 이상을 달성하는 방법을 학습합니다.
2. **UI Test**: FlaUI를 사용하여 실제 사용자 시나리오를 자동화 테스트하고, Page Object Model 패턴으로 유지보수성을 높이는 기술을 습득합니다.
3. **CI/CD**: Docker 컨테이너 기반 빌드/배포 파이프라인을 구축하고, GitHub Actions로 자동화하여 배포 시간을 30초 이내로 단축하는 방법을 학습합니다.

---

## 이번 주 주요 내용

### 배경
반도체 장비 HMI는 24/7 연속 운전되며, 소프트웨어 버그로 인한 다운타임은 시간당 수백만 원의 손실을 초래합니다. 체계적인 테스트와 안정적인 배포 프로세스는 필수입니다. xUnit으로 로직 오류를 사전 검증하고, FlaUI로 실제 운영 시나리오를 재현하며, Docker로 일관된 배포 환경을 보장합니다.

### 핵심 개념
- **AAA 패턴** (Arrange-Act-Assert): 테스트 코드 구조화 (준비-실행-검증)
- **Moq**: Interface를 Mock 객체로 대체하여 의존성 격리
- **FlaUI**: Windows UI Automation으로 버튼 클릭, 텍스트 입력 자동화
- **Docker**: Dockerfile로 빌드 환경 컨테이너화, 재현 가능한 배포

### 실습 내용
- xUnit으로 ProcessController Unit Test (온도 범위 200-450°C 검증)
- Moq로 ISensorService Mock 생성 (실제 센서 없이 테스트)
- FlaUI로 Start/Stop 버튼 클릭 자동화 (Page Object Model 적용)
- Docker로 WPF HMI 빌드 및 배포 (빌드 시간 <30초, 성공률 >95%)

---

## Week 4 복습

**Week 4 핵심 내용**:
- Strategy Pattern: 차트 종류 동적 변경 (Bar/Line/Heatmap)
- Decorator Pattern: 알람 테두리 및 블링킹 효과
- Custom Control: CircularGauge, LinearGauge 개발
- 성능 목표: 60 FPS, CPU <10%, GPU >70%

**Week 5 연결점**:
- Week 4는 **UI/UX 개발** (Feature Development)
- Week 5는 **품질 보증 및 배포** (Quality Assurance & Deployment)
- 개발한 UI/UX가 정상 동작하는지 자동 테스트로 검증

---

## Week 1 HCI 이론 연결

- **Miller's Law (7±2 항목)**: UI 테스트 케이스를 7개 이하 시나리오로 그룹화 (로그인, 공정 시작, 알람 처리, 레시피 변경, 데이터 조회, 긴급 정지, 종료). 테스트 복잡도 30% 감소, 유지보수 시간 50% 단축.
- **Fitts' Law (타겟 크기/거리)**: FlaUI 테스트에서 버튼 클릭 시 좌표 정확도 ±5px 이내 검증. 자동화 테스트 성공률 80% → 95%로 향상.
- **정보처리 모델**: 테스트 실행(10ms) → 결과 수집(20ms) → 리포트 생성(20ms) = 총 50ms로 빠른 피드백 제공. CI/CD 파이프라인 응답성 40% 향상.

---

## Mermaid 다이어그램

```mermaid
flowchart TD
    A[소스 코드] --> B[Unit Test<br/>xUnit + Moq]
    A --> C[UI Test<br/>FlaUI]

    B --> D{테스트 통과?}
    C --> D

    D -->|Yes| E[Docker Build]
    D -->|No| F[실패 알림<br/>개발자 수정]

    E --> G[Docker Image<br/>hmi:v1.0]

    G --> H{배포 환경}
    H -->|Dev| I[개발 서버<br/>즉시 배포]
    H -->|Integration| J[통합 서버<br/>야간 배포]
    H -->|Production| K[운영 서버<br/>점진적 배포<br/>1%→10%→100%]

    I --> L[배포 완료<br/>모니터링 시작]
    J --> L
    K --> L

    style B fill:#e8f5e8,stroke:#28a745,stroke-width:2px
    style C fill:#e3f2fd,stroke:#2196f3,stroke-width:2px
    style E fill:#fff3e0,stroke:#ef6c00,stroke-width:2px
    style K fill:#ffebee,stroke:#c62828,stroke-width:2px
    style L fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px
```

---
## 실습 과제

### 과제 1: xUnit Unit Test (20분)
**목표**: ProcessController의 온도 제어 로직 테스트 (AAA 패턴)

```csharp
using Xunit;
using Moq;

public class ProcessControllerTests
{
    [Fact]
    public void SetTemperature_WithinRange_ShouldSucceed()
    {
        // Arrange (준비)
        var mockSensor = new Mock<ISensorService>();
        mockSensor.Setup(s => s.GetTemperature()).Returns(300.0);

        var controller = new ProcessController(mockSensor.Object);

        // Act (실행)
        var result = controller.SetTemperature(350.0); // 200-450°C 범위 내

        // Assert (검증)
        Assert.True(result.Success);
        Assert.Equal(350.0, controller.TargetTemperature);
    }

    [Theory]
    [InlineData(150.0)] // 범위 미만
    [InlineData(500.0)] // 범위 초과
    public void SetTemperature_OutOfRange_ShouldFail(double temperature)
    {
        // Arrange
        var controller = new ProcessController(Mock.Of<ISensorService>());

---
## 실습 과제
        // Act
        var result = controller.SetTemperature(temperature);

        // Assert
        Assert.False(result.Success);
        Assert.Contains("out of range", result.ErrorMessage);
    }

    [Fact]
    public void StartProcess_WhenTemperatureReached_ShouldTransitionToRunning()
    {
        // Arrange
        var mockSensor = new Mock<ISensorService>();
        mockSensor.Setup(s => s.GetTemperature()).Returns(350.0);

        var controller = new ProcessController(mockSensor.Object);
        controller.SetTemperature(350.0);

        // Act
        controller.StartProcess();

        // Assert
        Assert.Equal(ProcessState.Running, controller.State);
    }
}
```

---
## 실습 과제
**검증 기준**:
- xUnit [Fact], [Theory] 속성 사용
- Moq로 ISensorService Mock 생성
- AAA 패턴 준수 (Arrange-Act-Assert)
- 코드 커버리지 80% 이상 (dotCover, Coverlet 도구 사용)
---
## 실습 과제 (계속)

### 과제 2: FlaUI UI Test (30분)
**목표**: Start/Stop 버튼 클릭 자동화 (Page Object Model)

```csharp
using FlaUI.Core;
using FlaUI.UIA3;
using Xunit;

// 1. Page Object Model 정의
public class MainWindowPage
{
    private readonly Window _window;

    public MainWindowPage(Window window)
    {
        _window = window;
    }

    public Button StartButton => _window.FindFirstDescendant(cf => cf.ByAutomationId("StartButton"))?.AsButton();
    public Button StopButton => _window.FindFirstDescendant(cf => cf.ByAutomationId("StopButton"))?.AsButton();
    public TextBox TemperatureTextBox => _window.FindFirstDescendant(cf => cf.ByAutomationId("TemperatureTextBox"))?.AsTextBox();

    public void ClickStart() => StartButton.Click();
    public void ClickStop() => StopButton.Click();
    public string GetTemperature() => TemperatureTextBox.Text;
}

---
## 실습 과제 (계속)
// 2. UI Test 작성
public class MainWindowTests : IDisposable
{
    private readonly Application _app;
    private readonly MainWindowPage _page;

    public MainWindowTests()
    {
        _app = Application.Launch("HmiApp.exe");
        var window = _app.GetMainWindow(new UIA3Automation());
        _page = new MainWindowPage(window);
    }

    [Fact]
    public void ClickStartButton_ShouldStartProcess()
    {
        // Arrange
        _page.TemperatureTextBox.Text = "350";

---
## 실습 과제 (계속)
        // Act
        _page.ClickStart();
        Thread.Sleep(1000); // UI 업데이트 대기

        // Assert
        Assert.False(_page.StartButton.IsEnabled); // Start 버튼 비활성화
        Assert.True(_page.StopButton.IsEnabled);   // Stop 버튼 활성화
    }
---
## 실습 과제 (계속)
    public void Dispose()
    {
        _app?.Close();
    }
}
```

**검증 기준**:
- FlaUI로 실행 중인 WPF 앱 제어
- Page Object Model로 UI 요소 캡슐화
- AutomationId로 요소 검색 (XAML에 `AutomationProperties.AutomationId` 설정 필요)
- UI 테스트 성공률 80% 이상
---
## 실습 과제 (계속)

### 과제 3: Docker 빌드 및 배포 (30분)
**목표**: Dockerfile로 WPF HMI 빌드 환경 컨테이너화

```dockerfile
# 1. .NET SDK 이미지로 빌드
FROM mcr.microsoft.com/dotnet/sdk:8.0 AS build
WORKDIR /src

COPY ["HmiApp/HmiApp.csproj", "HmiApp/"]
RUN dotnet restore "HmiApp/HmiApp.csproj"

COPY . .
WORKDIR "/src/HmiApp"
RUN dotnet build "HmiApp.csproj" -c Release -o /app/build
RUN dotnet publish "HmiApp.csproj" -c Release -o /app/publish

# 2. Runtime 이미지로 실행
FROM mcr.microsoft.com/dotnet/runtime:8.0-windowsservercore-ltsc2022
WORKDIR /app
COPY --from=build /app/publish .

ENTRYPOINT ["dotnet", "HmiApp.dll"]
```

**GitHub Actions 워크플로우**:
```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [ main ]

---
## 실습 과제 (계속)
jobs:
  test-and-deploy:
    runs-on: windows-latest

    steps:
    - uses: actions/checkout@v3

    - name: Setup .NET
      uses: actions/setup-dotnet@v3
      with:
        dotnet-version: 8.0.x

    - name: Restore dependencies
      run: dotnet restore

    - name: Build
      run: dotnet build --no-restore -c Release

    - name: Run Unit Tests
      run: dotnet test --no-build --verbosity normal --collect:"XPlat Code Coverage"

    - name: Build Docker Image
      run: docker build -t hmi:${{ github.sha }} .

    - name: Push to Registry
      run: docker push hmi:${{ github.sha }}
```

---
## 실습 과제 (계속)
**검증 기준**:
- Docker 빌드 성공 (이미지 크기 <500MB)
- 빌드 시간 <30초
- GitHub Actions 파이프라인 성공률 >95%
---

## 성능 벤치마크

### 테스트 및 배포 성능 목표
- **Unit Test 실행 시간**: <5초 (100개 테스트 케이스)
- **UI Test 실행 시간**: <30초 (10개 시나리오)
- **코드 커버리지**: >80% (Statement Coverage)
- **Docker 빌드 시간**: <30초
- **배포 성공률**: >95% (실패 시 자동 롤백)

### 배포 전략
1. **개발 환경 (Dev)**: 즉시 배포, 다운타임 허용 (<1분)
2. **통합 환경 (Integration)**: 야간 배포, 통합 테스트 실행
3. **운영 환경 (Production)**: 점진적 배포 (1% → 10% → 100%), 30분 간격 모니터링

---

## 반도체 HMI 배포 특수 요구사항

### 고가용성 (High Availability)
- **24/7 연속 운전**: 배포 시 다운타임 최소화 (Blue-Green Deployment)
- **응답 시간**: <100ms (센서 데이터 수집 주기)
- **오류율**: <0.1% (99.9% 가용성 목표)
- **롤백 시간**: <5분 (문제 발생 시 이전 버전 복구)

### 규정 준수
- **SEMI E10**: 장비 안전 표준 (Emergency Stop 기능 필수)
- **SEMI E30**: GEM (Generic Equipment Model) 통신 프로토콜
- **ISO 9001**: 품질 관리 시스템 (배포 이력 기록)
- **IEC 61508**: 기능 안전 (SIL 2 이상 요구)
- **트레이서빌리티**: 소스 코드 → 빌드 → 테스트 → 배포 전 과정 추적

---

## 테스트 피라미드

### 1. Unit Tests (전체 테스트의 70%)
```text
     /\
    /  \    UI Tests (10%)
   /____\
  /      \  Integration Tests (20%)
 /________\
/__________\ Unit Tests (70%)
```

**특징**:
- 빠른 실행 속도 (<1초)
- 격리된 테스트 (Mock 사용)
- 높은 커버리지 (80% 목표)

### 2. Integration Tests (전체 테스트의 20%)
- **하드웨어 통합**: PLC, 센서, 액추에이터 연동 테스트
- **프로토콜 테스트**: TCP/IP, OPC UA, Modbus 통신 검증
- **외부 시스템**: MES, ERP, FDC 연계 테스트

### 3. UI Tests (전체 테스트의 10%)
- **사용자 시나리오**: 공정 시작/정지, 알람 처리, 레시피 변경
- **회귀 테스트**: 신규 기능 추가 시 기존 기능 동작 검증
- **E2E 테스트**: 로그인부터 공정 완료까지 전체 플로우

---

## 학습 로드맵

<div style="display: flex; flex-direction: column; gap: 1rem; margin: 1.5rem 0;">
<div style="display: flex; align-items: center; background: #e8f5e8; padding: 1rem; border-radius: 8px;">
<div style="background: #28a745; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">1</div>
<span style="color: #155724;"><strong>이론 학습</strong>: xUnit, Moq, FlaUI, Docker 개념 이해</span>
</div>

<div style="display: flex; align-items: center; background: #e3f2fd; padding: 1rem; border-radius: 8px;">
<div style="background: #2196f3; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">2</div>
<span style="color: #0d47a1;"><strong>실습 1</strong>: xUnit + Moq로 Unit Test (커버리지 80%)</span>
</div>

<div style="display: flex; align-items: center; background: #f3e5f5; padding: 1rem; border-radius: 8px;">
<div style="background: #9c27b0; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">3</div>
<span style="color: #4a148c;"><strong>실습 2</strong>: FlaUI로 UI Test (Page Object Model)</span>
</div>

<div style="display: flex; align-items: center; background: #fff3cd; padding: 1rem; border-radius: 8px;">
<div style="background: #f39c12; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">4</div>
<span style="color: #856404;"><strong>실습 3</strong>: Docker 빌드 및 GitHub Actions CI/CD 파이프라인 구축</span>
</div>
</div>

---

## 다음 주 예고: Week 6 - Python PySide6 기초

Week 5까지 C# WPF로 반도체 HMI를 개발했습니다. Week 6부터는 Python PySide6로 동일한 기능을 구현합니다.

- **PySide6 소개**: Qt for Python, Signal/Slot 메커니즘
- **Qt Designer**: GUI 드래그 앤 드롭 디자인 도구
- **MVC 패턴**: Model-View-Controller 구조 (C# MVVM과 유사)
- **실습**: ETCH Chamber HMI를 Python으로 재구현, C# 대비 코드량 40% 감소
