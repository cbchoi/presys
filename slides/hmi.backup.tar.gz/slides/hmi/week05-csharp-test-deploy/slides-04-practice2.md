# 심화 실습: UI 자동화 테스트 및 성능 테스트

## UI 자동화 테스트 (FlaUI)

### FlaUI 테스트 설정

<div class="code-section">

**SemiconductorHMI.UITests.csproj**

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
```xml
<Project Sdk="Microsoft.NET.Sdk">

 <PropertyGroup>
 <TargetFramework>net6.0-windows</TargetFramework>
 <UseWPF>true</UseWPF>
 <ImplicitUsings>enable</ImplicitUsings>
 <Nullable>enable</Nullable>
 <IsPackable>false</IsPackable>
 </PropertyGroup>

 <ItemGroup>
 <PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.3.2" />
 <PackageReference Include="xunit" Version="2.4.2" />
 <PackageReference Include="xunit.runner.visualstudio" Version="2.4.3" />
 <PackageReference Include="FlaUI.Core" Version="4.0.0" />
 <PackageReference Include="FlaUI.UIA3" Version="4.0.0" />
 <PackageReference Include="FluentAssertions" Version="6.8.0" />
 </ItemGroup>

 <ItemGroup>
 <ProjectReference Include="..\SemiconductorHMI\SemiconductorHMI.csproj" />
 </ItemGroup>

</Project>
```

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
</div>

**배경 설명**

반도체 HMI는 WPF로 구축된 복잡한 UI를 가지며, 버튼 클릭, 차트 업데이트, 다이얼로그 표시 등의 UI 로직 오류는 운영자의 작업을 방해합니다. FlaUI는 Windows UI Automation API를 활용하여 UI 요소를 자동으로 조작하고 검증하는 테스트를 작성할 수 있습니다.

**핵심 개념**

FlaUI는 .NET용 UI 자동화 라이브러리로, UIA3 Automation Provider를 통해 WPF, WinForms 애플리케이션을 제어합니다. AutomationId로 UI 요소를 식별하고, Click(), FindFirstDescendant() 등으로 상호작용합니다. Retry와 Wait로 비동기 UI 업데이트를 안정적으로 처리합니다.

**코드 해설**

- Line 17: `net6.0-windows`는 Windows 전용 프레임워크, WPF 필수
- Line 28-29: FlaUI.Core 4.0.0과 FlaUI.UIA3로 UI Automation 구현
- Line 18: `UseWPF=true`로 WPF 프로젝트 참조 활성화
- Line 30: FluentAssertions로 UI 검증문 작성
- Line 34: 실제 HMI 프로젝트 참조하여 애플리케이션 실행

**실제 사례**

Applied Materials Fab에서는 Etcher HMI의 3D 장비 뷰, 센서 게이지, 알람 패널 등 50개 이상의 UI 컴포넌트를 FlaUI로 테스트합니다. 테스트는 야간에 자동 실행되며, 윈도우 타이틀, 버튼 활성화 상태, 차트 렌더링을 10분 이내에 검증합니다. UI 회귀 테스트로 배포 전 품질을 보장합니다.

**Week 1 HCI 이론 연결**

Don Norman의 디자인 원칙에 따라 UI 테스트는 가시성(Visibility), 피드백(Feedback), 제약(Constraints)을 검증합니다. 버튼이 보이는지, 클릭 시 피드백이 있는지, 잘못된 입력을 제한하는지 자동으로 확인하여 사용성을 보장합니다.

```mermaid
graph TD
    A[FlaUI 테스트 시작] --> B[Application.Launch]
    B --> C[WPF 앱 실행]
    C --> D[UIA3Automation 생성]
    D --> E[GetMainWindow]
    E --> F{Window 로드?}
    F -->|Retry 10s| E
    F -->|Success| G[AutomationId로 요소 찾기]
    G --> H[UI 요소 조작]
    H --> I{Action Type}
    I -->|Click| J[버튼 클릭]
    I -->|Input| K[텍스트 입력]
    I -->|Select| L[항목 선택]
    J --> M[Wait.UntilInputIsProcessed]
    K --> M
    L --> M
    M --> N[Assert 검증]
    N --> O[Dispose: 앱 종료]
```

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
### 메인 대시보드 UI 테스트

<div class="code-section">

**MainDashboardUITests.cs**
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
```csharp
using FlaUI.Core;
using FlaUI.Core.AutomationElements;
using FlaUI.Core.Definitions;
using FlaUI.Core.Tools;
using FlaUI.UIA3;
using FluentAssertions;
using System.Diagnostics;
using Xunit;

namespace SemiconductorHMI.UITests
{
 public class MainDashboardUITests : IDisposable
 {
 private readonly Application application;
 private readonly UIA3Automation automation;
 private readonly Window mainWindow;

 public MainDashboardUITests()
 {
 // 테스트 모드로 애플리케이션 시작
 var appPath = Path.Combine(TestContext.CurrentContext.TestDirectory, "SemiconductorHMI.exe");
 application = Application.Launch(appPath + " --test-mode");
 automation = new UIA3Automation();

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 // 메인 윈도우가 로드될 때까지 대기
 var retry = Retry.WhileEmpty(() => application.GetMainWindow(automation), TimeSpan.FromSeconds(10));
 mainWindow = retry.Result;
 mainWindow.Should().NotBeNull("Main window should be loaded");
 }

 [Fact]
 public void MainWindow_ShouldLoadWithCorrectTitle()
 {
 // Assert
 mainWindow.Title.Should().Be("반도체 장비 통합 모니터링 시스템");
 mainWindow.IsEnabled.Should().BeTrue();
 }

 [Fact]
 public void EquipmentList_ShouldDisplayAvailableEquipment()
 {
 // Arrange
 var equipmentListPanel = mainWindow.FindFirstDescendant(cf => cf.ByAutomationId("EquipmentListPanel"));
 equipmentListPanel.Should().NotBeNull("Equipment list panel should be present");

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 // Act
 var equipmentItems = equipmentListPanel.FindAllDescendants(cf => cf.ByControlType(ControlType.ListItem));
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 // Assert
 equipmentItems.Should().NotBeEmpty("Equipment list should contain items");
 equipmentItems.Length.Should().BeGreaterThan(0);
 }

 [Fact]
 public void SelectEquipment_ShouldUpdate3DView()
 {
 // Arrange
 var equipmentList = mainWindow.FindFirstDescendant(cf => cf.ByAutomationId("EquipmentList"));
 var firstEquipment = equipmentList.FindFirstDescendant(cf => cf.ByControlType(ControlType.ListItem));
 var equipment3DView = mainWindow.FindFirstDescendant(cf => cf.ByAutomationId("Equipment3DView"));

 // Act
 firstEquipment.Click();
 Wait.UntilInputIsProcessed(); // UI 업데이트 대기

 // Assert
 equipment3DView.IsEnabled.Should().BeTrue();

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 // 3D 뷰에 장비 모델이 로드되었는지 확인
 var viewport = equipment3DView.FindFirstDescendant(cf => cf.ByControlType(ControlType.Custom));
 viewport.Should().NotBeNull("3D viewport should be loaded");
 }
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 [Fact]
 public void TemperatureGauge_ShouldDisplayCurrentValue()
 {
 // Arrange
 var temperatureGauge = mainWindow.FindFirstDescendant(cf => cf.ByAutomationId("TemperatureGauge"));
 temperatureGauge.Should().NotBeNull("Temperature gauge should be present");

 // Act
 var valueText = temperatureGauge.FindFirstDescendant(cf => cf.ByControlType(ControlType.Text));

 // Assert
 valueText.Should().NotBeNull("Temperature value should be displayed");
 double.TryParse(valueText.Name, out var temperature).Should().BeTrue("Temperature should be a valid number");
 temperature.Should().BeGreaterThan(0, "Temperature should be a positive value");
 }

 [Fact]
 public void StartProcess_ShouldShowConfirmationDialog()
 {
 // Arrange
 var startProcessButton = mainWindow.FindFirstDescendant(cf => cf.ByAutomationId("StartProcessButton"));
 startProcessButton.Should().NotBeNull("Start process button should be present");

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 // Act
 startProcessButton.Click();
 Wait.UntilInputIsProcessed();
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 // Assert
 var confirmDialog = mainWindow.ModalWindows.FirstOrDefault();
 confirmDialog.Should().NotBeNull("Confirmation dialog should appear");
 confirmDialog.Title.Should().Contain("공정 시작", "Dialog should have correct title");

 // Cleanup - 다이얼로그 닫기
 var cancelButton = confirmDialog.FindFirstDescendant(cf => cf.ByName("취소"));
 cancelButton?.Click();
 }

 [Fact]
 public void AlarmPanel_ShouldDisplayActiveAlarms()
 {
 // Arrange
 var alarmPanel = mainWindow.FindFirstDescendant(cf => cf.ByAutomationId("AlarmPanel"));
 alarmPanel.Should().NotBeNull("Alarm panel should be present");

 // Act
 var alarmItems = alarmPanel.FindAllDescendants(cf => cf.ByControlType(ControlType.DataItem));

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 // Assert
 // 테스트 환경에서는 알람이 없을 수 있으므로 패널 존재만 확인
 alarmPanel.IsEnabled.Should().BeTrue("Alarm panel should be enabled");
 }
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 [Fact]
 public void NavigationButtons_ShouldSwitchViews()
 {
 // Arrange
 var overviewButton = mainWindow.FindFirstDescendant(cf => cf.ByName("개요"));
 var processButton = mainWindow.FindFirstDescendant(cf => cf.ByName("공정 모니터링"));

 overviewButton.Should().NotBeNull("Overview button should be present");
 processButton.Should().NotBeNull("Process monitoring button should be present");

 // Act - 공정 모니터링 버튼 클릭
 processButton.Click();
 Wait.UntilInputIsProcessed();

 // Assert
 var processMonitoringPanel = mainWindow.FindFirstDescendant(cf => cf.ByAutomationId("ProcessMonitoringPanel"));
 processMonitoringPanel.Should().NotBeNull("Process monitoring panel should be displayed");

 // Act - 개요 버튼으로 다시 전환
 overviewButton.Click();
 Wait.UntilInputIsProcessed();

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 // Assert
 var overviewPanel = mainWindow.FindFirstDescendant(cf => cf.ByAutomationId("OverviewPanel"));
 overviewPanel.Should().NotBeNull("Overview panel should be displayed");
 }
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 [Fact]
 public void ThemeToggle_ShouldSwitchBetweenLightAndDark()
 {
 // Arrange
 var themeToggle = mainWindow.FindFirstDescendant(cf => cf.ByAutomationId("ThemeToggle"));
 themeToggle.Should().NotBeNull("Theme toggle should be present");

 var originalState = themeToggle.IsToggled;

 // Act
 themeToggle.Click();
 Wait.UntilInputIsProcessed(TimeSpan.FromMilliseconds(500)); // 테마 전환 애니메이션 대기

 // Assert
 themeToggle.IsToggled.Should().Be(!originalState, "Theme toggle state should change");

 // 테마가 실제로 변경되었는지 확인 (배경색 확인)
 var mainGrid = mainWindow.FindFirstDescendant(cf => cf.ByControlType(ControlType.Pane));
 mainGrid.Should().NotBeNull("Main grid should be accessible");
 }

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 [Fact]
 public void RealTimeChart_ShouldUpdateWithNewData()
 {
 // Arrange
 var chartArea = mainWindow.FindFirstDescendant(cf => cf.ByAutomationId("RealTimeChart"));
 chartArea.Should().NotBeNull("Real-time chart should be present");
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 // Act - 데이터 업데이트를 위해 잠시 대기
 Thread.Sleep(2000);

 // Assert
 // 차트가 실제로 렌더링되고 있는지 확인
 chartArea.IsEnabled.Should().BeTrue("Chart should be enabled and updating");

 var chartElements = chartArea.FindAllDescendants(cf => cf.ByControlType(ControlType.Custom));
 chartElements.Should().NotBeEmpty("Chart should contain visual elements");
 }

 public void Dispose()
 {
 mainWindow?.Close();
 application?.Dispose();
 automation?.Dispose();
 }
 }
}
```
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
</div>

**배경 설명**

반도체 HMI의 대시보드는 장비 목록, 3D 뷰, 센서 게이지, 알람 패널 등 다양한 UI 요소로 구성됩니다. 각 요소의 동작을 개별적으로 테스트하여 버튼 클릭, 데이터 업데이트, 네비게이션 전환 등이 정상 작동하는지 검증합니다.

**핵심 개념**

FlaUI의 FindFirstDescendant()는 UI 트리를 탐색하여 AutomationId로 요소를 찾고, Click()으로 버튼을 조작합니다. ModalWindows로 다이얼로그를 감지하고, IsEnabled, IsToggled로 상태를 확인합니다. Wait.UntilInputIsProcessed()는 UI 스레드가 입력을 처리할 때까지 대기하여 안정적인 테스트를 보장합니다.

**코드 해설**

- Line 74: `--test-mode`로 테스트 데이터 로드, 실제 하드웨어 비활성화
- Line 78: Retry.WhileEmpty()로 10초간 윈도우 로드 대기, UI 초기화 시간 고려
- Line 95: ByAutomationId()로 XAML의 `x:Name="EquipmentListPanel"` 요소 찾기
- Line 115: Click()으로 ListItem 선택, UI 이벤트 트리거
- Line 150-156: ModalWindows로 다이얼로그 감지, Contain()으로 제목 검증

**실제 사례**

Lam Research Fab에서는 Etcher HMI의 온도 게이지가 실시간으로 업데이트되는지 테스트합니다. 2초 간격으로 150-180°C 범위의 센서 데이터를 UI에 표시하고, FlaUI가 TextBox의 값 변화를 감지하여 업데이트 주기를 검증합니다. 테마 토글 시 Dark/Light 모드 전환을 500ms 이내에 완료해야 합니다.

**Week 1 HCI 이론 연결**

Hick-Hyman의 법칙에 따라 네비게이션 버튼은 2-3개로 제한하여 선택 시간을 단축합니다. 테스트는 버튼 클릭 후 패널 전환이 즉시 발생하는지 검증하여 응답성을 보장합니다. 색상 대비(다크/라이트 모드)는 WCAG 2.1 기준(4.5:1)을 충족해야 합니다.

```mermaid
sequenceDiagram
    participant Test as UI 테스트
    participant FlaUI as FlaUI
    participant WPF as WPF 앱
    participant UI as UI 요소

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
    Test->>FlaUI: Application.Launch("HMI.exe")
    FlaUI->>WPF: 프로세스 시작
    WPF-->>FlaUI: MainWindow
    FlaUI->>Test: Window 객체 반환

    Test->>FlaUI: FindFirstDescendant("StartProcessButton")
    FlaUI->>WPF: AutomationId 검색
    WPF-->>FlaUI: Button 요소
    FlaUI->>Test: Button 객체

    Test->>FlaUI: Button.Click()
    FlaUI->>UI: UI Automation 이벤트
    UI->>WPF: ButtonClick 이벤트
    WPF->>WPF: 다이얼로그 표시
    WPF-->>FlaUI: ModalWindow

    Test->>FlaUI: ModalWindows.FirstOrDefault()
    FlaUI-->>Test: Dialog 객체
    Test->>Test: 다이얼로그 제목 검증
```

### Page Object Model 구현

<div class="code-section">

**MainDashboardPage.cs**
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
```csharp
public class MainDashboardPage : PageBase
{
 public MainDashboardPage(Window window) : base(window) { }

 // UI 요소들
 public Button StartProcessButton => Window.FindFirstDescendant(cf => cf.ByAutomationId("StartProcessButton"))?.AsButton();
 public Button StopProcessButton => Window.FindFirstDescendant(cf => cf.ByAutomationId("StopProcessButton"))?.AsButton();
 public ListBox EquipmentList => Window.FindFirstDescendant(cf => cf.ByAutomationId("EquipmentList"))?.AsListBox();
 public TextBox TemperatureValue => Window.FindFirstDescendant(cf => cf.ByAutomationId("TemperatureValue"))?.AsTextBox();
 public ProgressBar ProcessProgress => Window.FindFirstDescendant(cf => cf.ByAutomationId("ProcessProgress"))?.AsProgressBar();

 // 페이지 액션들
 public void SelectEquipment(string equipmentId)
 {
 var equipmentItem = EquipmentList.Items.FirstOrDefault(item =>
 item.Name.Contains(equipmentId));

 equipmentItem?.Select();
 Wait.UntilInputIsProcessed();
 }

 public void StartProcess(ProcessParameters parameters)
 {
 StartProcessButton.Click();

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 var dialog = Window.ModalWindows.FirstOrDefault();
 if (dialog != null)
 {
 var parametersPage = new ProcessParametersDialog(dialog);
 parametersPage.SetParameters(parameters);
 parametersPage.Confirm();
 }
 }

 public double GetCurrentTemperature()
 {
 var tempText = TemperatureValue.Text;
 return double.TryParse(tempText, out var temp) ? temp : 0;
 }

 public bool IsProcessRunning()
 {
 return ProcessProgress.Value > 0 && StartProcessButton.IsEnabled == false;
 }
}
```
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
</div>

**배경 설명**

UI 테스트 코드가 반복적인 FindFirstDescendant() 호출로 복잡해지면 유지보수가 어려워집니다. Page Object Model(POM)은 각 화면을 클래스로 캡슐화하여 UI 요소와 액션을 재사용 가능한 메서드로 정의하고, 테스트 코드를 간결하게 유지합니다.

**핵심 개념**

POM은 UI 요소를 프로퍼티로, 사용자 액션을 메서드로 정의하는 디자인 패턴입니다. PageBase 추상 클래스를 상속하여 공통 기능을 재사용하고, 각 페이지는 해당 화면의 요소와 동작만 관리합니다. 테스트는 페이지 객체의 메서드를 호출하여 복잡한 UI 조작을 단순화합니다.

**코드 해설**

- Line 312-321: 프로퍼티로 UI 요소 정의, `AsButton()`, `AsListBox()`로 타입 변환
- Line 324-331: SelectEquipment() 메서드로 장비 선택 로직 캡슐화
- Line 333-344: StartProcess()로 버튼 클릭 + 다이얼로그 처리를 한 메서드로 통합
- Line 346-350: GetCurrentTemperature()로 센서 값 파싱 로직 재사용
- Line 352-355: IsProcessRunning()으로 복잡한 상태 판단 로직 추상화

**실제 사례**

Tokyo Electron Fab에서는 CVD HMI의 5개 화면(Dashboard, Process, Recipe, Alarm, Settings)을 각각 POM 클래스로 관리합니다. 100개 이상의 테스트가 이 클래스를 재사용하며, UI 변경 시 페이지 클래스만 수정하면 되어 유지보수 시간을 70% 단축했습니다.

**Week 1 HCI 이론 연결**

정보 아키텍처 원칙에 따라 POM은 UI를 논리적 단위(페이지)로 그룹화하여 인지 부하를 줄입니다. 메서드 이름(SelectEquipment, StartProcess)은 사용자의 멘탈 모델과 일치하여 테스트 의도를 명확히 전달합니다.

```mermaid
classDiagram
    class PageBase {
        +Window Window
        +PageBase(Window window)
    }
    class MainDashboardPage {
        +Button StartProcessButton
        +Button StopProcessButton
        +ListBox EquipmentList
        +TextBox TemperatureValue
        +SelectEquipment(equipmentId)
        +StartProcess(parameters)
        +GetCurrentTemperature()
        +IsProcessRunning()
    }
    class ProcessParametersDialog {
        +TextBox TemperatureInput
        +TextBox PressureInput
        +Button ConfirmButton
        +SetParameters(parameters)
        +Confirm()
    }
    PageBase <|-- MainDashboardPage
    PageBase <|-- ProcessParametersDialog
    MainDashboardPage --> ProcessParametersDialog: uses
```

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
## 성능 테스트 (NBomber)

### 부하 테스트 시나리오

<div class="code-section">

**SemiconductorHMI.PerformanceTests.csproj**
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
```xml
<Project Sdk="Microsoft.NET.Sdk">

 <PropertyGroup>
 <TargetFramework>net6.0</TargetFramework>
 <ImplicitUsings>enable</ImplicitUsings>
 <Nullable>enable</Nullable>
 <IsPackable>false</IsPackable>
 </PropertyGroup>

 <ItemGroup>
 <PackageReference Include="Microsoft.NET.Test.Sdk" Version="17.3.2" />
 <PackageReference Include="NBomber" Version="4.1.2" />
 <PackageReference Include="NBomber.Http" Version="4.1.2" />
 <PackageReference Include="Serilog.Sinks.Console" Version="4.1.0" />
 </ItemGroup>

</Project>
```

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
</div>

<div class="code-section">

**EquipmentAPIPerformanceTests.cs**

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
```csharp
using NBomber.CSharp;
using NBomber.Http.CSharp;
using Serilog;

namespace SemiconductorHMI.PerformanceTests
{
 public class EquipmentAPIPerformanceTests
 {
 private const string BaseUrl = "https://localhost:7001";

 [Fact]
 public void Equipment_API_LoadTest()
 {
 // 시나리오 1: 장비 상태 조회 (높은 빈도)
 var equipmentStatusScenario = Scenario.Create("equipment_status", async context =>
 {
 var equipmentId = GetRandomEquipmentId();

 var response = await HttpClientFactory.Create()
 .GetAsync($"{BaseUrl}/api/equipment/{equipmentId}/status");

 return response.IsSuccessStatusCode ? Response.Ok() : Response.Fail();
 })
 .WithLoadSimulations(
 Simulation.InjectPerSec(rate: 100, during: TimeSpan.FromMinutes(5))
 );

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 // 시나리오 2: 센서 데이터 저장 (중간 빈도)
 var sensorDataScenario = Scenario.Create("sensor_data_save", async context =>
 {
 var sensorData = GenerateSensorData();
 var jsonContent = JsonContent.Create(sensorData);

 var response = await HttpClientFactory.Create()
 .PostAsync($"{BaseUrl}/api/sensor-data", jsonContent);

 return response.IsSuccessStatusCode ? Response.Ok() : Response.Fail();
 })
 .WithLoadSimulations(
 Simulation.InjectPerSec(rate: 50, during: TimeSpan.FromMinutes(5))
 );

 // 시나리오 3: 프로세스 시작 (낮은 빈도, 높은 리소스 사용)
 var processStartScenario = Scenario.Create("process_start", async context =>
 {
 var processRequest = GenerateProcessRequest();
 var jsonContent = JsonContent.Create(processRequest);
 var equipmentId = GetRandomEquipmentId();

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 var response = await HttpClientFactory.Create()
 .PostAsync($"{BaseUrl}/api/equipment/{equipmentId}/start-process", jsonContent);
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 return response.IsSuccessStatusCode ? Response.Ok() : Response.Fail();
 })
 .WithLoadSimulations(
 Simulation.InjectPerSec(rate: 5, during: TimeSpan.FromMinutes(5))
 );

 // 성능 테스트 실행
 var stats = NBomberRunner
 .RegisterScenarios(equipmentStatusScenario, sensorDataScenario, processStartScenario)
 .WithReportFolder("performance_reports")
 .WithReportFormats(ReportFormat.Html, ReportFormat.Csv, ReportFormat.Json)
 .Run();

 // 성능 기준 검증
 ValidatePerformanceRequirements(stats);
 }

 [Fact]
 public void Database_Connection_StressTest()
 {
 var dbStressScenario = Scenario.Create("database_stress", async context =>
 {
 var equipmentId = GetRandomEquipmentId();
 var startDate = DateTime.UtcNow.AddHours(-1);
 var endDate = DateTime.UtcNow;

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 var response = await HttpClientFactory.Create()
 .GetAsync($"{BaseUrl}/api/equipment/{equipmentId}/sensor-data?" +
 $"startDate={startDate:yyyy-MM-ddTHH:mm:ss}&" +
 $"endDate={endDate:yyyy-MM-ddTHH:mm:ss}");

 return response.IsSuccessStatusCode ? Response.Ok() : Response.Fail();
 })
 .WithLoadSimulations(
 // 점진적 부하 증가
 Simulation.RampingInject(rate: 200, interval: TimeSpan.FromSeconds(1), during: TimeSpan.FromMinutes(10))
 );

 var stats = NBomberRunner
 .RegisterScenarios(dbStressScenario)
 .WithReportFolder("db_stress_reports")
 .Run();

 // 데이터베이스 성능 검증
 stats.AllOkCount.Should().BeGreaterThan(0);
 stats.AllFailCount.Should().BeLessThan(stats.AllOkCount * 0.01); // 1% 미만 실패율
 }

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 [Fact]
 public void RealTime_Updates_PerformanceTest()
 {
 // SignalR 연결 성능 테스트
 var signalRScenario = Scenario.Create("signalr_updates", async context =>
 {
 // SignalR 허브 연결 및 실시간 업데이트 구독
 var hubConnection = new HubConnectionBuilder()
 .WithUrl($"{BaseUrl}/equipmentHub")
 .Build();
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 await hubConnection.StartAsync();

 // 실시간 업데이트 수신 대기
 var updateReceived = new TaskCompletionSource<bool>();
 hubConnection.On<EquipmentStatus>("EquipmentStatusUpdate", (status) =>
 {
 updateReceived.SetResult(true);
 });

 // 업데이트 트리거
 await hubConnection.InvokeAsync("RequestEquipmentUpdate", GetRandomEquipmentId());

 // 업데이트 수신 대기 (최대 5초)
 var completed = await Task.WhenAny(
 updateReceived.Task,
 Task.Delay(TimeSpan.FromSeconds(5))
 );

 await hubConnection.DisposeAsync();

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 return completed == updateReceived.Task ? Response.Ok() : Response.Fail();
 })
 .WithLoadSimulations(
 Simulation.KeepConstant(copies: 50, during: TimeSpan.FromMinutes(3))
 );
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 var stats = NBomberRunner
 .RegisterScenarios(signalRScenario)
 .WithReportFolder("realtime_reports")
 .Run();

 // 실시간 업데이트 성능 검증
 var avgResponseTime = stats.ScenarioStats[0].Ok.Response.Mean;
 avgResponseTime.Should().BeLessThan(100); // 100ms 미만 응답시간
 }

 private void ValidatePerformanceRequirements(NBomberStats stats)
 {
 foreach (var scenarioStats in stats.ScenarioStats)
 {
 switch (scenarioStats.ScenarioName)
 {
 case "equipment_status":
 // 장비 상태 조회: 95% 요청이 50ms 미만
 scenarioStats.Ok.Response.Percentile95.Should().BeLessThan(50);
 // 처리량: 초당 95개 이상
 scenarioStats.Ok.Request.RPS.Should().BeGreaterThan(95);
 break;

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 case "sensor_data_save":
 // 센서 데이터 저장: 95% 요청이 100ms 미만
 scenarioStats.Ok.Response.Percentile95.Should().BeLessThan(100);
 // 실패율: 1% 미만
 scenarioStats.Fail.Request.Percent.Should().BeLessThan(1);
 break;

 case "process_start":
 // 프로세스 시작: 95% 요청이 500ms 미만
 scenarioStats.Ok.Response.Percentile95.Should().BeLessThan(500);
 // 실패율: 0.1% 미만
 scenarioStats.Fail.Request.Percent.Should().BeLessThan(0.1);
 break;
 }
 }

 // 전체 시스템 안정성
 stats.AllFailCount.Should().BeLessThan(stats.AllOkCount * 0.01);
 }

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 private string GetRandomEquipmentId()
 {
 var equipmentIds = new[] { "CVD-001", "CVD-002", "PVD-001", "ETCH-001", "CMP-001" };
 return equipmentIds[Random.Shared.Next(equipmentIds.Length)];
 }
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 private object GenerateSensorData()
 {
 return new
 {
 EquipmentId = GetRandomEquipmentId(),
 SensorType = "Temperature",
 Value = Random.Shared.NextDouble() * 200 + 50, // 50-250도
 Timestamp = DateTime.UtcNow,
 Unit = "°C"
 };
 }

 private object GenerateProcessRequest()
 {
 return new
 {
 TargetTemperature = Random.Shared.NextDouble() * 100 + 100, // 100-200도
 PressureSetpoint = Random.Shared.NextDouble() * 2 + 0.5, // 0.5-2.5 Torr
 Duration = TimeSpan.FromMinutes(Random.Shared.Next(15, 61)), // 15-60분
 ProcessType = "StandardCVD"
 };
 }
 }
}
```
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
</div>

### 메모리 및 CPU 프로파일링

<div class="code-section">

**MemoryProfileTests.cs**

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
```csharp
public class MemoryProfileTests
{
 [Fact]
 public void LongRunning_SensorDataCollection_ShouldNotLeakMemory()
 {
 // Arrange
 var initialMemory = GC.GetTotalMemory(true);
 var dataCollector = new SensorDataCollector();
 var memoryUsages = new List<long>();

 // Act - 1시간 동안 데이터 수집 시뮬레이션
 for (int i = 0; i < 3600; i++) // 1초마다 수집
 {
 var sensorData = GenerateRandomSensorData();
 dataCollector.CollectData(sensorData);

 // 10초마다 메모리 사용량 기록
 if (i % 10 == 0)
 {
 memoryUsages.Add(GC.GetTotalMemory(false));
 }

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 Thread.Sleep(1); // 빠른 시뮬레이션
 }

 // Force garbage collection
 GC.Collect();
 GC.WaitForPendingFinalizers();
 GC.Collect();

 var finalMemory = GC.GetTotalMemory(false);

 // Assert
 // 메모리 사용량이 초기 대비 200% 이상 증가하지 않아야 함
 var memoryIncrease = (double)(finalMemory - initialMemory) / initialMemory;
 memoryIncrease.Should().BeLessThan(2.0, "Memory usage should not increase more than 200%");

 // 메모리 사용량이 지속적으로 증가하지 않아야 함
 var recentMemoryUsages = memoryUsages.TakeLast(10).ToList();
 var memoryTrend = CalculateLinearTrend(recentMemoryUsages);
 memoryTrend.Should().BeLessThan(1000, "Memory should not show consistent upward trend");
 }

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 [Fact]
 public void HighFrequency_UIUpdates_ShouldMaintainResponsiveness()
 {
 // UI 업데이트 성능 테스트
 var uiUpdateTimes = new List<TimeSpan>();
 var stopwatch = new Stopwatch();
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 for (int i = 0; i < 1000; i++)
 {
 stopwatch.Restart();

 // UI 업데이트 시뮬레이션
 Application.Current.Dispatcher.Invoke(() =>
 {
 // 화면 업데이트 로직
 UpdateTemperatureGauge(Random.Shared.NextDouble() * 200);
 UpdatePressureChart(Random.Shared.NextDouble() * 5);
 });

 stopwatch.Stop();
 uiUpdateTimes.Add(stopwatch.Elapsed);
 }

 // Assert
 var averageUpdateTime = uiUpdateTimes.Average(t => t.TotalMilliseconds);
 var p95UpdateTime = uiUpdateTimes.OrderBy(t => t).Skip(950).First().TotalMilliseconds;

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 averageUpdateTime.Should().BeLessThan(16, "Average UI update should be under 16ms (60 FPS)");
 p95UpdateTime.Should().BeLessThan(33, "95% of UI updates should be under 33ms (30 FPS)");
 }

 private double CalculateLinearTrend(List<long> values)
 {
 if (values.Count < 2) return 0;
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
 var n = values.Count;
 var sumX = Enumerable.Range(0, n).Sum();
 var sumY = values.Sum();
 var sumXY = values.Select((y, x) => (long)x * y).Sum();
 var sumX2 = Enumerable.Range(0, n).Sum(x => x * x);

 return (double)(n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
 }
}
```
---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
</div>

**배경 설명**

반도체 Fab의 HMI는 여러 장비에서 동시에 센서 데이터를 수집하고 처리하며, 부하가 높을 때 응답 지연이나 시스템 다운이 발생할 수 있습니다. 성능 테스트는 높은 동시 사용자 수와 대량 데이터 처리 상황을 시뮬레이션하여 시스템의 처리량, 응답 시간, 안정성을 검증합니다.

**핵심 개념**

NBomber는 .NET 기반 부하 테스트 프레임워크로, Scenario와 Step으로 사용자 행동을 정의합니다. LoadSimulation으로 동시 사용자 수를 제어하고, RampingConstant로 점진적으로 부하를 증가시킵니다. Response.Ok()와 Response.Fail()로 요청 성공/실패를 기록하고, NBomberStats로 성능 지표(RPS, 응답 시간, Percentile)를 수집합니다.

**코드 해설**

- Line 615-617: SignalR HubConnection으로 실시간 WebSocket 연결 생성
- Line 623-626: `On<T>()` 이벤트 핸들러로 서버 푸시 메시지 수신, TaskCompletionSource로 비동기 대기
- Line 632-635: Task.WhenAny()로 업데이트 수신 또는 5초 타임아웃 처리
- Line 641-643: KeepConstant(50 copies, 3분)로 50명 동시 사용자 시뮬레이션
- Line 655-677: ValidatePerformanceRequirements()로 시나리오별 성능 기준 검증 (95% Percentile <50ms)

**실제 사례**

SMIC Fab에서는 100대의 CMP 장비가 동시에 센서 데이터를 전송하는 상황을 NBomber로 테스트합니다. 초당 1,000건의 센서 데이터 저장 요청을 3시간 동안 유지하며, 95% 요청의 응답 시간이 100ms 이하, 실패율 1% 미만을 요구합니다. 메모리 누수는 시간당 증가율 5MB 이하로 제한합니다.

**Week 1 HCI 이론 연결**

Response Time Guidelines(Nielsen, 1993)에 따라 0.1초 이내는 즉각적, 1초 이내는 수용 가능, 10초 이상은 사용자 불만을 유발합니다. 성능 테스트는 장비 상태 조회 50ms, 센서 데이터 저장 100ms, 프로세스 시작 500ms 기준을 검증하여 우수한 사용자 경험을 보장합니다.

```mermaid
graph TD
    A[성능 테스트 시작] --> B[Scenario 정의]
    B --> C{LoadSimulation}
    C --> D1[RampingConstant: 0→100 users]
    C --> D2[KeepConstant: 50 users]
    C --> D3[InjectPerSec: 100 req/s]

---
# 심화 실습: UI 자동화 테스트 및 성능 테스트
    D1 --> E[Step 실행]
    D2 --> E
    D3 --> E

    E --> F[HTTP 요청]
    F --> G{응답?}
    G -->|Success| H[Response.Ok]
    G -->|Failure| I[Response.Fail]

    H --> J[통계 수집]
    I --> J

    J --> K[NBomberStats]
    K --> L{성능 검증}
    L --> M1[RPS > 95?]
    L --> M2[P95 < 50ms?]
    L --> M3[실패율 < 1%?]

    M1 --> N{모두 통과?}
    M2 --> N
    M3 --> N
    N -->|Yes| O[테스트 성공]
    N -->|No| P[성능 최적화 필요]

    style O fill:#90EE90
    style P fill:#FFB6C1
```