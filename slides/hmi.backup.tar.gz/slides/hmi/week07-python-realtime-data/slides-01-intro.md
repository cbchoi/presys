# Week 7: Python 실시간 데이터 처리

## 실시간 데이터 처리의 핵심

### 배경: 왜 실시간 처리가 필요한가?

**문제 상황**:
반도체 제조 공정에서는 초당 수백~수천 개의 센서 데이터가 발생하며, 이를 실시간으로 모니터링하지 않으면 불량품 발생이나 장비 손상으로 이어질 수 있습니다. 예를 들어 CVD 장비의 챔버 온도가 허용 범위를 벗어나면 즉시(250ms 이내) 대응해야 합니다.

**해결책**:
PySide6의 멀티스레드 기반 비동기 처리를 통해 UI 응답성을 유지하면서 대량의 실시간 데이터를 처리하고 저장합니다.

### 핵심 개념

**실시간 데이터 처리의 3대 요소**:

1. **데이터 수집 (Collection)**: 센서/장비로부터 지속적인 데이터 획득
2. **데이터 처리 (Processing)**: 유효성 검증, 변환, 분석
3. **데이터 저장/시각화 (Persistence/Visualization)**: DB 저장 및 실시간 차트 표시

**동작 원리**:
- **UI 스레드**: 사용자 입력과 화면 업데이트만 처리 (60fps 유지)
- **백그라운드 스레드**: 데이터 수집, DB 저장 등 무거운 작업 수행
- **Signal/Slot**: 스레드 간 안전한 데이터 전달

---

### 시스템 아키텍처
```mermaid
sequenceDiagram
    participant User as 사용자
    participant UI as UI Thread
    participant BG as Background Thread
    participant Data as 데이터베이스

    User->>UI: 모니터링 시작
    UI->>BG: 데이터 수집 요청
    BG->>Data: 데이터 저장
    Data-->>BG: 저장 완료
    BG->>UI: Signal로 UI 업데이트
    UI->>User: 차트 표시
```

---

### 실습 과제 개요 (1/2)

**학습 목표**:

1. **실습 1: 실시간 데이터 수집**
   - Serial 통신으로 센서 데이터 수집
   - 요구사항: 초당 20개 이상 데이터 수집
   - 실제 사례: SQLite에 1000 rows/s 저장

2. **실습 2: 멀티스레드 데이터 처리**
   - SQLite Batch INSERT (1000 rows/s)
   - 요구사항: 코드 블록 30줄 이하
   - 실제 사례: CVD 장비의 SQLite 버퍼링
---
### 실습 과제 개요 (2/2)

3. **실습 3: 실시간 차트 시각화**
   - PyQtGraph로 QChart 구현 (100ms 업데이트)
   - 성능 지표: 메시지 처리율(msg/s), DB INSERT(rows/s), 응답시간(ms)
   - 목표 성능: >1000 msg/s, INSERT >500 rows/s, 응답시간 <100ms

**핵심 체크포인트**:
- [ ] 멀티스레드로 UI 블로킹 없이 데이터 수집
- [ ] SQLite 트랜잭션으로 안정적 데이터 저장
- [ ] 차트가 60fps 이상 부드럽게 업데이트

**핵심 기술**:
- **PySide6 QThread**: QThread로 UI 블로킹 방지
- **데이터베이스 연동**: Serial/TCP 통신
- **차트 라이브러리**: SQLite 트랜잭션 처리
- **성능 최적화**: PyQtGraph 실시간 차트

---

### Week 1 HCI 이론 적용

**정보처리 모델 (Information Processing Model)**:
인간의 정보 처리는 **250ms** 이내에 시각 피드백이 있어야 자연스럽게 느껴집니다. 따라서 실시간 HMI는 100ms 이내로 데이터를 업데이트하여 조작감을 높입니다.

**반도체 장비 적용 사례**:
- **CVD 챔버 온도 모니터링**: 100ms 간격으로 차트 업데이트 → 운영자가 실시간으로 온도 변화 감지
- **압력 이상 알람**: 임계값 초과 시 40ms 이내 경고 표시 → 즉각적인 대응 가능

### 실시간 데이터 흐름도

```mermaid
flowchart TD
    A[센서/장비] -->|Serial/TCP| B[데이터 수집 스레드]
    B -->|Signal| C[데이터 검증]
    C -->|유효한 데이터| D[DB 저장 스레드]
    C -->|유효한 데이터| E[UI 업데이트 스레드]
    D -->|SQLite| F[(데이터베이스)]
    E -->|60fps| G[실시간 차트]
    E -->|60fps| H[통계 정보]

    style A fill:#e1f5ff
    style B fill:#fff4e1
    style D fill:#ffe1e1
    style E fill:#e1ffe1
    style G fill:#f0e1ff
```

---

## 1⃣ 기초 이론
### **PySide6 멀티스레딩 기초**

#### **1.1 Qt Threading **

<div class="concept-explanation">

** Qt **:
- ** (GUI )**: UI
- ** **:
- ** **: -

** **:
- GUI
- - -

</div>

##### **1.1.1 QThread vs Threading **

```python
