---
layout: cover
---

# Week 13: ImGUI C++ 통합 프로젝트
## 이론 강의

엔터프라이즈 시스템 아키텍처 및 DevOps

---
## 1️⃣ 엔터프라이즈 아키텍처 패턴

### ️ Monolithic vs Microservices 아키텍처

<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem; margin: 2rem 0;">

<div style="background: #f0f4ff; padding: 1.5rem; border-radius: 8px;">

#### **Monolithic Architecture**

**특징:**
- 단일 배포 단위
- 단순한 개발/배포 프로세스
- 강한 데이터 일관성
- 직접 함수 호출

**장점:**
- 개발 초기 빠른 구현
- 간단한 테스트 및 디버깅
- 낮은 운영 복잡도
- 트랜잭션 관리 용이

---
## 1️⃣ 엔터프라이즈 아키텍처 패턴
**단점:**
- 확장성 제한
- 기술 스택 고정
- 배포 위험 증가
- 큰 코드베이스 관리 어려움

</div>

<div style="background: #f0fff4; padding: 1.5rem; border-radius: 8px;">

#### **Microservices Architecture**

**특징:**
- 독립적인 서비스 단위
- 서비스별 배포
- 느슨한 결합
- API 기반 통신

---
## 1️⃣ 엔터프라이즈 아키텍처 패턴
**장점:**
- 독립적 확장 가능
- 기술 다양성
- 장애 격리
- 팀 자율성 향상

**단점:**
- 운영 복잡도 증가
- 분산 시스템 문제
- 데이터 일관성 관리
- 네트워크 레이턴시

</div>

</div>

**산업용 HMI 선택 기준:**

| 요구사항 | 권장 아키텍처 | 이유 |
|---------|--------------|------|
---
## 1️⃣ 엔터프라이즈 아키텍처 패턴
| 단일 장비 모니터링 | Monolithic | 단순성, 낮은 레이턴시 |
| 팹 레벨 통합 시스템 | Microservices | 확장성, 장애 격리 |
| 중소규모 라인 | Modular Monolith | 균형잡힌 접근 |
| 클라우드 기반 | Microservices | 클라우드 네이티브 이점 |
---
### Event-Driven Architecture (EDA)

#### **EDA 핵심 개념**

```
┌─────────────┐ Event ┌──────────────┐ Event ┌─────────────┐
│ Producer │ ──────────────> │ Event Broker │ ──────────────> │ Consumer │
│ (장비센서) │ │ (Message │ │ (UI 업데이트)│
└─────────────┘ │ Queue) │ └─────────────┘
 └──────────────┘
 ↓
 Event Store
 (이벤트 이력)
```

**주요 패턴:**

1. **Event Notification**
---
### Event-Driven Architecture (EDA)
 - 단순 알림 전달
 - 최소 데이터 포함
 - 예: "장비 상태 변경됨"

2. **Event-Carried State Transfer**
 - 전체 상태 정보 포함
 - Consumer 자율성 향상
 - 예: 전체 장비 상태 스냅샷

3. **Event Sourcing**
 - 모든 변경사항을 이벤트로 저장
 - 완전한 감사 추적
 - 시점별 상태 재구성 가능

**실시간 HMI 적용:**

---
### Event-Driven Architecture (EDA)
```cpp
// Event-Driven HMI Architecture
class EquipmentEventBus {
public:
 // 이벤트 발행
 void PublishEvent(const EquipmentEvent& event) {
 for (auto& handler : subscribers_[event.type]) {
 handler(event);
 }
 event_store_.Store(event); // Event Sourcing
 }

 // 구독 등록
 void Subscribe(EventType type, EventHandler handler) {
 subscribers_[type].push_back(handler);
 }

 // 과거 이벤트 재생
 std::vector<EquipmentEvent> ReplayEvents(TimePoint from, TimePoint to) {
 return event_store_.Query(from, to);
 }
};
```

---
### Event-Driven Architecture (EDA)
**장점:**
- 느슨한 결합
- 비동기 처리
- 확장 용이
- 완벽한 감사 추적
---
### CQRS (Command Query Responsibility Segregation)

#### **CQRS 패턴 개요**

---
### CQRS (Command Query Responsibility Segregation)
```
 ┌─────────────────┐
 │ Application │
 └────────┬────────┘
 │
 ┌───────────────┴────────────────┐
 │ │
 Commands Queries
 │ │
 ┌─────────▼─────────┐ ┌─────────▼─────────┐
 │ Write Model │ │ Read Model │
 │ (정규화된 DB) │ Sync │ (비정규화 DB) │
 │ - 트랜잭션 보장 │ ───────> │ - 빠른 조회 │
 │ - 비즈니스 로직 │ │ - 뷰 최적화 │
 └───────────────────┘ └───────────────────┘
```

---
### CQRS (Command Query Responsibility Segregation)
**실제 구현:**

---
### CQRS (Command Query Responsibility Segregation)
```cpp
// Command Side (쓰기)
class SetTemperatureCommand {
 EquipmentId equipment_id;
 double temperature;
 UserId user_id;
 Timestamp timestamp;
};

class EquipmentCommandHandler {
public:
 void Handle(const SetTemperatureCommand& cmd) {
 // 1. 비즈니스 규칙 검증
 ValidateTemperatureRange(cmd.temperature);

 // 2. 도메인 모델 업데이트
 auto equipment = repository_.Load(cmd.equipment_id);
 equipment.SetTemperature(cmd.temperature);

 // 3. 이벤트 발행
 PublishEvent(TemperatureChangedEvent{...});
 }
};

---
### CQRS (Command Query Responsibility Segregation)
// Query Side (읽기)
class EquipmentDashboardQuery {
public:
 struct DashboardData {
 std::vector<EquipmentSummary> equipments;
 std::map<string, double> aggregates;
 std::vector<Alert> active_alerts;
 };

 DashboardData GetDashboard(FabId fab_id) {
 // 비정규화된 읽기 전용 DB에서 조회
 return read_db_.QueryOptimizedView("dashboard", fab_id);
 }
};
```
---
### CQRS (Command Query Responsibility Segregation)
**HMI 적용 이점:**
- **쓰기**: 복잡한 비즈니스 로직, 트랜잭션 보장
- **읽기**: 초고속 대시보드 렌더링, 다양한 뷰 지원
- **독립 확장**: 읽기/쓰기 부하에 따라 별도 스케일링
---
### Domain-Driven Design (DDD)

#### **반도체 장비 도메인 모델**

---
### Domain-Driven Design (DDD)
```cpp
namespace SemiconductorDomain {

// 핵심 도메인 엔티티
class Equipment {
private:
 EquipmentId id_;
 EquipmentType type_;
 EquipmentState state_;
 std::vector<Sensor> sensors_;
 Recipe current_recipe_;

public:
 // 도메인 로직
 Result<void> StartProcess(Recipe recipe) {
 if (!CanStartProcess()) {
 return Error("Equipment not ready");
 }

 // 비즈니스 규칙 적용
 if (!recipe.IsCompatibleWith(type_)) {
 return Error("Recipe incompatible");
 }

---
### Domain-Driven Design (DDD)
 state_ = EquipmentState::PROCESSING;
 current_recipe_ = recipe;
 PublishDomainEvent(ProcessStartedEvent{...});

 return Success();
 }

 bool CanStartProcess() const {
 return state_ == EquipmentState::IDLE
 && AllSensorsHealthy()
 && NoActiveAlarms();
 }
};

// 값 객체 (Value Object)
class Temperature {
private:
 double value_;
 TemperatureUnit unit_;

---
### Domain-Driven Design (DDD)
public:
 static Result<Temperature> Create(double value, TemperatureUnit unit) {
 if (value < -273.15) {
 return Error("Temperature below absolute zero");
 }
 return Temperature(value, unit);
 }
---
### Domain-Driven Design (DDD)
 Temperature ConvertTo(TemperatureUnit target_unit) const {
 // 단위 변환 로직
 }
};

// 애그리게이트 루트
class Fab {
private:
 FabId id_;
 std::vector<std::shared_ptr<Equipment>> equipments_;
 ProductionSchedule schedule_;

public:
 Result<void> ScheduleProduction(const ProductionOrder& order) {
 // 팹 레벨 비즈니스 로직
 auto available_equipment = FindAvailableEquipment(order.recipe_type);
 if (!available_equipment) {
 return Error("No available equipment");
 }

---
### Domain-Driven Design (DDD)
 schedule_.AddOrder(order);
 return Success();
 }
};
---
### Domain-Driven Design (DDD)
// 도메인 서비스
class RecipeOptimizationService {
public:
 OptimizedRecipe OptimizeForEquipment(
 const Recipe& base_recipe,
 const Equipment& equipment
 ) {
 // 장비 특성에 맞는 레시피 최적화
 // 여러 엔티티/값 객체를 활용한 복잡한 로직
 }
};

} // namespace SemiconductorDomain
```
---
### Domain-Driven Design (DDD)
**DDD 전략적 설계:**

| Bounded Context | 책임 | 핵심 엔티티 |
|----------------|------|------------|
| Equipment Management | 장비 상태 관리 | Equipment, Sensor |
| Recipe Management | 공정 레시피 관리 | Recipe, ProcessStep |
| Production Scheduling | 생산 계획 | ProductionOrder, Schedule |
| Quality Control | 품질 관리 | Measurement, Specification |
---
## 2️⃣ 보안 아키텍처

### Zero Trust Security Model

#### **기존 보안 vs Zero Trust**

---
## 2️⃣ 보안 아키텍처
```
┌─────────────────────────────────────────────────────────┐
│ 기존 성곽 모델 (Perimeter Security) │
│ │
│ ┌──────────────────────────────────────┐ │
│ │ 신뢰 영역 (Trust Zone) │ │
│ │ ┌──────┐ ┌──────┐ ┌──────┐ │ │
│ │ │ App │──│ DB │──│ User │ │ │
│ │ └──────┘ └──────┘ └──────┘ │ │
│ └──────────────────────────────────────┘ │
│ 방화벽 (한번 통과하면 내부 신뢰) │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ Zero Trust Model │
│ │
│ ┌──────┐ 인증 ┌──────┐ 인증 ┌──────┐ │
│ │ User │────────│ App │────────│ DB │ │
│ └──────┘ 인가 └──────┘ 인가 └──────┘ │
│ │ 암호화 │ 암호화 │ │
│ └──────────────┴──────────────┘ │
│ 모든 연결마다 검증 (Never Trust, Always Verify) │
└─────────────────────────────────────────────────────────┘
```

---
## 2️⃣ 보안 아키텍처
**Zero Trust 핵심 원칙:**

1. **명시적 검증**: 모든 요청은 인증/인가 필수
2. **최소 권한**: 필요한 최소한의 접근만 허용
3. **침해 가정**: 침해가 이미 발생했다고 가정하고 설계
4. **세분화된 세그먼트**: 마이크로 세그먼테이션
5. **지속적 모니터링**: 실시간 위협 탐지

**HMI 구현:**

---
## 2️⃣ 보안 아키텍처
```cpp
class ZeroTrustAccessController {
public:
 Result<AccessToken> AuthenticateAndAuthorize(
 const Credentials& creds,
 const Resource& resource,
 const Context& context
 ) {
 // 1. 다중 인증 (MFA)
 if (!mfa_provider_.Verify(creds)) {
 LogSecurityEvent("MFA failed", creds.user_id);
 return Unauthorized();
 }

 // 2. 컨텍스트 기반 검증
 if (!ValidateContext(context)) {
 // IP, 디바이스, 시간대 등 검증
 return Forbidden("Suspicious context");
 }

 // 3. 최소 권한 확인
 auto permissions = rbac_.GetMinimalPermissions(
 creds.user_id, resource
 );

---
## 2️⃣ 보안 아키텍처
 // 4. 단기 토큰 발급 (15분)
 auto token = token_service_.IssueShortLivedToken(
 creds.user_id, permissions, 15min
 );

 // 5. 감사 로깅
 audit_log_.RecordAccess(creds.user_id, resource, token);

 return token;
 }

private:
 bool ValidateContext(const Context& ctx) {
 // 디바이스 신뢰도 확인
 if (!device_trust_.IsTrusted(ctx.device_id)) return false;

 // 지리적 위치 검증
 if (!geo_policy_.IsAllowed(ctx.ip_address)) return false;

 // 행동 분석
 if (behavior_analytics_.IsAnomaly(ctx.user_id, ctx.action)) {
 return false;
 }

 return true;
 }
};
```
---
### Role-Based Access Control (RBAC)

#### **RBAC 계층 구조**

---
### Role-Based Access Control (RBAC)
```
 ┌─────────────┐
 │ Admin │
 └──────┬──────┘
 │
 ┌────────────┼────────────┐
 │ │
 ┌─────▼──────┐ ┌───────▼────────┐
 │ Engineer │ │ Supervisor │
 └─────┬──────┘ └───────┬────────┘
 │ │
 └────────────┬───────────┘
 │
 ┌──────▼──────┐
 │ Operator │
 └─────────────┘
```

---
### Role-Based Access Control (RBAC)
**권한 매트릭스:**

| Role | 장비 조작 | 레시피 수정 | 보고서 조회 | 시스템 설정 | 사용자 관리 |
|------|----------|-----------|-----------|-----------|-----------|
| Operator | | | | | |
| Engineer | | | | ️ (제한적) | |
| Supervisor | | | | | ️ (팀만) |
| Admin | | | | | |

**구현:**

---
### Role-Based Access Control (RBAC)
```cpp
class RBACSystem {
private:
 struct Permission {
 string resource;
 string action; // read, write, execute, delete
 vector<string> conditions;
 };

 struct Role {
 string name;
 vector<Permission> permissions;
 vector<string> parent_roles; // 상속
 };

 map<UserId, vector<string>> user_roles_;
 map<string, Role> roles_;

public:
 bool HasPermission(
 UserId user_id,
 const string& resource,
 const string& action
 ) {
 auto user_roles = user_roles_[user_id];

---
### Role-Based Access Control (RBAC)
 for (const auto& role_name : user_roles) {
 auto role = roles_[role_name];

 // 직접 권한 확인
 if (HasDirectPermission(role, resource, action)) {
 return true;
 }

 // 상속된 권한 확인
 if (HasInheritedPermission(role, resource, action)) {
 return true;
 }
 }

 return false;
 }

 // 동적 권한 (시간, 컨텍스트 기반)
 bool HasTemporalPermission(
 UserId user_id,
 const string& resource,
 const string& action,
 const Context& context
 ) {
 if (!HasPermission(user_id, resource, action)) {
 return false;
 }

---
### Role-Based Access Control (RBAC)
 // 추가 조건 검증
 auto role = GetUserRole(user_id);
 for (const auto& condition : role.permissions) {
 if (condition.resource == resource) {
 if (!EvaluateConditions(condition.conditions, context)) {
 return false;
 }
 }
 }

 return true;
 }
};

// 사용 예시
void EquipmentController::StartProcess(UserId user, Recipe recipe) {
 if (!rbac_.HasPermission(user, "equipment.process", "execute")) {
 throw UnauthorizedException("User lacks execute permission");
 }

---
### Role-Based Access Control (RBAC)
 if (recipe.IsHighRisk() &&
 !rbac_.HasPermission(user, "equipment.high_risk", "execute")) {
 throw UnauthorizedException("High-risk recipe requires special permission");
 }
---
### Role-Based Access Control (RBAC)
 // 프로세스 시작
 equipment_.StartProcess(recipe);

 // 감사 로깅
 audit_log_.Record(user, "started_process", recipe.id);
}
```
---
### 암호화 및 키 관리
```
┌─────────────────────────────────────────────────────┐
│ Layer 1: 전송 중 암호화 (In-Transit) │
│ - TLS 1.3 │
│ - Certificate Pinning │
│ - Perfect Forward Secrecy │
└─────────────────────────────────────────────────────┘
 ↓
┌─────────────────────────────────────────────────────┐
│ Layer 2: 저장 시 암호화 (At-Rest) │
│ - AES-256-GCM │
│ - 데이터베이스 암호화 │
│ - 파일 시스템 암호화 │
└─────────────────────────────────────────────────────┘
 ↓
┌─────────────────────────────────────────────────────┐
│ Layer 3: 사용 중 암호화 (In-Use) │
│ - Intel SGX / AMD SEV │
│ - Homomorphic Encryption (고급) │
└─────────────────────────────────────────────────────┘
```

---
### 암호화 및 키 관리
```cpp
class KeyManagementService {
private:
 // Hardware Security Module 연동
 unique_ptr<HSMProvider> hsm_;

 // 키 계층 구조
 struct KeyHierarchy {
 CryptoKey master_key; // HSM에 저장
 CryptoKey kek; // Key Encryption Key
 map<string, CryptoKey> deks; // Data Encryption Keys
 };

public:
 // 데이터 암호화
 EncryptedData Encrypt(const Data& plaintext, const string& key_id) {
 // 1. DEK 조회 (또는 생성)
 auto dek = GetOrCreateDEK(key_id);

 // 2. AES-GCM 암호화
 auto nonce = GenerateNonce();
 auto ciphertext = aes_gcm_.Encrypt(plaintext, dek, nonce);

 return EncryptedData{
 .ciphertext = ciphertext,
 .nonce = nonce,
 .key_id = key_id,
 .algorithm = "AES-256-GCM"
 };
 }

---
### 암호화 및 키 관리
 // 키 로테이션
 void RotateKeys() {
 auto new_deks = GenerateNewDEKs();

 // 모든 데이터 재암호화
 for (auto& [key_id, old_dek] : current_deks_) {
 auto new_dek = new_deks[key_id];
 ReencryptData(old_dek, new_dek);
 }

 // 이전 키는 grace period 동안 유지
 ArchiveOldKeys(current_deks_, grace_period_days: 30);
 }

 // 키 감사
 void AuditKeyUsage() {
 for (const auto& [key_id, dek] : current_deks_) {
 auto usage = GetKeyUsageMetrics(key_id);

 if (usage.age > max_key_age_) {
 ScheduleKeyRotation(key_id);
 }

 if (usage.encryption_count > max_operations_) {
 ForceKeyRotation(key_id);
 }
 }
 }
};
```
---
### 암호화 및 키 관리
```cpp
class SecureCommunication {
public:
 void ConfigureTLS() {
 ssl_context_.set_options(
 boost::asio::ssl::context::default_workarounds
 | boost::asio::ssl::context::no_sslv2
 | boost::asio::ssl::context::no_sslv3
 | boost::asio::ssl::context::no_tlsv1
 | boost::asio::ssl::context::no_tlsv1_1
 | boost::asio::ssl::context::single_dh_use
 );

 // TLS 1.3만 허용
 SSL_CTX_set_min_proto_version(ssl_context_.native_handle(), TLS1_3_VERSION);

 // 강력한 암호화 스위트만 허용
 ssl_context_.set_cipher_list(
 "TLS_AES_256_GCM_SHA384:"
 "TLS_CHACHA20_POLY1305_SHA256"
 );

 // Certificate pinning
 ssl_context_.set_verify_mode(boost::asio::ssl::verify_peer);
 ssl_context_.set_verify_callback([this](bool preverified, auto& ctx) {
 return VerifyCertificatePinning(ctx);
 });
 }
};
```
---
## 3️⃣ 컨테이너 오케스트레이션

### Container vs Virtual Machine

#### **아키텍처 비교**

---
## 3️⃣ 컨테이너 오케스트레이션
```
┌─────────────────────────────────────────────────────────┐
│ Virtual Machine Architecture │
├─────────────────────────────────────────────────────────┤
│ ┌──────────┐ ┌──────────┐ ┌──────────┐ │
│ │ App A │ │ App B │ │ App C │ │
│ ├──────────┤ ├──────────┤ ├──────────┤ │
│ │Guest OS │ │Guest OS │ │Guest OS │ │
│ │ (Linux) │ │(Windows) │ │ (Linux) │ │
│ └────┬─────┘ └────┬─────┘ └────┬─────┘ │
│ └─────────────┴─────────────┘ │
│ Hypervisor (VMware, KVM) │
│ ───────────────────────────────────────────── │
│ Host Operating System │
│ ───────────────────────────────────────────── │
│ Physical Hardware │
└─────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────┐
│ Container Architecture │
├─────────────────────────────────────────────────────────┤
│ ┌──────────┐ ┌──────────┐ ┌──────────┐ │
│ │ App A │ │ App B │ │ App C │ │
│ │ + Deps │ │ + Deps │ │ + Deps │ │
│ └────┬─────┘ └────┬─────┘ └────┬─────┘ │
│ └─────────────┴─────────────┘ │
│ Container Runtime (Docker) │
│ ───────────────────────────────────────────── │
│ Host Operating System │
│ ───────────────────────────────────────────── │
│ Physical Hardware │
└─────────────────────────────────────────────────────────┘
```

---
## 3️⃣ 컨테이너 오케스트레이션
**비교 분석:**

| 특성 | Virtual Machine | Container |
|-----|----------------|-----------|
| **시작 시간** | 분 단위 | 초 단위 |
| **리소스 사용** | 높음 (각 VM마다 전체 OS) | 낮음 (OS 커널 공유) |
| **격리 수준** | 완전 격리 (하드웨어 레벨) | 프로세스 격리 (네임스페이스) |
| **이미지 크기** | GB 단위 | MB 단위 |
| **이식성** | 제한적 (하이퍼바이저 의존) | 높음 (런타임만 필요) |
| **보안** | 강함 (완전 격리) | 중간 (커널 공유) |
| **밀집도** | 낮음 (10-20 VMs/서버) | 높음 (100+ 컨테이너/서버) |
| **오버헤드** | 높음 | 낮음 |

**HMI 선택 가이드:**

---
## 3️⃣ 컨테이너 오케스트레이션
- **Container 사용**:
 - 마이크로서비스 아키텍처
 - 빠른 배포/스케일링 필요
 - 클라우드 네이티브 환경
 - CI/CD 자동화

- **VM 사용**:
 - 완전한 격리 필요 (보안 critical)
 - 다른 OS 필요
 - 레거시 애플리케이션
 - 하드웨어 에뮬레이션 필요
---
### ️ Kubernetes 아키텍처
```
┌────────────────────────────────────────────────────────────────┐
│ Control Plane (Master) │
├────────────────────────────────────────────────────────────────┤
│ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ │
│ │ API Server │ │ Scheduler │ │ Controller │ │
│ │ │ │ │ │ Manager │ │
│ └──────┬───────┘ └──────┬───────┘ └──────┬───────┘ │
│ └──────────────────┴──────────────────┘ │
│ ┌──────────┐ │
│ │ etcd │ (분산 key-value 저장소) │
│ └──────────┘ │
└────────────────────────────────────────────────────────────────┘
 │
 ┌──────────────────────┼──────────────────────┐
 │ │ │
┌───────▼─────────┐ ┌────────▼────────┐ ┌────────▼────────┐
│ Worker Node 1 │ │ Worker Node 2 │ │ Worker Node 3 │
├─────────────────┤ ├─────────────────┤ ├─────────────────┤
│ ┌───────────┐ │ │ ┌───────────┐ │ │ ┌───────────┐ │
│ │ kubelet │ │ │ │ kubelet │ │ │ │ kubelet │ │
│ └───────────┘ │ │ └───────────┘ │ │ └───────────┘ │
│ ┌───────────┐ │ │ ┌───────────┐ │ │ ┌───────────┐ │
│ │kube-proxy │ │ │ │kube-proxy │ │ │ │kube-proxy │ │
│ └───────────┘ │ │ └───────────┘ │ │ └───────────┘ │
│ ┌───────────┐ │ │ ┌───────────┐ │ │ ┌───────────┐ │
│ │ Pod 1-1 │ │ │ │ Pod 2-1 │ │ │ │ Pod 3-1 │ │
│ │ Pod 1-2 │ │ │ │ Pod 2-2 │ │ │ │ Pod 3-2 │ │
│ └───────────┘ │ │ └───────────┘ │ │ └───────────┘ │
└─────────────────┘ └─────────────────┘ └─────────────────┘
```

---
### ️ Kubernetes 아키텍처
**핵심 오브젝트:**

1. **Pod**: 최소 배포 단위
---
### ️ Kubernetes 아키텍처
```yaml
apiVersion: v1
kind: Pod
metadata:
 name: hmi-frontend
spec:
 containers:
 - name: imgui-app
 image: semiconductor-hmi:latest
 resources:
 limits:
 memory: "512Mi"
 cpu: "500m"
 requests:
 memory: "256Mi"
 cpu: "250m"
```

---
### ️ Kubernetes 아키텍처
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
 name: hmi-backend
spec:
 replicas: 3 # 3개 인스턴스
 selector:
 matchLabels:
 app: hmi-backend
 template:
 metadata:
 labels:
 app: hmi-backend
 spec:
 containers:
 - name: backend
 image: hmi-backend:v2.0
 env:
 - name: DB_HOST
 valueFrom:
 configMapKeyRef:
 name: db-config
 key: host
```

---
### ️ Kubernetes 아키텍처
3. **Service**: 네트워크 추상화
```yaml
apiVersion: v1
kind: Service
metadata:
 name: hmi-service
spec:
 type: LoadBalancer
 selector:
 app: hmi-backend
 ports:
 - protocol: TCP
 port: 80
 targetPort: 8080
```

---
### ️ Kubernetes 아키텍처
4. **ConfigMap & Secret**: 설정 관리
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
 name: hmi-config
data:
 database.url: "postgresql://db:5432/hmi"
 log.level: "INFO"
---
apiVersion: v1
kind: Secret
metadata:
 name: hmi-secrets
type: Opaque
data:
 db-password: cGFzc3dvcmQxMjM= # base64 encoded
```

**주요 기능:**

- **자동 스케일링**: HPA (Horizontal Pod Autoscaler)
- **자가 치유**: 실패한 Pod 자동 재시작
- **롤링 업데이트**: 무중단 배포
- **로드 밸런싱**: 트래픽 자동 분산
- **서비스 디스커버리**: DNS 기반 서비스 찾기

---
### ️ Service Mesh (Istio)

#### **Service Mesh 아키텍처**

---
### ️ Service Mesh (Istio)
```
┌─────────────────────────────────────────────────────────────┐
│ Control Plane (Istiod) │
│ ┌──────────────┐ ┌──────────────┐ ┌──────────────┐ │
│ │ Pilot │ │ Citadel │ │ Galley │ │
│ │ (트래픽 관리) │ │ (인증/인가) │ │ (설정) │ │
│ └──────────────┘ └──────────────┘ └──────────────┘ │
└───────────────────────────┬─────────────────────────────────┘
 │ 설정 전파
 ┌───────────────────┼───────────────────┐
 │ │ │
┌───────▼────────┐ ┌───────▼────────┐ ┌──────▼─────────┐
│ Service A │ │ Service B │ │ Service C │
│ ┌────┐ ┌─────┐ │ │ ┌────┐ ┌─────┐ │ │ ┌────┐ ┌─────┐ │
│ │App │ │Envoy│ │ │ │App │ │Envoy│ │ │ │App │ │Envoy│ │
│ │ │ │Proxy│ │ │ │ │ │Proxy│ │ │ │ │ │Proxy│ │
│ └────┘ └─────┘ │ │ └────┘ └─────┘ │ │ └────┘ └─────┘ │
└────────────────┘ └────────────────┘ └────────────────┘
 Sidecar Sidecar Sidecar
```

---
### ️ Service Mesh (Istio)
**Service Mesh 기능:**

1. **트래픽 관리**
---
### ️ Service Mesh (Istio)
```yaml
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
 name: hmi-backend
spec:
 hosts:
 - hmi-backend
 http:
 - match:
 - headers:
 version:
 exact: v2
 route:
 - destination:
 host: hmi-backend
 subset: v2
 weight: 100
 - route:
 - destination:
 host: hmi-backend
 subset: v1
 weight: 90
 - destination:
 host: hmi-backend
 subset: v2
 weight: 10 # Canary 10%
```

---
### ️ Service Mesh (Istio)
2. **보안 (mTLS)**
```yaml
apiVersion: security.istio.io/v1beta1
kind: PeerAuthentication
metadata:
 name: default
spec:
 mtls:
 mode: STRICT # 모든 통신 암호화
```

3. **관찰성**
- 분산 추적 (Distributed Tracing)
- 메트릭 수집 (Prometheus)
- 로그 집계

---
### ️ Service Mesh (Istio)
**장점:**
- 애플리케이션 코드 변경 없이 고급 기능 추가
- 일관된 보안 정책
- 상세한 관찰성
- A/B 테스트, 카나리 배포 용이
---
## 4️⃣ CI/CD 파이프라인

### GitOps 및 Infrastructure as Code

#### **GitOps 워크플로우**

---
## 4️⃣ CI/CD 파이프라인
```
┌──────────────┐
│ Developer │
└──────┬───────┘
 │ 1. Code Commit
 ▼
┌──────────────┐
│ Git Repo │
│ (Source of │
│ Truth) │
└──────┬───────┘
 │ 2. Webhook Trigger
 ▼
┌──────────────┐
│ CI Pipeline │
│ - Build │
│ - Test │
│ - Scan │
└──────┬───────┘
 │ 3. Push Image
 ▼
┌──────────────┐ 4. Update ┌──────────────┐
│ Registry │ ──────Manifest──────> │ GitOps Repo │
│ (Docker Hub) │ │ (K8s YAML) │
└──────────────┘ └──────┬───────┘
 │ 5. Detect Change
 ▼
 ┌──────────────┐
 │ ArgoCD/Flux │
 │ (Operator) │
 └──────┬───────┘
 │ 6. Apply
 ▼
 ┌──────────────┐
 │ Kubernetes │
 │ Cluster │
 └──────────────┘
```

---
## 4️⃣ CI/CD 파이프라인
**GitOps 원칙:**

1. **선언적**: 시스템 상태를 선언적으로 기술
2. **버전 관리**: 모든 것이 Git에 저장
3. **자동 적용**: Git 변경사항이 자동으로 반영
4. **지속적 조정**: 실제 상태가 선언된 상태와 일치하도록 유지

**Infrastructure as Code (Terraform):**

---
## 4️⃣ CI/CD 파이프라인
```hcl
# Kubernetes 클러스터 프로비저닝
resource "google_container_cluster" "hmi_cluster" {
 name = "semiconductor-hmi-cluster"
 location = "us-central1"

 initial_node_count = 3

 node_config {
 machine_type = "n1-standard-4"
 disk_size_gb = 100

 oauth_scopes = [
 "https://www.googleapis.com/auth/cloud-platform"
 ]

 labels = {
 environment = "production"
 application = "hmi"
 }
 }

 # 자동 스케일링
 autoscaling {
 min_node_count = 3
 max_node_count = 10
 }

---
## 4️⃣ CI/CD 파이프라인
 # 네트워크 정책
 network_policy {
 enabled = true
 }
}

# 데이터베이스
resource "google_sql_database_instance" "hmi_db" {
 name = "hmi-postgres"
 database_version = "POSTGRES_14"
 region = "us-central1"

 settings {
 tier = "db-f1-micro"

 backup_configuration {
 enabled = true
 start_time = "02:00"
 }

 ip_configuration {
 ipv4_enabled = false
 private_network = google_compute_network.vpc.id
 }
 }
}
```
---
### 배포 전략
```
초기 상태:
┌─────────────────┐
│ Load Balancer │
└────────┬────────┘
 │ 100% Traffic
 ▼
 ┌────────┐
 │ Blue │ (v1.0)
 │ (현재) │
 └────────┘

배포 중:
┌─────────────────┐
│ Load Balancer │
└────┬───────┬────┘
 │ │ 0% Traffic
 │ ▼
 │ ┌────────┐
 │ │ Green │ (v2.0)
 │ │ (새버전) │
 │ └────────┘
 │ │ 테스트 완료
 ▼ ▼
┌────────┐ Ready!
│ Blue │
└────────┘

---
### 배포 전략
전환 후:
┌─────────────────┐
│ Load Balancer │
└────────┬────────┘
 │ 100% Traffic
 ▼
 ┌────────┐
 │ Green │ (v2.0)
 │ (현재) │
 └────────┘
```
---
### 배포 전략
**Kubernetes 구현:**

```yaml
apiVersion: v1
kind: Service
metadata:
 name: hmi-service
spec:
 selector:
 app: hmi
 version: blue # 트래픽 라우팅 대상
 ports:
 - port: 80
 targetPort: 8080
---
# Blue Deployment
apiVersion: apps/v1
kind: Deployment
metadata:
 name: hmi-blue
spec:
 replicas: 3
 selector:
 matchLabels:
 app: hmi
 version: blue
 template:
 metadata:
 labels:
 app: hmi
 version: blue
---
# Blue Deployment
 spec:
 containers:
 - name: hmi
 image: hmi:v1.0
---
# Green Deployment
apiVersion: apps/v1
kind: Deployment
metadata:
 name: hmi-green
spec:
 replicas: 3
 selector:
 matchLabels:
 app: hmi
 version: green
 template:
 metadata:
 labels:
 app: hmi
 version: green
---
# Green Deployment
 spec:
 containers:
 - name: hmi
 image: hmi:v2.0
```

**전환 스크립트:**

---
# Green Deployment
```bash
# Green 배포
kubectl apply -f hmi-green-deployment.yaml

# Green 헬스체크
kubectl wait --for=condition=available deployment/hmi-green --timeout=300s

# 스모크 테스트
./run-smoke-tests.sh hmi-green

# 트래픽 전환
kubectl patch service hmi-service -p '{"spec":{"selector":{"version":"green"}}}'

# Blue 유지 (롤백 대비)
# 문제 없으면 나중에 삭제
# kubectl delete deployment hmi-blue
```

---
# Green Deployment
**장점:**
- 즉각적인 롤백 가능
- 무중단 배포
- 프로덕션 환경에서 테스트 가능

**단점:**
- 2배 리소스 필요
- 데이터베이스 마이그레이션 복잡
---
#### **2. Canary Deployment**
```
단계 1: Canary 10%
┌─────────────────┐
│ Load Balancer │
└────┬───────┬────┘
 │90% │10%
 ▼ ▼
┌────────┐ ┌────────┐
│ v1.0 │ │ v2.0 │
│ (안정) │ │(Canary)│
└────────┘ └────────┘
 모니터링...

단계 2: Canary 50%
┌─────────────────┐
│ Load Balancer │
└────┬───────┬────┘
 │50% │50%
 ▼ ▼
┌────────┐ ┌────────┐
│ v1.0 │ │ v2.0 │
└────────┘ └────────┘
 메트릭 정상...

---
#### **2. Canary Deployment**
단계 3: 완전 전환
┌─────────────────┐
│ Load Balancer │
└────────┬────────┘
 │100%
 ▼
 ┌────────┐
 │ v2.0 │
 └────────┘
```
---
#### **2. Canary Deployment**
```yaml
apiVersion: networking.istio.io/v1alpha3
kind: VirtualService
metadata:
 name: hmi-canary
spec:
 hosts:
 - hmi-service
 http:
 - match:
 - headers:
 user-type:
 exact: beta-tester
 route:
 - destination:
 host: hmi-service
 subset: v2
 weight: 100
 - route:
 - destination:
 host: hmi-service
 subset: v1
 weight: 90
 - destination:
 host: hmi-service
 subset: v2
 weight: 10 # 10% 사용자에게 신버전
```

---
#### **2. Canary Deployment**
**자동화된 Canary (Flagger):**

---
#### **2. Canary Deployment**
```yaml
apiVersion: flagger.app/v1beta1
kind: Canary
metadata:
 name: hmi-canary
spec:
 targetRef:
 apiVersion: apps/v1
 kind: Deployment
 name: hmi
 service:
 port: 8080
 analysis:
 interval: 1m
 threshold: 5 # 5번 실패하면 롤백
 maxWeight: 50
 stepWeight: 10 # 10%씩 증가
 metrics:
 - name: request-success-rate
 thresholdRange:
 min: 99 # 99% 성공률 유지
 - name: request-duration
 thresholdRange:
 max: 500 # 500ms 이하
 webhooks:
 - name: smoke-test
 url: http://flagger-loadtester/
 timeout: 5m
 metadata:
 type: cmd
 cmd: "./smoke-test.sh"
```
---
#### **3. Rolling Update**

```
초기: [v1] [v1] [v1] [v1]

Step1: [v2] [v1] [v1] [v1] # 1개 업데이트

Step2: [v2] [v2] [v1] [v1] # 2개 업데이트

Step3: [v2] [v2] [v2] [v1] # 3개 업데이트

완료: [v2] [v2] [v2] [v2] # 전체 업데이트
```

**Kubernetes 설정:**

---
#### **3. Rolling Update**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
 name: hmi-deployment
spec:
 replicas: 4
 strategy:
 type: RollingUpdate
 rollingUpdate:
 maxUnavailable: 1 # 최대 1개까지 다운 허용
 maxSurge: 1 # 최대 1개 추가 생성 허용
 template:
 spec:
 containers:
 - name: hmi
 image: hmi:v2.0
 livenessProbe:
 httpGet:
 path: /health
 port: 8080
 initialDelaySeconds: 30
 periodSeconds: 10
 readinessProbe:
 httpGet:
 path: /ready
 port: 8080
 initialDelaySeconds: 5
 periodSeconds: 5
```
---
### 자동화 테스트 피라미드

```
 /\
 / \
 / \
 / E2E \ <- UI Tests (느림, 비쌈)
 / Tests \ 10%
 /──────────\
 / \
 / Integration \ <- API Tests (중간)
 / Tests \ 20%
 /────────────────\
 / \
 / Unit Tests \ <- Fast, Cheap
 /______________________\ 70%
```

---
### 자동화 테스트 피라미드
```cpp
// Google Test 사용
TEST(EquipmentControllerTest, StartProcess_ValidRecipe_Success) {
 // Arrange
 auto controller = EquipmentController();
 auto recipe = Recipe::CreateDefault();
 auto equipment = Equipment::Create(EquipmentType::ETCHER);

 // Act
 auto result = controller.StartProcess(equipment, recipe);

 // Assert
 EXPECT_TRUE(result.IsSuccess());
 EXPECT_EQ(equipment.GetState(), EquipmentState::PROCESSING);
}

TEST(EquipmentControllerTest, StartProcess_InvalidRecipe_Failure) {
 auto controller = EquipmentController();
 auto invalid_recipe = Recipe(); // 빈 레시피
 auto equipment = Equipment::Create(EquipmentType::ETCHER);

 auto result = controller.StartProcess(equipment, invalid_recipe);

 EXPECT_FALSE(result.IsSuccess());
 EXPECT_EQ(result.GetError(), "Invalid recipe");
}
```

---
### 자동화 테스트 피라미드
```cpp
TEST_F(DatabaseIntegrationTest, SaveAndRetrieveEquipment) {
 // Arrange
 auto db = DatabaseConnection::Create(test_db_url_);
 auto equipment = Equipment::Create(EquipmentType::CVD);
 equipment.SetTemperature(450.0);

 // Act
 auto save_result = db.Save(equipment);
 auto loaded_equipment = db.Load<Equipment>(equipment.GetId());

 // Assert
 ASSERT_TRUE(save_result.IsSuccess());
 ASSERT_TRUE(loaded_equipment.has_value());
 EXPECT_EQ(loaded_equipment->GetTemperature(), 450.0);
}

TEST_F(APIIntegrationTest, GetEquipmentStatus_ReturnsCorrectData) {
 auto client = HTTPClient::Create("http://localhost:8080");

 auto response = client.Get("/api/equipment/123/status");

 EXPECT_EQ(response.status_code, 200);
 auto json = nlohmann::json::parse(response.body);
 EXPECT_EQ(json["state"], "IDLE");
 EXPECT_DOUBLE_EQ(json["temperature"], 25.0);
}
```

---
### 자동화 테스트 피라미드
```cpp
TEST_F(E2ETest, CompleteProductionWorkflow) {
 // 1. 사용자 로그인
 auto ui = UIAutomation::Create();
 ui.Login("engineer@fab.com", "password");

 // 2. 레시피 선택
 ui.NavigateTo("/recipes");
 ui.SelectRecipe("SiO2_Deposition_v2");

 // 3. 장비 선택 및 프로세스 시작
 ui.NavigateTo("/equipment");
 ui.SelectEquipment("CVD-01");
 ui.ClickButton("Start Process");

 // 4. 프로세스 진행 확인
 ui.WaitForProcessStart(timeout: 10s);
 EXPECT_TRUE(ui.IsElementVisible("Processing..."));

 // 5. 모니터링 대시보드 확인
 ui.NavigateTo("/dashboard");
 auto temperature = ui.GetDisplayedValue("temperature");
 EXPECT_GT(temperature, 400.0);
 EXPECT_LT(temperature, 500.0);

---
### 자동화 테스트 피라미드
 // 6. 프로세스 완료 대기 (시뮬레이션)
 ui.WaitForProcessComplete(timeout: 60s);
 EXPECT_TRUE(ui.IsElementVisible("Process Complete"));
}
```
---
### 자동화 테스트 피라미드
```yaml
# .github/workflows/ci.yml
name: CI Pipeline

on: [push, pull_request]

jobs:
 unit-tests:
 runs-on: ubuntu-latest
 steps:
 - uses: actions/checkout@v2
 - name: Build
 run: cmake --build build
 - name: Run Unit Tests
 run: ctest --test-dir build --output-on-failure
 - name: Coverage Report
 run: |
 gcov build/**/*.gcda
 bash <(curl -s https://codecov.io/bash)

 integration-tests:
 runs-on: ubuntu-latest
 services:
 postgres:
 image: postgres:14
 env:
 POSTGRES_PASSWORD: test
 steps:
 - uses: actions/checkout@v2
 - name: Run Integration Tests
 run: ./run-integration-tests.sh

---
### 자동화 테스트 피라미드
 e2e-tests:
 runs-on: ubuntu-latest
 steps:
 - uses: actions/checkout@v2
 - name: Start Application
 run: docker-compose up -d
 - name: Run E2E Tests
 run: ./run-e2e-tests.sh
 - name: Cleanup
 run: docker-compose down
```
---
## 5️⃣ 성능 최적화

### 프로파일링 및 병목 분석

#### **계층별 프로파일링 전략**

---
## 5️⃣ 성능 최적화
```
┌─────────────────────────────────────────────────────┐
│ Application Layer │
│ - CPU Profiling (perf, gprof, VTune) │
│ - Memory Profiling (Valgrind, Heaptrack) │
│ - GPU Profiling (NSight, RenderDoc) │
└─────────────────────────────────────────────────────┘
 ↓
┌─────────────────────────────────────────────────────┐
│ Runtime Layer │
│ - Garbage Collection (GC 로그) │
│ - Thread Contention (Thread Sanitizer) │
└─────────────────────────────────────────────────────┘
 ↓
┌─────────────────────────────────────────────────────┐
│ System Layer │
│ - I/O Profiling (iostat, iotop) │
│ - Network Profiling (tcpdump, Wireshark) │
│ - System Calls (strace, dtrace) │
└─────────────────────────────────────────────────────┘
```

---
## 5️⃣ 성능 최적화
**CPU 프로파일링 (Linux perf):**

```bash
# 프로파일링 데이터 수집
perf record -g ./hmi_application

# Flamegraph 생성
perf script | ./FlameGraph/stackcollapse-perf.pl | ./FlameGraph/flamegraph.pl > flamegraph.svg

# 핫스팟 분석
perf report --stdio
```

**C++ 프로파일링 코드:**

---
## 5️⃣ 성능 최적화
```cpp
class PerformanceProfiler {
private:
 struct ProfileData {
 string function_name;
 chrono::high_resolution_clock::time_point start;
 chrono::high_resolution_clock::time_point end;
 size_t memory_before;
 size_t memory_after;
 };

 vector<ProfileData> profile_stack_;

public:
 class ScopedProfile {
 public:
 ScopedProfile(PerformanceProfiler& profiler, const string& name)
 : profiler_(profiler), name_(name) {
 profiler_.BeginProfile(name);
 }

 ~ScopedProfile() {
 profiler_.EndProfile(name_);
 }

---
## 5️⃣ 성능 최적화
 private:
 PerformanceProfiler& profiler_;
 string name_;
 };

 void BeginProfile(const string& name) {
 ProfileData data;
 data.function_name = name;
 data.start = chrono::high_resolution_clock::now();
 data.memory_before = GetCurrentMemoryUsage();
 profile_stack_.push_back(data);
 }

 void EndProfile(const string& name) {
 auto& data = profile_stack_.back();
 data.end = chrono::high_resolution_clock::now();
 data.memory_after = GetCurrentMemoryUsage();

---
## 5️⃣ 성능 최적화
 auto duration = chrono::duration_cast<chrono::microseconds>(
 data.end - data.start
 ).count();

 cout << "[PROFILE] " << name
 << " took " << duration << "μs"
 << ", memory delta: "
 << (data.memory_after - data.memory_before) / 1024 << "KB"
 << endl;
---
## 5️⃣ 성능 최적화
 profile_stack_.pop_back();
 }
};

// 사용 예시
void RenderDashboard() {
 auto profile = profiler.ScopedProfile(profiler, "RenderDashboard");

 {
 auto sub_profile = profiler.ScopedProfile(profiler, "FetchData");
 auto data = database.FetchEquipmentData();
 }

 {
 auto sub_profile = profiler.ScopedProfile(profiler, "RenderCharts");
 chart_renderer.Render(data);
 }
}
```
---
### 캐싱 전략
```
┌────────────────────────────────────────────────────┐
│ L1 Cache: In-Memory (Application) │
│ - LRU Cache │
│ - TTL: 5초 │
│ - Size: 100MB │
└────────────────┬───────────────────────────────────┘
 │ Cache Miss
┌────────────────▼───────────────────────────────────┐
│ L2 Cache: Redis (Distributed) │
│ - TTL: 1분 │
│ - Size: 1GB │
└────────────────┬───────────────────────────────────┘
 │ Cache Miss
┌────────────────▼───────────────────────────────────┐
│ L3: Database / API │
│ - Primary Data Source │
└────────────────────────────────────────────────────┘
```

---
### 캐싱 전략
```cpp
template<typename Key, typename Value>
class LRUCache {
private:
 struct CacheEntry {
 Value value;
 chrono::system_clock::time_point expire_time;
 };

 size_t capacity_;
 unordered_map<Key, typename list<pair<Key, CacheEntry>>::iterator> cache_map_;
 list<pair<Key, CacheEntry>> lru_list_;
 mutable shared_mutex mutex_;

public:
 LRUCache(size_t capacity) : capacity_(capacity) {}

 optional<Value> Get(const Key& key) {
 shared_lock lock(mutex_);

 auto it = cache_map_.find(key);
 if (it == cache_map_.end()) {
 return nullopt; // Cache miss
 }

---
### 캐싱 전략
 // TTL 체크
 auto& entry = it->second->second;
 if (chrono::system_clock::now() > entry.expire_time) {
 return nullopt; // Expired
 }

 // LRU 업데이트 (최근 사용으로 이동)
 lru_list_.splice(lru_list_.begin(), lru_list_, it->second);

 return entry.value;
 }

 void Put(const Key& key, const Value& value, chrono::seconds ttl) {
 unique_lock lock(mutex_);

 auto it = cache_map_.find(key);

 if (it != cache_map_.end()) {
 // 기존 엔트리 업데이트
 lru_list_.erase(it->second);
 } else if (cache_map_.size() >= capacity_) {
 // 용량 초과: 가장 오래된 항목 제거
 auto last = lru_list_.back();
 cache_map_.erase(last.first);
 lru_list_.pop_back();
 }

---
### 캐싱 전략
 // 새 엔트리 추가
 CacheEntry entry{
 .value = value,
 .expire_time = chrono::system_clock::now() + ttl
 };

 lru_list_.push_front({key, entry});
 cache_map_[key] = lru_list_.begin();
 }

 void Invalidate(const Key& key) {
 unique_lock lock(mutex_);

 auto it = cache_map_.find(key);
 if (it != cache_map_.end()) {
 lru_list_.erase(it->second);
 cache_map_.erase(it);
 }
 }
};
```
---
### 캐싱 전략
```cpp
class DistributedCache {
private:
 redis::Redis redis_client_;
 LRUCache<string, string> local_cache_{1000}; // L1 캐시

public:
 optional<string> Get(const string& key) {
 // L1 캐시 확인
 if (auto value = local_cache_.Get(key)) {
 return value;
 }

 // L2 캐시 (Redis) 확인
 auto redis_value = redis_client_.get(key);
 if (redis_value) {
 // L1 캐시에 저장
 local_cache_.Put(key, *redis_value, 5s);
 return redis_value;
 }

 return nullopt;
 }

---
### 캐싱 전략
 void Put(const string& key, const string& value, chrono::seconds ttl) {
 // L1 캐시
 local_cache_.Put(key, value, ttl);

 // L2 캐시 (Redis)
 redis_client_.setex(key, ttl.count(), value);
 }

 // Write-Through 패턴
 void UpdateWithDatabase(
 const string& key,
 const string& value,
 function<void(const string&, const string&)> db_writer
 ) {
 // 1. DB 업데이트
 db_writer(key, value);

 // 2. 캐시 업데이트
 Put(key, value, 60s);
 }

---
### 캐싱 전략
 // Cache-Aside 패턴
 string GetOrLoad(
 const string& key,
 function<string()> loader
 ) {
 if (auto cached = Get(key)) {
 return *cached;
 }
---
### 캐싱 전략
 // DB에서 로드
 auto value = loader();

 // 캐시에 저장
 Put(key, value, 60s);

 return value;
 }
};
```
---
### 캐싱 전략
```cpp
class CacheInvalidationStrategy {
public:
 // 1. TTL 기반
 void TTLInvalidation(Cache& cache, const string& key, chrono::seconds ttl) {
 cache.Put(key, value, ttl); // 자동 만료
 }

 // 2. 이벤트 기반
 void EventBasedInvalidation(EventBus& event_bus, Cache& cache) {
 event_bus.Subscribe("equipment.updated", [&cache](const Event& e) {
 cache.Invalidate("equipment:" + e.equipment_id);
 });
 }

 // 3. 버전 기반
 string GetVersionedKey(const string& base_key, int version) {
 return base_key + ":v" + to_string(version);
 }

 // 4. Tag 기반
 void InvalidateByTag(Cache& cache, const string& tag) {
 auto keys = cache.GetKeysByTag(tag);
 for (const auto& key : keys) {
 cache.Invalidate(key);
 }
 }
};
```
---
### ️ 데이터베이스 최적화
```sql
-- 1. B-Tree 인덱스 (기본)
CREATE INDEX idx_equipment_state ON equipment(state);

-- 2. 복합 인덱스 (쿼리 패턴 맞춤)
CREATE INDEX idx_equipment_fab_type
ON equipment(fab_id, equipment_type, state);

-- 3. Partial 인덱스 (조건부)
CREATE INDEX idx_active_equipment
ON equipment(equipment_id)
WHERE state IN ('IDLE', 'PROCESSING');

-- 4. Expression 인덱스
CREATE INDEX idx_equipment_temp_celsius
ON equipment((temperature * 9/5 + 32));

-- 5. Full-Text Search
CREATE INDEX idx_recipe_search
ON recipe USING GIN(to_tsvector('english', description));
```

---
### ️ 데이터베이스 최적화
```sql
-- 비효율적인 쿼리
SELECT * FROM equipment
WHERE YEAR(created_at) = 2024; -- 함수 사용으로 인덱스 무효화

-- 최적화된 쿼리
SELECT * FROM equipment
WHERE created_at >= '2024-01-01'
 AND created_at < '2025-01-01'; -- 인덱스 사용 가능

-- N+1 쿼리 문제
for equipment in equipments:
 sensors = db.query("SELECT * FROM sensors WHERE equipment_id = ?", equipment.id)

-- JOIN 사용
SELECT e.*, s.*
FROM equipment e
LEFT JOIN sensors s ON e.id = s.equipment_id
WHERE e.fab_id = ?;

-- WITH 절 (복잡한 쿼리 최적화)
WITH equipment_stats AS (
 SELECT
 fab_id,
 COUNT(*) as total_equipment,
 AVG(temperature) as avg_temp
 FROM equipment
 WHERE state = 'PROCESSING'
 GROUP BY fab_id
)
SELECT f.name, es.*
FROM fab f
JOIN equipment_stats es ON f.id = es.fab_id;
```

---
### ️ 데이터베이스 최적화
```cpp
class ConnectionPool {
private:
 queue<unique_ptr<DBConnection>> available_connections_;
 atomic<int> active_connections_{0};
 const int max_connections_ = 100;
 const int min_connections_ = 10;
 mutex mutex_;
 condition_variable cv_;

public:
 class PooledConnection {
 public:
 ~PooledConnection() {
 pool_.ReleaseConnection(move(conn_));
 }

 DBConnection* operator->() { return conn_.get(); }

 private:
 friend class ConnectionPool;
 PooledConnection(ConnectionPool& pool, unique_ptr<DBConnection> conn)
 : pool_(pool), conn_(move(conn)) {}

---
### ️ 데이터베이스 최적화
 ConnectionPool& pool_;
 unique_ptr<DBConnection> conn_;
 };

 PooledConnection AcquireConnection(chrono::milliseconds timeout = 5s) {
 unique_lock lock(mutex_);

 // 사용 가능한 연결 대기
 if (!cv_.wait_for(lock, timeout, [this] {
 return !available_connections_.empty() ||
 active_connections_ < max_connections_;
 })) {
 throw TimeoutException("Connection pool timeout");
 }

 unique_ptr<DBConnection> conn;

 if (!available_connections_.empty()) {
 conn = move(available_connections_.front());
 available_connections_.pop();
 } else {
 conn = CreateNewConnection();
 active_connections_++;
 }

---
### ️ 데이터베이스 최적화
 return PooledConnection(*this, move(conn));
 }

private:
 void ReleaseConnection(unique_ptr<DBConnection> conn) {
 unique_lock lock(mutex_);

 if (available_connections_.size() < min_connections_) {
 available_connections_.push(move(conn));
 } else {
 active_connections_--;
 }

 cv_.notify_one();
 }
};
```
---
## 6️⃣ 시스템 모니터링 및 관찰성

### 메트릭 수집 (Prometheus)

#### **메트릭 계층**

---
## 6️⃣ 시스템 모니터링 및 관찰성
```
┌─────────────────────────────────────────────────────┐
│ Business Metrics (비즈니스 메트릭) │
│ - Equipment Utilization Rate │
│ - Process Throughput │
│ - Error Rate by Recipe │
└─────────────────────────────────────────────────────┘
 ↓
┌─────────────────────────────────────────────────────┐
│ Application Metrics (애플리케이션 메트릭) │
│ - Request Rate, Latency, Error Rate │
│ - Database Query Time │
│ - Cache Hit Rate │
└─────────────────────────────────────────────────────┘
 ↓
┌─────────────────────────────────────────────────────┐
│ Infrastructure Metrics (인프라 메트릭) │
│ - CPU, Memory, Disk, Network │
│ - Container Metrics │
└─────────────────────────────────────────────────────┘
```

---
## 6️⃣ 시스템 모니터링 및 관찰성
```cpp
#include <prometheus/counter.h>
#include <prometheus/histogram.h>
#include <prometheus/gauge.h>
#include <prometheus/registry.h>

class MetricsCollector {
private:
 shared_ptr<prometheus::Registry> registry_;

 // Counter: 증가만 하는 값
 prometheus::Family<prometheus::Counter>& request_counter_;
 prometheus::Family<prometheus::Counter>& error_counter_;

 // Histogram: 분포 측정
 prometheus::Family<prometheus::Histogram>& request_duration_;
 prometheus::Family<prometheus::Histogram>& db_query_duration_;

 // Gauge: 증감 가능한 값
 prometheus::Family<prometheus::Gauge>& active_equipment_;
 prometheus::Family<prometheus::Gauge>& temperature_gauge_;

public:
 MetricsCollector()
 : registry_(make_shared<prometheus::Registry>()),
 request_counter_(prometheus::BuildCounter()
 .Name("hmi_requests_total")
 .Help("Total number of HTTP requests")
 .Register(*registry_)),
 error_counter_(prometheus::BuildCounter()
 .Name("hmi_errors_total")
 .Help("Total number of errors")
 .Register(*registry_)),
 request_duration_(prometheus::BuildHistogram()
 .Name("hmi_request_duration_seconds")
 .Help("HTTP request duration")
 .Register(*registry_)),
 active_equipment_(prometheus::BuildGauge()
 .Name("hmi_active_equipment")
 .Help("Number of active equipment")
 .Register(*registry_))
 {}

---
## 6️⃣ 시스템 모니터링 및 관찰성
 void RecordRequest(const string& endpoint, const string& method) {
 request_counter_
 .Add({{"endpoint", endpoint}, {"method", method}})
 .Increment();
 }

 void RecordRequestDuration(
 const string& endpoint,
 double duration_seconds
 ) {
 request_duration_
 .Add({{"endpoint", endpoint}},
 prometheus::Histogram::BucketBoundaries{
 0.001, 0.01, 0.1, 0.5, 1.0, 5.0, 10.0
 })
 .Observe(duration_seconds);
 }

---
## 6️⃣ 시스템 모니터링 및 관찰성
 void SetActiveEquipment(const string& fab_id, int count) {
 active_equipment_
 .Add({{"fab_id", fab_id}})
 .Set(count);
 }
---
## 6️⃣ 시스템 모니터링 및 관찰성
 // 자동 메트릭 수집
 class ScopedTimer {
 public:
 ScopedTimer(
 prometheus::Histogram& histogram
 ) : histogram_(histogram),
 start_(chrono::high_resolution_clock::now()) {}

 ~ScopedTimer() {
 auto end = chrono::high_resolution_clock::now();
 auto duration = chrono::duration<double>(end - start_).count();
 histogram_.Observe(duration);
 }

 private:
 prometheus::Histogram& histogram_;
 chrono::high_resolution_clock::time_point start_;
 };
};

---
## 6️⃣ 시스템 모니터링 및 관찰성
// 사용 예시
void HandleRequest(const Request& req) {
 metrics.RecordRequest(req.endpoint, req.method);
---
## 6️⃣ 시스템 모니터링 및 관찰성
 auto timer = MetricsCollector::ScopedTimer(
 metrics.GetRequestDurationHistogram(req.endpoint)
 );

 try {
 ProcessRequest(req);
 } catch (const exception& e) {
 metrics.RecordError(req.endpoint, e.what());
 throw;
 }
}
```
---
## 6️⃣ 시스템 모니터링 및 관찰성
```promql
# Request Rate (QPS)
rate(hmi_requests_total[5m])

# 99th Percentile Latency
histogram_quantile(0.99,
 rate(hmi_request_duration_seconds_bucket[5m])
)

# Error Rate
rate(hmi_errors_total[5m]) / rate(hmi_requests_total[5m])

# Equipment Utilization
avg(hmi_active_equipment) / avg(hmi_total_equipment) * 100

# Alerts
ALERT HighErrorRate
 IF rate(hmi_errors_total[5m]) > 0.05
 FOR 5m
 LABELS { severity = "critical" }
 ANNOTATIONS {
 summary = "High error rate detected",
 description = "Error rate is {{ $value }}%"
 }
```
---
### 분산 추적 (OpenTelemetry)
```
User Request
 │
 ├─> API Gateway (Span 1)
 │ │
 │ ├─> Auth Service (Span 2)
 │ │ └─> Redis Cache (Span 3)
 │ │
 │ ├─> Equipment Service (Span 4)
 │ │ ├─> Database Query (Span 5)
 │ │ └─> MQTT Publish (Span 6)
 │ │
 │ └─> Notification Service (Span 7)
 │
 └─> Response

Trace ID: abc123-def456-ghi789
각 Span은 시작/종료 시간, 메타데이터 포함
```

---
### 분산 추적 (OpenTelemetry)
```cpp
#include <opentelemetry/trace/provider.h>
#include <opentelemetry/sdk/trace/simple_processor.h>
#include <opentelemetry/exporters/jaeger/jaeger_exporter.h>

class TracingService {
private:
 unique_ptr<opentelemetry::trace::Tracer> tracer_;

public:
 void Initialize() {
 auto exporter = make_unique<opentelemetry::exporters::jaeger::JaegerExporter>(
 opentelemetry::exporters::jaeger::JaegerExporterOptions{
 .endpoint = "http://jaeger:14250",
 .service_name = "hmi-backend"
 }
 );

 auto processor = make_unique<opentelemetry::sdk::trace::SimpleSpanProcessor>(
 move(exporter)
 );

 auto provider = make_shared<opentelemetry::sdk::trace::TracerProvider>(
 move(processor)
 );

 opentelemetry::trace::Provider::SetTracerProvider(provider);
 tracer_ = provider->GetTracer("hmi-backend", "1.0.0");
 }

---
### 분산 추적 (OpenTelemetry)
 class Span {
 public:
 Span(
 opentelemetry::nostd::shared_ptr<opentelemetry::trace::Span> span
 ) : span_(span) {}

 ~Span() {
 span_->End();
 }

 void SetAttribute(const string& key, const string& value) {
 span_->SetAttribute(key, value);
 }

 void AddEvent(const string& name) {
 span_->AddEvent(name);
 }

 void RecordException(const exception& e) {
 span_->SetStatus(
 opentelemetry::trace::StatusCode::kError,
 e.what()
 );
 }

---
### 분산 추적 (OpenTelemetry)
 private:
 opentelemetry::nostd::shared_ptr<opentelemetry::trace::Span> span_;
 };

 Span StartSpan(const string& name) {
 auto span = tracer_->StartSpan(name);
 return Span(span);
 }

 Span StartSpanWithParent(
 const string& name,
 const opentelemetry::context::Context& parent_ctx
 ) {
 opentelemetry::trace::StartSpanOptions options;
 options.parent = parent_ctx;
 auto span = tracer_->StartSpan(name, options);
 return Span(span);
 }
};

---
### 분산 추적 (OpenTelemetry)
// 사용 예시
void HandleEquipmentRequest(const Request& req) {
 auto span = tracing.StartSpan("HandleEquipmentRequest");
 span.SetAttribute("equipment.id", req.equipment_id);
 span.SetAttribute("user.id", req.user_id);
---
### 분산 추적 (OpenTelemetry)
 try {
 // 데이터베이스 조회
 {
 auto db_span = tracing.StartSpan("DatabaseQuery");
 db_span.SetAttribute("query", "SELECT * FROM equipment WHERE id = ?");
 auto equipment = db.Query(req.equipment_id);
 }

 // MQTT 메시지 발행
 {
 auto mqtt_span = tracing.StartSpan("MQTTPublish");
 mqtt_span.SetAttribute("topic", "equipment/status");
 mqtt.Publish("equipment/status", equipment.ToJson());
 }

 span.AddEvent("Request processed successfully");
 } catch (const exception& e) {
 span.RecordException(e);
 throw;
 }
}
```
---
### 로그 집계 (ELK Stack)
```cpp
class StructuredLogger {
public:
 enum class Level {
 DEBUG, INFO, WARN, ERROR, FATAL
 };

 struct LogEntry {
 Level level;
 string message;
 map<string, string> fields;
 chrono::system_clock::time_point timestamp;
 string trace_id;
 string span_id;
 };

 void Log(Level level, const string& message, const map<string, string>& fields = {}) {
 LogEntry entry{
 .level = level,
 .message = message,
 .fields = fields,
 .timestamp = chrono::system_clock::now(),
 .trace_id = GetCurrentTraceId(),
 .span_id = GetCurrentSpanId()
 };

---
### 로그 집계 (ELK Stack)
 // JSON 형식으로 출력
 nlohmann::json log_json = {
 {"level", LevelToString(level)},
 {"message", message},
 {"timestamp", FormatTimestamp(entry.timestamp)},
 {"trace_id", entry.trace_id},
 {"span_id", entry.span_id},
 {"service", "hmi-backend"},
 {"environment", "production"}
 };

 for (const auto& [key, value] : fields) {
 log_json[key] = value;
 }

 cout << log_json.dump() << endl;

 // Logstash로 전송
 logstash_client_.Send(log_json.dump());
 }

---
### 로그 집계 (ELK Stack)
 void Info(const string& message, const map<string, string>& fields = {}) {
 Log(Level::INFO, message, fields);
 }
---
### 로그 집계 (ELK Stack)
 void Error(const string& message, const exception& e) {
 Log(Level::ERROR, message, {
 {"exception.type", typeid(e).name()},
 {"exception.message", e.what()},
 {"stack_trace", GetStackTrace()}
 });
 }
};

// 사용 예시
void ProcessEquipment(const Equipment& equipment) {
 logger.Info("Processing equipment", {
 {"equipment.id", equipment.GetId()},
 {"equipment.type", equipment.GetType()},
 {"fab.id", equipment.GetFabId()}
 });

 try {
 auto result = equipment.StartProcess();

 logger.Info("Process started successfully", {
 {"equipment.id", equipment.GetId()},
 {"process.id", result.process_id},
 {"recipe.id", result.recipe_id}
 });
 } catch (const exception& e) {
 logger.Error("Failed to start process", e);
 }
}
```
---
### 로그 집계 (ELK Stack)
```json
{
 "query": {
 "bool": {
 "must": [
 { "match": { "level": "ERROR" }},
 { "range": { "timestamp": { "gte": "now-1h" }}}
 ],
 "filter": [
 { "term": { "service": "hmi-backend" }},
 { "term": { "environment": "production" }}
 ]
 }
 },
 "aggs": {
 "error_by_type": {
 "terms": { "field": "exception.type" }
 }
 }
}
```
---
## 7️⃣ 품질 보증 (QA)

### 성능 테스트

#### **부하 테스트 시나리오**

---
## 7️⃣ 품질 보증 (QA)
```cpp
// Locust (Python) 스크립트를 C++에서 실행
class LoadTest {
public:
 struct TestScenario {
 string name;
 int concurrent_users;
 int ramp_up_time_seconds;
 int duration_seconds;
 function<void(int user_id)> user_behavior;
 };

 void RunLoadTest(const TestScenario& scenario) {
 vector<thread> user_threads;
 atomic<bool> test_running{true};

 // 사용자 램프업
 for (int i = 0; i < scenario.concurrent_users; i++) {
 user_threads.emplace_back([&, user_id = i]() {
 // 램프업 딜레이
 this_thread::sleep_for(chrono::milliseconds(
 scenario.ramp_up_time_seconds * 1000 / scenario.concurrent_users * user_id
 ));

---
## 7️⃣ 품질 보증 (QA)
 // 테스트 시나리오 실행
 while (test_running) {
 try {
 scenario.user_behavior(user_id);
 } catch (const exception& e) {
 RecordError(e);
 }

 // Think time
 this_thread::sleep_for(chrono::milliseconds(rand() % 1000));
 }
 });
 }

 // 테스트 지속 시간
 this_thread::sleep_for(chrono::seconds(scenario.duration_seconds));
 test_running = false;

---
## 7️⃣ 품질 보증 (QA)
 // 모든 스레드 종료 대기
 for (auto& thread : user_threads) {
 thread.join();
 }

 PrintResults();
 }
---
## 7️⃣ 품질 보증 (QA)
private:
 struct Metrics {
 atomic<int> total_requests{0};
 atomic<int> successful_requests{0};
 atomic<int> failed_requests{0};
 vector<double> response_times;
 mutex metrics_mutex;
 } metrics_;

 void RecordError(const exception& e) {
 metrics_.failed_requests++;
 logger.Error("Load test error", e);
 }

 void PrintResults() {
 auto total = metrics_.total_requests.load();
 auto success = metrics_.successful_requests.load();
 auto failed = metrics_.failed_requests.load();

---
## 7️⃣ 품질 보증 (QA)
 cout << "=== Load Test Results ===" << endl;
 cout << "Total Requests: " << total << endl;
 cout << "Successful: " << success << " ("
 << (success * 100.0 / total) << "%)" << endl;
 cout << "Failed: " << failed << " ("
 << (failed * 100.0 / total) << "%)" << endl;
---
## 7️⃣ 품질 보증 (QA)
 sort(metrics_.response_times.begin(), metrics_.response_times.end());
 cout << "P50 Latency: "
 << metrics_.response_times[metrics_.response_times.size() * 0.5] << "ms" << endl;
 cout << "P95 Latency: "
 << metrics_.response_times[metrics_.response_times.size() * 0.95] << "ms" << endl;
 cout << "P99 Latency: "
 << metrics_.response_times[metrics_.response_times.size() * 0.99] << "ms" << endl;
 }
};

// 사용 예시
void RunEquipmentMonitoringLoadTest() {
 LoadTest load_test;

 LoadTest::TestScenario scenario{
 .name = "Equipment Monitoring",
 .concurrent_users = 1000,
 .ramp_up_time_seconds = 60,
 .duration_seconds = 300,
 .user_behavior = [](int user_id) {
 auto client = HTTPClient::Create("http://hmi-backend");

---
## 7️⃣ 품질 보증 (QA)
 // 1. 장비 목록 조회
 auto equipment_list = client.Get("/api/equipment");
---
## 7️⃣ 품질 보증 (QA)
 // 2. 특정 장비 상세 조회
 auto equipment_id = SelectRandomEquipment(equipment_list);
 auto equipment_detail = client.Get("/api/equipment/" + equipment_id);

 // 3. 실시간 센서 데이터 조회
 auto sensor_data = client.Get("/api/equipment/" + equipment_id + "/sensors");
 }
 };

 load_test.RunLoadTest(scenario);
}
```
---
### 카오스 엔지니어링
```cpp
class ChaosEngineering {
public:
 // 1. 네트워크 레이턴시 주입
 void InjectNetworkLatency(chrono::milliseconds delay) {
 network_interceptor_.AddLatency(delay);
 }

 // 2. 랜덤 서비스 장애
 void KillRandomPod(const string& service_name, double probability = 0.1) {
 if (Random() < probability) {
 kubernetes_client_.DeletePod(GetRandomPod(service_name));
 }
 }

 // 3. CPU 스트레스
 void StressCPU(int percentage, chrono::seconds duration) {
 stress_tool_.InjectCPULoad(percentage, duration);
 }

 // 4. 메모리 압박
 void StressMemory(size_t bytes, chrono::seconds duration) {
 auto garbage = new char[bytes];
 this_thread::sleep_for(duration);
 delete[] garbage;
 }

---
### 카오스 엔지니어링
 // 5. 디스크 I/O 지연
 void InjectDiskLatency(chrono::milliseconds delay) {
 disk_interceptor_.AddLatency(delay);
 }

 // 종합 카오스 시나리오
 void RunChaosScenario() {
 logger.Info("Starting chaos scenario");

 // 10% Pod 랜덤 종료
 KillRandomPod("hmi-backend", 0.1);

 // 네트워크 레이턴시 100ms 주입
 InjectNetworkLatency(100ms);

 // CPU 50% 스트레스 30초
 StressCPU(50, 30s);

 // 시스템이 복원되는지 관찰
 this_thread::sleep_for(60s);

---
### 카오스 엔지니어링
 // 메트릭 확인
 VerifySystemRecovery();
 }

private:
 void VerifySystemRecovery() {
 auto error_rate = prometheus_client_.Query("hmi_errors_total");
 auto latency = prometheus_client_.Query("hmi_request_duration_seconds");
---
### 카오스 엔지니어링
 EXPECT_LT(error_rate, 0.01); // 1% 미만 에러율
 EXPECT_LT(latency.p99, 1.0); // P99 1초 미만
 }
};
```