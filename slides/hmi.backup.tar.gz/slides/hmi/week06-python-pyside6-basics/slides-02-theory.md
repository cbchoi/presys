## Python 기초 개념 복습

### Python 기본 문법과 특징

**Python 언어의 핵심 특징**

<div class="grid grid-cols-2 gap-8">
<div>

**1. 동적 타이핑 (Dynamic Typing)**:
- 변수 선언 시 타입 명시 불필요
- 런타임에 타입 결정
- 유연하지만 주의 필요

---
## Python 기초 개념 복습
```python
# 동적 타이핑 예제
x = 42 # int
x = "Hello" # str (타입 변경 가능)
x = [1, 2, 3] # list
x = {"a": 1} # dict

# 함수도 변수에 할당 가능
def greet():
 return "Hello"

func = greet
print(func()) # "Hello"

# 타입 체크
print(type(x)) # <class 'dict'>
print(isinstance(x, dict)) # True
```

---
## Python 기초 개념 복습
**2. 들여쓰기 (Indentation)**:
- 블록 구분에 중괄호 대신 들여쓰기 사용
- 일관된 들여쓰기 필수 (보통 4칸)

---
## Python 기초 개념 복습
```python
# 올바른 들여쓰기
def calculate_average(numbers):
 if not numbers:
 return 0

 total = 0
 for num in numbers:
 total += num

 return total / len(numbers)

# 클래스도 동일
class TemperatureSensor:
 def __init__(self, sensor_id):
 self.sensor_id = sensor_id
 self.temperature = 0.0

 def read(self):
 # 센서 읽기 로직
 return self.temperature
```

---
## Python 기초 개념 복습
**3. 덕 타이핑 (Duck Typing)**:
- "오리처럼 걷고 오리처럼 꽥꽥거리면 오리다"
- 타입보다 인터페이스(메서드) 중시

---
## Python 기초 개념 복습
```python
# 덕 타이핑 예제
class FileLogger:
 def write(self, message):
 with open("log.txt", "a") as f:
 f.write(message + "\n")

class ConsoleLogger:
 def write(self, message):
 print(message)

class DatabaseLogger:
 def write(self, message):
 # DB에 저장
 pass

# write 메서드만 있으면 사용 가능
def log_equipment_status(logger, equipment):
 logger.write(f"Equipment {equipment.id}: {equipment.status}")

# 어떤 logger든 사용 가능
log_equipment_status(FileLogger(), equipment)
log_equipment_status(ConsoleLogger(), equipment)
```

---
## Python 기초 개념 복습
</div>
<div>

**4. 리스트 컴프리헨션 (List Comprehension)**:
- 간결한 리스트 생성 문법
- 가독성과 성능 우수

---
## Python 기초 개념 복습
```python
# 전통적 방법
squares = []
for i in range(10):
 squares.append(i ** 2)

# 리스트 컴프리헨션
squares = [i ** 2 for i in range(10)]

# 조건 포함
even_squares = [i ** 2 for i in range(10) if i % 2 == 0]

# 딕셔너리 컴프리헨션
sensor_data = {
 f"sensor_{i}": random.random() * 100
 for i in range(5)
}

# 세트 컴프리헨션
unique_statuses = {
 equipment.status
 for equipment in equipment_list
}
```

---
## Python 기초 개념 복습
**5. 제너레이터 (Generator)**:
- 메모리 효율적인 이터레이션
- `yield` 키워드 사용

---
## Python 기초 개념 복습
```python
# 일반 함수: 모든 데이터를 메모리에
def get_sensor_readings_list(count):
 readings = []
 for i in range(count):
 readings.append(read_sensor())
 return readings

# 제너레이터: 필요할 때만 생성
def get_sensor_readings_gen(count):
 for i in range(count):
 yield read_sensor()

# 사용
for reading in get_sensor_readings_gen(1000000):
 process(reading) # 메모리 효율적

# 제너레이터 표현식
squares_gen = (i ** 2 for i in range(1000000))
```

---
## Python 기초 개념 복습
**6. 람다 함수 (Lambda)**:
- 익명 함수
- 간단한 함수 정의

---
## Python 기초 개념 복습
```python
# 정규 함수
def add(x, y):
 return x + y

# 람다 함수
add = lambda x, y: x + y

# 사용 예시
equipment_list.sort(key=lambda e: e.temperature)

filtered = filter(
 lambda e: e.status == "Running",
 equipment_list
)

mapped = map(
 lambda e: e.temperature * 1.8 + 32, # C to F
 equipment_list
)
```

---
## Python 기초 개념 복습
**7. 데코레이터 (Decorator)**:
- 함수/메서드를 수정하는 함수
- 로깅, 타이밍, 권한 체크 등

---
## Python 기초 개념 복습
```python
import time
from functools import wraps

# 실행 시간 측정 데코레이터
def timing_decorator(func):
 @wraps(func)
 def wrapper(*args, **kwargs):
 start = time.perf_counter()
 result = func(*args, **kwargs)
 elapsed = time.perf_counter() - start
 print(f"{func.__name__} took {elapsed:.3f}s")
 return result
 return wrapper

@timing_decorator
def process_wafer_data(wafer_id):
 # 처리 작업
 time.sleep(0.5)
 return f"Processed {wafer_id}"

# 호출하면 자동으로 시간 측정
result = process_wafer_data("W001")
# 출력: process_wafer_data took 0.500s
```

---
## Python 기초 개념 복습
</div>
</div>
---
### Python 객체지향 프로그래밍

**Python의 OOP 구현**

#### 배경: 반도체 장비 HMI의 객체지향 설계 필요성

반도체 제조 장비는 복잡한 하위 시스템들의 집합입니다. CVD, PVD, ETCH 등 각 장비는 고유한 특성을 가지지만 공통 인터페이스가 필요합니다. 객체지향 프로그래밍은 이러한 장비들을 체계적으로 모델링하고, 코드 재사용성과 유지보수성을 극대화합니다.

#### 핵심 개념: 캡슐화와 추상화

Python의 클래스는 데이터(속성)와 동작(메서드)을 하나의 단위로 캡슐화합니다. `__init__` 생성자는 객체 초기화를, property 데코레이터는 안전한 속성 접근을 보장합니다. 이는 Week 1에서 배운 **정보 은닉(Information Hiding)** 원칙을 구현하여 사용자가 필요한 정보만 노출합니다.

<div class="grid grid-cols-2 gap-8">
<div>

**1. 클래스 정의**:
```python
class Equipment:
 # 클래스 변수 (모든 인스턴스 공유)
 equipment_count = 0

 def __init__(self, equipment_id, name):
 """생성자 (Constructor)"""
 # 인스턴스 변수
 self.equipment_id = equipment_id
 self.name = name
 self.status = "Idle"
 self._temperature = 0.0 # protected (관례)
---
### Python 객체지향 프로그래밍
 self.__internal_state = 0 # private (name mangling)

 Equipment.equipment_count += 1

 def start(self):
 """인스턴스 메서드"""
 if self.status == "Idle":
 self.status = "Running"
 return True
 return False

 @property
 def temperature(self):
 """Getter 프로퍼티"""
 return self._temperature

 @temperature.setter
 def temperature(self, value):
 """Setter 프로퍼티"""
---
### Python 객체지향 프로그래밍
 if 0 <= value <= 500:
 self._temperature = value
 else:
 raise ValueError("Temperature out of range")

 @classmethod
 def get_equipment_count(cls):
 """클래스 메서드"""
 return cls.equipment_count

 @staticmethod
 def is_valid_id(equipment_id):
 """정적 메서드"""
 return len(equipment_id) > 0 and equipment_id[0].isalpha()

 def __str__(self):
 """문자열 표현"""
 return f"Equipment({self.equipment_id}, {self.status})"

---
### Python 객체지향 프로그래밍
 def __repr__(self):
 """개발자용 문자열 표현"""
 return f"Equipment(equipment_id='{self.equipment_id}', name='{self.name}')"

# 사용
eq1 = Equipment("E001", "Etcher")
eq1.temperature = 250.0 # setter 호출
print(eq1.temperature) # getter 호출

print(Equipment.get_equipment_count()) # 1
print(Equipment.is_valid_id("E001")) # True
```

#### 코드 해설

**핵심 라인 설명:**
- `self.equipment_id = equipment_id`: 각 장비 인스턴스마다 고유 ID 저장
- `@property def temperature(self)`: getter 메서드로 private 변수를 안전하게 읽기
- `@temperature.setter def temperature(self, value)`: 유효성 검사 후 값 설정
- `Equipment.equipment_count += 1`: 클래스 변수로 생성된 장비 총 개수 추적
- `@classmethod`: 인스턴스가 아닌 클래스 레벨 메서드

#### 실제 사례: CVD 장비 온도 관리

**Samsung Foundry CVD 챔버**: 증착 공정 중 챔버 온도는 250-450°C 범위 유지가 필수입니다. property setter를 사용하면 온도 설정 시 자동으로 범위 검증이 이루어져, 잘못된 값으로 인한 웨이퍼 손상을 방지할 수 있습니다.

#### HCI 연결: Miller's Law 적용

클래스 설계 시 인스턴스 변수를 5-9개 이내로 제한하면 사용자가 객체 상태를 쉽게 파악할 수 있습니다. 복잡한 내부 상태는 private 변수로 숨기고, 필수 정보만 public 인터페이스로 노출합니다.

```mermaid
classDiagram
    class Equipment {
        +String equipment_id
        +String name
        +String status
        -float _temperature
        -int __internal_state
        +start() bool
        +get temperature() float
        +set temperature(value)
    }
    Equipment : +classmethod get_equipment_count()
    Equipment : +staticmethod is_valid_id()
```

---
### Python 객체지향 프로그래밍
**2. 상속 (Inheritance)**:
```python
class CVDEquipment(Equipment):
 """CVD 장비 클래스"""

 def __init__(self, equipment_id, name, gas_type):
---
### Python 객체지향 프로그래밍
 # 부모 클래스 생성자 호출
 super().__init__(equipment_id, name)
 self.gas_type = gas_type
 self.gas_flow = 0.0

 def start(self):
 """메서드 오버라이드"""
 # 부모 메서드 호출
 if super().start():
 self._preheat_chamber()
 self._start_gas_flow()
 return True
 return False

 def _preheat_chamber(self):
 """CVD 전용 메서드"""
 print("Preheating chamber...")

---
### Python 객체지향 프로그래밍
 def _start_gas_flow(self):
 self.gas_flow = 100.0
 print(f"Starting {self.gas_type} flow...")

# 사용
cvd = CVDEquipment("CVD001", "PECVD", "SiH4")
cvd.start()
```

</div>
<div>

**3. 다중 상속 (Multiple Inheritance)**:
```python
class Loggable:
 """로깅 믹스인 클래스"""
 def log(self, message):
 print(f"[{self.__class__.__name__}] {message}")

---
### Python 객체지향 프로그래밍
class Monitorable:
 """모니터링 믹스인 클래스"""
 def get_metrics(self):
 return {
 "status": getattr(self, "status", "Unknown"),
 "temperature": getattr(self, "temperature", 0)
 }

class AdvancedEquipment(Equipment, Loggable, Monitorable):
 """다중 상속 예제"""
 def start(self):
 self.log("Starting equipment...")
 result = super().start()
 if result:
 self.log("Equipment started successfully")
 return result

---
### Python 객체지향 프로그래밍
# 사용
adv_eq = AdvancedEquipment("AE001", "Advanced Etcher")
adv_eq.start() # 로깅 포함
metrics = adv_eq.get_metrics()
```

**4. 매직 메서드 (Magic Methods / Dunder Methods)**:
```python
class SensorReading:
 def __init__(self, value, timestamp):
 self.value = value
 self.timestamp = timestamp

 def __eq__(self, other):
 """== 연산자"""
 return self.value == other.value

 def __lt__(self, other):
---
### Python 객체지향 프로그래밍
 """< 연산자"""
 return self.value < other.value

 def __add__(self, other):
 """+ 연산자"""
 return SensorReading(
 self.value + other.value,
 max(self.timestamp, other.timestamp)
 )

 def __len__(self):
 """len() 함수"""
 return 1

 def __getitem__(self, key):
 """인덱싱 []"""
 if key == 0:
 return self.value
---
### Python 객체지향 프로그래밍
 elif key == 1:
 return self.timestamp
 raise IndexError()

 def __iter__(self):
 """이터레이션"""
 yield self.value
 yield self.timestamp

 def __enter__(self):
 """컨텍스트 매니저"""
 return self

 def __exit__(self, *args):
 print("Cleaning up...")
 return False

# 사용
r1 = SensorReading(25.5, time.time())
---
### Python 객체지향 프로그래밍
r2 = SensorReading(30.0, time.time())

print(r1 == r2) # False (__eq__)
print(r1 < r2) # True (__lt__)
r3 = r1 + r2 # __add__
value, ts = r1 # __iter__
```

**5. 프로퍼티 (Property)**:
```python
class TemperatureController:
 def __init__(self):
 self._celsius = 0.0

 @property
 def celsius(self):
 """섭씨 온도"""
 return self._celsius

---
### Python 객체지향 프로그래밍
 @celsius.setter
 def celsius(self, value):
 if value < -273.15:
 raise ValueError("Temperature below absolute zero")
 self._celsius = value

 @property
 def fahrenheit(self):
 """화씨 온도 (읽기 전용)"""
 return self._celsius * 9/5 + 32

 @property
 def kelvin(self):
 """켈빈 온도"""
 return self._celsius + 273.15

 @kelvin.setter
 def kelvin(self, value):
---
### Python 객체지향 프로그래밍
 self.celsius = value - 273.15

# 사용
tc = TemperatureController()
tc.celsius = 25.0
print(tc.fahrenheit) # 77.0 (자동 계산)
tc.kelvin = 300
print(tc.celsius) # 26.85
```

</div>
</div>
---
### Python 타입 힌팅 (Type Hinting)

**Python 3.5+ 타입 주석**

<div class="grid grid-cols-2 gap-8">
<div>

**기본 타입 힌팅**:
```python
from typing import List, Dict, Tuple, Optional, Union, Any

# 변수 타입 힌팅
name: str = "Equipment-001"
temperature: float = 25.5
is_running: bool = True

# 함수 타입 힌팅
def calculate_average(numbers: List[float]) -> float:
 """평균 계산"""
 if not numbers:
 return 0.0
---
### Python 타입 힌팅 (Type Hinting)
 return sum(numbers) / len(numbers)

# Optional: None 가능
def find_equipment(equipment_id: str) -> Optional[Equipment]:
 """장비 검색"""
 # 찾으면 Equipment 반환, 못 찾으면 None
 ...

# Union: 여러 타입 가능
def process_value(value: Union[int, float, str]) -> str:
 """다양한 타입 처리"""
 return str(value)

# Dict 타입
def get_sensor_data() -> Dict[str, float]:
 """센서 데이터 반환"""
 return {
 "temperature": 25.5,
---
### Python 타입 힌팅 (Type Hinting)
 "pressure": 1.2,
 "flow_rate": 100.0
 }

# Tuple 타입
def get_coordinates() -> Tuple[float, float, float]:
 """X, Y, Z 좌표"""
 return (1.0, 2.0, 3.0)

# 제네릭
from typing import TypeVar, Generic

T = TypeVar('T')

class DataBuffer(Generic[T]):
 def __init__(self):
 self.items: List[T] = []

 def add(self, item: T) -> None:
 self.items.append(item)

---
### Python 타입 힌팅 (Type Hinting)
 def get(self, index: int) -> T:
 return self.items[index]

# 사용
int_buffer: DataBuffer[int] = DataBuffer()
int_buffer.add(42)

str_buffer: DataBuffer[str] = DataBuffer()
str_buffer.add("Hello")
```

</div>
<div>

**고급 타입 힌팅**:
```python
from typing import Callable, Protocol, Literal

# Callable: 함수 타입
def apply_filter(
---
### Python 타입 힌팅 (Type Hinting)
 data: List[float],
 filter_func: Callable[[float], bool]
) -> List[float]:
 """필터 함수 적용"""
 return [x for x in data if filter_func(x)]

# 사용
filtered = apply_filter(
 [1.0, 2.0, 3.0],
 lambda x: x > 1.5
)

# Protocol: 구조적 서브타이핑
class Readable(Protocol):
 """읽기 가능한 객체의 프로토콜"""
 def read(self) -> str:
 ...

---
### Python 타입 힌팅 (Type Hinting)
class FileSensor:
 def read(self) -> str:
 return "sensor data"

class NetworkSensor:
 def read(self) -> str:
 return "network data"

def process_readable(obj: Readable) -> None:
 """Readable 프로토콜을 따르는 모든 객체 처리"""
 data = obj.read()
 print(data)

# FileSensor와 NetworkSensor 모두 사용 가능
process_readable(FileSensor())
process_readable(NetworkSensor())

# Literal: 특정 값만 허용
EquipmentStatus = Literal["Idle", "Running", "Error", "Maintenance"]

---
### Python 타입 힌팅 (Type Hinting)
def set_status(status: EquipmentStatus) -> None:
 """상태 설정 (특정 문자열만 허용)"""
 print(f"Status: {status}")

set_status("Running") # OK
# set_status("Unknown") # 타입 체커 경고

# TypedDict: 딕셔너리 구조 정의
from typing import TypedDict

class EquipmentData(TypedDict):
 id: str
 name: str
 temperature: float
 status: EquipmentStatus

# 사용
eq_data: EquipmentData = {
 "id": "E001",
---
### Python 타입 힌팅 (Type Hinting)
 "name": "Etcher",
 "temperature": 25.5,
 "status": "Running"
}
```

**타입 체킹 도구**:
```bash
# mypy 설치
pip install mypy

# 타입 체크 실행
mypy equipment.py

# pyright (Microsoft)
pip install pyright
pyright equipment.py
---
### Python 타입 힌팅 (Type Hinting)
```

**타입 힌팅의 장점**:
- IDE 자동완성 향상
- 버그 조기 발견
- 코드 문서화
- 리팩터링 안전성

</div>
</div>
---
## Python 디자인 패턴

### Context Manager Pattern

**`with` 문을 통한 리소스 관리**

<div class="grid grid-cols-2 gap-8">
<div>

---
## Python 디자인 패턴
```python
# Context Manager Protocol
class DatabaseConnection:
 def __init__(self, db_path):
 self.db_path = db_path
 self.connection = None

 def __enter__(self):
 """진입 시 실행: 리소스 획득"""
 import sqlite3
 self.connection = sqlite3.connect(self.db_path)
 print(f"Database {self.db_path} opened")
 return self.connection

 def __exit__(self, exc_type, exc_val, exc_tb):
 """종료 시 실행: 리소스 해제"""
 if self.connection:
 if exc_type is None:
 # 예외 없이 정상 종료
 self.connection.commit()
 print("Changes committed")
 else:
 # 예외 발생 시 롤백
 self.connection.rollback()
 print(f"Error occurred: {exc_val}")
 print("Changes rolled back")

---
## Python 디자인 패턴
 self.connection.close()
 print("Database closed")

 # False 반환 시 예외 전파, True 반환 시 예외 억제
 return False

# 사용
with DatabaseConnection("equipment.db") as conn:
 cursor = conn.cursor()
 cursor.execute("""
 INSERT INTO equipment (id, name, status)
 VALUES (?, ?, ?)
 """, ("E001", "Etcher", "Running"))
 # with 블록 종료 시 자동으로 commit & close
```
---
## Python 디자인 패턴
```python
from contextlib import contextmanager
import time

@contextmanager
def timer(operation_name):
 """실행 시간 측정 컨텍스트"""
 start = time.perf_counter()
 print(f"Starting {operation_name}...")

 try:
 yield # 여기서 with 블록 실행
 finally:
 elapsed = time.perf_counter() - start
 print(f"{operation_name} completed in {elapsed:.3f}s")

# 사용
with timer("Data Processing"):
 # 처리 작업
 process_sensor_data()
 calculate_statistics()
# 자동으로 시간 측정 및 출력
```

---
## Python 디자인 패턴
</div>
<div>

**Context Manager의 핵심**:
- **`__enter__()`**: with 진입 시 호출
 - 리소스 획득 (파일 열기, DB 연결 등)
 - 반환값이 `as` 변수로 전달

- **`__exit__()`**: with 종료 시 호출
 - 리소스 해제 (정리 작업)
 - 예외 발생 여부와 관계없이 실행
 - 예외 정보 수신 (exc_type, exc_val, exc_tb)

**장점**:
- 리소스 누수 방지
- 예외 안전성 보장
- 코드 가독성 향상
- RAII 패턴의 Python 구현

---
## Python 디자인 패턴
```python
@contextmanager
def equipment_operation(equipment_id):
 """장비 작업 컨텍스트"""
 equipment = get_equipment(equipment_id)

 # 시작 전 검증
 if not equipment.is_idle():
 raise EquipmentBusyError(equipment_id)

 equipment.start()
 equipment.log("Operation started")

 try:
 yield equipment
 except Exception as e:
 equipment.abort()
 equipment.log(f"Operation aborted: {e}")
 raise
 finally:
 equipment.stop()
 equipment.log("Operation completed")

# 사용
with equipment_operation("E001") as etcher:
 etcher.set_temperature(250)
 etcher.process_wafer("W12345")
 etcher.wait_until_complete()
# 자동으로 stop() 및 로깅
```

---
## Python 디자인 패턴
**다중 컨텍스트**:
```python
# 여러 리소스 동시 관리
with (
 DatabaseConnection("equipment.db") as db,
 LogFile("process.log") as log,
 equipment_operation("E001") as etcher
):
 log.write("Starting process")
 etcher.process_wafer("W001")
 db.cursor().execute("INSERT INTO ...")
# 모든 리소스 자동 정리 (역순)
```

**contextlib 유틸리티**:
```python
---
## Python 디자인 패턴
from contextlib import suppress, redirect_stdout

# 예외 무시
with suppress(FileNotFoundError):
 os.remove("temp_file.txt")

# 출력 리다이렉션
with open("output.txt", "w") as f:
 with redirect_stdout(f):
 print("이 내용은 파일로 저장됨")
```

</div>
</div>
---
### Descriptor Pattern

**속성 접근 제어 및 검증**

<div class="grid grid-cols-2 gap-8">
<div>

---
### Descriptor Pattern
```python
# Descriptor Protocol
class TemperatureDescriptor:
 def __init__(self, min_value=0, max_value=300):
 self.min_value = min_value
 self.max_value = max_value
 self.data = {} # 인스턴스별 값 저장

 def __set_name__(self, owner, name):
 """Python 3.6+: descriptor 이름 자동 저장"""
 self.name = name

 def __get__(self, instance, owner):
 """값 읽기"""
 if instance is None:
 return self # 클래스에서 접근 시
 return self.data.get(id(instance), self.min_value)

 def __set__(self, instance, value):
 """값 쓰기 (검증 포함)"""
 if not isinstance(value, (int, float)):
 raise TypeError(
 f"{self.name} must be numeric, "
 f"got {type(value).__name__}"
 )

---
### Descriptor Pattern
 if not (self.min_value <= value <= self.max_value):
 raise ValueError(
 f"{self.name} must be between "
 f"{self.min_value} and {self.max_value}, "
 f"got {value}"
 )

 self.data[id(instance)] = value
 print(f"{self.name} set to {value}")

 def __delete__(self, instance):
 """값 삭제"""
 self.data.pop(id(instance), None)

class Equipment:
 # Descriptor 인스턴스를 클래스 변수로 선언
 temperature = TemperatureDescriptor(0, 300)
 pressure = TemperatureDescriptor(0, 10)

 def __init__(self, equipment_id):
 self.equipment_id = equipment_id
 self.temperature = 25 # Descriptor를 통해 검증됨
 self.pressure = 1.0

---
### Descriptor Pattern
# 사용
etcher = Equipment("E001")
etcher.temperature = 150 # OK
# 출력: temperature set to 150
---
### Descriptor Pattern
try:
 etcher.temperature = 350 # ValueError!
except ValueError as e:
 print(e)
# 출력: temperature must be between 0 and 300, got 350

try:
 etcher.temperature = "hot" # TypeError!
except TypeError as e:
 print(e)
# 출력: temperature must be numeric, got str
```
---
### Descriptor Pattern
</div>
<div>

**Descriptor Protocol**:
- **`__get__(self, instance, owner)`**: 속성 읽기
- **`__set__(self, instance, value)`**: 속성 쓰기
- **`__delete__(self, instance)`**: 속성 삭제
- **`__set_name__(self, owner, name)`**: 이름 자동 설정

**장점**:
- 재사용 가능한 검증 로직
- DRY 원칙 준수
- @property보다 유연함
- 여러 속성에 동일 로직 적용

**실무 활용 - Typed Descriptor**:

---
### Descriptor Pattern
```python
class TypedDescriptor:
 def __init__(self, expected_type,
 validator=None, default=None):
 self.expected_type = expected_type
 self.validator = validator
 self.default = default
 self.data = {}

 def __set_name__(self, owner, name):
 self.name = name

 def __get__(self, instance, owner):
 if instance is None:
 return self
 return self.data.get(
 id(instance), self.default)

 def __set__(self, instance, value):
 if not isinstance(value,
 self.expected_type):
 raise TypeError(
 f"{self.name} must be "
 f"{self.expected_type.__name__}")

---
### Descriptor Pattern
 if self.validator and \
 not self.validator(value):
 raise ValueError(
 f"Invalid value for {self.name}: "
 f"{value}")

 self.data[id(instance)] = value

class WaferProcessor:
 # 타입 검증 + 커스텀 검증
 wafer_id = TypedDescriptor(
 str,
 validator=lambda x: x.startswith("W"),
 default=""
 )

 slot_number = TypedDescriptor(
 int,
 validator=lambda x: 1 <= x <= 25,
 default=1
 )

---
### Descriptor Pattern
 temperature = TypedDescriptor(
 float,
 validator=lambda x: 0 <= x <= 400,
 default=25.0
 )
---
### Descriptor Pattern
processor = WaferProcessor()
processor.wafer_id = "W12345" # OK
processor.slot_number = 10 # OK
processor.temperature = 250.0 # OK

try:
 processor.wafer_id = 12345 # TypeError
except TypeError as e:
 print(e)

try:
 processor.slot_number = 30 # ValueError
except ValueError as e:
 print(e)
```
---
### Descriptor Pattern
**@property와 비교**:
```python
# @property (단일 속성)
class Equipment:
 def __init__(self):
 self._temp = 0

 @property
 def temperature(self):
 return self._temp

 @temperature.setter
 def temperature(self, value):
 if not 0 <= value <= 300:
 raise ValueError("Out of range")
 self._temp = value

# Descriptor (재사용 가능)
---
### Descriptor Pattern
class Equipment:
 temperature = RangeDescriptor(0, 300)
 pressure = RangeDescriptor(0, 10)
 voltage = RangeDescriptor(0, 500)
 # 검증 로직 재사용!
```

</div>
</div>
---
### Property Pattern

**Pythonic한 getter/setter**

<div class="grid grid-cols-2 gap-8">
<div>

---
### Property Pattern
```python
class Equipment:
 def __init__(self, equipment_id):
 self.equipment_id = equipment_id
 self._temperature = 25.0
 self._status = "Idle"
 self._alarm_count = 0

 # Read-only property
 @property
 def equipment_id(self):
 """장비 ID (읽기 전용)"""
 return self._equipment_id

 @equipment_id.setter
 def equipment_id(self, value):
 # 초기 설정만 허용
 if hasattr(self, '_equipment_id'):
 raise AttributeError(
 "equipment_id is read-only after initialization")
 self._equipment_id = value

 # Read-write property with validation
 @property
 def temperature(self):
 """온도 (℃)"""
 return self._temperature

---
### Property Pattern
 @temperature.setter
 def temperature(self, value):
 if not isinstance(value, (int, float)):
 raise TypeError("Temperature must be numeric")

 if not (0 <= value <= 300):
 raise ValueError(
 f"Temperature {value} out of range [0, 300]")

 old_value = self._temperature
 self._temperature = value

 # 로깅
 print(f"Temperature changed: {old_value} → {value}")

 # 알람 체크
 if value > 250:
 self._trigger_high_temp_alarm()

 @temperature.deleter
 def temperature(self):
 """온도 리셋"""
 print("Resetting temperature to default")
 self._temperature = 25.0

---
### Property Pattern
 # Computed property (계산된 속성)
 @property
 def status_display(self):
 """사용자 표시용 상태 문자열"""
 alarm_suffix = ""
 if self._alarm_count > 0:
 alarm_suffix = f" ({self._alarm_count} alarms)"
---
### Property Pattern
 return f"[{self.equipment_id}] {self._status}" + alarm_suffix

 # Property with caching
 @property
 def is_healthy(self):
 """장비 건강 상태 (캐시됨)"""
 if not hasattr(self, '_health_cache'):
 # 비용이 큰 계산
 self._health_cache = self._calculate_health()
 return self._health_cache

 def invalidate_health_cache(self):
 """건강 상태 캐시 무효화"""
 if hasattr(self, '_health_cache'):
 delattr(self, '_health_cache')

 def _calculate_health(self):
 """건강 상태 계산 (비용이 큼)"""
 # 복잡한 계산 로직...
 return self._alarm_count == 0 and \
 self._temperature < 250
```
---
### Property Pattern
</div>
<div>

**@property 데코레이터**:
- **getter**: `@property`
- **setter**: `@<name>.setter`
- **deleter**: `@<name>.deleter`

**사용 패턴**:

**1. Read-only (읽기 전용)**:
```python
class Wafer:
 def __init__(self, wafer_id):
 self._id = wafer_id
 self._created_at = datetime.now()

 @property
 def wafer_id(self):
---
### Property Pattern
 return self._id
 # setter 없음 → 읽기 전용

wafer = Wafer("W001")
print(wafer.wafer_id) # OK
wafer.wafer_id = "W002" # AttributeError!
```

**2. Lazy Loading (지연 로딩)**:
```python
class DataAnalyzer:
 def __init__(self, data_path):
 self.data_path = data_path
 self._data = None # 아직 로드 안 함

 @property
 def data(self):
 """데이터 지연 로딩"""
---
### Property Pattern
 if self._data is None:
 print("Loading data...")
 self._data = load_large_dataset(
 self.data_path)
 return self._data

analyzer = DataAnalyzer("sensors.csv")
# 여기까지는 데이터 로드 안 함
result = analyzer.data.mean()
# 첫 접근 시 로드
```

**3. Computed Property (계산)**:
```python
class Rectangle:
 def __init__(self, width, height):
 self.width = width
---
### Property Pattern
 self.height = height

 @property
 def area(self):
 return self.width * self.height

 @property
 def perimeter(self):
 return 2 * (self.width + self.height)

rect = Rectangle(10, 5)
print(rect.area) # 50 (계산됨)
print(rect.perimeter) # 30 (계산됨)
```

**4. 변경 알림 (Change Notification)**:
```python
class ObservableEquipment:
 def __init__(self):
---
### Property Pattern
 self._temperature = 25
 self.observers = []

 @property
 def temperature(self):
 return self._temperature

 @temperature.setter
 def temperature(self, value):
 old = self._temperature
 self._temperature = value
 # 모든 옵저버에게 알림
 for observer in self.observers:
 observer.on_temperature_changed(
 old, value)
---
### Property Pattern
```

**장점**:
- Pythonic한 캡슐화
- 내부 구현 숨김
- 계산 로직 추상화
- 검증 및 로깅 중앙화

</div>
</div>
---
### Decorator Pattern (함수/메서드)

**함수 동작 확장**

<div class="grid grid-cols-2 gap-8">
<div>

---
### Decorator Pattern (함수/메서드)
```python
import functools
import time
from typing import Callable

# 1. 기본 Decorator
def timer(func: Callable) -> Callable:
 """실행 시간 측정 데코레이터"""
 @functools.wraps(func)
 def wrapper(*args, **kwargs):
 start = time.perf_counter()
 result = func(*args, **kwargs)
 elapsed = time.perf_counter() - start
 print(f"{func.__name__} took {elapsed:.3f}s")
 return result
 return wrapper

@timer
def process_wafer(wafer_id: str):
 print(f"Processing {wafer_id}...")
 time.sleep(1)
 return f"Completed {wafer_id}"

# 사용
result = process_wafer("W001")
# 출력:
# Processing W001...
# process_wafer took 1.001s

---
### Decorator Pattern (함수/메서드)
# 2. 파라미터를 받는 Decorator
def retry(max_attempts: int = 3,
 delay: float = 1.0):
 """재시도 데코레이터"""
 def decorator(func: Callable) -> Callable:
 @functools.wraps(func)
 def wrapper(*args, **kwargs):
 for attempt in range(1, max_attempts + 1):
 try:
 return func(*args, **kwargs)
 except Exception as e:
 if attempt == max_attempts:
 raise
 print(f"Attempt {attempt} failed: {e}")
 print(f"Retrying in {delay}s...")
 time.sleep(delay)
 return wrapper
 return decorator

---
### Decorator Pattern (함수/메서드)
@retry(max_attempts=3, delay=0.5)
def unstable_sensor_read():
 """불안정한 센서 읽기"""
 import random
 if random.random() < 0.7:
 raise IOError("Sensor read failed")
 return 125.5
---
### Decorator Pattern (함수/메서드)
# 3. 클래스 Decorator
def singleton(cls):
 """싱글톤 패턴 구현"""
 instances = {}

 @functools.wraps(cls)
 def get_instance(*args, **kwargs):
 if cls not in instances:
 instances[cls] = cls(*args, **kwargs)
 return instances[cls]

 return get_instance

@singleton
class DatabaseConnection:
 def __init__(self, db_path):
 self.db_path = db_path
 print(f"Connected to {db_path}")

# 항상 같은 인스턴스 반환
db1 = DatabaseConnection("equipment.db")
db2 = DatabaseConnection("equipment.db")
print(db1 is db2) # True
```
---
### Decorator Pattern (함수/메서드)
</div>
<div>

**Decorator 핵심**:
- 함수/클래스를 받아 수정된 버전 반환
- 원본 코드 변경 없이 기능 추가
- `@` 문법으로 간편하게 적용
- `functools.wraps`로 메타데이터 보존

**반도체 HMI 적용 예시**:

---
### Decorator Pattern (함수/메서드)
```python
def log_equipment_operation(func):
 """장비 작업 로깅"""
 @functools.wraps(func)
 def wrapper(self, *args, **kwargs):
 logger.info(
 f"[{self.equipment_id}] "
 f"Starting {func.__name__}")

 try:
 result = func(self, *args, **kwargs)
 logger.info(
 f"[{self.equipment_id}] "
 f"{func.__name__} completed")
 return result
 except Exception as e:
 logger.error(
 f"[{self.equipment_id}] "
 f"{func.__name__} failed: {e}")
 raise

 return wrapper

---
### Decorator Pattern (함수/메서드)
def require_idle_state(func):
 """Idle 상태 검증"""
 @functools.wraps(func)
 def wrapper(self, *args, **kwargs):
 if self.status != "Idle":
 raise EquipmentBusyError(
 f"Equipment {self.equipment_id} "
 f"is {self.status}")
 return func(self, *args, **kwargs)
 return wrapper

class Equipment:
 @log_equipment_operation
 @require_idle_state
 def start_process(self, recipe):
 """공정 시작"""
 self.status = "Running"
 self.execute_recipe(recipe)
 return True
```
---
### Decorator Pattern (함수/메서드)
**다중 Decorator 적용**:
```python
@timer
@retry(max_attempts=3)
@log_equipment_operation
def critical_operation():
 # 실행 순서 (아래에서 위로):
 # 1. log_equipment_operation
 # 2. retry
 # 3. timer
 pass
```

**functools.lru_cache (내장)**:
```python
from functools import lru_cache

---
### Decorator Pattern (함수/메서드)
@lru_cache(maxsize=128)
def expensive_calculation(n):
 """비용이 큰 계산 (캐싱)"""
 time.sleep(1)
 return n ** 2

# 첫 호출: 1초 소요
result1 = expensive_calculation(10)

# 두 번째 호출: 즉시 반환 (캐시)
result2 = expensive_calculation(10)
```

**클래스 메서드 Decorator**:
```python
class Equipment:
 @staticmethod
 def validate_id(equipment_id: str):
---
### Decorator Pattern (함수/메서드)
 """정적 메서드"""
 return equipment_id.startswith("E")

 @classmethod
 def create_default(cls):
 """클래스 메서드"""
 return cls("E000", "Default")

 @property
 def status_code(self):
 """프로퍼티"""
 return self._status_code
```

</div>
</div>
---
## C# WPF vs Python PySide6 비교

### 아키텍처 및 철학의 차이

| 측면 | C# WPF | Python PySide6 |
|------|--------|----------------|
| **플랫폼** | Windows 전용 | 크로스 플랫폼 (Windows, Linux, macOS) |
| **언어** | C# (.NET) | Python |
| **UI 프레임워크** | WPF (Windows Presentation Foundation) | Qt 6.x |
| **데이터 바인딩** | XAML 기반 강력한 바인딩 | 시그널-슬롯 + 수동 바인딩 |
| **UI 설계** | XAML + Blend | Qt Designer + Python 코드 |
| **성능** | 네이티브 컴파일, 높은 성능 | 인터프리터 기반, 적당한 성능 |
| **개발 생산성** | Visual Studio 통합 | 유연한 IDE 선택 |

### 주요 개념 매핑

<div class="code-section">

**C# WPF → Python PySide6 개념 매핑**

---
## C# WPF vs Python PySide6 비교
```python
# C# WPF 개념 → PySide6 개념
"""
Window → QMainWindow, QWidget
UserControl → QWidget (커스텀)
DataBinding → Signal-Slot + Property
Command → Signal-Slot
MVVM → MVC/MVP (Model-View-Controller)
Dependency Injection → Python 모듈 시스템
ObservableCollection → QAbstractItemModel
INotifyPropertyChanged → QObject.signal
Event → Signal
"""

# 1. C# WPF의 Window
# public partial class MainWindow : Window
# {
# public MainWindow() { InitializeComponent(); }
# }

# PySide6 equivalent
from PySide6.QtWidgets import QMainWindow, QApplication
from PySide6.QtCore import QObject, Signal

class MainWindow(QMainWindow):
 def __init__(self):
 super().__init__()
 self.setupUi()

# 2. C# WPF의 Data Binding
# <TextBox Text="{Binding Name}" />

# PySide6 equivalent - Signal/Slot 방식
class DataModel(QObject):
 nameChanged = Signal(str) # C#의 PropertyChanged 이벤트와 유사

---
## C# WPF vs Python PySide6 비교
 def __init__(self):
 super().__init__()
 self._name = ""

 @property
 def name(self):
 return self._name

 @name.setter
 def name(self, value):
 if self._name != value:
 self._name = value
 self.nameChanged.emit(value) # 변경 알림

# 3. C# WPF의 Command
# <Button Command="{Binding SaveCommand}" />

# PySide6 equivalent - Signal/Slot
from PySide6.QtWidgets import QPushButton

button = QPushButton("Save")
button.clicked.connect(self.save_data) # 직접 연결
```
---
## C# WPF vs Python PySide6 비교
</div>

## PySide6 핵심 구조

### Qt 모듈 구조

<div class="code-section">

**주요 PySide6 모듈**

---
## C# WPF vs Python PySide6 비교
```python
# 1. QtWidgets - GUI 위젯 및 레이아웃
from PySide6.QtWidgets import (
 QApplication, # 애플리케이션 객체
 QMainWindow, # 메인 윈도우
 QWidget, # 기본 위젯
 QPushButton, # 버튼
 QLabel, # 레이블
 QLineEdit, # 텍스트 입력
 QTableWidget, # 테이블
 QVBoxLayout, # 수직 레이아웃
 QHBoxLayout, # 수평 레이아웃
 QGridLayout, # 그리드 레이아웃
 QSplitter, # 분할 위젯
 QTabWidget, # 탭 위젯
 QTreeWidget, # 트리 위젯
 QGraphicsView, # 그래픽 뷰
 QMenuBar, # 메뉴바
 QStatusBar, # 상태바
 QToolBar, # 툴바
 QDockWidget, # 도킹 위젯
)

---
## C# WPF vs Python PySide6 비교
# 2. QtCore - 핵심 기능 (시그널, 슬롯, 타이머 등)
from PySide6.QtCore import (
 QObject, # 모든 Qt 객체의 기본 클래스
 Signal, # 시그널 정의
 Slot, # 슬롯 데코레이터
 QTimer, # 타이머
 QThread, # 스레드
 QSettings, # 설정 관리
 QFileInfo, # 파일 정보
 QDir, # 디렉토리
 QDateTime, # 날짜/시간
 QSize, # 크기
 QPoint, # 좌표
 QRect, # 사각형
 Property, # 프로퍼티
 QAbstractItemModel, # 데이터 모델
)

---
## C# WPF vs Python PySide6 비교
# 3. QtGui - 그래픽 및 입력 처리
from PySide6.QtGui import (
 QPixmap, # 이미지
 QIcon, # 아이콘
 QFont, # 폰트
 QColor, # 색상
 QPainter, # 그리기
 QPen, # 펜
 QBrush, # 브러시
 QKeySequence, # 키 시퀀스
 QAction, # 액션
 QValidator, # 입력 검증
)
---
## C# WPF vs Python PySide6 비교
# 4. QtCharts - 차트 위젯 (별도 설치 필요)
from PySide6.QtCharts import (
 QChart, # 차트
 QChartView, # 차트 뷰
 QLineSeries, # 라인 시리즈
 QBarSeries, # 바 시리즈
 QValueAxis, # 값 축
)

# 5. QtOpenGL - OpenGL 지원
from PySide6.QtOpenGL import QOpenGLWidget

# 6. Qt3DCore, Qt3DRender - 3D 지원 (고급)
# from PySide6.Qt3DCore import QEntity
# from PySide6.Qt3DRender import QCamera
```
---
## C# WPF vs Python PySide6 비교
</div>

### 시그널-슬롯 메커니즘

<div class="code-section">

**시그널-슬롯 패턴 이해**

#### 배경: 반도체 장비 HMI의 비동기 이벤트 처리 문제

반도체 제조 공정에서는 온도 센서, 압력 게이지, 가스 유량계 등 다양한 센서가 실시간으로 데이터를 생성합니다. 이러한 데이터를 UI에 즉시 반영하되, 센서 읽기와 UI 업데이트가 서로 독립적으로 동작해야 합니다. 시그널-슬롯 메커니즘은 이러한 느슨한 결합(Loose Coupling)을 가능하게 합니다.

#### 핵심 개념: 이벤트 기반 아키텍처

**Signal**: 이벤트 발생을 알리는 방송국 같은 역할. 여러 리스너가 동시에 수신 가능
**Slot**: 시그널을 받아 처리하는 함수. 하나의 시그널에 여러 슬롯 연결 가능
**emit()**: 시그널 발송. 연결된 모든 슬롯이 순차적으로 실행
**connect()**: 시그널과 슬롯을 연결하는 배선 작업

시그널-슬롯은 **Observer 패턴**의 Qt 구현으로, 발신자와 수신자를 분리하여 유지보수성과 확장성을 높입니다.

---
## C# WPF vs Python PySide6 비교
```python
from PySide6.QtCore import QObject, Signal, Slot
from PySide6.QtWidgets import QWidget, QPushButton, QLineEdit, QVBoxLayout

class EquipmentController(QObject):
 """장비 컨트롤러 - 시그널 정의"""

 # 커스텀 시그널 정의
 temperatureChanged = Signal(float) # 온도 변경 시그널
 pressureChanged = Signal(float) # 압력 변경 시그널
 statusChanged = Signal(str) # 상태 변경 시그널
 errorOccurred = Signal(str, int) # 에러 발생 시그널 (메시지, 코드)
 processCompleted = Signal(bool, str) # 프로세스 완료 시그널

 def __init__(self):
 super().__init__()
 self._temperature = 0.0
 self._pressure = 0.0
 self._status = "Idle"

 def update_temperature(self, temp):
 """온도 업데이트 및 시그널 발송"""
 if self._temperature != temp:
 self._temperature = temp
 self.temperatureChanged.emit(temp)

---
## C# WPF vs Python PySide6 비교
 # 임계값 검사
 if temp > 200:
 self.errorOccurred.emit(f"High temperature: {temp}°C", 1001)

 def update_pressure(self, pressure):
 """압력 업데이트 및 시그널 발송"""
 if self._pressure != pressure:
 self._pressure = pressure
 self.pressureChanged.emit(pressure)

 def set_status(self, status):
 """상태 변경 및 시그널 발송"""
 if self._status != status:
 old_status = self._status
 self._status = status
 self.statusChanged.emit(status)
 print(f"Status changed: {old_status} → {status}")

class EquipmentDisplay(QWidget):
 """장비 디스플레이 - 슬롯 정의"""

---
## C# WPF vs Python PySide6 비교
 def __init__(self, controller):
 super().__init__()
 self.controller = controller
 self.setupUI()
 self.connectSignals()
---
## C# WPF vs Python PySide6 비교
 def setupUI(self):
 """UI 구성"""
 layout = QVBoxLayout()

 # 온도 표시
 self.temp_label = QLabel("Temperature: 0°C")
 layout.addWidget(self.temp_label)

 # 압력 표시
 self.pressure_label = QLabel("Pressure: 0 Torr")
 layout.addWidget(self.pressure_label)

 # 상태 표시
 self.status_label = QLabel("Status: Idle")
 layout.addWidget(self.status_label)

 # 에러 메시지
 self.error_label = QLabel("")
 self.error_label.setStyleSheet("color: red; font-weight: bold;")
 layout.addWidget(self.error_label)

 # 제어 버튼
 self.start_button = QPushButton("Start Process")
 self.stop_button = QPushButton("Stop Process")
 layout.addWidget(self.start_button)
 layout.addWidget(self.stop_button)

---
## C# WPF vs Python PySide6 비교
 self.setLayout(layout)

 def connectSignals(self):
 """시그널-슬롯 연결"""
 # 컨트롤러 시그널을 디스플레이 슬롯에 연결
 self.controller.temperatureChanged.connect(self.on_temperature_changed)
 self.controller.pressureChanged.connect(self.on_pressure_changed)
 self.controller.statusChanged.connect(self.on_status_changed)
 self.controller.errorOccurred.connect(self.on_error_occurred)
---
## C# WPF vs Python PySide6 비교
 # 버튼 클릭을 컨트롤러 메서드에 연결
 self.start_button.clicked.connect(self.start_process)
 self.stop_button.clicked.connect(self.stop_process)

 @Slot(float)
 def on_temperature_changed(self, temp):
 """온도 변경 슬롯"""
 self.temp_label.setText(f"Temperature: {temp:.1f}°C")

 # 온도에 따른 색상 변경
 if temp > 200:
 self.temp_label.setStyleSheet("color: red; font-weight: bold;")
 elif temp > 150:
 self.temp_label.setStyleSheet("color: orange; font-weight: bold;")
 else:
 self.temp_label.setStyleSheet("color: green;")

 @Slot(float)
 def on_pressure_changed(self, pressure):
 """압력 변경 슬롯"""
 self.pressure_label.setText(f"Pressure: {pressure:.2f} Torr")

---
## C# WPF vs Python PySide6 비교
 @Slot(str)
 def on_status_changed(self, status):
 """상태 변경 슬롯"""
 self.status_label.setText(f"Status: {status}")
---
## C# WPF vs Python PySide6 비교
 # 상태에 따른 버튼 활성화/비활성화
 if status == "Running":
 self.start_button.setEnabled(False)
 self.stop_button.setEnabled(True)
 else:
 self.start_button.setEnabled(True)
 self.stop_button.setEnabled(False)

 @Slot(str, int)
 def on_error_occurred(self, message, error_code):
 """에러 발생 슬롯"""
 self.error_label.setText(f"ERROR {error_code}: {message}")

 # 3초 후 에러 메시지 지우기
 QTimer.singleShot(3000, lambda: self.error_label.setText(""))

 def start_process(self):
 """프로세스 시작"""
 self.controller.set_status("Running")

 # 시뮬레이션을 위한 타이머 설정
 self.simulation_timer = QTimer()
 self.simulation_timer.timeout.connect(self.simulate_data)
 self.simulation_timer.start(1000) # 1초마다 실행

---
## C# WPF vs Python PySide6 비교
 def stop_process(self):
 """프로세스 정지"""
 if hasattr(self, 'simulation_timer'):
 self.simulation_timer.stop()
 self.controller.set_status("Idle")
---
## C# WPF vs Python PySide6 비교
 def simulate_data(self):
 """데이터 시뮬레이션"""
 import random

 # 랜덤 온도/압력 생성
 temp = random.uniform(20, 250)
 pressure = random.uniform(0.1, 5.0)

 self.controller.update_temperature(temp)
 self.controller.update_pressure(pressure)

# 사용 예시
if __name__ == "__main__":
 import sys
 from PySide6.QtWidgets import QApplication

 app = QApplication(sys.argv)

 # 컨트롤러와 디스플레이 생성
 controller = EquipmentController()
 display = EquipmentDisplay(controller)

 display.show()
 sys.exit(app.exec())
```

#### 코드 해설

**핵심 라인 설명:**
- `temperatureChanged = Signal(float)`: 클래스 레벨에서 시그널 정의. float 타입 매개변수
- `self.temperatureChanged.emit(temp)`: 시그널 발송. 연결된 모든 슬롯 호출
- `controller.temperatureChanged.connect(self.on_temperature_changed)`: 시그널-슬롯 연결
- `@Slot(float)`: 슬롯 데코레이터. 타입 명시로 성능 최적화
- `QTimer.singleShot(3000, lambda: ...)`: 3초 후 1회 실행되는 타이머

---
## C# WPF vs Python PySide6 비교
#### 실제 사례: ASML 노광 장비 실시간 모니터링

**ASML EUV Scanner**: 노광 공정 중 렌즈 온도, 웨이퍼 스테이지 위치, 레이저 출력 등 수십 개 센서가 밀리초 단위로 데이터를 생성합니다. 각 센서마다 개별 시그널을 정의하고, UI 위젯들이 필요한 시그널만 선택적으로 구독합니다. 온도가 임계값 초과 시 `errorOccurred` 시그널이 발송되어 알람 시스템, 로깅 시스템, UI가 동시에 반응합니다.

**데이터 범위**: 온도 20-80°C, 압력 0.1-10 Torr, 응답 시간 <100ms

#### HCI 연결: 피드백의 즉시성 (Hick's Law)

시그널-슬롯은 사용자 행동(버튼 클릭)과 시스템 응답(UI 업데이트) 사이의 지연을 최소화합니다. Week 1에서 배운 **Hick's Law**에 따르면, 선택지가 많을수록 반응 시간이 증가하지만, 시그널-슬롯은 이벤트를 병렬로 처리하여 복잡도를 숨깁니다. 사용자는 단순히 버튼을 누르고, 내부적으로는 여러 시스템이 동시에 반응합니다.

```mermaid
sequenceDiagram
    participant User
    participant Button
    participant Controller
    participant Display
    participant Logger

    User->>Button: Click "Start"
    Button->>Controller: start_process()
    Controller->>Controller: set_status("Running")
    Controller->>Display: statusChanged.emit("Running")
    Controller->>Logger: statusChanged.emit("Running")
    Controller->>Controller: update_temperature(150)
    Controller->>Display: temperatureChanged.emit(150)
    Display->>Display: on_temperature_changed(150)
    Display->>User: Update UI Label
    Note over Controller,Display: 느슨한 결합<br/>Controller는 Display를 직접 참조하지 않음
```
---
## C# WPF vs Python PySide6 비교
</div>

## Python 생태계와 데이터 처리

### 반도체 HMI에 유용한 Python 라이브러리

<div class="code-section">

**핵심 라이브러리 및 활용**

---
## C# WPF vs Python PySide6 비교
```python
# 1. NumPy - 수치 계산 및 배열 처리
import numpy as np

class SensorDataProcessor:
 """센서 데이터 처리 클래스"""

 def __init__(self):
 self.temperature_history = np.array([])
 self.pressure_history = np.array([])

 def add_temperature_data(self, temp_data):
 """온도 데이터 추가"""
 self.temperature_history = np.append(self.temperature_history, temp_data)

 # 최근 100개 데이터만 유지
 if len(self.temperature_history) > 100:
 self.temperature_history = self.temperature_history[-100:]

 def calculate_statistics(self):
 """통계 계산"""
 if len(self.temperature_history) == 0:
 return None

 return {
 'mean': np.mean(self.temperature_history),
 'std': np.std(self.temperature_history),
 'min': np.min(self.temperature_history),
 'max': np.max(self.temperature_history),
 'trend': self.calculate_trend()
 }

---
## C# WPF vs Python PySide6 비교
 def calculate_trend(self):
 """트렌드 계산 (선형 회귀)"""
 if len(self.temperature_history) < 2:
 return 0

 x = np.arange(len(self.temperature_history))
 y = self.temperature_history

 # 최소제곱법으로 기울기 계산
 slope, _ = np.polyfit(x, y, 1)
 return slope

# 2. Pandas - 데이터 프레임 및 시계열 처리
import pandas as pd
from datetime import datetime, timedelta

class EquipmentDataLogger:
 """장비 데이터 로깅"""

 def __init__(self):
 self.data = pd.DataFrame(columns=[
 'timestamp', 'equipment_id', 'temperature',
 'pressure', 'gas_flow', 'status'
 ])

---
## C# WPF vs Python PySide6 비교
 def log_data(self, equipment_id, temperature, pressure, gas_flow, status):
 """데이터 로깅"""
 new_row = {
 'timestamp': datetime.now(),
 'equipment_id': equipment_id,
 'temperature': temperature,
 'pressure': pressure,
 'gas_flow': gas_flow,
 'status': status
 }
---
## C# WPF vs Python PySide6 비교
 # DataFrame에 새 행 추가 (pandas 2.0+ 방식)
 self.data = pd.concat([self.data, pd.DataFrame([new_row])],
 ignore_index=True)

 def get_recent_data(self, equipment_id, hours=1):
 """최근 데이터 조회"""
 cutoff_time = datetime.now() - timedelta(hours=hours)

 mask = (self.data['equipment_id'] == equipment_id) & \
 (self.data['timestamp'] >= cutoff_time)

 return self.data[mask].copy()

 def export_to_csv(self, filename):
 """CSV로 내보내기"""
 self.data.to_csv(filename, index=False)

 def get_hourly_summary(self, equipment_id):
 """시간별 요약 통계"""
 equipment_data = self.data[self.data['equipment_id'] == equipment_id].copy()

 if equipment_data.empty:
 return pd.DataFrame()

---
## C# WPF vs Python PySide6 비교
 # 시간별 그룹핑
 equipment_data.set_index('timestamp', inplace=True)
 hourly_stats = equipment_data.resample('H').agg({
 'temperature': ['mean', 'min', 'max', 'std'],
 'pressure': ['mean', 'min', 'max', 'std'],
 'gas_flow': ['mean', 'min', 'max', 'std']
 })
---
## C# WPF vs Python PySide6 비교
 return hourly_stats

# 3. Matplotlib - 데이터 시각화
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

class RealTimeChart(FigureCanvas):
 """실시간 차트 위젯"""

 def __init__(self, parent=None):
 self.figure = Figure(figsize=(10, 6))
 super().__init__(self.figure)
 self.setParent(parent)

 # 서브플롯 생성
 self.ax1 = self.figure.add_subplot(2, 1, 1)
 self.ax2 = self.figure.add_subplot(2, 1, 2)

 # 데이터 저장용 리스트
 self.time_data = []
 self.temp_data = []
 self.pressure_data = []

---
## C# WPF vs Python PySide6 비교
 # 라인 객체 생성
 self.temp_line, = self.ax1.plot([], [], 'r-', label='Temperature')
 self.pressure_line, = self.ax2.plot([], [], 'b-', label='Pressure')

 # 축 설정
 self.ax1.set_ylabel('Temperature (°C)')
 self.ax1.legend()
 self.ax1.grid(True)
---
## C# WPF vs Python PySide6 비교
 self.ax2.set_ylabel('Pressure (Torr)')
 self.ax2.set_xlabel('Time')
 self.ax2.legend()
 self.ax2.grid(True)

 # 타이트한 레이아웃
 self.figure.tight_layout()

 def update_data(self, timestamp, temperature, pressure):
 """데이터 업데이트"""
 self.time_data.append(timestamp)
 self.temp_data.append(temperature)
 self.pressure_data.append(pressure)

 # 최근 50개 데이터만 유지
 if len(self.time_data) > 50:
 self.time_data = self.time_data[-50:]
 self.temp_data = self.temp_data[-50:]
 self.pressure_data = self.pressure_data[-50:]

 # 차트 업데이트
 self.update_chart()

---
## C# WPF vs Python PySide6 비교
 def update_chart(self):
 """차트 업데이트"""
 if not self.time_data:
 return

 # 데이터 설정
 self.temp_line.set_data(self.time_data, self.temp_data)
 self.pressure_line.set_data(self.time_data, self.pressure_data)
---
## C# WPF vs Python PySide6 비교
 # 축 범위 자동 조정
 self.ax1.relim()
 self.ax1.autoscale_view()
 self.ax2.relim()
 self.ax2.autoscale_view()

 # 그래프 다시 그리기
 self.draw()

# 4. PySerial - 시리얼 통신 (장비 연동)
import serial
import serial.tools.list_ports
from PySide6.QtCore import QThread, Signal

class SerialCommunication(QThread):
 """시리얼 통신 스레드"""

 dataReceived = Signal(str)
 errorOccurred = Signal(str)

 def __init__(self, port, baudrate=9600):
 super().__init__()
 self.port = port
 self.baudrate = baudrate
 self.serial_connection = None
 self.running = False

---
## C# WPF vs Python PySide6 비교
 def run(self):
 """스레드 실행"""
 try:
 self.serial_connection = serial.Serial(
 port=self.port,
 baudrate=self.baudrate,
 timeout=1
 )
 self.running = True
---
## C# WPF vs Python PySide6 비교
 while self.running:
 if self.serial_connection.in_waiting > 0:
 data = self.serial_connection.readline().decode('utf-8').strip()
 self.dataReceived.emit(data)

 self.msleep(100) # 100ms 대기

 except serial.SerialException as e:
 self.errorOccurred.emit(f"Serial error: {str(e)}")
 except Exception as e:
 self.errorOccurred.emit(f"Unexpected error: {str(e)}")
 finally:
 if self.serial_connection and self.serial_connection.is_open:
 self.serial_connection.close()

 def stop(self):
 """통신 중지"""
 self.running = False
 self.wait()

---
## C# WPF vs Python PySide6 비교
 def send_command(self, command):
 """명령 전송"""
 if self.serial_connection and self.serial_connection.is_open:
 self.serial_connection.write(f"{command}\n".encode('utf-8'))
---
## C# WPF vs Python PySide6 비교
 @staticmethod
 def get_available_ports():
 """사용 가능한 포트 목록"""
 ports = serial.tools.list_ports.comports()
 return [port.device for port in ports]
```