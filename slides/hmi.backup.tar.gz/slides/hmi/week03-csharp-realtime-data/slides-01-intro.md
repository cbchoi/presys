# Week 3: C# 실시간 데이터 처리 및 멀티스레딩

## 학습 목표

1. **Background Thread**: System.Threading.Timer를 사용하여 100ms 주기로 센서 데이터를 수집하고, UI Thread와 분리하여 성능 저하를 방지하는 방법을 학습합니다.
2. **Thread-safe 데이터 구조**: ConcurrentQueue를 활용하여 멀티스레드 환경에서 안전하게 데이터를 공유하는 기술을 습득합니다.
3. **Dispatcher 동기화**: Background Thread에서 수집한 데이터를 Dispatcher를 통해 UI Thread로 전달하여 ObservableCollection을 업데이트하는 방법을 학습합니다.

---

## 이번 주 주요 내용

### 배경
반도체 장비는 100ms 이하의 주기로 수백 개의 센서 데이터(온도, 압력, 가스 유량, RF 파워 등)를 수집합니다. UI Thread에서 직접 처리하면 화면이 멈추거나 버벅이는 현상이 발생하므로, Background Thread를 활용한 비동기 처리가 필수입니다.

### 핵심 개념
- **System.Threading.Timer**: 100ms 주기로 센서 데이터 수집 (Callback 방식)
- **ConcurrentQueue**: 멀티스레드 환경에서 Lock 없이 안전한 데이터 큐
- **Dispatcher.Invoke**: Background Thread → UI Thread 마샬링 (<10ms 목표)
- **Task.Run**: 비동기 작업 실행 (CPU 바운드 작업용)

### 실습 내용
- Timer 콜백에서 센서 데이터 생성 (100ms 주기)
- ConcurrentQueue에 데이터 저장 (Thread-safe 보장)
- Dispatcher로 UI Thread에 데이터 전달 (<5ms 지연)
- ObservableCollection 업데이트 및 UI 렌더링 (60 FPS 유지)

---

## Week 2 복습

**Week 2 핵심 내용**:
- MVVM 패턴: View ↔ ViewModel ↔ Model 분리
- INotifyPropertyChanged: 속성 변경 시 UI 자동 업데이트
- ObservableCollection: 리스트 데이터 자동 갱신
- RelayCommand: 버튼 클릭 명령 처리

**Week 3 연결점**:
- Week 2는 **단일 스레드**에서 UI 업데이트 (동기 방식)
- Week 3는 **멀티 스레드**로 확장 (비동기 방식)
- Background Thread에서 데이터 수집 → Dispatcher로 UI Thread 전달

---

## Week 1 HCI 이론 연결

- **Miller's Law (7±2 항목)**: UI에 표시할 센서 데이터를 7개로 제한 (온도, 압력, 가스, RF파워, 공정시간, 웨이퍼수, 알람수). 나머지는 상세 뷰로 분리하여 인지부하 감소 30% 달성.
- **정보처리 모델 (250ms 반응시간)**: 센서 데이터 수집(100ms) → Dispatcher 마샬링(<5ms) → UI 렌더링(16ms) = 총 121ms로, 운영자 인지 시간 250ms 이내 달성. 응답성 40% 향상.
- **Fitts' Law**: 알람 발생 시 긴급 정지 버튼 강조 표시 (크기 2배 확대, 색상 빨간색), 클릭 시간 800ms → 500ms로 단축.

---
## Mermaid 다이어그램

```mermaid
sequenceDiagram
    participant User as 운영자
    participant UI as UI Thread
    participant Timer as System.Threading.Timer
    participant BG as Background Thread
    participant Queue as ConcurrentQueue
    participant Dispatcher as Dispatcher
    participant Data as 센서 데이터

    User->>UI: HMI 시작
    UI->>Timer: Timer 시작 (100ms 주기)

    loop 100ms 주기
        Timer->>BG: Callback 호출
        BG->>Data: 센서 데이터 수집
        Data-->>BG: 온도/압력/가스 데이터
        BG->>Queue: Enqueue (Thread-safe)
        BG->>Dispatcher: Invoke (UI Thread 전환)
        Dispatcher->>UI: ObservableCollection 업데이트
        UI->>User: 화면 갱신 (60 FPS)
    end

---
## Mermaid 다이어그램
    style BG fill:#fff3e0,stroke:#ef6c00,stroke-width:2px
    style Dispatcher fill:#e1f5fe,stroke:#0277bd,stroke-width:2px
    style Queue fill:#c8e6c9,stroke:#2e7d32,stroke-width:2px
```
---
## 실습 과제

### 과제 1: System.Threading.Timer 구현 (20분)
**목표**: 100ms 주기로 센서 데이터 수집

```csharp
public class SensorDataService
{
    private System.Threading.Timer _timer;
    private Random _random = new Random();

    public void Start()
    {
        _timer = new System.Threading.Timer(OnTimerCallback, null, 0, 100); // 100ms 주기
    }

    private void OnTimerCallback(object state)
    {
        var sensorData = new SensorData
        {
            Temperature = 200 + _random.NextDouble() * 250, // 200-450°C
            Pressure = 1 + _random.NextDouble() * 9,        // 1-10 Torr
            GasFlow = 100 + _random.NextDouble() * 400,     // 100-500 sccm
            Timestamp = DateTime.Now
        };

        // ConcurrentQueue에 저장 (다음 과제)
    }

---
## 실습 과제
    public void Stop()
    {
        _timer?.Dispose();
    }
}
```

**검증 기준**:
- Timer 콜백 100ms 주기 정확성 확인 (Stopwatch 측정)
- Background Thread에서 실행 확인 (Thread.CurrentThread.ManagedThreadId 출력)
- 센서 데이터 범위 검증 (온도 200-450°C, 압력 1-10 Torr)
---
## 실습 과제 (계속)

### 과제 2: ConcurrentQueue 구현 (30분)
**목표**: Thread-safe 큐로 데이터 저장 및 Dispatcher로 UI 업데이트

```csharp
using System.Collections.Concurrent;

public class SensorDataService
{
    private ConcurrentQueue<SensorData> _dataQueue = new();
    private System.Windows.Threading.Dispatcher _dispatcher;
    private ObservableCollection<SensorData> _sensorDataList;

    public SensorDataService(Dispatcher dispatcher, ObservableCollection<SensorData> sensorDataList)
    {
        _dispatcher = dispatcher;
        _sensorDataList = sensorDataList;
    }

    private void OnTimerCallback(object state)
    {
        var sensorData = new SensorData { /* ... */ };

        // 1. ConcurrentQueue에 저장 (Thread-safe)
        _dataQueue.Enqueue(sensorData);

        // 2. Dispatcher로 UI Thread 전환
        _dispatcher.InvokeAsync(() =>
        {
            if (_dataQueue.TryDequeue(out var data))
            {
                _sensorDataList.Add(data);

---
## 실습 과제 (계속)
                // 최대 1000개 유지 (메모리 제한)
                if (_sensorDataList.Count > 1000)
                    _sensorDataList.RemoveAt(0);
            }
        });
    }
}
```

**검증 기준**:
- ConcurrentQueue 사용 (Lock 불필요)
- Dispatcher.InvokeAsync 호출 (UI Thread 전환)
- ObservableCollection 업데이트 (UI 자동 갱신)
---
## 실습 과제 (계속)

### 과제 3: 성능 측정 및 최적화 (30분)
**목표**: Dispatcher 지연 시간, UI 렌더링 FPS, CPU 사용률 측정

```csharp
// 성능 측정 코드
private Stopwatch _dispatcherWatch = new Stopwatch();
private int _frameCount = 0;
private Stopwatch _fpsWatch = Stopwatch.StartNew();

private void OnTimerCallback(object state)
{
    var sensorData = new SensorData { /* ... */ };
    _dataQueue.Enqueue(sensorData);

    _dispatcherWatch.Restart();
    _dispatcher.InvokeAsync(() =>
    {
        _dispatcherWatch.Stop();
        Console.WriteLine($"Dispatcher Delay: {_dispatcherWatch.ElapsedMilliseconds} ms");

        if (_dataQueue.TryDequeue(out var data))
        {
            _sensorDataList.Add(data);

            // FPS 계산
            _frameCount++;
            if (_fpsWatch.ElapsedMilliseconds >= 1000)
            {
                double fps = _frameCount / (_fpsWatch.ElapsedMilliseconds / 1000.0);
                Console.WriteLine($"UI FPS: {fps:F1}");
                _frameCount = 0;
                _fpsWatch.Restart();
            }
        }
    });
}

---
## 실습 과제 (계속)
// CPU 사용률 측정 (PerformanceCounter)
var cpuCounter = new PerformanceCounter("Processor", "% Processor Time", "_Total");
Console.WriteLine($"CPU Usage: {cpuCounter.NextValue()}%");
```

**검증 기준**:
- Dispatcher 지연 시간 <5ms
- UI FPS 60 유지
- CPU 사용률 <5% (Background Thread 실행 중)
---

## 성능 벤치마크

### 실시간 데이터 처리 목표
- **데이터 수집 주기**: 100ms (정확도 ±2ms 이내)
- **Dispatcher 지연**: <5ms (Background → UI Thread 전환)
- **UI 렌더링**: 60 FPS (16.67ms per frame)
- **메모리 사용량**: <100MB (1000개 센서 데이터 유지)
- **CPU 사용률**: <1% (유휴), <5% (데이터 수집 중)

### 병목 지점 및 최적화
1. **ConcurrentQueue 오버헤드**: Enqueue/Dequeue 비용 <1μs (무시 가능)
2. **Dispatcher.InvokeAsync**: 평균 3-5ms (목표 달성)
3. **ObservableCollection.Add**: VirtualizingStackPanel 사용 시 <1ms
4. **UI 렌더링**: WPF 가상화로 보이는 항목만 렌더링 (성능 80% 향상)

---

## 추가 학습 내용

### 반도체 HMI 실시간 요구사항
- **데이터 수집**: PLC/센서에서 TCP/IP, OPC UA, Modbus로 100ms 주기 수신
- **데이터 처리**: 이상치 필터링, 이동평균 계산, 알람 판정
- **데이터 저장**: TimescaleDB, InfluxDB 시계열 DB에 1초 단위 저장
- **데이터 표시**: WPF Chart 실시간 그래프 (10초 윈도우, 60 FPS)
- **장기 운영**: 24/7 연속 실행 시 메모리 누수 방지 (WeakReference, Dispose 패턴)

---

## 학습 로드맵

<div style="display: flex; flex-direction: column; gap: 1rem; margin: 1.5rem 0;">
<div style="display: flex; align-items: center; background: #e8f5e8; padding: 1rem; border-radius: 8px;">
<div style="background: #28a745; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">1</div>
<span style="color: #155724;"><strong>이론 학습</strong>: System.Threading.Timer, ConcurrentQueue, Dispatcher 개념 이해</span>
</div>

<div style="display: flex; align-items: center; background: #e3f2fd; padding: 1rem; border-radius: 8px;">
<div style="background: #2196f3; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">2</div>
<span style="color: #0d47a1;"><strong>실습 1</strong>: Timer 콜백에서 센서 데이터 생성 (100ms 주기)</span>
</div>

<div style="display: flex; align-items: center; background: #f3e5f5; padding: 1rem; border-radius: 8px;">
<div style="background: #9c27b0; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">3</div>
<span style="color: #4a148c;"><strong>실습 2</strong>: ConcurrentQueue + Dispatcher로 UI 업데이트</span>
</div>

<div style="display: flex; align-items: center; background: #fff3cd; padding: 1rem; border-radius: 8px;">
<div style="background: #f39c12; color: white; border-radius: 50%; width: 30px; height: 30px; display: flex; align-items: center; justify-content: center; margin-right: 1rem; font-weight: bold;">4</div>
<span style="color: #856404;"><strong>실습 3</strong>: 성능 측정 (Dispatcher 지연, FPS, CPU 사용률)</span>
</div>
</div>

---

## 다음 주 예고: Week 4 - C# 고급 UI/UX 패턴

Week 3에서 구현한 실시간 데이터 처리에 고급 UI/UX 패턴을 추가합니다.

- **Strategy Pattern**: 차트 종류 동적 변경 (Bar/Line/Heatmap)
- **Decorator Pattern**: UI 컴포넌트 기능 확장 (Alarm Border, Blinking Effect)
- **Custom Control**: CircularGauge, LinearGauge 커스텀 컨트롤 개발
- **실습**: ETCH Chamber 온도/압력/가스를 3가지 차트로 시각화, 60 FPS 유지
