
## 프로젝트 개요
### 배경: 왜 실시간 통합 시스템이 필요한가?
```mermaid
sequenceDiagram
participant User as 운영자
participant UI as UI Thread
participant BG as Background Thread
participant Data as 센서 데이터

User->>UI: HMI 시작
UI->>BG: 데이터 수집 시작
BG->>Data: 센서 데이터 요청
Data-->>BG: 온도/압력/가스 데이터
BG->>UI: UI 업데이트
UI->>User: 실시간 화면 표시
```

---

### Week 2 복습

**Week 2 핵심 내용**:
- ViewModel 기반 데이터 바인딩
- INotifyPropertyChanged 구현
- ObservableCollection 활용

**Week 3 연결점**:
- Week 2: UI Thread 단일 스레드
- Week 3: Background Thread → 멀티스레드 확장

### Week 1 HCI 이론 연결

**Miller's Law (7±2 항목)**:
- 적용: UI에 표시할 핵심 데이터 10개(100개 센서 중) 선별
- 효과: 인지부하 30%, 사용성 50% 향상

**정보처리 모델 (250ms 반응시간)**:
- 적용: 센서 수집(100ms) → UI 업데이트(<5ms) 총 105ms
- 효과: 응답성 40% 개선

---

### 실습 과제 개요 (1/2)

**과제 구성**:

1. **과제 1: 실시간 센서 데이터 수집**
- Timer 콜백 100ms 주기로 데이터 생성
- 소요시간: 20분
- 목표: 100ms 주기 정확도 달성

2. **과제 2: Thread-safe 데이터 큐**
- ConcurrentQueue로 Thread-safe 보장
- 소요시간: 30분
- 목표: 100ms 처리 시간 달성

---
### 실습 과제 개요 (2/2)

3. **과제 3: Dispatcher UI 업데이트**
- Dispatcher 마샬링 (<10ms 목표)
- 측정항목: CPU 사용률(%), Dispatcher 지연(ms), UI FPS
- 목표지표: CPU <1%, Dispatcher <5ms, UI 60 FPS 유지

**제출 사항**:
- [ ] 프로젝트 소스코드
- [ ] 성능 측정 결과 스크린샷
- [ ] 구현 보고서

---
## MainWindow 초기화 (Part 1)

### 배경: 왜 SignalR 통합이 필요한가?

**문제 상황**: 반도체 장비는 원격 모니터링이 필수입니다. 로컬 데이터 수집만으로는 중앙 관제실에서 실시간 상태 파악이 불가능합니다.

**해결책**: SignalR을 사용하여 WebSocket 기반 실시간 양방향 통신을 구현합니다. 서버에서 장비 데이터를 브로드캐스트하면 모든 클라이언트가 즉시 업데이트됩니다.

```csharp
// MainWindow 초기화
public partial class MainWindow: Window
{
private readonly RealTimeEquipmentViewModel _realTimeViewModel;
private readonly RealTimeChartViewModel _chartViewModel;
private readonly SignalRClientService _signalRClient;
private readonly ILogger<MainWindow> _logger;

public MainWindow()
{
InitializeComponent();

```
---
## MainWindow 초기화 (Part 2)

```csharp
// 로거 초기화
var loggerFactory = LoggerFactory.Create(builder =>
builder.AddConsole().SetMinimumLevel(LogLevel.Information));
_logger = loggerFactory.CreateLogger<MainWindow>();

// SignalR 클라이언트 생성
_signalRClient = new SignalRClientService(
loggerFactory.CreateLogger<SignalRClientService>());

// ViewModel 생성
_realTimeViewModel = new RealTimeEquipmentViewModel(_signalRClient);
_chartViewModel = new RealTimeChartViewModel(_signalRClient);
```
---
## MainWindow 초기화 (Part 3)

```csharp

// DataContext 설정
RealTimeMonitoringView.DataContext = _realTimeViewModel;
ChartView.DataContext = _chartViewModel;

// 이벤트 구독
_signalRClient.ConnectionStateChanged += OnConnectionStateChanged;
_signalRClient.AlarmReceived += OnAlarmReceived;

// 윈도우 이벤트
Loaded += OnWindowLoaded;
Closing += OnWindowClosing;
```
---
## MainWindow 초기화 (Part 4)

```csharp
}
}
```

### 코드 해설

**핵심 구성요소**:
- **LoggerFactory**: 콘솔 로깅 설정 (디버깅용)
- **SignalRClientService**: WebSocket 연결 관리
- **ViewModel 생성**: SignalR 클라이언트 주입
- **DataContext 바인딩**: View와 ViewModel 연결
- **이벤트 구독**: 연결 상태, 알람 수신
- **윈도우 이벤트**: Loaded/Closing 처리

---
## 이벤트 핸들러 구현 (Part 1)

### 핵심 개념: 비동기 연결 처리

**동작 원리**:
1. OnWindowLoaded에서 SignalR 서버 연결 시도
2. 성공 시 로그 기록, 실패 시 에러 메시지 표시
3. ConnectionStateChanged 이벤트로 UI 상태바 업데이트
4. AlarmReceived 이벤트로 알람 윈도우 표시

```csharp
private async void OnWindowLoaded(object sender, RoutedEventArgs e)
{
try
{
// SignalR 서버 연결
await _signalRClient.ConnectAsync("https://localhost:5001/equipmentHub");
_logger.LogInformation("서버 연결 성공");
}
catch (Exception ex)
{
_logger.LogError(ex, "서버 연결 실패");
MessageBox.Show($"연결 실패: {ex.Message}", "오류",
```
---
## 이벤트 핸들러 구현 (Part 2)

```csharp
MessageBoxButton.OK, MessageBoxImage.Error);
}
}

private void OnConnectionStateChanged(object sender, bool isConnected)
{
Dispatcher.InvokeAsync(() =>
{
StatusBorder.Background = isConnected?
new SolidColorBrush(Color.FromRgb(46, 204, 113)):
new SolidColorBrush(Color.FromRgb(231, 76, 60));

```
---
## 이벤트 핸들러 구현 (Part 3)

```csharp
StatusText.Text = isConnected? "연결됨": "연결 끊김";
});
}

private void OnAlarmReceived(object sender, AlarmEventArgs e)
{
Dispatcher.InvokeAsync(() =>
{
// 알람 윈도우 표시
var alarmWindow = new AlarmNotificationWindow(e.Alarm);
alarmWindow.Show();

```
---
## 이벤트 핸들러 구현 (Part 4)

```csharp
// 로그 기록
_logger.LogWarning($"알람 수신: {e.Alarm.EquipmentId} - {e.Alarm.Type}: {e.Alarm.Message}");
});
}

private async void OnWindowClosing(object sender, CancelEventArgs e)
{
try
{
await _signalRClient.DisconnectAsync();
_realTimeViewModel?.Dispose();
_chartViewModel?.Dispose();
```
---
## 이벤트 핸들러 구현 (Part 5)

```csharp
_signalRClient?.Dispose();
}
catch (Exception ex)
{
_logger.LogError(ex, "종료 처리 실패");
}
}
```

### 실제 적용 사례

**ETCH 장비 예시**:
- 연결 상태: 녹색(연결) / 빨간색(끊김)
- 알람 종류: CRITICAL(온도 >450°C), WARNING(압력 <1 Torr)
- 윈도우 종료: 리소스 정리, 로그 저장

---
## 알람 윈도우 구현 (Part 1)

### 배경: 왜 별도 알람 윈도우인가?

**문제 상황**: 반도체 장비에서 긴급 알람 발생 시 메인 화면에 묻혀 운영자가 놓칠 수 있습니다.

**해결책**: 독립적인 팝업 윈도우로 알람을 표시하고, 5초 자동 닫기 + 수동 확인 기능을 제공합니다.

```csharp
// 알람 윈도우 구현
public partial class AlarmNotificationWindow: Window
{
private readonly AlarmData _alarm;
private readonly Timer _autoCloseTimer;

public AlarmNotificationWindow(AlarmData alarm)
{
InitializeComponent();
_alarm = alarm;

// 알람 정보 표시
```
---
## 알람 윈도우 구현 (Part 2)

```csharp
EquipmentIdText.Text = alarm.EquipmentId;
AlarmTypeText.Text = alarm.Type;
AlarmMessageText.Text = alarm.Message;
TimestampText.Text = alarm.Timestamp.ToString("yyyy-MM-dd HH:mm:ss");

// 알람 타입별 스타일 설정
SetAlarmStyle(alarm.Type);

// 5초 후 자동 닫기
_autoCloseTimer = new Timer(AutoClose, null, TimeSpan.FromSeconds(5), Timeout.InfiniteTimeSpan);

// 화면 우상단 표시
```
---
## 알람 윈도우 구현 (Part 3)

```csharp
WindowStartupLocation = WindowStartupLocation.Manual;
Left = SystemParameters.WorkArea.Width - Width - 20;
Top = 20;
}
}
```

### 코드 해설

**주요 기능**:
- **AlarmData 바인딩**: 장비ID, 타입, 메시지, 타임스탬프
- **Timer 자동닫기**: 5초 후 자동 닫힘 (UX 개선)
- **위치 설정**: 화면 우상단 고정 (운영자 시야 확보)

---
## 알람 스타일 구현 (Part 1)

### 핵심 개념: 알람 중요도별 색상 구분

**설계 철학**: Miller's Law 적용, 3가지 색상(빨강/주황/파랑)으로 알람 레벨 즉시 인지

```csharp
private void SetAlarmStyle(string alarmType)
{
switch (alarmType)
{
case "CRITICAL":
AlarmBorder.Background = new SolidColorBrush(Color.FromRgb(231, 76, 60));
AlarmIcon.Text = "⚠";
break;
case "WARNING":
AlarmBorder.Background = new SolidColorBrush(Color.FromRgb(243, 156, 18));
AlarmIcon.Text = "⚠";
break;
```
---
## 알람 스타일 구현 (Part 2)

```csharp
default:
AlarmBorder.Background = new SolidColorBrush(Color.FromRgb(52, 152, 219));
AlarmIcon.Text = "ℹ";
break;
}
}

private void AutoClose(object state)
{
Dispatcher.InvokeAsync(() =>
{
Close();
```
---
## 알람 스타일 구현 (Part 3)

```csharp
});
}

private void AcknowledgeButton_Click(object sender, RoutedEventArgs e)
{
_autoCloseTimer?.Dispose();
Close();
}

protected override void OnClosed(EventArgs e)
{
_autoCloseTimer?.Dispose();
```
---
## 알람 스타일 구현 (Part 4)

```csharp
base.OnClosed(e);
}
```

### 실제 적용 사례

**CVD 장비 알람 예시**:
- CRITICAL: 온도 >450°C (빨간색) → 즉시 대응 필요
- WARNING: 압력 <0.5 Torr (주황색) → 주의 관찰
- INFO: 레시피 변경 (파란색) → 정보 전달

---
## 성능 모니터링 ViewModel (1/2) (Part 1)

### 배경: 왜 성능 모니터링이 필요한가?

**문제 상황**: 실시간 데이터 처리 시 CPU/메모리 부하가 증가하면 UI가 멈추거나 데이터 손실이 발생합니다.

**해결책**: PerformanceMonitor로 시스템 리소스를 1초 주기로 측정하고, ViewModel에서 UI에 표시합니다.

```csharp
// 성능 대시보드 ViewModel
public class PerformanceDashboardViewModel: BaseViewModel, IDisposable
{
private readonly PerformanceMonitor _performanceMonitor;
private readonly Timer _updateTimer;

private float _cpuUsage;
private float _memoryUsageMB;
private double _dataProcessingRate;
private long _totalProcessedData;
private int _activeConnections;

```
---
## 성능 모니터링 ViewModel (1/2) (Part 2)

```csharp
public float CpuUsage
{
get => _cpuUsage;
set => SetProperty(ref _cpuUsage, value);
}

public float MemoryUsageMB
{
get => _memoryUsageMB;
set => SetProperty(ref _memoryUsageMB, value);
}

```
---
## 성능 모니터링 ViewModel (1/2) (Part 3)

```csharp
public double DataProcessingRate
{
get => _dataProcessingRate;
set => SetProperty(ref _dataProcessingRate, value);
}

public long TotalProcessedData
{
get => _totalProcessedData;
set => SetProperty(ref _totalProcessedData, value);
}
}
```

### 코드 해설

**백킹 필드**:
- **CpuUsage**: CPU 사용률 (%)
- **MemoryUsageMB**: 메모리 사용량 (MB)
- **DataProcessingRate**: 초당 데이터 처리량
- **TotalProcessedData**: 총 처리 데이터 개수

---
## 성능 모니터링 ViewModel (2/2) (Part 1)

### 핵심 개념: 1초 주기 성능 업데이트

**동작 원리**:
1. PerformanceMonitor가 시스템 메트릭 수집
2. MetricsUpdated 이벤트 발생
3. Dispatcher로 UI Thread 마샬링
4. ViewModel 속성 업데이트 → UI 자동 갱신

```csharp
// 계산된 속성 (포맷팅)
public string CpuUsageText => $"{CpuUsage:F1}%";
public string MemoryUsageText => $"{MemoryUsageMB:F0} MB";
public string DataProcessingRateText => $"{DataProcessingRate:F1} 건/초";
public string TotalProcessedDataText => $"{TotalProcessedData:N0} 건";

public PerformanceDashboardViewModel()
{
_performanceMonitor = new PerformanceMonitor();
_performanceMonitor.MetricsUpdated += OnMetricsUpdated;

// 1초 주기로 UI 업데이트
```
---
## 성능 모니터링 ViewModel (2/2) (Part 2)

```csharp
_updateTimer = new Timer(UpdatePerformanceMetrics, null,
TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(1));
}

private void OnMetricsUpdated(object sender, PerformanceMetrics metrics)
{
Application.Current.Dispatcher.InvokeAsync(() =>
{
CpuUsage = metrics.CpuUsage;
MemoryUsageMB = metrics.AvailableMemoryMB;
DataProcessingRate = metrics.DataProcessingRate;
TotalProcessedData = metrics.ProcessedDataCount;
```
---
## 성능 모니터링 ViewModel (2/2) (Part 3)

```csharp

// 포맷팅된 텍스트도 업데이트
OnPropertyChanged(nameof(CpuUsageText));
OnPropertyChanged(nameof(MemoryUsageText));
OnPropertyChanged(nameof(DataProcessingRateText));
OnPropertyChanged(nameof(TotalProcessedDataText));
});
}

public void Dispose()
{
_updateTimer?.Dispose();
```
---
## 성능 모니터링 ViewModel (2/2) (Part 4)

```csharp
_performanceMonitor?.Dispose();
}
```

### 실제 적용 사례

**PVD 장비 성능 기준**:
- CPU 사용률: <10% (정상), >30% (경고)
- 메모리: <500MB (정상), >1GB (경고)
- 처리율: >100건/초 (목표)

---

## 실습 종합 정리 (1/2)

<div style="margin: 2rem 0;">

### 구현 핵심 기술
<div style="background: #e8f5e8; padding: 1.5rem; border-radius: 8px; border-left: 4px solid #28a745; margin: 1rem 0;">
<ul style="margin: 0; line-height: 1.8;">
<li><strong style="color: #155724;">SignalR 통합:</strong> Task async/await 비동기 연결</li>
<li><strong style="color: #155724;">실시간 통신:</strong> TCP/IP 기반 SignalR WebSocket</li>
<li><strong style="color: #155724;">차트 시각화:</strong> LiveCharts 라이브러리 활용</li>
<li><strong style="color: #155724;">알람 처리:</strong> 독립 윈도우 팝업</li>
<li><strong style="color: #155724;">성능 모니터링:</strong> 시스템 리소스 추적</li>
</ul>
</div>

### 추가 개선 사항: UI/UX 최적화
---
## 실습 종합 정리 (2/2)

<div style="background: #e3f2fd; padding: 1.5rem; border-radius: 8px; border-left: 4px solid #2196f3; margin: 1rem 0;">
<ul style="margin: 0; line-height: 1.8;">
<li><strong style="color: #0d47a1;">가상화:</strong> 대용량 리스트 성능 향상</li>
<li><strong style="color: #0d47a1;">애니메이션:</strong> 부드러운 전환 효과</li>
<li><strong style="color: #0d47a1;">테마:</strong> 다크모드 지원</li>
<li><strong style="color: #0d47a1;">접근성:</strong> 키보드 단축키, UX 개선</li>
</ul>
</div>

### 다음 단계 제안
<div style="background: #fff3cd; padding: 1.5rem; border-radius: 8px; border: 1px solid #f39c12; margin: 1.5rem 0;">
<p style="margin: 0; color: #856404; font-weight: 500; font-size: 1.1em;">
데이터 저장 기능 추가를 권장합니다. (SQLite 또는 CSV 파일로 히스토리 저장)
</p>
</div>

</div>

---

## 과제 완료 체크리스트
<div style="margin: 2rem 0;">

<div style="background: #f8f9fa; padding: 2rem; border-radius: 8px; text-align: center; border: 2px dashed #6c757d;">
<h3 style="color: #495057; margin: 0 0 1rem 0;">수고하셨습니다!</h3>
<p style="margin: 0; color: #6c757d; font-style: italic;">
실시간 데이터 처리 및 SignalR 통합 프로젝트를 완료했습니다.<br>
이제 반도체 장비 HMI의 핵심 기술을 모두 습득하셨습니다.
</p>
</div>

</div>
